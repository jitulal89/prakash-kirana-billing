const $=id=>document.getElementById(id);
const DEFAULT_PRODUCTS=[
{name:"Singdana",rate:180},{name:"Sabudana",rate:90},{name:"Sugar",rate:60},{name:"Rice",rate:55},{name:"Dal",rate:120},
{name:"Wheat",rate:45},{name:"Atta",rate:45},{name:"Maida",rate:45},{name:"Besan",rate:90},{name:"Rava",rate:60},{name:"Sooji",rate:60},{name:"Poha",rate:60},
{name:"Moong Dal",rate:120},{name:"Toor Dal",rate:150},{name:"Masoor Dal",rate:110},{name:"Urad Dal",rate:140},{name:"Chana Dal",rate:100},{name:"Rajma",rate:140},{name:"Chole",rate:110},
{name:"Kabuli Chana",rate:140},{name:"Moong",rate:120},{name:"Masoor",rate:110},{name:"Black Gram",rate:140},{name:"Tea",rate:300},{name:"Coffee",rate:500},{name:"Salt",rate:25},
{name:"Jaggery",rate:70},{name:"Turmeric",rate:220},{name:"Red Chilli Powder",rate:280},{name:"Coriander Powder",rate:180},{name:"Garam Masala",rate:350},{name:"Cumin",rate:300},
{name:"Mustard Seeds",rate:180},{name:"Fennel",rate:250},{name:"Black Pepper",rate:700},{name:"Cardamom",rate:1800},{name:"Cloves",rate:900},{name:"Cinnamon",rate:500},
{name:"Cooking Oil",rate:150},{name:"Sunflower Oil",rate:150},{name:"Groundnut Oil",rate:180},{name:"Mustard Oil",rate:170},{name:"Ghee",rate:650},{name:"Butter",rate:600},
{name:"Milk",rate:65},{name:"Curd",rate:80},{name:"Bread",rate:50},{name:"Biscuits",rate:100},{name:"Namkeen",rate:180},{name:"Chips",rate:200},{name:"Papad",rate:180},
{name:"Noodles",rate:120},{name:"Pasta",rate:160},{name:"Vermicelli",rate:100},{name:"Corn Flakes",rate:350},{name:"Oats",rate:180},{name:"Jam",rate:220},{name:"Peanut Butter",rate:350},
{name:"Honey",rate:450},{name:"Tomato Ketchup",rate:180},{name:"Pickle",rate:180},{name:"Coconut",rate:120},{name:"Dry Coconut",rate:250},{name:"Almonds",rate:900},{name:"Cashews",rate:1000},
{name:"Raisins",rate:350},{name:"Walnuts",rate:1000},{name:"Dates",rate:300},{name:"Mouth Freshener",rate:300},{name:"Chocolate",rate:500},{name:"Toffee",rate:400},
{name:"Colgate",rate:100},{name:"Toothpaste",rate:100},{name:"Toothbrush",rate:60},{name:"Soap",rate:50},{name:"Shampoo",rate:300},{name:"Hair Oil",rate:180},{name:"Face Wash",rate:180},
{name:"Body Lotion",rate:250},{name:"Detergent",rate:120},{name:"Washing Powder",rate:120},{name:"Dishwash",rate:120},{name:"Dishwash Bar",rate:30},{name:"Floor Cleaner",rate:180},
{name:"Toilet Cleaner",rate:180},{name:"Phenyl",rate:100},{name:"Handwash",rate:120},{name:"Sanitizer",rate:150},{name:"Tissue",rate:100},{name:"Toilet Paper",rate:100},
{name:"Garbage Bags",rate:100},{name:"Mosquito Coil",rate:80},{name:"Mosquito Repellent",rate:200},{name:"Matchbox",rate:2},{name:"Candles",rate:100},{name:"Battery",rate:20},
{name:"Notebook",rate:50},{name:"Pen",rate:10},{name:"Pencil",rate:5},{name:"Eraser",rate:5},{name:"Sharpener",rate:10}
];
const storedProducts=JSON.parse(localStorage.getItem("pksProducts")||"null");
const mergedProducts=storedProducts||[];
for(const p of DEFAULT_PRODUCTS){if(!mergedProducts.some(x=>String(x.name).toLowerCase()===p.name.toLowerCase()))mergedProducts.push({...p});}

const state={products:mergedProducts,bills:JSON.parse(localStorage.getItem("pksBills")||"[]"),customers:JSON.parse(localStorage.getItem("pksCustomers")||"[]")};
let editingProduct=-1, deferredInstall=null;

function save(){localStorage.setItem("pksProducts",JSON.stringify(state.products));localStorage.setItem("pksBills",JSON.stringify(state.bills));localStorage.setItem("pksCustomers",JSON.stringify(state.customers))}
function today(){let d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
$("billDate").value=today();
function money(n){return "₹"+Number(n||0).toFixed(2)}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]))}
function nextBillNo(){const y=new Date().getFullYear(),nums=state.bills.map(b=>Number((b.billNo||"").split("/").pop())).filter(Number.isFinite);const next=Math.max(94,...nums)+1;return `#PKS-${y}/${String(next).padStart(3,"0")}`}

function addItem(item={name:"",qty:"1",rate:0}){
 const row=document.createElement("div");row.className="item";
 row.innerHTML=`<label>Item<input class="iname" list="productNames" value="${esc(item.name)}" placeholder="Sugar"></label>
 <label>Qty<input class="iqty" type="text" inputmode="text" value="${esc(item.qty)}" placeholder="2, 250 gram, 1 kg"></label>
 <label>Rate/kg<input class="irate" type="number" min="0" step="0.01" value="${item.rate}"></label>
 <div><label>Amount</label><div class="amount">₹0.00</div></div>
 <button class="remove" type="button">×</button>`;
 items.appendChild(row);
 row.querySelectorAll("input").forEach(x=>x.addEventListener("input",()=>{autoRate(row);calc()}));
 row.querySelector(".remove").onclick=()=>{row.remove();calc()};
 calc();
}
function autoRate(row){const name=row.querySelector(".iname").value.trim(),rate=row.querySelector(".irate").value;if(!rate||Number(rate)===0){const p=findProduct(name);if(p)row.querySelector(".irate").value=p.rate}}

// Quantity is stored/displayed as text (VARCHAR-like). For calculation only,
// it is converted to kilograms because the rate field is Rate/kg.
function quantityValue(qtyText){
 const text=String(qtyText??"").trim().toLowerCase().replace(/,/g," ").replace(/\s+/g," ");
 if(!text)return 0;
 const m=text.match(/(?:^|\s)(\d+(?:\.\d+)?)\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams)?(?:\s|$)/i);
 if(!m)return 0;
 const n=Number(m[1]);
 const unit=(m[2]||"").toLowerCase();
 if(["mg","milligram","milligrams"].includes(unit))return n/1000000;
 if(["g","gm","gram","grams"].includes(unit))return n/1000;
 if(["kg","kgs","kilo","kilos","kilogram","kilograms"].includes(unit)||!unit)return n;
 return n;
}
function calc(){
 let total=0;
 [...items.children].forEach(r=>{const q=quantityValue(r.querySelector(".iqty").value),rate=Number(r.querySelector(".irate").value)||0,a=q*rate;total+=a;r.querySelector(".amount").textContent=money(a)});
 $("grandTotal").textContent=money(total);
}
function clearBill(){pendingVoiceText="";$("customer").value="";items.innerHTML="";addItem();$("billDate").value=today();$("voiceStatus").textContent="Ready";calc()}
addItem();

document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
function showPage(name){document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.page===name));document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));$(name+"Page").classList.add("active");if(name==="products")renderProducts();if(name==="history")renderHistory()}
$("addItemBtn").onclick=()=>addItem();$("clearBtn").onclick=()=>clearBill();$("newBillBtn")?.addEventListener("click",clearBill);

function normalizeVoiceText(text){return String(text||"").replace(/[₹,]/g," ").replace(/[;|]/g," ").replace(/\s+/g," ").trim()}
function cleanCommandText(text){return normalizeVoiceText(text).replace(/\b(?:please|pls|kindly)\b/gi," ").replace(/\s+/g," ").trim()}

// Common speech-recognition substitutions. These are deliberately conservative.
function normalizeSpokenNumbers(text){
 let s=text.toLowerCase();
 const replacements={"one":"1","two":"2","three":"3","four":"4","five":"5","six":"6","seven":"7","eight":"8","nine":"9","ten":"10","half":"0.5"};
 for(const [w,n] of Object.entries(replacements))s=s.replace(new RegExp(`\\b${w}\\b`,"gi"),n);
 return s;
}
function normalizeUnits(text){
 return text.toLowerCase()
   .replace(/\bkilograms?\b/g,"kg").replace(/\bkilos?\b/g,"kg").replace(/\bkgs?\b/g,"kg")
   .replace(/\bgrams?\b/g,"gram").replace(/\bgms?\b/g,"gram").replace(/\bmilligrams?\b/g,"mg");
}
function normalizeForParsing(text){return normalizeUnits(normalizeSpokenNumbers(cleanCommandText(text))).replace(/\s+/g," ").trim()}

function levenshtein(a,b){
 a=a.toLowerCase();b=b.toLowerCase();
 const dp=Array.from({length:a.length+1},()=>Array(b.length+1).fill(0));
 for(let i=0;i<=a.length;i++)dp[i][0]=i;
 for(let j=0;j<=b.length;j++)dp[0][j]=j;
 for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++)dp[i][j]=Math.min(dp[i-1][j]+1,dp[i][j-1]+1,dp[i-1][j-1]+(a[i-1]===b[j-1]?0:1));
 return dp[a.length][b.length];
}
function findProduct(spoken){
 const s=String(spoken||"").trim().toLowerCase();if(!s)return null;
 let exact=state.products.find(p=>p.name.toLowerCase()===s);if(exact)return exact;
 let best=null,bestScore=Infinity;
 for(const p of state.products){
   const n=p.name.toLowerCase();
   let d=levenshtein(s,n);
   if(s.includes(n)||n.includes(s))d=Math.min(d,1);
   const threshold=Math.max(2,Math.floor(Math.max(s.length,n.length)*0.4));
   if(d<=threshold&&d<bestScore){best=p;bestScore=d}
 }
 return best;
}

function addProductIfMissing(name,rate){
 const clean=String(name||"").trim();
 const r=Number(rate)||0;
 if(!clean||r<=0)return false;
 const existing=state.products.find(p=>p.name.toLowerCase()===clean.toLowerCase());
 if(existing){
   if((!Number(existing.rate)||Number(existing.rate)===0)&&r>0){existing.rate=r;save();}
   return false;
 }
 state.products.push({name:clean,rate:r});
 save();
 renderDatalist();renderCustomerDatalist();
 return true;
}

function extractQuantity(raw){
 const r=normalizeForParsing(raw);
 // quantity 2 kg / qty 250 gram / quantity 2 / quantity two kg
 let m=r.match(/\b(?:quantity|qty|quanity|quant|qnty)\s*[:=-]?\s*(\d+(?:\.\d+)?)\s*(kg|gram|g|mg)?\b/i);
 if(!m){m=r.match(/\b(?:quantity|qty|quanity|quant|qnty)\s*[:=-]?\s*(\d+(?:\.\d+)?)\s*(kg|gram|g|mg)?/i)}
 if(m)return {value:Number(m[1]),unit:m[2]||"",text:(m[1]+(m[2]?" "+m[2]:""))};
 // Also allow: Item Sugar 2 kg Rate 100
 m=r.match(/\b(?:item|add\s+item|new\s+item)\b\s+.*?\b(\d+(?:\.\d+)?)\s*(kg|gram|g|mg)\b/i);
 if(m)return {value:Number(m[1]),unit:m[2],text:(m[1]+" "+m[2])};
 return null;
}
function extractRate(raw){
 const r=normalizeForParsing(raw);
 const m=r.match(/\b(?:rate|price|cost|rs|rupees|rupay|rupaye|right)\s*[:=-]?\s*(?:₹\s*)?(\d+(?:\.\d+)?)\b/i);
 return m?Number(m[1]):null;
}
function extractItemName(raw,qty,rate){
 let s=normalizeForParsing(raw);
 // "Item" is optional. Accept "Colgate quantity 1 rate 100",
 // "Add Colgate quantity 1 rate 100", "Tem Colgate...", etc.
 s=s.replace(/^(?:add\s+)?(?:new\s+)?(?:item|tem)\b\s*/i,"");
 s=s.replace(/\b(?:quantity|qty|quanity|quant|qnty)\s*[:=-]?\s*\d+(?:\.\d+)?\s*(?:kg|gram|g|mg)?\b.*$/i,"");
 s=s.replace(/\b(?:rate|price|cost|rs|rupees|rupay|rupaye|right)\s*[:=-]?\s*\d+(?:\.\d+)?\b.*$/i,"");
 if(qty)s=s.replace(new RegExp(`\\s${qty.value}(?:\\s${qty.unit})?\\s*$`,"i"),"");
 return s.replace(/\s+/g," ").trim();
}

function parseVoice(text){
 const raw=normalizeForParsing(text);if(!raw)return null;
 if(/^(?:customer|grahak)\b/i.test(raw))return {type:"customerIgnored"};
 if(/^(?:add\s+item|new\s+item|item|tem)$/i.test(raw))return {type:"blank"};
 const qty=extractQuantity(raw);const rate=extractRate(raw);
 if(!qty||rate===null)return null;
 let name=extractItemName(raw,qty,rate);
 if(!name)return null;
 let product=findProduct(name);
 if(!product){
   const words=name.split(/\s+/).filter(Boolean);
   for(let i=0;i<words.length&&!product;i++){
     for(let j=words.length;j>i;j--){
       const candidate=findProduct(words.slice(i,j).join(" "));
       if(candidate){product=candidate;break;}
     }
   }
 }
 const finalName=product?product.name:name;
 const qtyText=qty.text;
 if(quantityValue(qtyText)<=0)return null;
 return {type:"item",name:finalName,qty:qtyText,rate,matched:!!product,spokenName:name};
}

let pendingVoiceText="";
function processVoiceSegment(text){
 const segment=cleanCommandText(text);if(!segment)return;
 if(/^customer\b/i.test(segment)||/^grahak\b/i.test(segment)){$("voiceStatus").textContent="Customer voice is disabled. Say an item command.";return}
 pendingVoiceText=(pendingVoiceText+" "+segment).trim();
 const parsed=parseVoice(pendingVoiceText);
 if(parsed?.type==="item"){
   addItem({name:parsed.name,qty:parsed.qty,rate:parsed.rate});
   if(!parsed.matched)addProductIfMissing(parsed.name,parsed.rate);
   calc();
   $("voiceStatus").textContent=`Added: ${parsed.name} | Qty ${parsed.qty} | Rate ₹${parsed.rate}/kg | Amount ${money(quantityValue(parsed.qty)*parsed.rate)}`;
   pendingVoiceText="";
   return;
 }
 if(parsed?.type==="blank"){
   addItem();calc();pendingVoiceText="";$("voiceStatus").textContent="New item row added.";return;
 }
 $("voiceStatus").textContent=`Heard: “${pendingVoiceText}” — waiting for item, quantity and rate.`;
 if(pendingVoiceText.length>180)pendingVoiceText=segment;
}

let rec=null,voiceActive=false,restartTimer=null;
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(SR){
 rec=new SR();rec.interimResults=false;rec.continuous=false;rec.maxAlternatives=5;
 rec.onstart=()=>{$("voiceBtn").classList.add("listening");$("voiceStatus").textContent="Listening… Say one complete item command."};
 rec.onresult=e=>{
   for(let i=e.resultIndex;i<e.results.length;i++)if(e.results[i].isFinal){
     const result=e.results[i];let best="",bestScore=-999;
     for(let j=0;j<result.length;j++){
       const t=(result[j].transcript||"").trim();if(!t)continue;
       const l=normalizeForParsing(t);let score=0;
       if(/\b(?:item|add|new)\b/.test(l))score+=4;
       if(/\b(?:quantity|qty|quanity|quant|qnty)\b/.test(l))score+=4;
       if(/\b(?:rate|price|cost|rs|rupees|rupay|rupaye|right)\b/.test(l))score+=4;
       if(/\d/.test(l))score+=3;
       for(const p of state.products){const pn=p.name.toLowerCase();if(l.includes(pn))score+=8;else if(findProduct(l.replace(/\b(?:item|add|new|quantity|qty|rate|price|cost|rs|rupees|rupay|rupaye|right)\b/gi," ").trim()))score+=2}
       if(score>bestScore){bestScore=score;best=t}
     }
     if(best)processVoiceSegment(best);
   }
 };
 rec.onerror=e=>{
   if(!voiceActive)return;
   if(e.error==='not-allowed'||e.error==='service-not-allowed'){voiceActive=false;$("voiceBtn").classList.remove("listening");$("voiceStatus").textContent="Allow microphone permission for the app.";return}
   $("voiceStatus").textContent="Listening…";
 };
 rec.onend=()=>{
   $("voiceBtn").classList.remove("listening");
   if(voiceActive){clearTimeout(restartTimer);restartTimer=setTimeout(()=>{if(!voiceActive)return;try{rec.lang=$("voiceLang").value;rec.start()}catch(e){}},400)}
   else $("voiceStatus").textContent=pendingVoiceText?`Voice stopped. Pending: ${pendingVoiceText}`:"Ready";
 };
}
$("voiceLang").onchange=()=>{if(rec)rec.lang=$("voiceLang").value};
$("voiceBtn").onclick=()=>{
 if(!rec){$("voiceStatus").textContent="Voice recognition is not supported here. Use Chrome on Android.";return}
 if(voiceActive){voiceActive=false;clearTimeout(restartTimer);try{rec.stop()}catch(e){}$("voiceBtn").classList.remove("listening");$("voiceStatus").textContent=pendingVoiceText?`Voice stopped. Pending: ${pendingVoiceText}`:"Voice stopped. Existing items are kept.";return}
 voiceActive=true;pendingVoiceText="";rec.lang=$("voiceLang").value;try{rec.start()}catch(e){}
};

$("generateBtn").onclick=()=>{
 const rows=[...items.children].map(r=>({name:r.querySelector(".iname").value.trim(),qty:r.querySelector(".iqty").value.trim(),rate:Number(r.querySelector(".irate").value)||0})).filter(x=>x.name&&quantityValue(x.qty)>0);
 if(!rows.length){alert("Add at least one item.");return}
 // Any manually entered item is automatically saved to Product Master.
 for(const row of rows)addProductIfMissing(row.name,row.rate);
 const bill={billNo:nextBillNo(),date:$("billDate").value,customer:$("customer").value.trim()||"Cash Sale",items:rows,total:rows.reduce((s,x)=>s+quantityValue(x.qty)*x.rate,0)};
 state.bills.unshift(bill);save();renderBill(bill);showPage("preview");$("previewPage").classList.add("active");
};
function normalizePhone(phone){
 let p=String(phone||"").replace(/\D/g,"");
 if(p.length===10)p="91"+p;
 if(p.startsWith("0091"))p=p.slice(2);
 return p;
}
function saveCustomer(name,phone){
 name=String(name||"").trim(); phone=normalizePhone(phone);
 if(!name||phone.length<12)return;
 const existing=state.customers.find(c=>normalizePhone(c.phone)===phone);
 if(existing){existing.name=name;existing.phone=phone}else state.customers.unshift({name,phone});
 state.customers=state.customers.slice(0,500);save();renderCustomerDatalist();
}
function findCustomer(name){return state.customers.find(c=>c.name.toLowerCase()===String(name||"").trim().toLowerCase())||null}
function renderCustomerDatalist(){
 let dl=document.getElementById("customerNames");if(!dl){dl=document.createElement("datalist");dl.id="customerNames";document.body.appendChild(dl)}
 dl.innerHTML="";state.customers.forEach(c=>{const o=document.createElement("option");o.value=c.name;o.label="+"+c.phone;dl.appendChild(o)});
}
function drawBillImage(b){
 const scale=2,w=900,pad=45,rowH=54,headH=70;
 const h=260+headH+b.items.length*rowH;
 const c=document.createElement("canvas");c.width=w*scale;c.height=h*scale;const x=c.getContext("2d");x.scale(scale,scale);
 x.fillStyle="#fff";x.fillRect(0,0,w,h);x.fillStyle="#24466f";x.textAlign="center";
 x.font="bold 34px sans-serif";x.fillText("PRAKASH KIRANA STORES",w/2,48);x.font="18px sans-serif";x.fillText("Dantoli, Nagpur",w/2,78);x.font="bold 22px sans-serif";x.fillText("CASH MEMO / BILL",w/2,112);
 x.textAlign="left";x.fillStyle="#111";x.font="18px sans-serif";x.fillText("Bill No: "+b.billNo,45,150);x.fillText("Date: "+b.date.split("-").reverse().join("/"),560,150);x.fillText("Customer: "+(b.customer||"Cash Sale"),45,180);x.fillText("Payment Mode: Cash",560,180);
 const top=210;const cols=[45,105,420,540,690,855];x.strokeStyle="#aaa";x.lineWidth=1;x.strokeRect(45,top,w-90,headH+b.items.length*rowH+70);
 x.fillStyle="#24466f";x.fillRect(46,top+1,w-92,headH-1);x.fillStyle="#fff";x.font="bold 16px sans-serif";["Sr.","Item Description","Qty","Rate/kg","Amount"].forEach((t,i)=>x.fillText(t,cols[i]+8,top+42));
 x.fillStyle="#111";x.font="16px sans-serif";b.items.forEach((it,i)=>{const y=top+headH+i*rowH+34;const amt=quantityValue(it.qty)*it.rate;x.fillText(String(i+1),cols[0]+8,y);x.fillText(it.name,cols[1]+8,y);x.fillText(it.qty,cols[2]+8,y);x.fillText(Number(it.rate).toFixed(2),cols[3]+8,y);x.fillText(amt.toFixed(2),cols[4]+8,y);x.strokeStyle="#ddd";x.beginPath();x.moveTo(46,y+20);x.lineTo(w-46,y+20);x.stroke()});
 const ty=top+headH+b.items.length*rowH+50;x.font="bold 22px sans-serif";x.fillText("Total Amount: "+money(b.total),45,ty);x.font="17px sans-serif";x.fillText("Thank you for shopping with us!",45,ty+38);x.font="14px sans-serif";x.fillText("Goods once sold will not be taken back.",45,ty+64);
 return c.toDataURL("image/png").split(",")[1];
}
function openWhatsAppModal(b){
 const saved=findCustomer(b.customer);$("waCustomerName").value=b.customer==="Cash Sale"?"":b.customer;$("waCustomerPhone").value=saved?String(saved.phone).replace(/^91/,""):"";
 renderCustomerDatalist();$("customerModal").classList.remove("hidden");
}
function renderBill(b){window.currentBill=b;const date=b.date.split("-").reverse().join("/");$("billPreview").innerHTML=`<h1>PRAKASH KIRANA STORES</h1><div class="location">Dantoli, Nagpur</div><div class="pill">CASH MEMO / BILL</div><hr><div class="meta"><div><b>Bill No:</b> ${esc(b.billNo)}</div><div><b>Date:</b> ${date}</div><div><b>Customer:</b> ${esc(b.customer)}</div><div><b>Payment Mode:</b> Cash</div></div><table><thead><tr><th>Sr.</th><th>Item Description</th><th>Qty</th><th>Rate/kg (₹)</th><th>Amount (₹)</th></tr></thead><tbody>${b.items.map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x.name)}</td><td>${esc(x.qty)}</td><td>${x.rate.toFixed(2)}</td><td>${(quantityValue(x.qty)*x.rate).toFixed(2)}</td></tr>`).join("")}</tbody><tfoot><tr><td colspan="4">Total Amount:</td><td>${money(b.total)}</td></tr></tfoot></table><div class="thanks">Thank you for shopping with us!</div><div class="muted">Goods once sold will not be taken back.</div><div class="sign">For Prakash Kirana Stores<br><span>(Authorized Signatory)</span></div>`}
$("printBtn").onclick=()=>window.print();
$("backToBilling").onclick=()=>showPage("billing");
$("whatsappBtn").onclick=()=>openWhatsAppModal(window.currentBill);
$("waCancel").onclick=()=>$("customerModal").classList.add("hidden");
$("waCustomerName").addEventListener("input",()=>{const c=findCustomer($("waCustomerName").value);if(c)$("waCustomerPhone").value=String(c.phone).replace(/^91/,"")});
$("waSend").onclick=()=>{
 const name=$("waCustomerName").value.trim(),phone=$("waCustomerPhone").value.trim();
 if(!name){alert("Enter customer name.");return} const np=normalizePhone(phone);if(np.length<12){alert("Enter a valid 10 digit WhatsApp number.");return}
 saveCustomer(name,np);window.currentBill.customer=name;save();renderBill(window.currentBill);$("customerModal").classList.add("hidden");
 const png=drawBillImage(window.currentBill);
 if(window.Android&&Android.shareBillImage){Android.shareBillImage(png,window.currentBill.billNo.replace(/[^a-z0-9]/gi,"_"),np)}else{
   const msg=`${window.currentBill.billNo} - Prakash Kirana Stores - Total ${money(window.currentBill.total)}`;
   window.open("https://wa.me/"+np+"?text="+encodeURIComponent(msg),"_blank");
 }
};
function renderProducts(){const list=$("productList");list.innerHTML="";state.products.forEach((p,i)=>{const r=document.createElement("div");r.className="product-row";r.innerHTML=`<div><div class="product-name">${esc(p.name)}</div><div class="muted">₹${p.rate.toFixed(2)} / kg</div></div><div><button class="secondary edit">Edit</button> <button class="danger del">Delete</button></div>`;r.querySelector(".edit").onclick=()=>openProduct(i);r.querySelector(".del").onclick=()=>{if(confirm("Delete this product?")){state.products.splice(i,1);save();renderProducts()}};list.appendChild(r)})}
$("addProductBtn").onclick=()=>openProduct(-1);function openProduct(i){editingProduct=i;$("modalTitle").textContent=i<0?"Add Product":"Edit Product";$("modalName").value=i<0?"":state.products[i].name;$("modalRate").value=i<0?"":state.products[i].rate;$("modal").classList.remove("hidden")}
$("modalCancel").onclick=()=>$("modal").classList.add("hidden");$("modalSave").onclick=()=>{const name=$("modalName").value.trim(),rate=+$("modalRate").value;if(!name||rate<0){alert("Enter a product and rate.");return}if(editingProduct<0)state.products.push({name,rate});else state.products[editingProduct]={name,rate};save();$("modal").classList.add("hidden");renderProducts();renderDatalist()};
function renderDatalist(){let dl=document.getElementById("productNames");if(dl)dl.remove();dl=document.createElement("datalist");dl.id="productNames";state.products.forEach(p=>{let o=document.createElement("option");o.value=p.name;dl.appendChild(o)});document.body.appendChild(dl)}
renderDatalist();renderCustomerDatalist();
function renderHistory(){const q=$("billSearch").value.toLowerCase(),list=$("historyList");list.innerHTML="";const bills=state.bills.filter(b=>JSON.stringify(b).toLowerCase().includes(q));if(!bills.length){list.innerHTML='<div class="muted">No bills found.</div>';return}bills.forEach(b=>{const r=document.createElement("div");r.className="history-row";r.innerHTML=`<div><div class="history-title">${esc(b.billNo)} • ${esc(b.customer)}</div><div class="muted">${b.date.split("-").reverse().join("/")} • ${b.items.length} item(s) • ${money(b.total)}</div></div><button class="secondary">View</button>`;r.querySelector("button").onclick=()=>{renderBill(b);showPage("preview")};list.appendChild(r)})}
$("billSearch").oninput=renderHistory;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;$("installBtn").classList.remove("hidden")});$("installBtn").onclick=async()=>{if(deferredInstall){deferredInstall.prompt();deferredInstall=null;$("installBtn").classList.add("hidden")}};
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
