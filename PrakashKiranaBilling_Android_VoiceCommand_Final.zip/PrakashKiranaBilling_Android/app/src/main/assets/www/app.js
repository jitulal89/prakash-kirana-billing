const $=id=>document.getElementById(id);
const state={products:JSON.parse(localStorage.getItem("pksProducts")||"null")||[
{name:"Singdana",rate:180},{name:"Sabudana",rate:90},{name:"Sugar",rate:60},{name:"Rice",rate:55},{name:"Dal",rate:120}
],bills:JSON.parse(localStorage.getItem("pksBills")||"[]")};
let editingProduct=-1, deferredInstall=null;

function save(){localStorage.setItem("pksProducts",JSON.stringify(state.products));localStorage.setItem("pksBills",JSON.stringify(state.bills))}
function today(){let d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
$("billDate").value=today();

function money(n){return "₹"+Number(n||0).toFixed(2)}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]))}
function nextBillNo(){
 const y=new Date().getFullYear(), nums=state.bills.map(b=>Number((b.billNo||"").split("/").pop())).filter(Number.isFinite);
 const next=Math.max(94,...nums)+1; return `#PKS-${y}/${String(next).padStart(3,"0")}`;
}
function addItem(item={name:"",qty:1,rate:0}){
 const row=document.createElement("div");row.className="item";
 row.innerHTML=`<label>Item<input class="iname" list="productNames" value="${esc(item.name)}" placeholder="Sugar"></label>
 <label>Qty<input class="iqty" type="number" min="0" step="0.01" value="${item.qty}"></label>
 <label>Rate<input class="irate" type="number" min="0" step="0.01" value="${item.rate}"></label>
 <div><label>Amount</label><div class="amount">₹0.00</div></div>
 <button class="remove" type="button">×</button>`;
 items.appendChild(row);
 row.querySelectorAll("input").forEach(x=>x.addEventListener("input",()=>{autoRate(row);calc()}));
 row.querySelector(".remove").onclick=()=>{row.remove();calc()};
}
function autoRate(row){
 const name=row.querySelector(".iname").value.trim().toLowerCase(), rate=row.querySelector(".irate").value;
 if(!rate||Number(rate)===0){const p=state.products.find(x=>x.name.toLowerCase()===name);if(p)row.querySelector(".irate").value=p.rate}
}
function calc(){
 let total=0;[...items.children].forEach(r=>{let q=+r.querySelector(".iqty").value||0,rate=+r.querySelector(".irate").value||0,a=q*rate;total+=a;r.querySelector(".amount").textContent=money(a)});$("grandTotal").textContent=money(total)
}
function clearBill(){ pendingVoiceText=""; $("customer").value="";items.innerHTML="";addItem();$("billDate").value=today();$("voiceStatus").textContent="Ready";calc() }
addItem();

document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
function showPage(name){
 document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.page===name));
 document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
 $(name+"Page").classList.add("active");
 if(name==="products")renderProducts();if(name==="history")renderHistory()
}
$("addItemBtn").onclick=()=>addItem();
$("clearBtn").onclick=()=>clearBill();
$("newBillBtn")?.addEventListener("click",clearBill);

function normalizeVoiceText(text){
  return String(text||"")
    .replace(/[₹,]/g," ")
    .replace(/\s+/g," ")
    .trim();
}

function cleanCommandText(text){
  return normalizeVoiceText(text)
    .replace(/\b(?:please|pls|kindly)\b/gi," ")
    .replace(/\s+/g," ")
    .trim();
}

// Voice commands are intentionally strict and simple:
//   Item Sugar quantity 2kg Rate 100
//   Add item Rice quantity 1kg Rate 80
// The parser also accepts small speech-recognition variations such as
// "qty", "quanity", "rate", "price", "at", and missing spaces in 2kg.
function parseVoice(text){
  const raw=cleanCommandText(text);
  if(!raw)return false;

  const lower=raw.toLowerCase();
  const hasItemCommand=/\b(?:item|add\s+item|new\s+item)\b/i.test(raw);
  const qtyMatch=raw.match(/\b(?:quantity|qty|quanity|quant|qnty)\s*[:=-]?\s*(\d+(?:\.\d+)?)\s*(?:kg|kgs|kilo|kilogram|kilograms|g|gram|grams|l|ltr|litre|liter|packet|packets|pack|pcs|piece|pieces)?\b/i);
  const rateMatch=raw.match(/\b(?:rate|price|cost|rs|rupees|rupay|rupaye)\s*[:=-]?\s*(?:₹\s*)?(\d+(?:\.\d+)?)\b/i);

  // Also support: Item Sugar 2kg Rate 100
  const shortQtyMatch=raw.match(/\b(?:item|add\s+item|new\s+item)\s+.+?\s+(\d+(?:\.\d+)?)\s*(?:kg|kgs|kilo|kilogram|kilograms)\b/i);

  if(hasItemCommand && (qtyMatch || shortQtyMatch) && rateMatch){
    let qty=qtyMatch ? Number(qtyMatch[1]) : Number(shortQtyMatch[1]);
    const rate=Number(rateMatch[1]);

    // Product name is everything after Item/Add Item and before Quantity/Qty,
    // or before the short quantity when the word quantity was omitted.
    let namePart=raw
      .replace(/^.*?\b(?:add\s+item|new\s+item|item)\b\s*/i,"")
      .replace(/\b(?:quantity|qty|quanity|quant|qnty)\s*[:=-]?\s*\d+(?:\.\d+)?\s*(?:kg|kgs|kilo|kilogram|kilograms|g|gram|grams|l|ltr|litre|liter|packet|packets|pack|pcs|piece|pieces)?\b.*$/i,"")
      .replace(/\b\d+(?:\.\d+)?\s*(?:kg|kgs|kilo|kilogram|kilograms)\b.*$/i,"")
      .replace(/\b(?:rate|price|cost|rs|rupees|rupay|rupaye)\s*[:=-]?\s*(?:₹\s*)?\d+(?:\.\d+)?\b.*$/i,"")
      .trim();

    // Remove any stray quantity/rate words left by speech recognition.
    namePart=namePart
      .replace(/\b(?:quantity|qty|quanity|quant|qnty|rate|price|cost)\b/ig,"")
      .replace(/\s+/g," ")
      .trim();

    if(namePart){
      // Match an existing product ignoring case; otherwise keep spoken name.
      const existing=state.products.find(p=>p.name.toLowerCase()===namePart.toLowerCase());
      const finalName=existing ? existing.name : namePart;

      addItem({name:finalName,qty:qty,rate:rate});
      calc();
      $('voiceStatus').textContent=`Added: ${finalName} | Qty ${qty} kg | Rate ₹${rate}`;
      return true;
    }
  }

  // "Add item" by itself creates a blank row, but does not replace anything.
  if(/^(?:add\s+item|new\s+item|item)$/i.test(raw)){
    addItem();
    calc();
    $('voiceStatus').textContent='New item row added. Say: “Item Sugar quantity 2kg Rate 100”.';
    return true;
  }

  return false;
}

let pendingVoiceText="";

function processVoiceSegment(text){
  const segment=cleanCommandText(text);
  if(!segment)return;

  // Ignore customer commands completely. Customer is intentionally not filled
  // by voice anymore.
  if(/^customer\b/i.test(segment) || /^grahak\b/i.test(segment)){
    $('voiceStatus').textContent='Customer voice entry is disabled. Say an item command.';
    return;
  }

  // Accumulate segments so a natural pause between "Item Sugar", "quantity 2kg"
  // and "Rate 100" does not lose the command.
  pendingVoiceText=(pendingVoiceText+" "+segment).trim();

  if(parseVoice(pendingVoiceText)){
    pendingVoiceText="";
    return;
  }

  // Keep the buffer while the command is incomplete. If it gets too long,
  // retain only the most recent useful part.
  if(pendingVoiceText.length>180){
    pendingVoiceText=segment;
  }

  $('voiceStatus').textContent='Heard: “'+pendingVoiceText+'” — waiting for quantity and rate.';
}


let rec=null;
let voiceActive=false;
let restartTimer=null;
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(SR){
  rec=new SR();

  // Android WebView/Chrome is much more reliable when each spoken segment
  // ends naturally and recognition is restarted automatically. This allows
  // the shopkeeper to pause between customer and items without losing data.
  rec.interimResults=false;
  rec.continuous=false;
  rec.maxAlternatives=3;

  rec.onstart=()=>{
    $('voiceBtn').classList.add('listening');
    $('voiceStatus').textContent='Listening… Speak a command, then pause if needed.';
  };

  rec.onresult=e=>{
    for(let i=e.resultIndex;i<e.results.length;i++){
      if(e.results[i].isFinal){
        const result=e.results[i];
        let best=result[0]?.transcript?.trim()||"";
        let bestScore=-1;

        // Prefer alternatives that contain our command keywords and numbers.
        // This helps when Android offers several speech-recognition guesses.
        for(let j=0;j<result.length;j++){
          const t=(result[j].transcript||"").trim();
          const l=t.toLowerCase();
          let score=0;
          if(/\b(?:item|add|new)\b/.test(l))score+=3;
          if(/\b(?:quantity|qty|quanity|quant|qnty)\b/.test(l))score+=3;
          if(/\b(?:rate|price|cost|rs|rupees|rupay|rupaye)\b/.test(l))score+=3;
          score+=(t.match(/\d+(?:\.\d+)?/g)||[]).length*2;
          for(const p of state.products){
            if(l.includes(p.name.toLowerCase()))score+=4;
          }
          if(score>bestScore){bestScore=score;best=t;}
        }

        if(best){
          $('voiceStatus').textContent='Heard: '+best;
          processVoiceSegment(best);
        }
      }
    }
  };

  rec.onerror=e=>{
    if(!voiceActive)return;

    if(e.error==='not-allowed'||e.error==='service-not-allowed'){
      voiceActive=false;
      $('voiceBtn').classList.remove('listening');
      $('voiceStatus').textContent='Microphone permission is required. Allow microphone access for the app.';
      return;
    }

    // no-speech/aborted/network can happen when the user pauses. Restart.
    $('voiceStatus').textContent='Listening…';
  };

  rec.onend=()=>{
    $('voiceBtn').classList.remove('listening');

    if(voiceActive){
      clearTimeout(restartTimer);
      restartTimer=setTimeout(()=>{
        if(!voiceActive)return;
        try{
          rec.lang=$('voiceLang').value;
          rec.start();
        }catch(e){
          // onend will fire again and retry.
        }
      },300);
    }else{
      $('voiceStatus').textContent='Ready';
    }
  };
}

$('voiceLang').onchange=()=>{
  if(rec)rec.lang=$('voiceLang').value;
};

$('voiceBtn').onclick=()=>{
  if(!rec){
    $('voiceStatus').textContent='Voice recognition is not supported here. Use Chrome on Android.';
    return;
  }

  if(voiceActive){
    voiceActive=false;
    clearTimeout(restartTimer);
    try{rec.stop()}catch(e){}
    $('voiceBtn').classList.remove('listening');
    $('voiceStatus').textContent=pendingVoiceText ? 'Voice stopped. Pending command kept: '+pendingVoiceText : 'Voice stopped. Existing items are kept.';
    return;
  }

  voiceActive=true;
  rec.lang=$('voiceLang').value;

  try{
    rec.start();
  }catch(e){
    // If recognition is already transitioning, onend will restart it.
  }
};

$("generateBtn").onclick=()=>{
 const rows=[...items.children].map(r=>({name:r.querySelector(".iname").value.trim(),qty:+r.querySelector(".iqty").value||0,rate:+r.querySelector(".irate").value||0})).filter(x=>x.name&&x.qty>0);
 if(!rows.length){alert("Add at least one item.");return}
 const bill={billNo:nextBillNo(),date:$("billDate").value,customer:$("customer").value.trim()||"Cash Sale",items:rows,total:rows.reduce((s,x)=>s+x.qty*x.rate,0)};
 state.bills.unshift(bill);save();renderBill(bill);showPage("preview");$("previewPage").classList.add("active");
};

function renderBill(b){
 const date=b.date.split("-").reverse().join("/");
 $("billPreview").innerHTML=`<h1>PRAKASH KIRANA STORES</h1><div class="location">Dantoli, Nagpur</div><div class="pill">CASH MEMO / BILL</div><hr>
 <div class="meta"><div><b>Bill No:</b> ${esc(b.billNo)}</div><div><b>Date:</b> ${date}</div><div><b>Customer:</b> ${esc(b.customer)}</div><div><b>Payment Mode:</b> Cash</div></div>
 <table><thead><tr><th>Sr.</th><th>Item Description</th><th>Qty</th><th>Rate/kg (₹)</th><th>Amount (₹)</th></tr></thead><tbody>
 ${b.items.map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x.name)}</td><td>${x.qty} kg</td><td>${x.rate.toFixed(2)}</td><td>${(x.qty*x.rate).toFixed(2)}</td></tr>`).join("")}
 </tbody><tfoot><tr><td colspan="4">Total Amount:</td><td>${money(b.total)}</td></tr></tfoot></table>
 <div class="thanks">Thank you for shopping with us!</div><div class="muted">Goods once sold will not be taken back.</div>
 <div class="sign">For Prakash Kirana Stores<br><span>(Authorized Signatory)</span></div>`;
}
$("printBtn").onclick=()=>window.print();
$("backToBilling").onclick=()=>showPage("billing");

function renderProducts(){
 const list=$("productList");list.innerHTML="";
 state.products.forEach((p,i)=>{const r=document.createElement("div");r.className="product-row";r.innerHTML=`<div><div class="product-name">${esc(p.name)}</div><div class="muted">₹${p.rate.toFixed(2)} / kg</div></div><div><button class="secondary edit">Edit</button> <button class="danger del">Delete</button></div>`;
 r.querySelector(".edit").onclick=()=>openProduct(i);r.querySelector(".del").onclick=()=>{if(confirm("Delete this product?")){state.products.splice(i,1);save();renderProducts()}};list.appendChild(r)});
}
$("addProductBtn").onclick=()=>openProduct(-1);
function openProduct(i){editingProduct=i;$("modalTitle").textContent=i<0?"Add Product":"Edit Product";$("modalName").value=i<0?"":state.products[i].name;$("modalRate").value=i<0?"":state.products[i].rate;$("modal").classList.remove("hidden")}
$("modalCancel").onclick=()=>$("modal").classList.add("hidden");
$("modalSave").onclick=()=>{const name=$("modalName").value.trim(),rate=+$("modalRate").value;if(!name||rate<0){alert("Enter a product and rate.");return}if(editingProduct<0)state.products.push({name,rate});else state.products[editingProduct]={name,rate};save();$("modal").classList.add("hidden");renderProducts()};
function renderDatalist(){let dl=document.getElementById("productNames");if(dl)dl.remove();dl=document.createElement("datalist");dl.id="productNames";state.products.forEach(p=>{let o=document.createElement("option");o.value=p.name;dl.appendChild(o)});document.body.appendChild(dl)}
renderDatalist();

function renderHistory(){
 const q=$("billSearch").value.toLowerCase(),list=$("historyList");list.innerHTML="";
 const bills=state.bills.filter(b=>JSON.stringify(b).toLowerCase().includes(q));
 if(!bills.length){list.innerHTML='<div class="muted">No bills found.</div>';return}
 bills.forEach(b=>{const r=document.createElement("div");r.className="history-row";r.innerHTML=`<div><div class="history-title">${esc(b.billNo)} • ${esc(b.customer)}</div><div class="muted">${b.date.split("-").reverse().join("/")} • ${b.items.length} item(s) • ${money(b.total)}</div></div><button class="secondary">View</button>`;r.querySelector("button").onclick=()=>{renderBill(b);showPage("preview")};list.appendChild(r)})
}
$("billSearch").oninput=renderHistory;

window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;$("installBtn").classList.remove("hidden")});
$("installBtn").onclick=async()=>{if(deferredInstall){deferredInstall.prompt();deferredInstall=null;$("installBtn").classList.add("hidden")}};

if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
