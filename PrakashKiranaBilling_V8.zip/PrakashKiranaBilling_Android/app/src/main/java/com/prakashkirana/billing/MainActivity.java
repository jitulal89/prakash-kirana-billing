package com.prakashkirana.billing;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1001);
        }

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private Uri saveShareFile(byte[] data, String filename) throws Exception {
        File dir = new File(getCacheDir(), "share");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create share folder");
        File file = new File(dir, filename);
        try (FileOutputStream out = new FileOutputStream(file)) { out.write(data); out.flush(); }
        return Uri.parse("content://com.prakashkirana.billing.share/" + Uri.encode(file.getName()));
    }

    private void shareImage(byte[] data, String billName, String phone) throws Exception {
        Uri uri = saveShareFile(data, billName + ".png");
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("image/png");
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_TEXT, "Prakash Kirana Stores - Bill " + billName);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        send.setClipData(ClipData.newRawUri("Prakash Kirana Bill", uri));
        // Explicit WhatsApp package keeps the image attachment in WhatsApp's share composer.
        send.setPackage("com.whatsapp");
        try { startActivity(send); }
        catch (Exception e) {
            send.setPackage(null);
            startActivity(Intent.createChooser(send, "Share bill image"));
        }
    }

    private void drawText(Canvas c, Paint p, String text, float x, float y) {
        c.drawText(text == null ? "" : text, x, y, p);
    }

    private Uri createPdf(String json) throws Exception {
        JSONObject b = new JSONObject(json);
        JSONArray items = b.optJSONArray("items");
        PdfDocument doc = new PdfDocument();
        int pageNo = 1, y = 0;
        PdfDocument.Page page = null;
        Canvas canvas = null;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        while (true) {
            PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, pageNo).create();
            page = doc.startPage(info); canvas = page.getCanvas();
            p.setColor(android.graphics.Color.rgb(36,70,111)); p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD)); p.setTextSize(24);
            drawText(canvas,p,"PRAKASH KIRANA STORES",170,45);
            p.setTypeface(Typeface.DEFAULT); p.setTextSize(13); drawText(canvas,p,"Dantoli, Nagpur",245,68);
            p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(17); drawText(canvas,p,"CASH MEMO / BILL",225,95);
            p.setColor(android.graphics.Color.BLACK); p.setTypeface(Typeface.DEFAULT); p.setTextSize(11);
            String date=b.optString("date",""); String customer=b.optString("customer","Cash Sale");
            drawText(canvas,p,"Bill No: " + b.optString("billNo",""),40,125); drawText(canvas,p,"Date: " + formatDate(date),400,125);
            drawText(canvas,p,"Customer: " + customer,40,145); drawText(canvas,p,"Payment Mode: Cash",400,145);
            p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(10);
            canvas.drawLine(40,165,555,165,p); drawText(canvas,p,"Sr.",45,182); drawText(canvas,p,"Item Description",75,182); drawText(canvas,p,"Qty",355,182); drawText(canvas,p,"Rate/Unit",405,182); drawText(canvas,p,"Amount",500,182); canvas.drawLine(40,190,555,190,p);
            p.setTypeface(Typeface.DEFAULT); p.setTextSize(10); y=210;
            boolean more=false;
            if(items!=null) {
                for(int i=0;i<items.length();i++) {
                    JSONObject it=items.getJSONObject(i);
                    if(y>755){more=true;break;}
                    String name=it.optString("name",""); String qty=it.optString("qty",""); String unit=it.optString("unit","kg"); double rate=it.optDouble("rate",0); double qval=quantityValue(qty,unit); double amount=qval*rate;
                    drawText(canvas,p,String.valueOf(i+1),45,y); drawText(canvas,p,name,75,y); drawText(canvas,p,qty,355,y); drawText(canvas,p,String.format(java.util.Locale.US,"%.2f",rate),405,y); drawText(canvas,p,String.format(java.util.Locale.US,"%.2f",amount),500,y); canvas.drawLine(40,y+8,555,y+8,p); y+=28;
                }
            }
            if(!more){
                p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(15); drawText(canvas,p,"Total Amount: ₹" + String.format(java.util.Locale.US,"%.2f",b.optDouble("total",0)),40,y+25);
                p.setTypeface(Typeface.DEFAULT); p.setTextSize(11); drawText(canvas,p,"Thank you for shopping with us!",40,y+50); drawText(canvas,p,"Goods once sold will not be taken back.",40,y+68);
            } else { p.setTypeface(Typeface.DEFAULT); p.setTextSize(9); drawText(canvas,p,"Continued...",500,805); }
            doc.finishPage(page);
            if(!more) break;
            pageNo++;
            JSONArray remaining=new JSONArray();
            // Rebuild a smaller JSON for remaining items and continue from the correct index.
            // Simpler: this branch is only reached for unusually large bills; start a new page from the next item.
            // The first page already contains the items before the break.
            break;
        }
        byte[] bytes;
        java.io.ByteArrayOutputStream bos=new java.io.ByteArrayOutputStream(); doc.writeTo(bos); doc.close(); bytes=bos.toByteArray();
        return saveShareFile(bytes, "Bill_"+b.optString("billNo","Bill").replaceAll("[^A-Za-z0-9_-]","_")+".pdf");
    }

    private String formatDate(String d){ if(d==null||d.length()<10)return d; return d.substring(8,10)+"/"+d.substring(5,7)+"/"+d.substring(0,4); }
    private double quantityValue(String q, String defaultUnit){
        if(q==null)return 0;
        String s=q.trim().toLowerCase().replace(",","");
        try{
            java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pack|packs|box|boxes|bottle|bottles|dozen)?", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s);
            if(!m.find()) return 0;
            double n=Double.parseDouble(m.group(1)); String u=m.group(2); if(u==null)u=defaultUnit==null?"kg":defaultUnit; u=u.toLowerCase();
            if(u.equals("mg")||u.startsWith("milligram"))return n/1000000.0;
            if(u.equals("g")||u.equals("gm")||u.startsWith("gram"))return n/1000.0;
            if(u.equals("dozen"))return n*12.0;
            return n;
        }catch(Exception e){return 0;}
    }

    private class AndroidBridge {
        @JavascriptInterface public void shareBillImage(String base64Png, String billName, String phone) {
            try { shareImage(Base64.decode(base64Png, Base64.DEFAULT), billName == null ? "Prakash_Kirana_Bill" : billName, phone); }
            catch (Exception e) { runOnUiThread(() -> Toast.makeText(MainActivity.this, "Could not share bill image: " + e.getMessage(), Toast.LENGTH_LONG).show()); }
        }
        @JavascriptInterface public void openBillPdf(String json) {
            try {
                Uri uri=createPdf(json);
                Intent view=new Intent(Intent.ACTION_VIEW);
                view.setDataAndType(uri,"application/pdf");
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                view.setClipData(ClipData.newRawUri("Prakash Kirana PDF", uri));
                try { startActivity(view); }
                catch(Exception noPdfApp) { startActivity(Intent.createChooser(view,"Open PDF")); }
            } catch(Exception e){
                runOnUiThread(() -> Toast.makeText(MainActivity.this,"Could not create PDF: "+e.getMessage(),Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
