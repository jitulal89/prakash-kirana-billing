package com.prakashkirana.billing;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Locale;

import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1001);
        }

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private Uri saveToCacheProvider(byte[] data, String filename) throws Exception {
        File dir = new File(getCacheDir(), "share");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create share folder");
        File file = new File(dir, filename);
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(data);
            out.flush();
        }
        return Uri.parse("content://com.prakashkirana.billing.share/" + Uri.encode(file.getName()));
    }

    private Uri saveForSharing(byte[] data, String filename, String mime) throws Exception {
        // Android 10+: use MediaStore so WhatsApp/PDF apps can read a normal system URI.
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    mime.equals("application/pdf") ?
                            Environment.DIRECTORY_DOWNLOADS + "/Prakash Kirana Stores" :
                            Environment.DIRECTORY_PICTURES + "/Prakash Kirana Stores");
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);

            Uri collection = mime.equals("application/pdf")
                    ? MediaStore.Downloads.EXTERNAL_CONTENT_URI
                    : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

            Uri uri = resolver.insert(collection, values);
            if (uri != null) {
                try (OutputStream out = resolver.openOutputStream(uri)) {
                    if (out == null) throw new Exception("Could not open output stream");
                    out.write(data);
                    out.flush();
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                resolver.update(uri, done, null, null);
                return uri;
            }
        }
        return saveToCacheProvider(data, filename);
    }

    private void shareFile(byte[] data, String filename, String mime, String title) throws Exception {
        Uri uri = saveForSharing(data, filename, mime);

        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType(mime);
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_TEXT, "Prakash Kirana Stores - " + title);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        send.setClipData(ClipData.newRawUri(title, uri));

        // Do NOT force a package. Android's Sharesheet gives WhatsApp the attachment
        // through the standard Android share contract and is more reliable across versions.
        Intent chooser = Intent.createChooser(send, title);
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(chooser);
    }

    private void drawText(Canvas c, Paint p, String text, float x, float y) {
        c.drawText(text == null ? "" : text, x, y, p);
    }

    private Uri createPdf(String json) throws Exception {
        JSONObject b = new JSONObject(json);
        JSONArray items = b.optJSONArray("items");
        PdfDocument doc = new PdfDocument();
        int pageNo = 1;
        PdfDocument.Page page = null;
        Canvas canvas = null;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, pageNo).create();
        page = doc.startPage(info);
        canvas = page.getCanvas();

        p.setColor(android.graphics.Color.rgb(36,70,111));
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setTextSize(24);
        drawText(canvas,p,"PRAKASH KIRANA STORES",170,45);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(13);
        drawText(canvas,p,"Dantoli, Nagpur",245,68);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(17);
        drawText(canvas,p,"CASH MEMO / BILL",225,95);

        p.setColor(android.graphics.Color.BLACK);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(11);
        String date=b.optString("date","");
        String customer=b.optString("customer","Cash Sale");
        drawText(canvas,p,"Bill No: " + b.optString("billNo",""),40,125);
        drawText(canvas,p,"Date: " + formatDate(date),400,125);
        drawText(canvas,p,"Customer: " + customer,40,145);
        drawText(canvas,p,"Payment Mode: Cash",400,145);

        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(10);
        canvas.drawLine(40,165,555,165,p);
        drawText(canvas,p,"Sr.",45,182);
        drawText(canvas,p,"Item Description",75,182);
        drawText(canvas,p,"Qty",350,182);
        drawText(canvas,p,"Unit",385,182);
        drawText(canvas,p,"Rate/Unit",425,182);
        drawText(canvas,p,"Amount",500,182);
        canvas.drawLine(40,190,555,190,p);

        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(10);
        int y=210;
        if(items!=null) {
            for(int i=0;i<items.length();i++) {
                JSONObject it=items.getJSONObject(i);
                String name=it.optString("name","");
                String qty=it.optString("qty","");
                String unit=it.optString("unit","piece");
                double rate=it.optDouble("rate",0);
                double qval=quantityValue(qty,unit);
                double amount=qval*rate;
                drawText(canvas,p,String.valueOf(i+1),45,y);
                drawText(canvas,p,name,75,y);
                drawText(canvas,p,qty,350,y);
                drawText(canvas,p,unit,385,y);
                drawText(canvas,p,String.format(Locale.US,"%.2f",rate),425,y);
                drawText(canvas,p,String.format(Locale.US,"%.2f",amount),500,y);
                canvas.drawLine(40,y+8,555,y+8,p);
                y+=28;
                if(y>755) break;
            }
        }

        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(15);
        drawText(canvas,p,"Total Amount: ₹" + String.format(Locale.US,"%.2f",b.optDouble("total",0)),40,y+25);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(11);
        drawText(canvas,p,"Thank you for shopping with us!",40,y+50);
        drawText(canvas,p,"Goods once sold will not be taken back.",40,y+68);

        doc.finishPage(page);

        ByteArrayOutputStream bos=new ByteArrayOutputStream();
        doc.writeTo(bos);
        doc.close();
        byte[] bytes=bos.toByteArray();
        String filename="Bill_"+b.optString("billNo","Bill").replaceAll("[^A-Za-z0-9_-]","_")+".pdf";
        return saveForSharing(bytes, filename, "application/pdf");
    }

    private String formatDate(String d){
        if(d==null||d.length()<10)return d;
        return d.substring(8,10)+"/"+d.substring(5,7)+"/"+d.substring(0,4);
    }

    private double quantityValue(String q, String defaultUnit){
        if(q==null)return 0;
        String s=q.trim().toLowerCase().replace(",","");
        try{
            java.util.regex.Matcher m=java.util.regex.Pattern.compile(
                    "(\\d+(?:\\.\\d+)?)\\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pack|packs|box|boxes|bottle|bottles|dozen)?",
                    java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s);
            if(!m.find()) return 0;
            double n=Double.parseDouble(m.group(1));
            String u=m.group(2);
            if(u==null)u=defaultUnit==null?"piece":defaultUnit;
            u=u.toLowerCase();
            if(u.equals("mg")||u.startsWith("milligram"))return n/1000000.0;
            if(u.equals("g")||u.equals("gm")||u.startsWith("gram"))return n/1000.0;
            if(u.equals("dozen"))return n*12.0;
            return n;
        }catch(Exception e){return 0;}
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void shareBillImage(String base64Png, String billName, String phone) {
            try {
                byte[] data=Base64.decode(base64Png, Base64.DEFAULT);
                String safe=(billName==null||billName.trim().isEmpty())?"Prakash_Kirana_Bill":billName;
                shareFile(data, safe+".png", "image/png", "WhatsApp Bill");
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "Could not share bill image: " + e.getMessage(),
                        Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void openBillPdf(String json) {
            try {
                Uri uri=createPdf(json);
                Intent send=new Intent(Intent.ACTION_SEND);
                send.setType("application/pdf");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_TEXT, "Prakash Kirana Stores - Bill");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                send.setClipData(ClipData.newRawUri("Prakash Kirana PDF", uri));
                Intent chooser=Intent.createChooser(send,"Share / Open PDF");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(chooser);
            } catch(Exception e){
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "Could not create/share PDF: "+e.getMessage(),
                        Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
