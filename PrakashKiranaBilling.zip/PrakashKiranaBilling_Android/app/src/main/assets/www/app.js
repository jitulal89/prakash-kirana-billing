const $=id=>document.getElementById(id);
const DEFAULT_PRODUCTS=[
{name:"Singdana",rate:180},{name:"Sabudana",rate:90},{name:"Sugar",rate:60},{name:"Rice",rate:55},{name:"Dal",rate:120},
{name:"Wheat",rate:45},{name:"Atta",rate:45},{name:"Maida",rate:45},{name:"Besan",rate:90},{name:"Rava",rate:60},{name:"Sooji",rate:60},{name:"Poha",rate:60},
{name:"Moong Dal",rate:120},{name:"Toor Dal",rate:150},{name:"Masoor Dal",rate:110},{name:"Urad Dal",rate:140},{name:"Chana Dal",rate:100},{name:"Rajma",rate:140},{name:"Chole",rate:110},
{name:"Kabuli Chana",rate:140},{name:"Moong",rate:120},{name:"Masoor",rate:110},{name:"Black Gram",rate:140},{name:"Tea",rate:300},{name:"Coffee",rate:500},{name:"Salt",rate:25},
{name:"Jaggery",rate:70},{name:"Turmeric",rate:220},{name:"Red Chilli Powder",rate:280},{name:"Coriander Powder",rate:180},{name:"Garam Masala",rate:350},{name:"Cumin",rate:300},
{name:"Mustard Seeds",rate:180},{name:"Fennel",rate:250},{name:"Black Pepper",rate:700},{name:"Cardamom",rate:1800},{name:"Cloves",rate:900},{name:"Cinnamon",rate:500},
{name:"Cooking Oil",rate:150},{name:"Sunflower Oil",rate:150},{name:"Groundnut Oil",rate:180},{name:"Mustard Oil",rate:170},{name:"Ghee",rate:650},{name:"Butter",rate:600},
{name:"Milk",rate:65},{name:"Curd",rate:80},{name:"Bread",rate:50},{name:"Biscuits",rate:100},{name:"Namkeen",rate:180},{name:"Chips",rate:200},{name:"Papad",rate:180},
{name:"Noodles",rate:120},{name:"Pasta",rate:160},{name:"Vermicelli",rate:100},{name:"Corn Flakes",rate:350},{name:"Oats",rate:180},{name:"Jam",rate:220},{name:"Peanut Butter",rate:350},
{name:"Honey",rate:450},{name:"Tomato Ketchup",rate:180},{name:"Pickle",rate:180},{name:"Coconut",rate:120},{name:"Dry Coconut",rate:250},{name:"Almonds",rate:900},{name:"Cashews",rate:1000},
{name:"Raisins",rate:350},{name:"Walnuts",rate:1000},{name:"Dates",rate:300},{name:"Mouth Freshener",rate:300},{name:"Chocolate",rate:500},{name:"Toffee",rate:400},
{name:"Colgate",rate:100},{name:"Toothpaste",rate:100},{name:"Toothbrush",rate:60},{name:"Soap",rate:50},{name:"Shampoo",rate:300},{name:"Hair Oil",rate:180},{name:"Face Wash",rate:180},
{name:"Body Lotion",rate:250},{name:"Detergent",rate:120},{name:"Washing Powder",rate:120},{name:"Dishwash",rate:120},{name:"Dishwash Bar",rate:30},{name:"Floor Cleaner",rate:180},
{name:"Toilet Cleaner",rate:180},{name:"Phenyl",rate:100},{name:"Handwash",rate:120},{name:"Sanitizer",rate:150},{name:"Tissue",rate:100},{name:"Toilet Paper",rate:100},
{name:"Garbage Bags",rate:100},{name:"Mosquito Coil",rate:80},{name:"Mosquito Repellent",rate:200},{name:"Matchbox",rate:2},{name:"Candles",rate:100},{name:"Battery",rate:20},
{name:"Notebook",rate:50},{name:"Pen",rate:10},{name:"Pencil",rate:5},{name:"Eraser",rate:5},{name:"Sharpener",rate:10}
];
const PIECE_PRODUCTS=new Set(["Biscuits","Namkeen","Chips","Papad","Noodles","Pasta","Vermicelli","Corn Flakes","Oats","Jam","Peanut Butter","Honey","Tomato Ketchup","Pickle","Mouth Freshener","Chocolate","Toffee","Colgate","Toothpaste","Toothbrush","Soap","Shampoo","Hair Oil","Face Wash","Body Lotion","Detergent","Washing Powder","Dishwash","Dishwash Bar","Floor Cleaner","Toilet Cleaner","Phenyl","Handwash","Sanitizer","Tissue","Toilet Paper","Garbage Bags","Mosquito Coil","Mosquito Repellent","Matchbox","Candles","Battery","Notebook","Pen","Pencil","Eraser","Sharpener","Bread","Milk","Curd","Butter"]);
for(const p of DEFAULT_PRODUCTS){if(!p.unit)p.unit=PIECE_PRODUCTS.has(p.name)?"piece":"kg";}
let nativeStore={};
try{
 const rawNative=window.Android?.loadAppState?.();
 if(rawNative) nativeStore=JSON.parse(rawNative)||{};
}catch(e){nativeStore={};}
const getStored=(key,fallback)=>{
 try{
   if(Object.prototype.hasOwnProperty.call(nativeStore,key)) return JSON.parse(nativeStore[key]||JSON.stringify(fallback));
   const raw=localStorage.getItem(key); return raw==null?fallback:JSON.parse(raw);
 }catch(e){return fallback;}
};
const storedProducts=getStored("pksProducts",null);
const mergedProducts=storedProducts||[];
for(const p of mergedProducts){if(!p.unit)p.unit=PIECE_PRODUCTS.has(p.name)?"piece":"kg";}
for(const p of DEFAULT_PRODUCTS){if(!mergedProducts.some(x=>String(x.name).toLowerCase()===p.name.toLowerCase()))mergedProducts.push({...p});}

const state={
 products:mergedProducts,
 bills:getStored("pksBills",[]),
 customers:getStored("pksCustomers",[]),
 vendors:getStored("pksVendors",[]),
 purchases:getStored("pksPurchases",[]),
 vendorPayments:getStored("pksVendorPayments",[]),
 purchaseAttachment:null
};
let editingProduct=-1, deferredInstall=null;
// Migrate existing WebView local data into the native SQLite store on first run.
if(Object.keys(nativeStore).length===0 && window.Android?.saveAppState){ try{ save(); }catch(e){} }

function save(){
 const payload={
  pksProducts:JSON.stringify(state.products),
  pksBills:JSON.stringify(state.bills),
  pksCustomers:JSON.stringify(state.customers),
  pksVendors:JSON.stringify(state.vendors),
  pksPurchases:JSON.stringify(state.purchases),
  pksVendorPayments:JSON.stringify(state.vendorPayments)
 };
 Object.entries(payload).forEach(([k,v])=>localStorage.setItem(k,v));
 try{ if(window.Android?.saveAppState) Android.saveAppState(JSON.stringify(payload)); }catch(e){ console.warn("Native save failed",e); }
}
function today(){let d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
$("billDate").value=today();
function money(n){return "₹"+Number(n||0).toFixed(2)}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]))}
function nextBillNo(){const y=new Date().getFullYear(),nums=state.bills.map(b=>Number((b.billNo||"").split("/").pop())).filter(Number.isFinite);const next=Math.max(94,...nums)+1;return `#PKS-${y}/${String(next).padStart(3,"0")}`}

function normalizeUnitName(unit){
 const u=String(unit||"").toLowerCase().trim();
 if(["g","gm","gram","grams"].includes(u))return "gram";
 if(["kg","kgs","kilo","kilos","kilogram","kilograms"].includes(u))return "kg";
 if(["mg","milligram","milligrams"].includes(u))return "mg";
 if(["piece","pieces","pc","pcs"].includes(u))return "piece";
 if(["packet","packets"].includes(u))return "packet";
 if(["pack","packs"].includes(u))return "pack";
 if(["box","boxes"].includes(u))return "box";
 if(["bottle","bottles"].includes(u))return "bottle";
 if(u==="dozen")return "dozen";
 return u||"kg";
}

function normalizeQtyForRow(row){
 const input=row.querySelector(".iqty");
 const select=row.querySelector(".iunit");
 const text=String(input.value||"").trim().toLowerCase().replace(/,/g," " ).replace(/\s+/g," ");
 const m=text.match(/^(\d+(?:\.\d+)?)\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pack|packs|box|boxes|bottle|bottles|dozen)?$/i);
 if(!m)return;
 input.value=m[1];
 if(m[2])select.value=normalizeUnitName(m[2]);
}

function parseQuickListLine(line){
 let raw=String(line||"").trim();
 if(!raw)return null;
 raw=raw.replace(/[|,;]/g," ").replace(/\s+/g," ").trim();
 raw=raw.replace(/^(?:add\s+)?(?:new\s+)?(?:item|tem)\s+/i,"").trim();
 const units="kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pack|packs|box|boxes|bottle|bottles|dozen";
 const rateMatch=raw.match(/(\d+(?:\.\d+)?)\s*$/);
 if(!rateMatch)return {error:`Could not find rate in: ${line}`};
 const rate=Number(rateMatch[1]);
 let before=raw.slice(0,rateMatch.index).trim();
 const qtyMatch=before.match(new RegExp(`(\\d+(?:\\.\\d+)?)\\s*(?:(${units}))?\\s*$`,"i"));
 if(!qtyMatch)return {error:`Could not find quantity in: ${line}`};
 const qty=qtyMatch[1];
 const explicitUnit=qtyMatch[2]?normalizeUnitName(qtyMatch[2]):"";
 let name=before.slice(0,qtyMatch.index).trim();
 name=name.replace(/\bx\s*$/i,"").trim();
 if(!name)return {error:`Could not find item name in: ${line}`};
 const saved=findProduct(name);
 const unit=explicitUnit || (saved && saved.unit ? saved.unit : "piece");
 return {name,qty,unit,rate};
}

function addQuickList(){
 const box=$("quickList");
 const text=String(box.value||"").trim();
 if(!text){box.focus();return}
 const lines=text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 const parsed=[];const errors=[];
 for(const line of lines){const item=parseQuickListLine(line);if(item?.error)errors.push(item.error);else if(item)parsed.push(item)}
 if(errors.length){alert("Please correct these lines:\n\n"+errors.join("\n"));return}

 // Keep the Quick List text on screen.  Re-pressing Add List updates
 // existing billing rows with the same item name and adds only new items.
 const existingRows=[...items.children];
 const updated=[];
 const added=[];
 parsed.forEach(item=>{
   const key=item.name.trim().toLowerCase();
   const row=existingRows.find(r=>String(r.querySelector(".iname")?.value||"").trim().toLowerCase()===key);
   if(row){
     row.querySelector(".iqty").value=item.qty;
     row.querySelector(".iunit").value=item.unit;
     row.querySelector(".irate").value=item.rate;
     normalizeQtyForRow(row);
     updated.push(item.name);
   }else{
     addItem(item);
     added.push(item.name);
   }
 });
 calc();
 if(parsed.length){
   $("voiceStatus").textContent=`Quick List updated: ${updated.length} updated, ${added.length} new. The list is retained for editing.`;
   const targetName=added.length?added[added.length-1]:updated[updated.length-1];
   const target=[...items.children].find(r=>String(r.querySelector(".iname")?.value||"").trim().toLowerCase()===String(targetName||"").trim().toLowerCase());
   target?.querySelector(".irate")?.focus();
 }
}

function addItem(item={name:"",qty:"",rate:0,unit:"kg"}){
 const row=document.createElement("div");row.className="item";
 const unit=normalizeUnitName(item.unit||"kg");
 const qtyText=String(item.qty??"").replace(/\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pack|packs|box|boxes|bottle|bottles|dozen)\s*$/i,"").trim();
 row.innerHTML=`<label class="item-name">Item<input class="iname" list="productNames" value="${esc(item.name)}" placeholder="Sugar"></label>
 <div class="item-details">
   <label>Qty<input class="iqty" type="text" inputmode="decimal" value="${esc(qtyText)}" placeholder="2"></label>
   <label>Unit<select class="iunit">
     <option value="kg">kg</option><option value="gram">gram</option><option value="piece">piece</option><option value="packet">packet</option><option value="pack">pack</option><option value="box">box</option><option value="bottle">bottle</option><option value="dozen">dozen</option>
   </select></label>
   <label>Rate / Unit<input class="irate" type="number" min="0" step="0.01" value="${item.rate}"></label>
   <div><label>Amount</label><div class="amount">₹0.00</div></div>
   <button class="remove" type="button">×</button>
 </div>`;
 items.appendChild(row);row.querySelector(".iunit").value=unit;
 row.querySelectorAll("input,select").forEach(x=>x.addEventListener("input",()=>{
   if(x.classList.contains("iqty"))normalizeQtyForRow(row);
   calc();
 }));
 // Auto-fill the default product rate only when the ITEM NAME changes.
 // Never refill the rate when the user intentionally clears the rate field.
 row.querySelector(".iname").addEventListener("input",()=>{
   row.querySelector(".irate").dataset.autoFilled="";
   autoRate(row);
   calc();
 });
 row.querySelector(".iqty").addEventListener("blur",()=>{normalizeQtyForRow(row);calc()});
 row.querySelector(".remove").onclick=()=>{row.remove();calc()};
 calc();
}
function autoRate(row){
 const name=row.querySelector(".iname").value.trim();
 if(!name)return;
 const rateInput=row.querySelector(".irate");
 // Only supply the product-master rate if this is a newly named/empty row.
 // Once the user has edited the rate, clearing it must remain blank until
 // the user enters a new rate.
 if(!rateInput.dataset.autoFilled && String(rateInput.value||"").trim()===""){
   const p=findProduct(name);
   if(p){
     rateInput.value=p.rate;
     rateInput.dataset.autoFilled="true";
     row.querySelector(".iunit").value=p.unit||"kg";
   }
 }
}

// Quantity is stored/displayed as text. The Unit field controls how the rate is applied.
// kg/gram are converted to kg for a Rate/kg product; piece/packet/box/etc. stay as counts.
function quantityValue(qtyText, defaultUnit="kg"){
 const text=String(qtyText??"").trim().toLowerCase().replace(/,/g," " ).replace(/\s+/g," ");
 if(!text)return 0;
 const m=text.match(/^(\d+(?:\.\d+)?)\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pack|packs|box|boxes|bottle|bottles|dozen)?$/i);
 if(!m)return 0;
 const n=Number(m[1]);
 const unit=normalizeUnitName(m[2]||defaultUnit||"kg");
 if(unit==="mg")return n/1000000;
 if(unit==="gram")return n/1000;
 if(unit==="kg")return n;
 if(unit==="dozen")return n*12;
 return n;
}
function qtyDisplayUnit(qtyText,defaultUnit="kg"){return normalizeUnitName(defaultUnit||"kg");}
function calc(){
 let total=0;
 [...items.children].forEach(r=>{const q=quantityValue(r.querySelector(".iqty").value,r.querySelector(".iunit").value),rate=Number(r.querySelector(".irate").value)||0,a=q*rate;total+=a;r.querySelector(".amount").textContent=money(a)});
 $("grandTotal").textContent=money(total);
}
function clearBill(){pendingVoiceText="";$("customer").value="";items.innerHTML="";$("billDate").value=today();$("voiceStatus").textContent="Ready - say an item command or tap + Add Item";calc()}

document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
function showPage(name){document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.page===name));document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));$(name+"Page").classList.add("active");if(name==="products")renderProducts();if(name==="history")renderHistory();if(name==="sales")renderSales();if(name==="purchases")renderPurchasing()}
$("addItemBtn").onclick=()=>addItem();$("quickListBtn").onclick=addQuickList;$("clearBtn").onclick=()=>clearBill();$("newBillBtn")?.addEventListener("click",clearBill);

function normalizeVoiceText(text){return String(text||"").replace(/[₹,]/g," ").replace(/[;|]/g," ").replace(/\s+/g," ").trim()}
function cleanCommandText(text){return normalizeVoiceText(text).replace(/\b(?:please|pls|kindly)\b/gi," ").replace(/\s+/g," ").trim()}

// Common speech-recognition substitutions. These are deliberately conservative.
function normalizeSpokenNumbers(text){
 let s=String(text||"").toLowerCase();
 const replacements={"one":"1","two":"2","three":"3","four":"4","five":"5","six":"6","seven":"7","eight":"8","nine":"9","ten":"10","half":"0.5"};
 for(const [w,n] of Object.entries(replacements))s=s.replace(new RegExp(`\\b${w}\\b`,"gi"),n);
 // Android speech recognition sometimes hears "two" as "to" or "too".
 // Only treat those as 2 when they occur immediately after a quantity keyword.
 s=s.replace(/\b(quantity|qty|quanity|quant|qnty)\s+(?:to|too|tu)\b/gi,"$1 2");
 return s;
}

function normalizeUnits(text){
 return text.toLowerCase()
   .replace(/\bkilograms?\b/g,"kg").replace(/\bkilos?\b/g,"kg").replace(/\bkgs?\b/g,"kg")
   .replace(/\bgrams?\b/g,"gram").replace(/\bgms?\b/g,"gram").replace(/\bmilligrams?\b/g,"mg");
}
function normalizeForParsing(text){return normalizeUnits(normalizeSpokenNumbers(cleanCommandText(text))).replace(/\s+/g," ").trim()}

function levenshtein(a,b){
 a=a.toLowerCase();b=b.toLowerCase();
 const dp=Array.from({length:a.length+1},()=>Array(b.length+1).fill(0));
 for(let i=0;i<=a.length;i++)dp[i][0]=i;
 for(let j=0;j<=b.length;j++)dp[0][j]=j;
 for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++)dp[i][j]=Math.min(dp[i-1][j]+1,dp[i][j-1]+1,dp[i-1][j-1]+(a[i-1]===b[j-1]?0:1));
 return dp[a.length][b.length];
}
function findProduct(spoken){
 const s=String(spoken||"").trim().toLowerCase();if(!s)return null;
 let exact=state.products.find(p=>p.name.toLowerCase()===s);if(exact)return exact;
 let best=null,bestScore=Infinity;
 for(const p of state.products){
   const n=p.name.toLowerCase();
   let d=levenshtein(s,n);
   if(s.includes(n)||n.includes(s))d=Math.min(d,1);
   const threshold=Math.max(2,Math.floor(Math.max(s.length,n.length)*0.4));
   if(d<=threshold&&d<bestScore){best=p;bestScore=d}
 }
 return best;
}

function addProductIfMissing(name,rate,unit="kg"){
 const clean=String(name||"").trim();
 const r=Number(rate)||0;
 if(!clean||r<=0)return false;
 const existing=state.products.find(p=>p.name.toLowerCase()===clean.toLowerCase());
 if(existing){
   if((!Number(existing.rate)||Number(existing.rate)===0)&&r>0){existing.rate=r;save();}
   return false;
 }
 state.products.push({name:clean,rate:r,unit:unit||"kg"});
 save();
 renderDatalist();renderCustomerDatalist();
 return true;
}

function extractQuantity(raw){
 const r=normalizeForParsing(raw);
 // First isolate the words between quantity and rate. This prevents the rate number
 // from ever being accidentally joined to the quantity (for example 1 kg + 50).
 let phrase="";
 const between=r.match(/\b(?:quantity|qty|quanity|quant|qnty)\s*[:=-]?\s*(.*?)\s+(?=(?:rate|price|cost|rs|rupees|rupay|rupaye|right)\b)/i);
 if(between) phrase=between[1].trim();
 else {
   const direct=r.match(/\b(?:quantity|qty|quanity|quant|qnty)\s*[:=-]?\s*(\d+(?:\.\d+)?)\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pack|packs|box|boxes|bottle|bottles|dozen)?\b/i);
   if(direct) return {value:Number(direct[1]),unit:direct[2]||"",text:direct[1]};
 }
 if(phrase){
   const m=phrase.match(/^(\d+(?:\.\d+)?)\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pack|packs|box|boxes|bottle|bottles|dozen)?\b/i);
   if(m)return {value:Number(m[1]),unit:m[2]||"",text:m[1]};
 }
 // Also allow: Add Item Sugar 1 kg Rate 50
 const m2=r.match(/\b(?:item|add\s+item|new\s+item)\b\s+.*?\b(\d+(?:\.\d+)?)\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pack|packs|box|boxes|bottle|bottles|dozen)\b/i);
 if(m2)return {value:Number(m2[1]),unit:m2[2],text:m2[1]};
 return null;
}
function extractRate(raw){
 const r=normalizeForParsing(raw);
 const m=r.match(/\b(?:rate|price|cost|rs|rupees|rupay|rupaye|right)\s*[:=-]?\s*(?:₹\s*)?(\d+(?:\.\d+)?)\b/i);
 return m?Number(m[1]):null;
}
function extractItemName(raw,qty,rate){
 let s=normalizeForParsing(raw);
 // "Item" is optional. Accept "Colgate quantity 1 rate 100",
 // "Add Colgate quantity 1 rate 100", "Tem Colgate...", etc.
 s=s.replace(/^(?:add\s+)?(?:new\s+)?(?:item|tem)\b\s*/i,"");
 s=s.replace(/\b(?:quantity|qty|quanity|quant|qnty)\s*[:=-]?\s*\d+(?:\.\d+)?\s*(?:kg|gram|g|mg)?\b.*$/i,"");
 s=s.replace(/\b(?:rate|price|cost|rs|rupees|rupay|rupaye|right)\s*[:=-]?\s*\d+(?:\.\d+)?\b.*$/i,"");
 if(qty)s=s.replace(new RegExp(`\\s${qty.value}(?:\\s${qty.unit})?\\s*$`,"i"),"");
 return s.replace(/\s+/g," ").trim();
}

function parseVoice(text){
 const raw=normalizeForParsing(text);if(!raw)return null;
 if(/^(?:customer|grahak)\b/i.test(raw))return {type:"customerIgnored"};
  const qty=extractQuantity(raw);const rate=extractRate(raw);
 if(!qty||rate===null)return null;
 let name=extractItemName(raw,qty,rate);
 if(!name)return null;
 let product=findProduct(name);
 if(!product){
   const words=name.split(/\s+/).filter(Boolean);
   for(let i=0;i<words.length&&!product;i++){
     for(let j=words.length;j>i;j--){
       const candidate=findProduct(words.slice(i,j).join(" "));
       if(candidate){product=candidate;break;}
     }
   }
 }
 const finalName=product?product.name:name;
 const qtyText=qty.text;
 const unit=normalizeUnitName(qty.unit||product?.unit||"kg");
 if(quantityValue(qtyText,unit)<=0)return null;
 return {type:"item",name:finalName,qty:qtyText,unit,rate,matched:!!product,spokenName:name};
}

let pendingVoiceText="";
function processVoiceSegment(text){
 const segment=cleanCommandText(text);if(!segment)return;
 if(/^customer\b/i.test(segment)||/^grahak\b/i.test(segment)){$("voiceStatus").textContent="Customer voice is disabled. Say an item command.";return}
 pendingVoiceText=(pendingVoiceText+" "+segment).trim();
 const parsed=parseVoice(pendingVoiceText);
 if(parsed?.type==="item"){
   addItem({name:parsed.name,qty:parsed.qty,unit:parsed.unit,rate:parsed.rate});
   if(!parsed.matched)addProductIfMissing(parsed.name,parsed.rate,parsed.unit);
   calc();
   $("voiceStatus").textContent=`Added: ${parsed.name} | Qty ${parsed.qty} | Rate ₹${parsed.rate}/${parsed.unit} | Amount ${money(quantityValue(parsed.qty,parsed.unit)*parsed.rate)}`;
   pendingVoiceText="";
   return;
 }
 $("voiceStatus").textContent=`Heard: “${pendingVoiceText}” — waiting for item, quantity and rate.`;
 if(pendingVoiceText.length>180)pendingVoiceText=segment;
}

let rec=null,voiceActive=false,restartTimer=null;
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(SR){
 rec=new SR();rec.interimResults=false;rec.continuous=false;rec.maxAlternatives=5;
 rec.onstart=()=>{$("voiceBtn").classList.add("listening");$("voiceStatus").textContent="Listening… Say one complete item command."};
 rec.onresult=e=>{
   for(let i=e.resultIndex;i<e.results.length;i++)if(e.results[i].isFinal){
     const result=e.results[i];let best="",bestScore=-999;
     for(let j=0;j<result.length;j++){
       const t=(result[j].transcript||"").trim();if(!t)continue;
       const l=normalizeForParsing(t);let score=0;
       if(/\b(?:item|add|new)\b/.test(l))score+=4;
       if(/\b(?:quantity|qty|quanity|quant|qnty)\b/.test(l))score+=4;
       if(/\b(?:rate|price|cost|rs|rupees|rupay|rupaye|right)\b/.test(l))score+=4;
       if(/\d/.test(l))score+=3;
       for(const p of state.products){const pn=p.name.toLowerCase();if(l.includes(pn))score+=8;else if(findProduct(l.replace(/\b(?:item|add|new|quantity|qty|rate|price|cost|rs|rupees|rupay|rupaye|right)\b/gi," ").trim()))score+=2}
       if(score>bestScore){bestScore=score;best=t}
     }
     if(best)processVoiceSegment(best);
   }
 };
 rec.onerror=e=>{
   if(!voiceActive)return;
   if(e.error==='not-allowed'||e.error==='service-not-allowed'){voiceActive=false;$("voiceBtn").classList.remove("listening");$("voiceStatus").textContent="Allow microphone permission for the app.";return}
   $("voiceStatus").textContent="Listening…";
 };
 rec.onend=()=>{
   $("voiceBtn").classList.remove("listening");
   if(voiceActive){clearTimeout(restartTimer);restartTimer=setTimeout(()=>{if(!voiceActive)return;try{rec.lang=$("voiceLang").value;rec.start()}catch(e){}},400)}
   else $("voiceStatus").textContent=pendingVoiceText?`Voice stopped. Pending: ${pendingVoiceText}`:"Ready";
 };
}
$("voiceLang").onchange=()=>{if(rec)rec.lang=$("voiceLang").value};
$("voiceBtn").onclick=()=>{
 if(!rec){$("voiceStatus").textContent="Voice recognition is not supported here. Use Chrome on Android.";return}
 if(voiceActive){voiceActive=false;clearTimeout(restartTimer);try{rec.stop()}catch(e){}$("voiceBtn").classList.remove("listening");$("voiceStatus").textContent=pendingVoiceText?`Voice stopped. Pending: ${pendingVoiceText}`:"Voice stopped. Existing items are kept.";return}
 voiceActive=true;pendingVoiceText="";rec.lang=$("voiceLang").value;try{rec.start()}catch(e){}
};

$("generateBtn").onclick=()=>{
 const rows=[...items.children].map(r=>({name:r.querySelector(".iname").value.trim(),qty:r.querySelector(".iqty").value.trim(),rate:Number(r.querySelector(".irate").value)||0,unit:r.querySelector(".iunit").value||"kg"})).filter(x=>x.name&&quantityValue(x.qty,x.unit)>0);
 if(!rows.length){alert("Add at least one item.");return}
 // Any manually entered item is automatically saved to Product Master.
 for(const row of rows)addProductIfMissing(row.name,row.rate,row.unit);
 const bill={billNo:nextBillNo(),date:$("billDate").value,customer:$("customer").value.trim()||"Cash Sale",items:rows,total:rows.reduce((s,x)=>s+quantityValue(x.qty,x.unit)*x.rate,0)};
 state.bills.unshift(bill);save();renderBill(bill);showPage("preview");$("previewPage").classList.add("active");
};
function normalizePhone(phone){
 let p=String(phone||"").replace(/\D/g,"");
 if(p.length===10)p="91"+p;
 if(p.startsWith("0091"))p=p.slice(2);
 return p;
}
function saveCustomer(name,phone){
 name=String(name||"").trim(); phone=normalizePhone(phone);
 if(!name||phone.length<12)return;
 const existing=state.customers.find(c=>normalizePhone(c.phone)===phone);
 if(existing){existing.name=name;existing.phone=phone}else state.customers.unshift({name,phone});
 state.customers=state.customers.slice(0,500);save();renderCustomerDatalist();
}
function findCustomer(name){return state.customers.find(c=>c.name.toLowerCase()===String(name||"").trim().toLowerCase())||null}
function renderCustomerDatalist(){
 let dl=document.getElementById("customerNames");if(!dl){dl=document.createElement("datalist");dl.id="customerNames";document.body.appendChild(dl)}
 dl.innerHTML="";state.customers.forEach(c=>{const o=document.createElement("option");o.value=c.name;o.label="+"+c.phone;dl.appendChild(o)});
}
async function drawBillImage(b){
 const logo=new Image(); logo.src="logo.jpg";
 try{await new Promise((resolve,reject)=>{logo.onload=resolve;logo.onerror=reject})}catch(e){}
 const scale=2,w=900,pad=45,rowH=54,headH=70;
 const h=300+headH+b.items.length*rowH;
 const c=document.createElement("canvas");c.width=w*scale;c.height=h*scale;const x=c.getContext("2d");x.scale(scale,scale);
 x.fillStyle="#fff";x.fillRect(0,0,w,h);
 if(logo.complete&&logo.naturalWidth){x.drawImage(logo,45,20,85,85)}
 x.fillStyle="#24466f";x.textAlign="left";x.font="bold 34px sans-serif";x.fillText("PRAKASH KIRANA STORES",155,52);
 x.font="18px sans-serif";x.fillText("Diamond One building, near Dhantoli park, opposite Axis Bank, Dhantoli, Nagpur - 440012",155,80);x.font="bold 22px sans-serif";x.fillText("CASH MEMO / BILL",155,112);
 x.textAlign="left";x.fillStyle="#111";x.font="18px sans-serif";x.fillText("Bill No: "+b.billNo,45,150);x.fillText("Date: "+b.date.split("-").reverse().join("/"),560,150);x.fillText("Customer: "+(b.customer||"Cash Sale"),45,180);x.fillText("Payment Mode: Cash",560,180);
 const top=210;const cols=[45,105,420,540,690,855];x.strokeStyle="#aaa";x.lineWidth=1;x.strokeRect(45,top,w-90,headH+b.items.length*rowH+70);
 x.fillStyle="#24466f";x.fillRect(46,top+1,w-92,headH-1);x.fillStyle="#fff";x.font="bold 16px sans-serif";["Sr.","Item Description","Qty","Unit","Rate/Unit","Amount"].forEach((t,i)=>x.fillText(t,cols[i]+8,top+42));
 x.fillStyle="#111";x.font="16px sans-serif";
 b.items.forEach((it,i)=>{const y=top+headH+i*rowH+34;const amt=quantityValue(it.qty,it.unit||"piece")*it.rate;x.fillText(String(i+1),cols[0]+8,y);x.fillText(it.name,cols[1]+8,y);x.fillText(it.qty,cols[2]+8,y);x.fillText(it.unit||"piece",cols[3]+8,y);x.fillText(Number(it.rate).toFixed(2),cols[4]+8,y);x.fillText(amt.toFixed(2),cols[5]+8,y);x.strokeStyle="#ddd";x.beginPath();x.moveTo(46,y+20);x.lineTo(w-46,y+20);x.stroke()});
 const ty=top+headH+b.items.length*rowH+50;x.font="bold 22px sans-serif";x.fillText("Total Amount: "+money(b.total),45,ty);x.font="17px sans-serif";x.fillText("Thank you for shopping with us!",45,ty+38);x.font="14px sans-serif";x.fillText("Goods once sold will not be taken back.",45,ty+64);
 return c.toDataURL("image/png").split(",")[1];
}
function renderBill(b){window.currentBill=b;const date=b.date.split("-").reverse().join("/");$("billPreview").innerHTML=`<div class="bill-logo-wrap"><img src="logo.jpg" class="bill-logo" alt="Prakash Kirana Stores logo"></div><h1>PRAKASH KIRANA STORES</h1><div class="location">Diamond One building, near Dhantoli park, opposite Axis Bank, Dhantoli, Nagpur - 440012</div><div class="pill">CASH MEMO / BILL</div><hr><div class="meta"><div><b>Bill No:</b> ${esc(b.billNo)}</div><div><b>Date:</b> ${date}</div><div><b>Customer:</b> ${esc(b.customer)}</div><div><b>Payment Mode:</b> Cash</div></div><table><thead><tr><th>Sr.</th><th>Item Description</th><th>Qty</th><th>Rate / Unit (₹)</th><th>Amount (₹)</th></tr></thead><tbody>${b.items.map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x.name)}</td><td>${esc(x.qty)}</td><td>${x.rate.toFixed(2)}</td><td>${(quantityValue(x.qty,x.unit||"kg")*x.rate).toFixed(2)}</td></tr>`).join("")}</tbody><tfoot><tr><td colspan="4">Total Amount:</td><td>${money(b.total)}</td></tr></tfoot></table><div class="thanks">Thank you for shopping with us!</div><div class="muted">Goods once sold will not be taken back.</div><div class="sign">For Prakash Kirana Stores<br><span>(Authorized Signatory)</span></div>`}
$("printBtn").onclick=()=>{
 if(window.currentBill && window.Android && Android.openBillPdf){
   Android.openBillPdf(JSON.stringify(window.currentBill));
 }else{
   window.print();
 }
};
$("backToBilling").onclick=()=>showPage("billing");

// ---------------- Purchasing / Vendor Accounts ----------------
function purchaseId(prefix="PUR"){return prefix+"-"+Date.now()+"-"+Math.random().toString(36).slice(2,7).toUpperCase()}
function renderVendorsSelects(){
 const pv=$("purchaseVendor"), pay=$("paymentVendor");
 if(pv){pv.innerHTML='<option value="">Select vendor</option>'+state.vendors.map(v=>`<option value="${esc(v.id)}">${esc(v.name)}</option>`).join("")}
 if(pay){pay.innerHTML='<option value="">Select vendor</option>'+state.vendors.map(v=>`<option value="${esc(v.id)}">${esc(v.name)}</option>`).join("")}
}
function vendorById(id){return state.vendors.find(v=>v.id===id)||null}
function vendorBalance(v){
 const purchases=state.purchases.filter(p=>p.vendorId===v.id).reduce((s,p)=>s+Number(p.total||0),0);
 const paid=state.vendorPayments.filter(p=>p.vendorId===v.id).reduce((s,p)=>s+Number(p.amount||0),0);
 return {purchases,paid,pending:Number(v.openingBalance||0)+purchases-paid};
}
function renderPurchasing(){
 renderVendorsSelects();
 const total=state.purchases.reduce((s,p)=>s+Number(p.total||0),0);
 const paid=state.purchases.reduce((s,p)=>s+Number(p.paid||0),0)+state.vendorPayments.reduce((s,p)=>s+Number(p.amount||0),0);
 const pending=state.vendors.reduce((s,v)=>s+vendorBalance(v).pending,0);
 $("purchaseTotal").textContent=money(total);
 $("purchasePaid").textContent=money(paid);
 $("purchasePending").textContent=money(pending);
 const va=$("vendorAccounts");va.innerHTML="";
 if(!state.vendors.length)va.innerHTML='<div class="muted">No vendors added yet.</div>';
 state.vendors.forEach(v=>{
   const b=vendorBalance(v);
   const r=document.createElement("div");r.className="vendor-account";
   r.innerHTML=`<div class="vendor-account-head"><div><div class="history-title">${esc(v.name)}</div><div class="muted">${esc(v.phone||"")} ${v.gstin?"• "+esc(v.gstin):""}</div></div><button class="secondary pay">Pay</button></div>
   <div class="purchase-summary">
     <div class="sales-box"><span>Purchases</span><strong>${money(b.purchases)}</strong></div>
     <div class="sales-box"><span>Paid</span><strong class="paid">${money(b.paid)}</strong></div>
     <div class="sales-box"><span>Pending</span><strong class="${b.pending>0?"payable":"paid"}">${money(b.pending)}</strong></div>
   </div>`;
   r.querySelector(".pay").onclick=()=>{ $("paymentVendor").value=v.id; $("paymentDate").value=today(); $("paymentModal").classList.remove("hidden"); };
   va.appendChild(r);
 });
 const vp=$("vendorPayments");vp.innerHTML="";
 const payments=[...state.vendorPayments].sort((a,b)=>String(b.date).localeCompare(String(a.date)));
 if(!payments.length)vp.innerHTML='<div class="muted">No vendor payments recorded.</div>';
 payments.slice(0,50).forEach(p=>{const v=vendorById(p.vendorId);const r=document.createElement("div");r.className="history-row";r.innerHTML=`<div><div class="history-title">${esc(v?.name||"Unknown Vendor")} • ${money(p.amount)}</div><div class="muted">${esc(p.date)} • ${esc(p.mode||"")} ${p.note?"• "+esc(p.note):""}</div></div>`;vp.appendChild(r)});
 const q=String($("purchaseSearch")?.value||"").toLowerCase();
 const ph=$("purchaseHistory");ph.innerHTML="";
 const list=state.purchases.filter(p=>JSON.stringify(p).toLowerCase().includes(q)).sort((a,b)=>String(b.date).localeCompare(String(a.date)));
 if(!list.length)ph.innerHTML='<div class="muted">No purchase bills found.</div>';
 list.forEach(p=>{const v=vendorById(p.vendorId);const r=document.createElement("div");r.className="history-row";r.innerHTML=`<div><div class="history-title">${esc(v?.name||p.vendorName||"Vendor")} • ${esc(p.invoiceNo||"No invoice")}</div><div class="muted">${esc(p.date)} • Total ${money(p.total)} • Paid ${money(p.paid)} • Pending ${money(Number(p.total)-Number(p.paid))}</div></div><button class="secondary viewPurchase">View</button>`;r.querySelector(".viewPurchase").onclick=()=>showPurchaseDetail(p);ph.appendChild(r)});
}
function showPurchaseDetail(p){
 const v=vendorById(p.vendorId);
 let lines=(p.items||[]).map((x,i)=>`${i+1}. ${x.name} — ${x.qty} ${x.unit||""} × ₹${Number(x.rate||0).toFixed(2)}`).join("\n");
 alert(`Vendor: ${v?.name||p.vendorName}\nInvoice: ${p.invoiceNo||"-"}\nDate: ${p.date}\n\n${lines||"No item details extracted."}\n\nTotal: ${money(p.total)}\nPaid: ${money(p.paid)}\nPending: ${money(Number(p.total)-Number(p.paid))}\n${p.attachment?.name?"Attachment: "+p.attachment.name:""}`);
 if(p.attachment?.id && window.Android?.openPurchaseAttachment) window.Android.openPurchaseAttachment(p.attachment.id,p.attachment.mime||"application/pdf");
}
function parsePurchaseText(text){
 const raw=String(text||"").replace(/\r/g,"");
 const clean=raw.replace(/[ \t]+/g," ").replace(/\n{3,}/g,"\n");
 const lines=clean.split("\n").map(s=>s.trim()).filter(Boolean);

 const invoiceNo=(clean.match(/(?:Invoice\s*(?:No|Number)|Inv\.?\s*No\.?)\s*[:#-]?\s*([A-Z0-9][A-Z0-9\/-]+)/i)||[])[1]||"";
 const date=(clean.match(/(?:Invoice\s*Date|Dated|Date)\s*[:\-]?\s*(\d{1,2}[\/-][A-Za-z]{3,9}[\/-]\d{2,4}|\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4})/i)||[])[1]||"";

 let total=0;
 const totalPatterns=[
   /Collectable\s+Amount[\s\S]{0,300}?\b(\d{4,7}\.\d{2})\b\s*$/im,
   /(?:Grand\s+Total|Invoice\s+Total|Total\s+Amount)\s*[:\-]?\s*₹?\s*([0-9,]+\.\d{2})/i
 ];
 for(const re of totalPatterns){const m=clean.match(re);if(m){total=Number(m[1].replace(/,/g,""));if(total)break;}}

 let vendorName="";
 const idx=lines.findIndex(x=>/tax invoice/i.test(x));
 if(idx>=0){
   for(let j=idx+1;j<Math.min(idx+8,lines.length);j++){
     const candidate=lines[j].replace(/\s*\(\d+\)\s*$/," ").trim();
     if(/private limited|limited|traders|distributors|agency|enterprises/i.test(candidate)){vendorName=candidate;break;}
   }
 }
 if(!vendorName){
   vendorName=lines.find(x=>/private limited|limited|traders|distributors|agency|enterprises/i.test(x))||"";
 }

 const gstin=(clean.match(/GSTIN\s*\/??\s*UIN\s*[: ]\s*([0-9A-Z]{15})/i)||[])[1]||
             (clean.match(/GSTIN\s*[: ]\s*([0-9A-Z]{15})/i)||[])[1]||"";
 const phone=(clean.match(/(?:Phone|Telephone)\s*[: ]\s*(\d{10})/i)||[])[1]||"";
 const buyerLine=lines.findIndex(x=>/^Buyer \(Billing Address\)/i.test(x));
 const buyer=buyerLine>=0&&lines[buyerLine+1]?lines[buyerLine+1]:"";

 const items=[];
 // Vendor invoice pattern: ITEM CODE - DESCRIPTION, followed by a row containing HSN, MRP, QTY, RATE.
 const codeRe=/(\d{5,8})\s*[-–]\s*([^\n]+)/g;
 const matches=[...raw.matchAll(codeRe)];
 for(let i=0;i<matches.length;i++){
   const code=matches[i][1];
   let block=matches[i][2]||"";
   const start=matches[i].index+matches[i][0].length;
   const end=i+1<matches.length?matches[i+1].index:Math.min(raw.length,start+1000);
   block+=(raw.slice(start,end));
   block=block.replace(/\n+/g," ").replace(/\s+/g," ").trim();

   // Don't treat GST summary or other numeric sections as items.
   if(!/\b(?:340|380|330|210|190)\d{5}\b/.test(block) && !/\b\d{8}\b/.test(block)) continue;

   const qtyMatch=block.match(/\b(\d+(?:\.\d+)?)\s*(EA|CA|PK|UN|PCS?|BOX|BOTTLE)\b/i);
   if(!qtyMatch) continue;
   const qty=qtyMatch[1];
   const unit="piece";
   const after=block.slice(qtyMatch.index+qtyMatch[0].length);
   const rateMatch=after.match(/\b(\d+(?:\.\d{1,2})?)\b/);
   const rate=rateMatch?Number(rateMatch[1]):0;

   let name=(matches[i][2]||"").trim();
   name=name.replace(/\s+/g," ").replace(/\s+$/g,"");
   if(name && rate) items.push({name,itemCode:code,qty,unit,rate});
 }

 // Remove duplicates caused by OCR/table header artifacts.
 const seen=new Set();
 const uniqueItems=items.filter(x=>{const k=x.itemCode+"|"+x.name;if(seen.has(k))return false;seen.add(k);return true;});
 return {vendorName,invoiceNo,date,total,buyer,gstin,phone,items:uniqueItems,rawText:raw,rawLength:raw.trim().length};
}
function applyPurchaseImport(data){
 const p=parsePurchaseText(data.text||"");
 const rawCount=Number(p.rawLength||String(data.text||"").trim().length||0);
 // Render first so the vendor list is populated, then apply extracted values.
 renderPurchasing();
 if(p.vendorName){
   let v=state.vendors.find(x=>String(x.name||"").toLowerCase()===p.vendorName.toLowerCase());
   if(!v){v={id:purchaseId("VEN"),name:p.vendorName,phone:p.phone||"",gstin:p.gstin||"",address:"",openingBalance:0};state.vendors.push(v);}
   else { if(p.phone&&!v.phone)v.phone=p.phone; if(p.gstin&&!v.gstin)v.gstin=p.gstin; }
   renderVendorsSelects();
   $("purchaseVendor").value=v.id;
 }
 $("purchaseInvoice").value=p.invoiceNo||"";
 const d=toInputDate(p.date);if(d)$("purchaseDate").value=d;
 $("purchaseTotalInput").value=p.total||"";
 $("purchasePaidInput").value="0";updatePurchasePending();
 $("purchaseItemsText").value=(p.items||[]).map(x=>`${x.name} ${x.qty} ${x.unit||"piece"} ${x.rate||""}`.trim()).join("\n");
 state.purchaseAttachment={id:data.attachmentId,name:data.fileName,mime:data.mime};
 $("purchaseAttachmentBox").innerHTML=`Attached: <b>${esc(data.fileName)}</b> • OCR finished. ${p.items?.length||0} item(s) extracted from ${rawCount} OCR characters.`;
 $("purchaseImportStatus").textContent=p.error?`Import completed with a warning: ${esc(p.error)}`:"Bill imported successfully. Please review the extracted fields before saving.";
 save();
}
window.onPurchaseImportProgress=function(message){
 const el=$("purchaseImportStatus"); if(el) el.textContent=String(message||"Reading vendor bill...");
};
window.onPurchaseImportError=function(message){
 const el=$("purchaseImportStatus"); if(el) el.textContent="Could not read the vendor bill: "+String(message||"Unknown error");
 alert("Purchase bill import failed.\n\n"+String(message||"Please try another PDF/photo."));
};
window.onPurchaseImportResultBase64=function(encoded){
 try{
   const bin=atob(encoded); let s=""; for(let i=0;i<bin.length;i++)s+=String.fromCharCode(bin.charCodeAt(i));
   const json=decodeURIComponent(Array.prototype.map.call(s,c=>"%"+("00"+c.charCodeAt(0).toString(16)).slice(-2)).join(""));
   applyPurchaseImport(JSON.parse(json));
 }catch(e){ window.onPurchaseImportError(e.message); }
};
function toInputDate(s){
 if(!s)return "";
 const m=String(s).match(/(\d{1,2})[\/-]([A-Za-z]{3}|\d{1,2})[\/-](\d{2,4})/);
 if(!m)return "";
 let mon=isNaN(Number(m[2]))?({jan:1,feb:2,mar:3,apr:4,may:5,jun:6,jul:7,aug:8,sep:9,oct:10,nov:11,dec:12}[m[2].slice(0,3).toLowerCase()]||0):Number(m[2]);
 let y=Number(m[3]);if(y<100)y+=2000;
 return mon?`${y}-${String(mon).padStart(2,"0")}-${String(m[1]).padStart(2,"0")}`:"";
}
function updatePurchasePending(){const t=Number($("purchaseTotalInput").value||0),p=Number($("purchasePaidInput").value||0);$("purchasePendingInput").value=Math.max(0,t-p).toFixed(2)}
function savePurchase(){
 const vendorId=$("purchaseVendor").value, vendor=vendorById(vendorId);
 if(!vendor){alert("Select a vendor.");return}
 const total=Number($("purchaseTotalInput").value||0),paid=Number($("purchasePaidInput").value||0);
 if(total<=0){alert("Enter purchase total.");return}
 const items=[];
 String($("purchaseItemsText").value||"").split(/\r?\n/).map(x=>x.trim()).filter(Boolean).forEach(line=>{const p=parseQuickListLine(line);if(p&&!p.error)items.push(p)});
 const rec={id:purchaseId(),vendorId,vendorName:vendor.name,invoiceNo:$("purchaseInvoice").value.trim(),date:$("purchaseDate").value||today(),total,paid:Math.min(paid,total),pending:Math.max(0,total-paid),items,notes:$("purchaseNotes").value.trim(),attachment:state.purchaseAttachment||null};
 state.purchases.unshift(rec);state.purchaseAttachment=null;save();
 $("purchaseInvoice").value="";$("purchaseTotalInput").value="";$("purchasePaidInput").value="";$("purchasePendingInput").value="";$("purchaseItemsText").value="";$("purchaseNotes").value="";$("purchaseAttachmentBox").textContent="";
 $("purchaseImportStatus").textContent="Purchase saved.";
 renderPurchasing();
}
function openVendorModal(){ $("vendorName").value="";$("vendorPhone").value="";$("vendorGstin").value="";$("vendorAddress").value="";$("vendorModal").classList.remove("hidden")}
function saveVendor(){
 const name=$("vendorName").value.trim();if(!name){alert("Enter vendor name.");return}
 state.vendors.unshift({id:purchaseId("VEN"),name,phone:$("vendorPhone").value.trim(),gstin:$("vendorGstin").value.trim(),address:$("vendorAddress").value.trim(),openingBalance:0});
 save();$("vendorModal").classList.add("hidden");renderPurchasing();
}
function savePayment(){
 const vendorId=$("paymentVendor").value,amount=Number($("paymentAmount").value||0);
 if(!vendorId||amount<=0){alert("Select vendor and enter amount.");return}
 state.vendorPayments.unshift({id:purchaseId("PAY"),vendorId,date:$("paymentDate").value||today(),amount,mode:$("paymentMode").value,note:$("paymentNote").value.trim()});
 save();$("paymentModal").classList.add("hidden");$("paymentAmount").value="";$("paymentNote").value="";renderPurchasing();
}
$("purchaseImportBtn").onclick=()=>{if(window.Android?.pickPurchaseDocument)Android.pickPurchaseDocument();else alert("Purchase document import is available in the Android APK.");};
$("purchaseSampleBtn").onclick=async()=>{try{const r=await fetch("sample_vendor_invoice.pdf");const blob=await r.blob();if(window.Android?.pickPurchaseDocument)alert("For the sample, please use Upload Bill / PDF and select the supplied sample invoice from your phone.");else alert("Open the sample invoice with Upload Bill / PDF.")}catch(e){alert("Use Upload Bill / PDF to import the sample invoice.")}};
$("savePurchaseBtn").onclick=savePurchase;
$("purchaseTotalInput").oninput=updatePurchasePending;$("purchasePaidInput").oninput=updatePurchasePending;
$("addVendorBtn").onclick=openVendorModal;$("vendorCancel").onclick=()=>$("vendorModal").classList.add("hidden");$("vendorSave").onclick=saveVendor;
$("addPaymentBtn").onclick=()=>{$("paymentDate").value=today();$("paymentModal").classList.remove("hidden")};$("paymentCancel").onclick=()=>$("paymentModal").classList.add("hidden");$("paymentSave").onclick=savePayment;
$("vendorRefreshBtn").onclick=renderPurchasing;$("purchaseSearch").oninput=renderPurchasing;
$("purchaseDate").value=today();
function renderProducts(){const list=$("productList");list.innerHTML="";state.products.forEach((p,i)=>{const r=document.createElement("div");r.className="product-row";r.innerHTML=`<div><div class="product-name">${esc(p.name)}</div><div class="muted">₹${Number(p.rate).toFixed(2)} / ${esc(p.unit||"kg")}</div></div><div><button class="secondary edit">Edit</button> <button class="danger del">Delete</button></div>`;r.querySelector(".edit").onclick=()=>openProduct(i);r.querySelector(".del").onclick=()=>{if(confirm("Delete this product?")){state.products.splice(i,1);save();renderProducts()}};list.appendChild(r)})}
$("addProductBtn").onclick=()=>openProduct(-1);function openProduct(i){editingProduct=i;$("modalTitle").textContent=i<0?"Add Product":"Edit Product";$("modalName").value=i<0?"":state.products[i].name;$("modalRate").value=i<0?"":state.products[i].rate;$("modalUnit").value=i<0?"kg":(state.products[i].unit||"kg");$("modal").classList.remove("hidden")}
$("modalCancel").onclick=()=>$("modal").classList.add("hidden");$("modalSave").onclick=()=>{const name=$("modalName").value.trim(),rate=+$("modalRate").value;if(!name||rate<0){alert("Enter a product and rate.");return}const unit=$("modalUnit").value||"kg";if(editingProduct<0)state.products.push({name,rate,unit});else state.products[editingProduct]={name,rate,unit};save();$("modal").classList.add("hidden");renderProducts();renderDatalist()};
function renderDatalist(){let dl=document.getElementById("productNames");if(dl)dl.remove();dl=document.createElement("datalist");dl.id="productNames";state.products.forEach(p=>{let o=document.createElement("option");o.value=p.name;dl.appendChild(o)});document.body.appendChild(dl)}
renderDatalist();renderCustomerDatalist();
function renderHistory(){const q=$("billSearch").value.toLowerCase(),list=$("historyList");list.innerHTML="";const bills=state.bills.filter(b=>JSON.stringify(b).toLowerCase().includes(q));if(!bills.length){list.innerHTML='<div class="muted">No bills found.</div>';return}bills.forEach(b=>{const r=document.createElement("div");r.className="history-row";r.innerHTML=`<div><div class="history-title">${esc(b.billNo)} • ${esc(b.customer)}</div><div class="muted">${b.date.split("-").reverse().join("/")} • ${b.items.length} item(s) • ${money(b.total)}</div></div><button class="secondary">View</button>`;r.querySelector("button").onclick=()=>{renderBill(b);showPage("preview")};list.appendChild(r)})}
$("billSearch").oninput=renderHistory;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;$("installBtn").classList.remove("hidden")});$("installBtn").onclick=async()=>{if(deferredInstall){deferredInstall.prompt();deferredInstall=null;$("installBtn").classList.add("hidden")}};
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));

function renderSales(){
 const selected=$("salesDate").value||today();
 const dayBills=state.bills.filter(b=>b.date===selected);
 const dayTotal=dayBills.reduce((s,b)=>s+Number(b.total||0),0);
 $("salesTotal").textContent=money(dayTotal);
 $("salesBills").textContent=String(dayBills.length);
 $("salesAverage").textContent=money(dayBills.length?dayTotal/dayBills.length:0);
 const list=$("salesList");list.innerHTML="";
 if(!dayBills.length){list.innerHTML='<div class="muted">No bills for this date.</div>';}
 else dayBills.forEach(b=>{const r=document.createElement("div");r.className="history-row";r.innerHTML=`<div><div class="history-title">${esc(b.billNo)} • ${esc(b.customer)}</div><div class="muted">${b.items.length} item(s) • ${money(b.total)}</div></div><button class="secondary">View</button>`;r.querySelector("button").onclick=()=>{renderBill(b);showPage("preview")};list.appendChild(r)});
 const ym=selected.slice(0,7);
 const monthBills=state.bills.filter(b=>String(b.date||"").startsWith(ym));
 $("monthSales").textContent=money(monthBills.reduce((s,b)=>s+Number(b.total||0),0));
 $("monthBills").textContent=String(monthBills.length);
}
$("salesDate").value=today();
$("salesDate").onchange=renderSales;

// Backup / restore is handled by the Android native layer so the ZIP can include the SQLite DB and invoice attachments.
if($("backupNowBtn")) $("backupNowBtn").onclick=()=>{
  if(window.Android?.backupData){$("backupStatus").textContent="Creating backup...";Android.backupData();}
  else $("backupStatus").textContent="Backup is available in the Android APK.";
};
if($("restoreBackupBtn")) $("restoreBackupBtn").onclick=()=>{
  if(!confirm("Restore will replace the current local shop data on this phone. Continue?"))return;
  if(window.Android?.restoreData){$("backupStatus").textContent="Choose your backup ZIP...";Android.restoreData();}
  else $("backupStatus").textContent="Restore is available in the Android APK.";
};
