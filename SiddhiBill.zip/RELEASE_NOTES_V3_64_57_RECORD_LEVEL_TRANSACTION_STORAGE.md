# SiddhiBill v3.64.57 — Record-level transaction persistence

## Performance changes
- Added an indexed SQLite `transaction_records` table for sales bills, purchase bills, and inventory movements.
- Normal bill generation and bill updates now upsert only the affected sales-bill record.
- Purchase creation and purchase edits now upsert only the affected purchase record.
- Existing transaction JSON arrays are migrated into rows with SQLite JSON1 in a single set-based operation. The legacy state keys are removed from the live database after migration.
- Vendor summary, vendor transaction, and purchase-history page queries now read the normalized purchase records.
- Inventory bill posting reverses the previous source movements and inserts only the new source movements. Product stock/weighted-average summaries are calculated in SQLite for affected products; the bill path no longer needs to load the complete inventory movement array.
- Inventory stock recalculation is batched per source transaction rather than rebuilt once per line item.

## Backup and restore compatibility
- Owner shop-setting updates now read/write only the settings key instead of loading and rewriting all transaction history.
- Both manual and scheduled automatic backups create a compatibility copy with the legacy JSON arrays, while leaving the live normalized database untouched.
- The live database remains at SQLite `user_version=1`; the new table is ensured additively in `onOpen` so older app builds do not reject the database as a downgrade.
- Backup creation builds a separate compatibility copy, reconstructs the legacy `pksBills`, `pksPurchases`, and `pksInventoryMovements` JSON state keys, and removes the normalized table and migration markers from that copy. The live database is not rewritten for this compatibility step.
- New builds can restore that backup and migrate the legacy arrays again on first transaction write. Older builds can continue to read and update the legacy JSON arrays.

## Version
- `versionName`: 3.64.57
- `versionCode`: 230
- Diagnostic build label and `app.js` cache-busting query updated to 3.64.57.

## Validation performed
- JavaScript syntax check passed.
- Focused purchase calculation, purchase editor, vendor lazy-entry, transaction history, backup-flow, and new record-persistence source regression tests passed.
- SQLite migration was exercised on a separate copy of the supplied synthetic database: 10,000 sales bills, 10,000 purchase bills, and 249,162 inventory movements were migrated with no count loss; SQLite integrity check passed.
- Vendor totals and purchase item search queries returned expected results on the migrated test database.
- Inventory source reversal, replacement insert, and weighted-average summary were exercised on the migrated test database.
- No Android Gradle build or physical-device test was available in this environment. Build and device validation remain required before installing over live shop data.
