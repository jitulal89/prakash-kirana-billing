# SiddhiBill v3.64.7 — Purchase unit-price mode and editable buying rate

- Added a checkbox above Vendor Bill Quick List: “4th value is per-unit price”. Unchecked means the fourth field is line total; checked means line total is quantity × fourth field.
- Added an editable Buying Rate / Unit (before GST) field to each purchase draft item. Line totals recalculate from quantity, buying rate, tax rate and inclusive/exclusive setting.
- GST %, HSN, taxable amount and GST amount fields are hidden when the purchase is marked non-taxable. The calculation summary omits tax-only rows for non-taxable purchases.
- The new checkbox defaults to unchecked. Existing database name, application ID and local-storage keys are unchanged.
- Validation: JavaScript syntax check and ZIP integrity check passed. Android Gradle build/device test not performed.
