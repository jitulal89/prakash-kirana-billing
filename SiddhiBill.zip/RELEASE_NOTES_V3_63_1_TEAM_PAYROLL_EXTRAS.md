# SiddhiBill v3.63.1 — Team Payroll and Extra Earnings

- Added configurable scheduled weekly-off days per team member (0–3 days/week; default 1).
- Monthly salary calculation now uses expected working days (calendar days minus estimated scheduled weekly offs). Attendance below expected working days prorates the salary; attendance beyond expected working days adds extra-day pay using monthly salary divided by expected working days.
- Added a Salary / Advance Paid vs Commission / Extra Work Earned entry type in the Team payment ledger. Extra earnings increase the amount payable and are not incorrectly counted as already paid.
- Team payroll summary and team report calculations include extra earnings; the ledger labels earnings separately from payments.

## Validation
Source-level JavaScript syntax and ZIP integrity checks only. No APK build or physical-device test was performed.
