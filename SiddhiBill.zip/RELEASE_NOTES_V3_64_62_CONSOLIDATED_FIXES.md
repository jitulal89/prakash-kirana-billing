# SiddhiBill v3.64.62 — Consolidated Performance Fixes

Baseline: SiddhiBill v3.64.61  
Version code: 235  
Application ID: `com.siddhibill.app`  
Java namespace: `com.dukaanbill.app`  
Database: `dukaanbill.db`

## Fix 1 — Customer Bill and Purchase Bill View/Edit
- Customer bill edit now retains and uses the selected bill record instead of searching the lazy full sales array when returning to Billing or saving an edit.
- Purchase edit retains the selected purchase object; purchase updates no longer force-load the full purchase history merely to locate the prior record.
- Native record-level SQLite persistence remains the source of truth for changed bill and purchase records. Existing identifiers, shop scope, calculations, and inventory source replacement are retained.

## Fix 2 — Reports and Inventory
- Reports landing screen uses date-scoped sales queries and compact native customer-credit/service-due summaries instead of forcing full bill history into the WebView.
- Inventory opening uses saved product stock/weighted-average balances and does not rebuild balances by deserializing the complete movement history.
- Inventory movement history displays the latest 100 rows through SQLite.
- Inventory movement ledger report reads only the selected date range; summary/valuation/low-stock reports use saved product balances.
- Manual inventory movements persist directly to SQLite and update the product balance incrementally when the full movement array is still lazy.

## Fix 3 — Profit & Loss and GST Compliance
- P&L retrieves sales bills and sale inventory movements for the selected date range and shop.
- GST Compliance retrieves tax invoices for the selected month and obtains the latest tax invoice date through a native SQLite lookup.
- Existing GST calculations, report exports, offline operation, and browser fallback paths are retained.

## Validation
- JavaScript syntax check passed.
- Consolidated v3.64.62 targeted assertions passed.
- Profit & Loss regression passed.
- Report source assertions passed.
- Service due report regression passed.
- Vendor native summary/pagination regression passed.
- Android Gradle build and physical-device runtime test were not run in this environment; run the supplied source through GitHub Actions before installing over the existing app. Do not uninstall or clear app data.
