# SiddhiBill v3.63.9 — A4/A6 PDF Header Alignment

- Updated A4/A6 bill PDF header when all Print Shop Details options are unchecked: customer details are left-aligned and invoice/cash details (including document title) are right-aligned in a compact two-column layout.
- When only Print Shop Name is enabled, the shop name appears above the customer details in the left column with clear spacing; invoice/cash details remain right-aligned in the right column.
- Other paper sizes and thermal printing retain the existing header layout.
- Version updated to 3.63.9 (versionCode 189).

Validation: JavaScript syntax check and ZIP integrity check. No APK build or physical-device print test was performed.
