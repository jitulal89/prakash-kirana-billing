# SiddhiBill v3.62.1 — Salesperson Selection and Monthly Sales Report

## Changes
- Added an optional Sales person selector to Billing. It appears only when at least one active Team Management member has "Include in sales reports and Billing salesperson list" enabled.
- Added a per-team-member sales reporting toggle in Team Management. It defaults off, so sales reporting and the Billing selector stay hidden until explicitly enabled.
- Saved salesperson ID and name on each generated/updated bill, allowing historical reports to remain associated with the selected person.
- Added a Team Management sales report with editable From/To dates. Defaults to the first day of the current month through today (e.g. 1 Oct–27 Oct).
- Report totals use bill final totals, are scoped to the active shop, sorted highest sales first, and show bill counts and overall sales total.
- Preserved existing team attendance/payroll, broker commission, estimate, billing and backup/sync data structures.
- Version updated to 3.62.1 (versionCode 171).

## Validation
- JavaScript syntax check passed with Node.js.
- Verified all new HTML IDs referenced by JavaScript exist.
- Verified version metadata and ZIP integrity.
- No Android APK build or physical-device test was performed.
