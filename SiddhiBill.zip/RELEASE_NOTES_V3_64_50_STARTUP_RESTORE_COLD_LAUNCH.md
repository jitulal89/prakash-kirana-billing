# SiddhiBill v3.64.50 – Startup, Restore and Cold-launch Reliability

Base: v3.64.49 Startup Performance Optimization
Version code: 223

## Changes
- Removed automatic Payment Transactions report rendering from startup and normal Reports refresh.
- Added an explicit **Load Payment Transactions** action. It loads the purchase history only when requested; Excel/PDF export continues to use the same report data path.
- Report date changes reset the explicit load action so the next request uses the selected date range.
- Restore now performs a fresh navigation to the bundled app page after the database has been installed and validated. Restored owner-dashboard data is applied from WebView `onPageFinished`, replacing the fragile fixed 900 ms delay.
- Removed full WebView cache clearing on every app launch. Bundled `file://` assets are part of the installed APK and the HTML script URL remains versioned.
- Updated startup diagnostics and asset cache-busting version to 3.64.50.

## Data safety
- No database schema changes.
- No sales, purchase, customer, vendor, product, payment, or attachment records are intentionally deleted or rewritten by these changes.
- Backup ZIP format and restore validation/rollback logic are unchanged.

## Validation
- JavaScript syntax and ZIP integrity checked.
- Android Gradle build and physical-device restore/cold-launch tests are not performed in this environment. Please test with a fresh backup copy before relying on restore in production.
