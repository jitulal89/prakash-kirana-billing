# SiddhiBill v3.64.53 — Vendor database summaries and purchase pagination

Base: v3.64.52. Version code: 226.

## Included
- Retains the v3.64.52 ledger PDF trailing-blank-page correction.
- Vendor Management landing totals are populated from compact SQLite JSON aggregates; no purchase array is transferred to WebView for those totals.
- Vendor Accounts calculates purchase, paid and pending amounts per vendor from SQLite aggregates.
- Vendor Payments renders the payment ledger without loading purchase bills.
- Purchase History requests one page (50 records) from SQLite; count, date ordering and search are applied natively. Search includes invoice/vendor/date/id and item name/HSN/barcode.
- If SQLite JSON functions are unavailable, the existing full-history path remains as a compatibility fallback. No transaction data is deleted or rewritten by the new queries.

## Notes
- Selecting a purchase for editing or opening a vendor's full transaction ledger can still load the complete purchase array because those legacy workflows expect mutable in-memory records.
- Android Gradle/device testing must be completed through the project's GitHub Actions/device workflow.
