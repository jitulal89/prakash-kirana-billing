# SiddhiBill v3.64.44 – Restore / Large Local State Safety Fix

## Changes
- Added bounded, chunk-based reads for native SQLite `app_state` values to avoid transferring the complete database state through one WebView JavaScript bridge response.
- Added fail-closed startup handling. If native SQLite state cannot be read or parsed, SiddhiBill displays an explicit warning and blocks normal state saves.
- Disabled legacy localStorage-to-SQLite migration when the native Android bridge is available. This prevents an empty/failed native read from silently writing stale browser storage over a restored database.
- Prevented startup cleanup/migration writes from running after a native state-load failure.

## Validation
- JavaScript syntax check (`node --check`) passed for `app.js`.
- ZIP packaging and source inspection performed.
- Android Gradle build was not run: this source package does not include `gradlew`, and Gradle is not installed in the execution environment.
- Device restore testing has not been performed. Build and test through the project's GitHub Actions workflow before installing.

## Notes
- Existing package ID, Java namespace, SQLite database name, state keys, and offline architecture are unchanged.
- The existing native save operation still sends the save payload as one bridge call. If large-dataset saving remains a bottleneck after the chunked-read fix, a separate chunked-write transaction should be implemented and tested.
