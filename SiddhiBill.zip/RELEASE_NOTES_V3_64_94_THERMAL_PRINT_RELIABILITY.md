# SiddhiBill v3.64.94 — 80mm Thermal Print Reliability

## Changes
- Corrected the native 80mm transaction-history renderer to identify credit sales from either the transaction label or payment mode.
- Credit-sale Paid values now use only explicit linked/partial payment fields and default to zero; they no longer fall back to the invoice amount.
- Recent customer bill payloads now include explicit payment mode and bill total metadata for native thermal rendering.
- Added a single-job lock to prevent overlapping direct Bluetooth thermal print jobs.
- Added paced Bluetooth output in bounded, flushed blocks to reduce overflow on small printer buffers.
- Added drain intervals after the Last 5 Transactions raster and UPI QR output before continuing the receipt.

## Preserved
- Existing bill HTML preview and A4 PDF paths were not changed.
- Existing 58mm/80mm layout settings and QR configuration were retained.
- App package, namespace, database, and stored data keys were not changed.

## Validation
- `node --check app/src/main/assets/www/app.js` passed.
- `node test_v36494_thermal_reliability.js` passed.
- `node test_v36493_paid_amount_thermal_font.js` passed.
- Android Gradle compilation was not run because this source workspace does not include `gradlew` and Gradle is not installed in the environment.
- Physical Bluetooth printer validation is still required, especially repeated 80mm prints with Last 5 Transactions and UPI QR enabled.
