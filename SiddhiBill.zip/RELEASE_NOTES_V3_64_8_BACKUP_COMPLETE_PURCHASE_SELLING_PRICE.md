# SiddhiBill v3.64.8 — Complete Backup and Purchase Selling Price

## Backup improvements
- Manual and automatic backup ZIPs retain the complete SQLite database and serialized app state.
- Added `settings/settings.json` as a directly readable snapshot of the current app settings.
- Added `data/modules_snapshot.json` for products, inventory movements, purchases, vendors, vendor payments, team members/attendance/payments, brokers/commissions/payments, estimates, GST compliance, sales bills, customers and customer payments.
- Added/expanded backup manifest and backup information so included data is auditable.
- Existing database filename, app ID and local-storage keys are unchanged.

## Purchase form
- Added editable `Selling Price / Unit` to each purchase draft item.
- Existing products load selling price from product master (`rate`, with legacy `sellingPrice` fallback).
- New products default to 0.
- Saving a purchase writes the entered selling price back to product master while keeping purchase buying cost (`lastPurchaseCost`) separate.

## Validation
- JavaScript syntax and ZIP integrity checks performed.
- Android Gradle build and physical-device backup/restore testing not performed in this environment.
