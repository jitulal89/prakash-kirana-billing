# SiddhiBill v3.64.64 — Vendor Management Root-Cause Analysis

## Scope
This release targets Vendor Management and Purchase Bills on top of v3.64.63. It does not change the app ID, Java namespace, database name, database version, shop identity, or existing stored purchase/vendor records.

## Findings in v3.64.63

### 1. Purchase history and vendor screens had a full-history fallback
The normal Android path uses `loadPurchaseHistoryPage()` and `loadVendorSummary()`, but if the native vendor summary returned `supported:false` or failed, `renderPurchasing()` fell through to `normalizePurchaseHistorySchema()` and `renderPurchasingFallback()`. Those functions access `state.purchases`, which triggers the lazy transaction getter and reads/parses the complete `pksPurchases` JSON array in the WebView thread. `renderPurchasingFallback()` also filters and sorts all purchase records and their item arrays. On a large database this can block the UI and make Edit/View appear unresponsive.

**Fix:** Android now stays on bounded native queries if the summary is unavailable. It shows an explicit summary/history-unavailable message instead of falling back to a full purchase-history load. The browser-only fallback remains for non-Android use.

### 2. Vendor Transactions transferred every full purchase record for the selected vendor
The old `loadVendorPurchasesJson(vendorId)` returned complete `record_json` values, including every invoice item, OCR text, tax breakdown and other nested data, for every purchase belonging to that vendor. The WebView then built the transaction list from those full records. This was much more data than a transaction ledger needs and could become slow for a vendor with many invoices.

**Fix:** The native query now returns only compact ledger fields: purchase ID, vendor ID/name, invoice number, date, total, paid and payment mode. It is scoped to the selected vendor and current shop. It recognizes `vendorId`, `supplierId`, `partyId`, and legacy supplier-name fields. Purchase item/OCR payloads are not sent to the transaction-history screen.

### 3. Vendor Transaction “View Bill” used the sales-bill lookup
The shared transaction-history renderer treated every non-payment transaction as a sales bill. Clicking View Bill queried `pksBills` using the purchase invoice number. Vendor purchase records are stored in `pksPurchases`, not `pksBills`, so the selected purchase could not be found. This is a functional routing bug, not a missing purchase record.

**Fix:** Vendor purchase rows now show **View Purchase** and resolve the purchase by its exact purchase record ID from `pksPurchases`. Sales transactions continue to use the sales-bill lookup.

### 4. Edit/View/PDF relied on a paginated row object rather than re-reading the selected record
Purchase history rows are intentionally compact/paged. The old edit/view/PDF handlers used the row object directly. That object could be stale or incomplete after a record update, restored backup, or compatibility migration.

**Fix:** A shared `resolvePurchaseRecord()` first retrieves the exact record from SQLite using `loadTransactionRecord("pksPurchases", id)`. Edit, View and PDF use the fresh record. The editor retains the selected record so an update replaces the same purchase ID rather than creating a new invoice.

## Purchase-history call-site audit

| Code path | v3.64.63 behaviour | v3.64.64 behaviour |
|---|---|---|
| `renderPurchasing()` | Native summary/page normally; full-history fallback on native failure | Native summary/page; no full-history fallback on Android |
| `renderPurchasingFallback()` | Reads `state.purchases`, totals and filters the full array | Kept only for browser/non-native fallback |
| `normalizePurchaseHistorySchema()` | Normalizes the complete purchase array | Not invoked by Android failure fallback |
| `vendorBalance()` | Filters all loaded purchase records per vendor | Not used on native summary path |
| Purchase history list | Native paged query when available | Remains paged; selected record fetched by ID on action |
| Vendor Transactions | Loads full purchase JSON for one vendor | Loads compact transaction fields for selected vendor/shop |
| Vendor Ledger | Native date-scoped query with browser fallback | Existing behaviour retained |
| Backup/restore and sync | Intentionally process complete datasets | Unchanged; these are explicit bulk-data operations |

## Files changed
- `app/src/main/assets/www/app.js`
- `app/src/main/assets/www/index.html` (cache-buster)
- `app/src/main/java/com/dukaanbill/app/LocalDatabase.java`
- `app/src/main/java/com/dukaanbill/app/MainActivity.java`
- `app/build.gradle`

## Validation performed
- JavaScript syntax check: passed.
- New v3.64.64 vendor workflow assertions: passed.
- v3.64.63 customer workflow regression assertions: passed.
- Existing vendor native summary/pagination assertions: passed.
- Existing report source assertions: passed.
- SQLite JSON1 query smoke test: passed for current vendor ID, legacy `supplierId`, shop scoping and compact result fields.
- ZIP integrity check: to be performed on final archive.

Some historical tests are not usable as-is because they assert old version numbers or require an invoice PDF fixture that is not present in this environment. Android Gradle compilation and physical-device testing were not available here; the GitHub Actions build and on-device test remain required.

## Suggested device verification
1. Open Vendor Management with a large purchase history; verify the screen opens without loading all invoices.
2. Open Purchase History; View an existing purchase and confirm all line items and totals.
3. Edit an existing purchase, change a harmless field, tap Update Purchase, leave and reopen it; verify the same purchase ID/invoice is updated.
4. Open its PDF and verify seller, items, tax and totals.
5. Open a vendor's Transactions; verify purchase and payment rows appear and balances are calculated.
6. Tap View Purchase from a vendor transaction; verify it opens that purchase rather than searching sales bills.
7. Repeat for a vendor with older records using supplierId/name fields if present.

No uninstall, app-data clearing, or database reset is required.
