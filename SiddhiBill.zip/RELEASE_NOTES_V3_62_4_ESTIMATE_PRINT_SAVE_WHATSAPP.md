# SiddhiBill v3.62.4 — Estimate print, save and WhatsApp fixes

- Estimate 58 mm, 80 mm, A6 and A4 print/PDF output now uses a consistent billing-inspired layout with the heading **ESTIMATE**, item descriptions, HSN/SAC, quantities, rates, GST, discount and totals.
- Added a checkbox to include or omit the shop header (shop name, logo, tagline and shop details) on estimate print/PDF and WhatsApp PDF output.
- Repeated Save on an estimate now updates the same estimate and preserves its estimate number. The form stays attached to that estimate until **New Estimate** is pressed.
- Estimate WhatsApp action generates and attaches a PDF and includes item-wise details, quantities, rates, line amounts, optional HSN/SAC, GST, discount, total and notes in the message.
- Added Android bridge methods for estimate print media sizes and PDF attachment sharing.

Validation: JavaScript syntax and source ZIP integrity checks completed. Android APK build and physical-device testing have not been performed.
