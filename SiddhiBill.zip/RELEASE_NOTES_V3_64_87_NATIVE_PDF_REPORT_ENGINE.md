# SiddhiBill v3.64.87 — Shared Native PDF Report Pipeline

## Phase 1 — reusable PDF report engine
- Unified HTML report export through Android WebView `PrintDocumentAdapter`.
- Removed full-document `capturePicture()` and per-page bitmap slicing from the general report export path.
- Android print framework handles layout and pagination incrementally, avoiding full-report bitmap allocation.
- Retains existing Downloads/SiddhiBill save location, duplicate-file confirmation and open/share workflow.
- A4 portrait by default; GSTR-1 report uses A4 landscape.

## Phase 2 — GST Compliance and Team Member reports
- GST Compliance summary, GSTR-1 working report, and GSTR-3B working report use the shared native print pipeline.
- Team Member report uses the same shared pipeline.
- Team Member sections may flow across pages; table rows are kept together and table headers repeat where supported by WebView print layout.
- Corrected status messages so the app does not claim a PDF is saved before the user chooses Save as PDF.

## Validation
- JavaScript syntax and source-level routing checks performed.
- Android Gradle build and physical-device print/PDF validation remain required.
