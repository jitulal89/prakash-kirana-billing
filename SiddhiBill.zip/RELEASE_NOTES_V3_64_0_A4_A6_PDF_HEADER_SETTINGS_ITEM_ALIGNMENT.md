# SiddhiBill v3.64.0 — A4/A6 PDF Header and Item Header Fixes

## Changes
- Fixed the native A4/A6 PDF header path in `MainActivity.java` instead of relying on the HTML bill preview state.
- When all four saved shop-detail flags (`printShopName`, `printShopAddress`, `printShopMobile`, `printShopLogo`) are false, A4/A6 PDF headers now use two columns: customer details left-aligned and invoice/cash-memo details in the right column.
- When only `printShopName` is enabled and the other three shop-detail flags are false, the shop name is placed above the customer name with visible separation; invoice metadata remains in the right column.
- Tax invoice statutory information (shop GSTIN/FSSAI/state/supply when configured) is retained in the right column for compliance visibility.
- Removed the “Print Shop Details” and “Thermal Bill Display” cards from Settings. Existing saved flags remain in stored settings for compatibility with older installs; the removed toggles are no longer editable in Settings.
- Centered the A4/A6 PDF item-table `ITEM` heading within its own column and added fit-to-width text rendering to prevent it from intruding into adjacent columns. The repeated table heading on continuation pages uses the same alignment.
- Bumped app version to 3.64.0 (versionCode 190).

## Validation
- JavaScript syntax check passed.
- Checked that the removed settings controls are no longer referenced by Settings loading/saving code.
- ZIP integrity check passed after packaging.
- Android Gradle build and physical-device PDF printing were not run in this environment; please verify sample A4 and A6 PDFs on-device.
