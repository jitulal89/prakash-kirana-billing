# SiddhiBill v3.64.61 – Bill History and Vendor Ledger Performance

Version code: 234

## Fixes

1. Restored transaction arrays are migrated from legacy `app_state` JSON into `transaction_records` before chunk reads. This prevents a legacy-compatible restored backup from appearing empty when the normalized table has not yet been populated.
2. Sales Bill History now requests 50-row pages directly from SQLite. It no longer loads, parses, filters and sorts the complete 10,000+ bill history in the WebView just to display the first page. Search is performed against stored bill JSON.
3. Vendor Ledger now requests only the selected vendor's purchase invoices and vendor payments for the selected date window from SQLite. It avoids loading and building a PDF from every purchase invoice in JavaScript.
4. App version/cache-buster updated to 3.64.61 / versionCode 234.

## Backup size clarification

The supplied 23 MB ZIP contains a 228,417,536-byte SQLite database. Its legacy transaction arrays contain 10,000 sales bills, 10,000 purchase bills and 249,162 inventory movements. The compressed ZIP size is not a reliable record-count indicator; the database and JSON counts were inspected directly.

## Validation

- JavaScript syntax check: passed.
- Legacy transaction migration SQL exercised against the supplied backup: 10,000 sales, 10,000 purchases, 249,162 inventory movements.
- Sales SQL pagination: 50 rows returned on page 1 with total 10,000.
- Vendor/date query: Test Supplier 007, October 2026 returned 25 invoices and 300 item rows from the supplied synthetic backup.
- ZIP integrity check: passed.

Android Gradle build and physical-device PDF/restore tests were not available in this environment.
