# SiddhiBill v3.63.7 — Billing Titles in Settings

- Added **Tax Invoice First Line / Title** to the Billing Details collapsible section, in the requested order.
- Billing Details order: Bill Prefix; Next Bill Number Start; Cash Invoice First Line / Title; Tax Invoice First Line / Title; Tax Invoice Prefix; Next Tax Invoice Number Start.
- Preserved the existing field ID and save binding.
- Version code: 187.

Validation: JavaScript syntax and ZIP integrity checks performed. APK build and physical-device testing not performed.
