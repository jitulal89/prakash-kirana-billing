# SiddhiBill v3.64.4 — A4/A6 PDF corrections

- Fixed shop-address rendering so wrapped lines are not prematurely cut off by an absolute Y-coordinate cutoff.
- Kept customer-address continuation lines aligned with the address value start, directly below the value rather than under the label; removed fixed-character truncation from wrapped address lines.
- Reduced ambiguity in invoice headers: taxable bills display `TAX INVOICE` and `INVOICE NO.`; cash bills display `CASH MEMO / BILL` and `BILL NO.`.
- Made the `PAYMENT:` label bold while keeping its value regular weight.
- Changed the A6 GST rate summary to a compact left-side panel beside the totals section, instead of taking a full-width row above totals. A4 layout is unchanged for this summary.

Validation performed: JavaScript syntax and ZIP integrity checks. Android Gradle build and physical-device PDF rendering were not performed.
