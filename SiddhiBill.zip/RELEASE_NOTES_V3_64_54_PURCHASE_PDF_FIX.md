# SiddhiBill v3.64.54 — Purchase Bill PDF Fix

Base: v3.64.53. Preserves vendor database summary/pagination and ledger PDF blank-page fixes.

Changes:
- Corrected purchase PDF item-table header text color so column labels are visible against the light header background.
- Replaced scientific-notation quantity formatting with readable decimal formatting (trailing zeros removed; e.g. 1000 remains 1000).
- Added spacing between Invoice Total and Paid/Balance lines to prevent visual collision.
- No database schema or transaction data changes.

Validation: source-level checks only; Android Gradle/device PDF validation remains pending.
