const fs = require('fs');
const js = fs.readFileSync('app/src/main/assets/www/app.js','utf8');
const java = fs.readFileSync('app/src/main/java/com/dukaanbill/app/MainActivity.java','utf8');
const assert = (v,m) => { if(!v) throw new Error(m); };
assert((js.match(/const paymentMode=String\(b\.paymentMode\|\|"Cash"\)\.trim\(\)\.toLowerCase\(\);const creditSale=paymentMode==="credit"\|\|paymentMode\.includes\("credit"\)/g)||[]).length===2,
  'Both customer transaction sources must normalize payment mode before classifying credit bills');
assert((js.match(/paymentMode:String\(b\.paymentMode\|\|"Cash"\)\.trim\(\)/g)||[]).length===2,
  'Transaction payload must carry normalized payment mode to native thermal renderer');
assert(js.includes('const paid=creditSale?Math.min(total,Math.max(0,linkedPaid)):total;'),
  'Recent history must show actual partial payments for credit bills and full paid total for non-credit bills');
assert(java.includes('private boolean isCreditSaleTransaction(JSONObject tr)'),
  'Thermal renderer must use shared credit classifier');
console.log('v3.64.95 credit thermal history regression checks passed');
