const fs=require('fs');
const s=fs.readFileSync('app/src/main/java/com/dukaanbill/app/MainActivity.java','utf8');
if(!s.includes('wrapLabeledAddress(customerAddress,p,Math.max(20,mid-left-16),labelW)')) throw new Error('A6 address must wrap first line after label while continuation starts at address block left');
if(!s.includes('drawText(c,p,trimText(addressLines.get(ai),35),addressX,cy)')) throw new Error('A6 continuation must start at left edge of address block');
if(!s.includes('wrapLabeledAddress(customerAddress,p,addressWidth,labelW)')) throw new Error('A4 address must wrap first line after label while continuation starts at address block left');
if(!s.includes('drawText(c,p,addressLines.get(ai),cx,cy)')) throw new Error('A4 continuation must start at left edge of address block');
if(s.includes('drawText(c,p,addressLines.get(ai),valueX,cy)')) throw new Error('Old hanging indent remains in A4 path');
console.log('PASS: A4/A6 address label appears once; continuation lines start at address block left edge and first line wraps within remaining width');
