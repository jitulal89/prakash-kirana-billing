# SiddhiBill v3.64.10 — Expense Management, Purchase Editing & Receipt Reporting

- Added a Home-page Expense Management module for rent, electricity, salaries, repairs, transport and other expenses. Supports date, category, description, amount, payment mode, optional payee/reference/notes, edit/delete and date filtering. Expenses are saved locally, shop-scoped, and included in sync bundles.
- Purchase bills now remain in edit/update mode after the first save. Further saves update the same purchase record; use the top New Bill button to start a different purchase. Existing attachments are preserved unless replaced.
- Added an explicit Received By field for partial payments on credit sales, with Cash/UPI/Card/Bank Transfer/Cheque and optional transaction/cheque details.
- Reports now summarize actual receipts by payment mode for bills in the selected period rather than counting the entire credit invoice as received. Credit Balance deducts recorded partial receipts.
- App version bumped to 3.64.10 (versionCode 199).

Validation: JavaScript syntax and ZIP integrity checks performed. Legacy regression scripts include hard-coded expectations for older version numbers; Android build and device testing were not performed.
