# SiddhiBill v3.64.19 — Inventory Navigation Reports

## Change
Added a dedicated **Inventory Reports** section inside the existing Inventory navigation page. No separate Home tile or new navigation item was added.

## Reports
- Stock Summary
- Stock Valuation
- Low Stock & Reorder
- Stock Movement Ledger

## Features
- Shop scope: Current Shop, All Shops, or a shop key represented in locally available inventory movements.
- Date range filters apply to Stock Movement Ledger.
- View report in the Inventory page.
- Download CSV for the selected report.
- Open a printable report and use Android Print / Save as PDF for PDF output.
- Reports use existing products and inventory movement data; no new database tables or migrations.

## Notes
- Current stock reports reflect current quantities and costs; date range is explicitly for the movement ledger.
- All Shops can only aggregate shop records available in this local dataset.
- The Stock Movement Ledger lists recorded signed movement quantities and recorded unit costs. Movement value is quantity multiplied by recorded unit cost and should not be interpreted as a full accounting valuation for negative-stock sequences.
