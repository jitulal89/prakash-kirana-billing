# SiddhiBill v3.64.25 — CSV and PDF Export Fixes

## Change 4 — Payment Transactions export
- Payment Transactions PDF now uses the native Android PDF generation/save/open bridge when running in the Android app.
- It saves directly under Downloads/SiddhiBill/Other-Reports/ (folder classification by report filename) and invokes the Android PDF app chooser.
- Browser fallback remains available outside Android.

## Change 5 — Profit & Loss export
- Profit & Loss PDF now uses the native Android PDF generation/save/open bridge rather than opening a separate browser window with a print button.
- It saves under Downloads/SiddhiBill/Profit-and-Loss/ and opens the Android PDF app chooser.
- Profit & Loss CSV continues through the native CSV save bridge.

## CSV header cleanup
- Removed UTF-8 BOM prefixes from generated CSV exports (including Payment Transactions, Profit & Loss, Inventory, and GST exports) because they were appearing as visible ï»¿ text in spreadsheet apps.
- CSV column labels and report data are otherwise unchanged.

## Validation
- JavaScript syntax check and ZIP integrity check performed.
- Android Gradle build/device verification not performed in this environment.
