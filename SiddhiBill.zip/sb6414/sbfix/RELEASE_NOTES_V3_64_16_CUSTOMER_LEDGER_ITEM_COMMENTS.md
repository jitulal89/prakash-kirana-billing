# SiddhiBill v3.64.16 — Customer Ledger Item Comments

- Customer Ledger PDF now displays each saved billing item comment directly below the corresponding item name in the Items Purchased table.
- Empty comments are omitted so the report does not show blank comment lines.
- Comment text is HTML-escaped and wraps within the item column for safer, readable PDF output.
- No billing data, calculation, or database schema changes.
