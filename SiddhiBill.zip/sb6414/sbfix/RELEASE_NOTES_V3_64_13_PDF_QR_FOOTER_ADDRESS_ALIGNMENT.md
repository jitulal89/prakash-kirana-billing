# SiddhiBill v3.64.13 — PDF QR Footer and Customer Address Alignment

## Fixes
- Reserved sufficient vertical space for the UPI QR image and its “Scan & Pay” caption in the native A4/A6 PDF footer, preventing the SiddhiBill credit footer from overlapping the QR caption.
- Removed the fixed footer Y-coordinate clamp that could force the credit footer back into the QR area on longer invoices.
- Made the A4/A6 customer ADDRESS value use a consistent hanging indent: wrapped continuation lines align with the start of the address value after `ADDRESS:`.

## Compatibility
- Kept the existing application ID, database identifiers, settings, and stored bill data unchanged.

## Validation
- JavaScript syntax and ZIP integrity checks are performed for the source package.
- Android APK/device PDF rendering has not been verified in this environment.
