# SiddhiBill v3.64.12 — Purchase Bill Two-Column Layout

- Redesigned Purchase Bill Entry to use two-column fields on mobile, following the Billing page layout.
- Kept Vendor full-width; paired invoice number/date, delivery date/PO number, supplier reference/payment terms, and other fields in two-column rows.
- Kept GST/tax settings in a dedicated section and retained existing element IDs and calculations.
- Moved Charges & Payment below the item quick-entry/display section and above Notes / Reference.
- Charges, discount, TCS, round-off, calculated total, payment mode, pending amount, and payment references use a two-column grid.
- Removed the “One item per line” explanatory note and the duplicate instructional note from Vendor Bill Quick List while retaining the useful tax-column and per-unit-price guidance.
- Existing purchase logic and element IDs preserved; versionCode incremented to 200 and versionName set to 3.64.12.

Validation: inline JavaScript syntax and ZIP integrity checks. No Android APK build or on-device visual test performed.
