SiddhiBill v3.64.18 — Billing Edit and Vendor Actions Responsive Layout

Changes
- Partial payment fields in the Billing form now span the full form grid and use a two-column responsive layout. This prevents Received By, transaction reference, cheque number, and cheque date from stacking only in the right column and leaving a large blank area beside them while editing a bill.
- On narrow screens, partial-payment fields switch to one column when the viewport is 360px or less.
- Vendor card action buttons (Edit, Pay, Transactions) now occupy a contained three-column row with constrained widths and wrapping text. Vendor name/details take their own row so Transactions no longer overflows the vendor card.
- No billing, payment, vendor, or database logic changed.

Validation
- CSS selectors and responsive rules added as a scoped append-only change.
- Source ZIP integrity and JavaScript syntax are checked before delivery.
- Android device rendering has not been tested in this environment.
