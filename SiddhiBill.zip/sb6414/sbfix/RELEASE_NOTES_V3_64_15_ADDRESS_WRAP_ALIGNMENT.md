# SiddhiBill v3.64.15 — Customer Address Wrapping

- Updated native A4/A6 PDF customer address wrapping.
- `Address:` / `ADDRESS:` appears only on the first line.
- The first address line reserves horizontal space for the label so text does not overlap it.
- Continuation lines begin at the left edge of the address block, as requested (not under the address value after the colon).
- No billing, tax, or payment calculations changed.

Validation: targeted address regression test and JavaScript syntax/ZIP checks should be run before release. Android rendering/build not verified in this source-only package.
