# SiddhiBill v3.64.26 — Combined Report and Export Fixes

This package combines the supplied v3.64.24 baseline with the CSV/PDF export work from v3.64.25 and the previously requested Changes 1–3.

## Change 1 — Customer Ledger
- Button label is now “Print/Download”.
- Android uses the native `printHtmlDocument` save-to-PDF flow directly; the main WebView is no longer overwritten with ledger HTML.
- PDF is saved in `Downloads/SiddhiBill/Customer-Ledger/` and passed to the Android PDF app chooser by the native bridge.
- Existing duplicate-PDF confirmation is retained.

## Change 2 — Customer Ledger layout
- Wider Date and Bill No. columns and nowrap date display.
- More compact headings: Mode, Disc., Total, Paid, Bal., Ref., Amt.
- Payment mode labels are shortened where mapped (e.g. Credit to Cr, Cheque to Chq).
- Reduced table cell padding and kept amounts on one line.

## Change 3 — Team Member and Broker reports
- Both use the native Android PDF save/open flow rather than the Android Print UI or popup window.
- Filenames include the date range and selected team member/broker where applicable.
- Folder routing uses Team-Reports and Broker-Reports.
- Native report WebView now enables JavaScript for content-height measurement, while removing embedded report scripts before rendering to prevent recursive print calls.
- Added a fallback height if the measurement callback returns null/undefined.

## Change 4 — Payment Transactions export
- Payment Transactions PDF uses native Android PDF save/open flow.
- CSV BOM prefix removed to avoid visible ï»¿ before the Date header.

## Change 5 — Profit & Loss export
- Profit & Loss PDF uses native Android PDF save/open flow.
- CSV BOM prefix removed to avoid visible ï»¿ before the report title.
- BOM prefixes also removed from Inventory and GST CSV export paths where present.

## Validation performed
- `node --check app/src/main/assets/www/app.js`: passed.
- Customer Ledger item-comments regression test: passed.
- ZIP integrity test: passed.
- Android Gradle build/device testing: not performed (no Gradle wrapper included in source package).
