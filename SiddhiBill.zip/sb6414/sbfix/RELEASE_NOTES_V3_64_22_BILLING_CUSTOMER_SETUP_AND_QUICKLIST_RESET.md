# SiddhiBill v3.64.22 — Billing Customer Setup and Quick List Reset

## Changes
- When Generate Bill detects a typed customer name that is not in Customer Master, it now opens the existing full Customer Setup popup instead of the small name/mobile-only popup.
- The typed customer name and any known mobile number are prefilled. GSTIN, FSSAI, address, state, notes, and opening balance can be completed in the same form.
- Mobile number is optional, consistent with the regular Customer Setup form. After the customer is saved, Billing selects the saved customer and resumes Generate Bill.
- Canceling Customer Setup clears the pending billing setup state so a later unrelated customer save cannot unexpectedly resume a previous bill.
- Clear / New Bill clears the Quick List product search text and suggestions and resets its quantity/rate/tax/HSN entry fields.

## Validation
- JavaScript syntax checked with `node --check`.
- Existing Customer Ledger item-comments regression test to be run against this source.
- Android build/device test not performed in this environment.
