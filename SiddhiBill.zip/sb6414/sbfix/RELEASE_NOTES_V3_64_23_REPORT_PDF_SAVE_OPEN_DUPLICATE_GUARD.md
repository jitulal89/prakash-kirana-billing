# SiddhiBill v3.64.23 — Report PDF Save/Open and Duplicate Guard

- HTML-based report PDF actions now render a PDF directly to `Downloads/SiddhiBill/<category>/`, then open Android's PDF app chooser. They no longer rely on the system Print dialog's Save as PDF workflow.
- Added duplicate detection and Cancel/Replace prompt for generated report PDFs.
- Added folder categories for Team Reports, Broker Reports, GST Reports, and Profit & Loss.
- Bill PDF open action now checks for an existing bill PDF and asks before replacing it; Cancel keeps the current file.
- Routed generic CSV exports, payment report CSV, and inventory movement CSV through native `saveExportFile` where available so the foldering and duplicate prompt are applied consistently.
- Existing offline data/database schema and application identity are unchanged.

Validation: JavaScript syntax check passed; Customer Ledger item-comments and Profit & Loss regression tests passed; ZIP integrity checked. Android Gradle build/device verification was not performed because the source bundle has no Gradle wrapper.
