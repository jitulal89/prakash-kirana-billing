# SiddhiBill v3.64.22 — Full Customer Setup from Billing & Quick List Reset

## Changes
- When a name typed on the Billing page is not in Customer Master, Generate Bill now opens the full Add Customer form rather than the old name/mobile-only prompt.
- The form includes mobile, GSTIN, FSSAI, address, state, customer notes/additional details, and opening balance.
- Saving the customer returns to bill generation with the saved customer selected. Mobile remains optional, consistent with Customer Master.
- The existing Customer Master Add Customer flow retains its normal behaviour and labels.
- Clear / New Bill now clears the Quick List product search field and suggestion list, and resets its quantity, unit, rate, GST, and HSN inputs along with the multiline Quick List.

## Validation
- JavaScript syntax check passed (`node --check app/src/main/assets/www/app.js`).
- Existing Customer Ledger item-comment regression test passed.
- Android build/device testing was not performed in this source-only update.
