# SiddhiBill v3.64.17 — Profit & Loss Report

- Added a dedicated Profit & Loss tile on the Home page and a separate report page.
- Date-range filtering, current-shop scoped totals, in-app summary, expense-category breakdown, PDF print/save flow, and CSV download.
- Net sales exclude recorded GST; gross profit is net sales less recorded inventory COGS; net profit is gross profit less expenses recorded in Expense Management.
- COGS is based on recorded sale inventory movements and stored unit costs. The report flags possible missing cost coverage rather than inventing costs.
- This is a management report; reconcile records before using for formal accounting or tax filing.
