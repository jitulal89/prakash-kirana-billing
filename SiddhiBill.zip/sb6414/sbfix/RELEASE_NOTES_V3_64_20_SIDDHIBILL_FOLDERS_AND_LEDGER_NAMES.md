# SiddhiBill v3.64.20 — Foldered Exports and Customer Ledger Naming

## Changes
- Exported CSV reports now save through the Android bridge into `Downloads/SiddhiBill/<category>/` on Android 10+ instead of opening the generic Save As dialog or defaulting to the browser Downloads root.
- Categories include `Bills`, `Customer-Ledger`, `Vendor-Ledger`, `Inventory-Reports`, `Backups`, `Ledgers`, and `Other-Reports`, selected from the filename.
- Shared PDF files use the corresponding `Downloads/SiddhiBill/<category>/` path on Android 10+.
- Inventory report CSV and Profit & Loss CSV now use the native export path. Other CSV exports using the shared file bridge are categorized by filename.
- Customer Ledger print/PDF title now includes a sanitized customer name and selected date range, e.g. `Customer_Ledger_Jitu_2026-10-01_2026-10-29`, so Save as PDF suggests a customer-specific filename.

## Platform note
Android's system Print dialog controls where a user saves PDFs created with `PrintManager`; the app cannot force that dialog's destination folder. These PDFs use the customer-specific title, while PDFs generated for sharing and native CSV exports are stored in the SiddhiBill folder structure. On Android 10+, folders are created by MediaStore when the first file is saved, rather than as empty folders during installation.

## Compatibility
- No database schema or app identity changes.
- Existing billing and inventory calculations are unchanged.
