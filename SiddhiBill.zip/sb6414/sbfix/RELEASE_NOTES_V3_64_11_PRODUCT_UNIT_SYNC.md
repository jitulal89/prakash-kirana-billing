# SiddhiBill v3.64.11 — Product Unit Sync

- Product unit defaults to Piece when adding a product or starting a sales item without a unit.
- Saving a sales bill updates the matching product master's unit to the unit selected on that sales line.
- Saving a purchase bill updates the matching product master's unit from the purchase line (existing purchase behavior retained).
- New products created from purchase or sales entries inherit the entered unit; fallback is Piece.
- Existing saved bills retain their recorded line units; this change does not rewrite historical transactions.
- Validation: JavaScript syntax and ZIP integrity checks. No Android build/device test performed.
