# SiddhiBill v3.64.14 — Customer Address Label Alignment

## Change
- In native A4/A6 PDF customer details, wrapped address continuation lines now start at the same horizontal position as the `A` in `ADDRESS:` / `Address:`.
- The address label and first line remain unchanged; only continuation-line alignment is adjusted.
- No billing calculations, saved records, tax settings, or payment logic changed.

## Validation
- JavaScript syntax check passed.
- Source assertions verify both A4/A6 address continuation paths draw at the label's left edge.
- ZIP integrity checked.
- Android APK build and device PDF rendering not performed.
