# SiddhiBill v3.64.21 — Duplicate Export Warning

## Changes
- Before saving an export through the native `saveExportFile` path, SiddhiBill checks the target `Downloads/SiddhiBill/<category>/` folder for the same filename.
- If the file exists, the user sees a **File already exists** warning with **Cancel** and **Replace** options.
- Cancel keeps the existing file and stops the new save.
- Replace removes the existing copy and saves the new export under the same filename, avoiding a second copy.
- The same filename check and prompt are included for the legacy Android filesystem path.
- No database schema, application ID, namespace, or existing local-storage keys were changed.

## Scope / limitation
- This applies to exports saved through the native `Android.saveExportFile` function, including Inventory and Profit & Loss CSV exports and GST CSV exports using that path.
- PDFs handled by Android's system Print dialog are still controlled by the print UI and may not use this duplicate check.
- Android build and device-level behaviour have not been verified in this source-only environment.
