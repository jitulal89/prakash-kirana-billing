# SiddhiBill v3.64.82 – Quick List Duplicate Prompt Runtime Fix

- Fixed an undefined `counts` variable in the duplicate-product prompt path.
- Corrected duplicate-name matching so the prompt lists the affected product names.
- Added a guard for an incomplete confirmation dialog to prevent a secondary JavaScript exception.
- This addresses the runtime exception that caused the generic “App script error: Script error.” dialog when adding repeated products from either Quick List entry action.
- Existing merge/separate behavior is retained.

Validation: JavaScript syntax and source assertions passed; ZIP integrity passed. Android Gradle build and device testing were not run.
