# SiddhiBill v3.64.81 – Quick List Duplicate Choice

## Change
When Billing Quick List contains the same product more than once, or the product is already present in the current bill, SiddhiBill now asks the user how to proceed:
- **Merge quantities**: combine duplicate entries with matching unit and rate; if a matching bill line exists, add the Quick List quantity to that line.
- **Add separate lines**: preserve each Quick List entry as its own billing line.

Different units or rates are never collapsed into one line when merging, to avoid silently changing price/unit calculations. The user is informed that those rows remain separate.

Cancel leaves the bill unchanged. The purchase Quick List and other billing flows are not modified.

## Validation
JavaScript syntax and source-level assertions passed; ZIP integrity checked. Android Gradle build and device UI testing were not run.
