# SiddhiBill v3.64.83 – Quick List Double-Add Fix

## Root cause
The saved-product "Add to Quick List" handler appended the selected product to the Quick List textarea and also immediately called `addQuickList()`, which inserted the product into the bill. Pressing the separate "Add List" button then inserted the textarea contents again. This caused an extra bill line.

## Fix
- "Add to Quick List" now only appends the selected product to the Quick List textarea and resets the product selector.
- "Add List" remains the only action that parses and inserts textarea entries into the bill.
- Duplicate Merge / Add separate lines prompt remains active on Add List.
- Purchase Quick List and database behavior unchanged.

## Validation
JavaScript syntax, handler assertions, and ZIP integrity passed. Android Gradle build and device testing were not run.
