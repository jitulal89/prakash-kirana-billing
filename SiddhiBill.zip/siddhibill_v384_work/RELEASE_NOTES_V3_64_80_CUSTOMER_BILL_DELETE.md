# SiddhiBill v3.64.80 – Customer and Bill Deletion Controls

## Customer deletion
- Adds a Delete action to customer cards.
- Blocks deletion when any sales bill is linked to the customer.
- Also blocks deletion when customer payment records or a non-zero opening balance exist, to protect financial history.
- Confirms permanent deletion and reports success/failure with a reason.
- Walk-in Customer is protected as a system customer.

## Bill deletion
- Adds a Delete action to Bill History.
- Blocks deletion when Inventory Management is enabled and any bill item is tracked in inventory; the notice identifies the tracked items.
- Allows deletion when inventory management is disabled or no bill items are inventory-tracked.
- Confirms bill number, customer and amount before deletion.
- Native SQLite delete now returns whether a matching row was actually deleted; the UI does not claim success without confirmation.
- When inventory is disabled but the bill contains tracked items, the code removes the deleted bill's inventory source entries and recalculates affected stock and warns if it cannot be confirmed.

## Preservation
- Existing app identity, database schema, WebView storage keys, and unrelated billing logic retained.
- App Lock and Team Member PDF changes from v3.64.79 retained.

## Validation
- JavaScript syntax check and source assertions performed.
- ZIP integrity check performed.
- Android Gradle build and device testing not performed in this environment.
