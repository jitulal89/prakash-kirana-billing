# SiddhiBill v3.64.84 – Restore Quick List Direct Add

- Restored **Add to Quick List** as a direct action that inserts the selected saved product into the bill Items section immediately.
- It uses the same duplicate detection and Merge / Add separate lines choice as the text-area Add List action.
- The direct-add action temporarily passes only the selected product through the existing parser, then restores the user's text area unchanged. This prevents the selected product from being added a second time when Add List is later pressed.
- **Add List** remains responsible for inserting the contents of the text area.
- No database schema or inventory logic changed.

Validation: JavaScript syntax and source assertions passed; ZIP integrity passed. Android Gradle build and device testing were not run.
