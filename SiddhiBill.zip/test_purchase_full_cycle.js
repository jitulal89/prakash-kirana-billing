const fs=require('fs'),vm=require('vm'),cp=require('child_process');
const src=fs.readFileSync(__dirname+'/app/src/main/assets/www/app.js','utf8');
function part(a,b){const i=src.indexOf(a),j=src.indexOf(b,i);if(i<0||j<0)throw Error('Missing source function '+a);return src.slice(i,j)}
const ctx={console,roundMoney:n=>Math.round((Number(n)||0)*100)/100,toInputDate:s=>s,vendorNum:v=>{const n=Number(v);return Number.isFinite(n)?n:0}};vm.createContext(ctx);
vm.runInContext(part('function parsePurchaseInvoiceTable(', 'function purchaseOcrEntryLine(')+part('function purchaseOcrEntryLine(', 'function parsePurchaseOcrRows(')+part('function parsePurchaseOcrMetadata(', 'function parsePurchaseInvoiceTable(')+part('function parsePurchaseEntryLine(', 'function vendorTaxContext(')+part('function purchaseLineMath(', 'function updatePurchaseDraftSummary('),ctx);
const pdf='/mnt/data/1000024866_RBIN033136_INV (1)(1).pdf';
const raw=cp.execFileSync('pdftotext',['-layout',pdf,'-'],{encoding:'utf8'});
const meta=ctx.parsePurchaseOcrMetadata(raw),items=ctx.parsePurchaseInvoiceTable(raw),quickRows=items.map(ctx.purchaseOcrEntryLine);
if(items.length!==13||quickRows.length!==13)throw Error(`Expected 13 source items and 13 Quick List rows; got ${items.length}/${quickRows.length}`);
const parsed=quickRows.map((row,i)=>{const cols=row.split(',');if(cols.length!==7)throw Error(`Row ${i+1} should have 7 columns, got ${cols.length}`);const item=ctx.parsePurchaseEntryLine(row);if(item.error)throw Error(`Row ${i+1} failed Add List parse: ${item.error}`);return item;});
for(let i=0;i<parsed.length;i++){
 const p=parsed[i],srcItem=items[i];
 if(!(Number(p.qty)>0)||!(p.lineTotalInclusive>0)||!p.name||!p.hsn)throw Error(`Row ${i+1} has missing/invalid item data: ${JSON.stringify(p)}`);
 if(p.lineTotalInclusive!==srcItem.invoiceLineTotal||p.taxRate!==srcItem.taxRate||p.hsn!==srcItem.hsn)throw Error(`Row ${i+1} fields changed during Quick List/Add List parse`);
 if(p.lineTotalInclusive===0||p.taxRate===13.5)throw Error(`Bad OCR mapping (zero total or discount misread as GST) in row ${i+1}`);
}
const savedStyleRows=parsed.map((p,i)=>({...p,priceIncludesTax:true,lineTotalInclusive:p.lineTotalInclusive,rate:p.rate,invoiceTaxableAmount:items[i].invoiceTaxableAmount,invoiceLineTotal:items[i].invoiceLineTotal}));
const math=savedStyleRows.map(ctx.purchaseLineMath);
const gross=ctx.roundMoney(math.reduce((a,x)=>a+x.gross,0));
const taxable=ctx.roundMoney(math.reduce((a,x)=>a+x.taxable,0));
const tax=ctx.roundMoney(math.reduce((a,x)=>a+x.tax,0));
const final=ctx.roundMoney(gross+meta.roundOff-meta.discount+meta.tcs);
if(Math.abs(taxable-meta.taxable)>.005)throw Error(`Taxable after Add List differs: ${taxable} vs ${meta.taxable}`);
if(Math.abs(tax-meta.tax)>.005)throw Error(`GST after Add List differs: ${tax} vs ${meta.tax}`);
if(Math.abs(final-meta.total)>.005)throw Error(`Final invoice total differs: ${final} vs ${meta.total}`);
if(parsed[0].lineTotalInclusive!==1375.19||parsed[0].taxRate!==18||parsed[0].hsn!=='34013090')throw Error('Dettol first row regression');
const expectedUom=items.map(x=>String(x.packSize));
for(let i=0;i<parsed.length;i++)if(parsed[i].qty!==expectedUom[i])throw Error(`Whole-bill numeric UOM rule mismatch on row ${i+1}: expected ${expectedUom[i]}, got ${parsed[i].qty}`);
if(!items.every(x=>Number(x.packSize)>0))throw Error('Expected numeric UOM field across all sample invoice rows');
console.log('PASS: whole-bill numeric UOM pattern selects UOM for every row; no item-by-item switching');
console.log('PASS: PDF OCR -> 13 source rows -> 13 seven-column Quick List rows -> Add List parser -> purchase calculations');
console.log(`PASS: all rows retain non-zero inclusive line totals, valid GST (5%/18%), HSN and quantity`);
console.log(`PASS: taxable ₹${taxable.toFixed(2)}, GST ₹${tax.toFixed(2)}, item gross ₹${gross.toFixed(2)}, round-off ₹${meta.roundOff.toFixed(2)}, final ₹${final.toFixed(2)}`);
console.log('PASS: no discount percentage is mapped as GST and no line total is replaced by zero');
