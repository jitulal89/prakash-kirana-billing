const fs=require('fs'),vm=require('vm');
const src=fs.readFileSync(__dirname+'/app/src/main/assets/www/app.js','utf8');
const a=src.indexOf('function parseQuickListLine(line, options={}){');
const b=src.indexOf('\nfunction addQuickList(){',a);
if(a<0||b<0)throw Error('quick list parser not found');
const units=[{name:'Kg',aliases:['kg','kgs','k']},{name:'Piece',aliases:['pc','pcs','piece','pieces']},{name:'Bottle',aliases:['btl','bottle']},{name:'Job',aliases:['job','jobs']},{name:'Meter',aliases:['meter','metre','m']},{name:'Packet',aliases:['packet','pkt']},{name:'Case',aliases:['case','cs','carton']},{name:'Each',aliases:['each','ea','unit']}];
const ctx={unitAliasPattern:()=>units.flatMap(x=>x.aliases).sort((a,b)=>b.length-a.length).join('|'),normalizeUnitName:u=>{let t=String(u||'').toLowerCase();for(const x of units)if(x.aliases.includes(t))return x.name;return t||'piece'},findProduct:()=>null};
vm.createContext(ctx);vm.runInContext(src.slice(a,b),ctx);
const tests=[
 ['Brake Shoe 2 piece 250',{defaultTaxRate:null,allowBareTax:false},'Brake Shoe',2,'Piece',250,null],
 ['Engine Oil 3 bottle 180',{defaultTaxRate:null,allowBareTax:false},'Engine Oil',3,'Bottle',180,null],
 ['Labour 1 job 500',{defaultTaxRate:null,allowBareTax:false},'Labour',1,'Job',500,null],
 ['Chana 1 kg 100',{defaultTaxRate:null,allowBareTax:false},'Chana',1,'Kg',100,null],
 ['Chana 1 kg 100 5%',{defaultTaxRate:null,allowBareTax:false},'Chana',1,'Kg',100,5],
 ['Part A 1 piece 105',{defaultTaxRate:null,allowBareTax:false},'Part A',1,'Piece',105,null],
 ['Cloth 2 metre 199.50',{defaultTaxRate:null,allowBareTax:false},'Cloth',2,'Meter',199.5,null],
 ['Brake Shoe 2 piece 250',{},'Brake Shoe',2,'Piece',250,5]
];
for(const [input,opts,name,qty,unit,rate,tax] of tests){const got=ctx.parseQuickListLine(input,opts);if(!got||got.error||got.name!==name||Number(got.qty)!==qty||got.unit.toLowerCase()!==unit.toLowerCase()||Number(got.rate)!==rate||got.taxRate!==tax)throw Error(`FAIL ${input}: ${JSON.stringify(got)} expected ${[name,qty,unit,rate,tax]}`);console.log('PASS',input,'=>',got.name,got.qty,got.unit,got.rate,'GST',got.taxRate);}
const app=fs.readFileSync(__dirname+'/app/src/main/assets/www/app.js','utf8');
if(!app.includes('purchaseDraftItems.push(item)'))throw Error('Add List does not add to purchase draft rows');
if(!app.includes('const items=purchaseDraftItems.map(x=>({...x}))'))throw Error('Save Purchase does not use editable draft rows');
if(!app.includes('renderPurchaseDraftItems()'))throw Error('Editable purchase row renderer missing');
console.log('PASS integration assertions: Add List populates editable rows; Save Purchase reads those rows.');
console.log('PASS all vendor Quick List parser tests');
