# SiddhiBill v3.65.3 — Thermal columns, tax-only HSN and Vendor Quick List units

## Thermal 80 mm printing
- Kept Font B and the custom 6/8 glyph test from v3.65.2.
- Rebalanced item-table columns to a compact 48-character row so Amount stays in its own right-aligned column rather than wrapping under the item name.
- Tax invoices show the `ITEM/HSN` heading, GST column and HSN values (when supplied).
- Cash/non-tax bills show `ITEM` and omit both the HSN heading and HSN values; GST column is also omitted.
- Item rows remain native ESC/POS text; no bitmap item table and no added character spacing.

## Vendor Bill Quick List
- Created/populated the `unitNames` datalist from the shop's unit catalogue.
- Vendor Bill Quick List and editable purchase draft Unit inputs now offer searchable unit suggestions while still allowing a new free-text unit.

## Validation
- JavaScript syntax check passed.
- Thermal layout / tax-only HSN / vendor unit regression passed.
- Custom 6/8 glyph regression passed.
- Font B transaction layout regression passed.
- Vendor Quick List parser and purchase-field regressions passed.
- Android Gradle build not run: Gradle wrapper is not present in the source package.
- Physical Posiflow KPC307-UEWB print test remains pending.
