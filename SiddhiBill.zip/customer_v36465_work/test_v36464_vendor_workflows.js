const fs=require('fs'),path=require('path'),root=__dirname;
const app=fs.readFileSync(path.join(root,'app/src/main/assets/www/app.js'),'utf8');
const db=fs.readFileSync(path.join(root,'app/src/main/java/com/dukaanbill/app/LocalDatabase.java'),'utf8');
const bridge=fs.readFileSync(path.join(root,'app/src/main/java/com/dukaanbill/app/MainActivity.java'),'utf8');
const gradle=fs.readFileSync(path.join(root,'app/build.gradle'),'utf8');
const checks=[
 [gradle.includes('versionCode 238')&&gradle.includes('versionName "3.64.65"'),'version metadata advanced to 3.64.65 / 238'],
 [app.includes('function resolvePurchaseRecord(candidate)')&&app.includes('loadTransactionRecord("pksPurchases",id)'),'View/Edit/PDF resolves selected purchase by exact SQLite record ID'],
 [app.includes('const rawPurchase=resolvePurchaseRecord(id)'),'purchase editor uses freshly resolved selected record'],
 [app.includes('view-transaction-purchase')&&app.includes('showPurchaseDetail(p)'),'vendor transaction opens purchase record, not sales-bill lookup'],
 [app.includes('loadVendorPurchases?.(String(key),String(vendor?.name||""),moduleShopKey())'),'vendor transaction requests only selected vendor and shop'],
 [app.includes('supplierId??p.partyId')&&app.includes('supplierSnapshot?.name'),'legacy supplier identifiers and names are supported'],
 [db.includes('loadVendorPurchasesJson(String vendorId, String vendorName, String shopKey)'),'native vendor history query is scoped to vendor/shop'],
 [db.includes("json_extract(record_json,'$.supplierId')")&&db.includes("json_extract(record_json,'$.partyId')"),'native query matches legacy vendor ID fields'],
 [db.includes("json_extract(record_json,'$.total')")&&db.includes('row.put("paymentMode"'),'vendor transaction result is compact and omits item/OCR payloads'],
 [bridge.includes('loadVendorPurchases(String vendorId,String vendorName,String shopKey)'),'Android bridge exposes scoped vendor transaction query'],
 [app.includes('function renderPurchaseHistoryPage()')&&app.includes('readNativePurchasePage(offset,TRANSACTION_PAGE_SIZE,q)'),'purchase history remains paged on native SQLite']
];
for(const [ok,msg] of checks){if(!ok)throw new Error('FAIL: '+msg);console.log('PASS:',msg)}
