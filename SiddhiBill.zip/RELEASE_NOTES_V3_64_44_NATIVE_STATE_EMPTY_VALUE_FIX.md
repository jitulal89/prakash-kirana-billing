# v3.64.44 – Native SQLite state loading correction

## Change
- Treats empty strings as valid persisted `app_state` values during chunked native SQLite loading.
- Keeps fail-closed protection: an actual bridge/SQLite exception still blocks writes and prevents stale localStorage migration.
- Includes the captured native loading error message in the on-screen diagnostic so a future failure can be diagnosed without guessing.

## Validation
- `node --check app/src/main/assets/www/app.js` passed.
- ZIP integrity checked after packaging.
- Android build/device restore test not performed in this environment.
