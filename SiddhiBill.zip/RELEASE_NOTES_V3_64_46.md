# SiddhiBill v3.64.46 – Startup Diagnostics Settings Fix

- Based on v3.64.45 Startup Trace Diagnostics.
- Corrected the diagnostics panel placement: it now appears inside Settings, not Billing.
- Updated diagnostic build identifier to 3.64.46.
- No database, migration, backup/restore, or transaction-loading logic changed.
- Startup performance regression is not claimed as fixed; this release is intended to make the trace accessible for diagnosis.
