# SiddhiBill v3.63.3 — Separate GST Compliance Module

## Added
- Added a separate GST Compliance tile on the Home screen and a dedicated GST Compliance page.
- Monthly compliance tracker for GSTR-1 and GSTR-3B statuses, ARN/reference numbers, manually confirmed ITC and adjustments.
- Monthly GST summary from saved tax-enabled bills with taxable value, invoice value and rate-wise CGST/SGST/IGST totals.
- GST Summary PDF via Android Print / Save as PDF or browser print.
- GSTR-1 sales working CSV, HSN summary CSV and GSTR-3B working CSV.
- Preliminary annual-return guidance based on financial year and user-entered aggregate turnover.
- Compliance tracker records are persisted in the app's existing local storage/native state store and separated by shop key and return period.

## Important limitations
- Exports are preparation/working files, not official GSTN direct-upload files. GSTR-1 CSV columns are a review-oriented invoice register; use the current GSTN offline utility/template to create the actual upload file.
- GSTR-3B working file does not determine eligible ITC. ITC must be reconciled against GSTR-2B and manually confirmed; reverse charge, exempt/nil-rated supplies, credit/debit notes and other return tables must be checked before filing.
- Annual-return guidance is informational; confirm applicable notifications and due dates on the GST portal.

## Validation
- `node --check` passed for app.js.
- Inline script syntax check passed.
- ZIP integrity checked after packaging.
- APK build and physical-device testing were not performed.
