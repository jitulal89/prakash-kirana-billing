# SiddhiBill v3.64.77 – Native App Lock

- Added native AndroidX BiometricPrompt authentication using the phone's strong biometric and device credential on Android 11+, with the system device-credential flow on Android 6–10.
- First launch and process restart require authentication.
- Returning from another app within 60 seconds resumes without another prompt; returning after 60 seconds requires authentication.
- The lock overlay covers the WebView and Android FLAG_SECURE is enabled while locked to obscure recent-app previews and block screenshots.
- No phone PIN, pattern, password, fingerprint or face data is stored or accessed by SiddhiBill.
- No database schema, database file, app ID, or WebView storage key changes.
- A secure device screen lock or supported biometric must be configured in Android Settings.
