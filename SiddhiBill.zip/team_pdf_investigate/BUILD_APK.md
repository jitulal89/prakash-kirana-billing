# Build SiddhiBill v3.64.67

- Application ID: `com.siddhibill.app`
- Java namespace: `com.dukaanbill.app`
- Version code: `240`
- Version name: `3.64.67`

## GitHub Actions
Build workflow: `.github/workflows/build-apk.yml`.

Commit/push this source package to the GitHub repository and run the **Build APK** workflow. Install the resulting APK over the existing app (do not uninstall or clear app data).

## First-launch / restore behaviour
On first launch after installing this release, SiddhiBill prepares any legacy transaction arrays in a background database worker before opening the main WebView. A preparation screen is shown while bills, purchases and inventory movements are normalized. Existing database contents are retained.

New manual and automatic backups keep both normalized transaction records and legacy compatibility arrays.

## Validation still required on Android
The uploaded APK and backup were inspected, and SQLite/source regression checks are documented in `E2E_TEST_REPORT_V3_64_67.md`. This workspace did not have Android SDK, Gradle, adb or an emulator, so install and physical-device E2E validation must be completed after the GitHub Actions build.
