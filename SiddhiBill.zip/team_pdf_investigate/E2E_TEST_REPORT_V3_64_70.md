# v3.64.70 Regression Test Report

| Area | Test | Result |
|---|---|---|
| Ledger PDF | Single semantic table retained; no fixed 18-row splitting | PASS |
| Ledger PDF | Native A4 raster renderer inserts repeated table headings at physical page boundaries | Source assertion PASS; device rendering pending |
| Team Management | Current-shop matcher includes compatible legacy shop-name records | Source assertion PASS |
| Team Management | Sales tracking flag normalization | Source assertion PASS |
| Team Management | Native sales summary and detailed bill SQL use salesperson/date/shop fallbacks | Source assertion PASS |
| Backup data | Migrated 10,000 bills in an extracted test database | PASS |
| Backup data | Team summary returns 20 team members and accounts for 10,000 bills | PASS |
| Backup data | Team member detail query returns 511 bills for SBX-TEAM-001 | PASS |
| JavaScript | Node syntax check | PASS |
| Package | ZIP integrity | PASS |

Android Gradle build, PDF visual inspection on Android, and physical-device Team Management interaction were not run. Do not treat the source/database checks as device E2E verification.

Four older historical scripts were also attempted. They stop immediately on hard-coded version assertions for v3.64.52, v3.64.43, v3.64.69, and v3.64.67 respectively; they do not reach their functional assertions on v3.64.70. These are stale test harnesses and are not counted as passes. The new v3.64.70 regression script is the applicable source check.
