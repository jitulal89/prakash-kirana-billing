# v3.64.68 Regression Test Report

## Baseline

- Source baseline: v3.64.67
- Supplied backup: `SiddhiBill_Backup_2026-11-03_15-39-55_95080.zip`
- App identity and local database schema retained.

## Backup data inspected

| Collection | Records |
|---|---:|
| Sales bills | 10,000 |
| Purchase bills | 10,000 |
| Inventory movements | 249,162 |
| Customers | 400 |
| Vendors | 100 |
| Team members | 20 |

## Results

| Check | Result | Scope |
|---|---|---|
| JavaScript syntax | PASS | `node --check` |
| v3.64.68 targeted assertions | PASS (16) | Source assertions |
| Customer workflow regression | PASS | Existing v3.64.63 source test |
| Report regression | PASS (7) | Existing v3.64.58 source test |
| Customer payment collection migration | PASS | SQLite JSON1 simulation with linked payment row |
| Team sales summary query | PASS | Actual supplied backup data; Aug–Oct 2026 |
| Purchase identity integrity | PASS | Actual supplied backup data; 10,000 unique IDs and valid vendor links |
| Ledger print pagination | SOURCE CHECK PASS | One continuous table per report section; physical print output not device-tested |
| Search suggestions | SOURCE CHECK PASS | Custom filtered panel replaces native datalist |
| Purchase edit path | SOURCE CHECK PASS | Single-record normalization no longer forces full purchase-array load |
| Android Gradle build | NOT RUN | No Gradle wrapper / Gradle executable / Android SDK in environment |
| Physical-device E2E | NOT RUN | No Android device or emulator attached |

## Important interpretation

The previous v3.64.67 save warning had a concrete cause: `pksCustomerPayments` was written through `saveTransactionRecord`, but that collection was not accepted by the native transaction persistence allow-list. A bill save with a linked partial receipt therefore raised the database confirmation warning even if the bill record itself had been written. v3.64.68 adds the collection and its migration/persistence lifecycle.

The purchase edit path also called `state.purchases.findIndex()` inside single-record normalization. That property is lazy and reading it loads the complete purchase history. v3.64.68 guards that update so the selected invoice can be normalized without materializing all purchases.

The ledger renderer previously created a new table every 18 rows and inserted forced page breaks. v3.64.68 emits one table per ledger section so the print engine repeats its header only at natural page breaks.

This report does not claim device-level end-to-end success. The APK must still be built by GitHub Actions and tested on the user's device.
