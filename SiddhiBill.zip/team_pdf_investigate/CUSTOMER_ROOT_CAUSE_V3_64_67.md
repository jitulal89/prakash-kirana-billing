# v3.64.67 — Root Cause and Regression Audit

## Confirmed cause from the uploaded APK and backup
The uploaded APK contains the exact v3.64.66 `app.js` and `index.html` assets. The uploaded backup database uses the legacy-compatible format: it has `app_state` arrays but no `transaction_records` table. Its arrays contain 10,000 bills, 10,000 purchases and 249,162 inventory movements.

The v3.64.66 native methods migrated those arrays lazily on first use. That work was reached synchronously from normal WebView actions (Generate Bill, Customer summary, Reports and Purchase history). This explains why unrelated tabs/actions could appear to hang on the same restored backup.

A second confirmed defect was that migration deletes the legacy `app_state` key, while the WebView lazy getter still read only that key. After migration, a direct `state.bills` or `state.purchases` read could therefore return an empty array even though the records existed in `transaction_records`. Team Management and Payment Transactions report still had direct full-array reads.

## v3.64.67 changes
- Background database preparation before loading the main WebView, including backup restore and other paths back to Billing.
- Manual and automatic backups now retain normalized rows and migration markers alongside compatibility arrays.
- Idempotent migration recognises a marked backup that already contains normalized rows and discards only the duplicate compatibility array.
- Lazy full-collection reads use paged `transaction_records` reads after migration.
- Team Management uses native date-scoped sales summaries; Team Report loads only the selected salesperson's bills in the requested period.
- Payment Transactions report loads cash sales/purchases by date from SQLite instead of forcing all bill/purchase JSON into the WebView.
- New Customer action is exposed on the billing screen and does not auto-generate a bill.
- Purchase View opens an in-app preview rather than a JavaScript alert.
- Invoice sequence query supports both legacy and current bill-number formats.

## Seven requested workflows covered
1. New Bill / selecting a new customer / Generate Bill.
2. Reports landing page and Payment Transactions rows.
3. Customer bill history Edit and record-level Update.
4. Team Management page and sales summary.
5. Purchase Edit.
6. Purchase View / in-app preview.
7. Customer page and native credit summary.

## Uploaded-backup SQL test results
- Migration counts: 10,000 bills; 10,000 purchases; 249,162 inventory movements.
- Customer summary grouping: 400 customers.
- Bill History and Purchase History: 50-row pages returned.
- Selected bill and purchase IDs: both resolved.
- Team sales summary: 10,000 bills / 87,140,981.13 total sales across the supplied date range.
- Cash report source rows: 7,000 cash sales and 4,000 cash purchases.
- Compatibility backup with normalized rows + legacy arrays + markers: row counts unchanged; redundant legacy arrays removed.

## Validation boundary
These are real SQLite tests against the supplied backup and source-level regression tests. They are not a physical Android end-to-end test. No Android SDK, Gradle executable/wrapper, adb or emulator is available in this environment, so the APK could not be installed and interacted with here. The final build/device confirmation remains necessary.
