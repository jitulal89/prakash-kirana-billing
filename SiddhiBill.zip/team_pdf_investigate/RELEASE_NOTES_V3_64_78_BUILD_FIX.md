# SiddhiBill v3.64.78 – GitHub Actions Build Fix

- MainActivity now extends AndroidX FragmentActivity for the AndroidX BiometricPrompt constructor.
- Team Member A4 PDF now uses Android PrintManager. Framework-owned callback classes are no longer instantiated by app code.
- User chooses Save as PDF in Android print dialog. Report WebView is retained until print job completes/cancels/fails.
- 60-second App Lock and secure locked-screen behaviour retained.

Validation: JavaScript syntax, source checks and ZIP integrity performed. Android Gradle build and device tests not run.
