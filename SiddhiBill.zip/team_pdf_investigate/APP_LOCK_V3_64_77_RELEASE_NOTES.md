# SiddhiBill v3.64.77 – Native App Lock

## Implemented
- Native AndroidX BiometricPrompt app lock.
- Supports strong biometrics and Android device credential (PIN, pattern, password) on Android 11+.
- Uses the legacy BiometricPrompt device-credential option on Android 6–10.
- Requires authentication on fresh launch/process restart.
- Applies a 60-second in-memory grace period after leaving the app.
- On return within 60 seconds, the app unlocks without another prompt; after 60 seconds, authentication is required.
- Displays a native lock overlay over the WebView.
- Enables FLAG_SECURE while locked to obscure the app in screenshots/recent-app previews.
- No PIN, biometric template, or unlocked-session state is stored by SiddhiBill.

## Compatibility and preservation
- Application ID remains `com.siddhibill.app`.
- Java namespace remains `com.dukaanbill.app`.
- Existing SQLite database (`dukaanbill.db`), WebView storage, and app business logic are not intentionally changed.
- No network/cloud service is introduced.

## Validation performed
- JavaScript syntax check (`node --check`) passed.
- Source-level checks for BiometricPrompt, 60-second timeout, lock overlay, and FLAG_SECURE passed.
- ZIP integrity check passed.
- Android Gradle build and physical-device biometric/PIN testing were not run in this environment.
