const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('app/src/main/assets/www/app.js','utf8');
for(const token of [
 'function ledgerPagedTable(headerHtml,rowHtml,footerHtml="")',
 'return `<table class="ledger-page-table"><thead><tr>${headerHtml}</tr></thead><tbody>${rows.join("")}</tbody>',
 'function moduleSalesTrackingEnabled(member)',
 'function moduleRows(arr){return (Array.isArray(arr)?arr:[]).filter(r=>moduleRecordBelongsToCurrentShop(r))}',
 'moduleSalesTrackingEnabled(m)',
 'loadTeamSalesSummary(from,to,String(people[0]?.shopKey||moduleShopKey()))'
]) assert(src.includes(token),'Missing expected source behavior: '+token);
const gradle=fs.readFileSync('app/build.gradle','utf8');assert(gradle.includes('versionCode 243')&&gradle.includes('versionName "3.64.70"'));
const java=fs.readFileSync('app/src/main/java/com/dukaanbill/app/MainActivity.java','utf8');
assert(java.includes('table.ledger-page-table'));assert(java.includes('pageCss=Math.floor(786/scale)/dpr'));
const db=fs.readFileSync('app/src/main/java/com/dukaanbill/app/LocalDatabase.java','utf8');
assert(db.includes("json_extract(record_json,'$.salesPersonId')"));assert(db.includes('LOWER(TRIM(?))'));
console.log('PASS: ledger single-table semantics, native physical-page header overlay, normalized team shop/salesperson matching, and release metadata');
