# SiddhiBill v3.64.69 — Regression and Purchase Quick List Test Report

## Baseline

- Source baseline: v3.64.68
- Version: v3.64.69 / versionCode 242
- Existing offline Android WebView and SQLite architecture retained.

## Changes in this iteration

- Added searchable product selection to Purchase Quick List.
- Search matches product name, item code and barcode.
- Product selection fills unit, last purchase cost, SP/MRP, GST, HSN and barcode when present in Product Master.
- Search entry accepts quantity, unit, purchase rate per unit, GST, HSN, barcode and SP/MRP per unit.
- Purchase Quick List parser accepts an eighth structured field for SP/MRP per unit and carries it to the purchase item's `sellingRate` field.
- Existing 7-column, 6-column and compact purchase entry formats remain supported.
- Retained the v3.64.68 fixes for purchase edit performance, customer-payment persistence, ledger page-break headings, Team Management reports, billing page button removal and ledger search.

## Checks executed

| Check | Result |
|---|---|
| `node --check app/src/main/assets/www/app.js` | PASS |
| New v3.64.69 Quick List / SP-MRP parser and UI assertions | PASS |
| Existing purchase Quick List parser regression | PASS |
| Purchase calculations | PASS |
| Inclusive/exclusive purchase tax calculations | PASS |
| v3.64.68 persistence / purchase / ledger / team / search assertions | PASS (16 assertions) |
| Customer workflow source regression | PASS |
| Report source regression | PASS (7 assertions) |

## Not verified

- Android Gradle compilation was not run; no Gradle executable / Android SDK is available in this environment.
- No physical Android device or emulator is attached, so UI interaction, actual SQLite save confirmation and PDF print pagination require device verification.
- Source-level assertions are not described as physical-device end-to-end testing.
