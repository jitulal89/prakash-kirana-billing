# v3.64.67 Validation Report — Supplied APK + Backup

## Inputs inspected
- APK ZIP: `SiddhiBill-APK (1).zip`
  - SHA-256: `2e48fa55085cfb4c811c250e198e5e21b4f9f1d384e1b3374e2a437888232b71`
  - The embedded `app-debug.apk` contains `assets/www/app.js` and `assets/www/index.html` byte-for-byte identical to the supplied v3.64.66 source.
- Backup ZIP: `SiddhiBill_Backup_2026-11-03_15-39-55_95080.zip`
  - SHA-256: `7500f5dc5b7e8d4668951e598970063c4475571176b1a05a328a7afb77c00f64`
  - The backup's SQLite DB is the compatibility format: `app_state` contains legacy arrays; the normalized `transaction_records` table is absent.

## Real backup data profile
- Sales bills: 10,000
- Purchase records: 10,000
- Inventory movements: 249,162
- Customers: 400
- Vendors: 100
- Team members: 20
- Team attendance: 1,840
- Vendor payments: 7,000

## Tests run against a disposable copy of the uploaded database
- Migrated all 10,000 bills, 10,000 purchases and 249,162 inventory movements.
- Confirmed 400 customer summary groups.
- Confirmed 50-row sales-history and purchase-history pages and a 100-row inventory-movement page.
- Confirmed selected bill and purchase record lookup by their persisted IDs.
- Confirmed bill and purchase update/upsert preserves collection row counts and updates the selected record.
- Confirmed legacy `#SBX-00001` through `#SBX-10000` invoice numbering yields next sequence 10001 (prevents restarting at 001).
- Confirmed Team sales summary returns 10,000 bills and 87,140,981.13 total sales for the tested period; selected salesperson detail query returned 511 bills.
- Confirmed payment-report source queries return 7,000 cash sales and 4,000 cash purchases.
- Confirmed a compatibility backup containing normalized rows, migration markers and legacy arrays does not duplicate rows when prepared.

## Source checks
- `node --check app/src/main/assets/www/app.js`: PASS.
- `test_v36467_backup_regression.js`: PASS (18 assertions).
- `test_v36467_backup_database.py` against the uploaded backup: PASS.
- Existing customer workflow, report regression, transaction-history preview and vendor pagination checks: PASS.
- Java parser check on the modified Java files: no Java syntax/parse errors detected. Full Android type-check/compile was not possible without Android SDK libraries.

## Device-test limitation
The environment does not contain Gradle/Gradle wrapper, Android SDK, `adb`, emulator, or an installable Android device. Chromium headless also did not launch even for a one-line HTML smoke page in this environment. Consequently, I did **not** install and tap through the supplied APK on an Android runtime. The report therefore distinguishes real backup/SQLite tests and source regression checks from a true device end-to-end test.
