# SiddhiBill v3.64.65 — Customer workflow root-cause analysis

Base: v3.64.64. This release addresses the four customer issues reported after the v3.64.63 customer workflow changes.

## 1. Generate Bill can hang

The bill-save path called the general `save()` routine, which serialized the entire `pksCustomerPayments` collection into JSON and passed it through local storage and the native app-state bridge even when a normal bill did not change customer payments. On shops with a large payment history this created avoidable synchronous WebView/native work during bill generation. The optional last-five-transactions invoice section also used the full customer transaction loader.

Changes:
- `save(options)` can omit `pksCustomerPayments` when that collection is unchanged; the bill handler uses this option for ordinary bills and still persists the collection whenever editing removes a linked receipt or a partial receipt is added.
- Added a shop/customer-scoped SQLite query limited to five recent bills for the optional invoice last-five-transactions section. This avoids transferring and parsing the customer's complete bill history during bill generation.
- Existing bill/purchase transaction storage and database schema are unchanged.

## 2. View Bill button missing in Customer Transactions

Customer bill rows were labelled `Bill` or `Credit`, but the renderer displayed the View Bill action only for rows whose internal type was `Sale`. The button condition therefore failed for every customer bill.

Changes:
- Customer bill rows now carry internal type `Sale` and a separate visible label (`Bill` or `Credit`).
- The existing View Bill action is consequently rendered and continues to load the exact bill from native SQLite before opening the bill preview.

## 3. Customer due and transaction balance mismatch

The customer-list balance calculation deducted every customer payment from credit sales, including receipts linked to individual bills. Credit-bill transaction rows also account for linked receipts against their bill. This could count linked partial receipts twice or let a linked receipt against a cash bill affect the overall customer due. The SQL credit summary also used gross credit bill totals instead of netting the bill's stored partial-payment amount.

Changes:
- Native credit summary now sums credit bill totals net of `partialPaymentAmount`.
- Overall customer due deducts only unlinked customer receipts; linked partial receipts are already netted against their source credit bill.
- Transaction rows use the greater of the bill's stored partial-payment amount and linked receipt total, preventing duplicate deductions.
- Customer payment totals are cached by customer to avoid rescanning the full payment collection on every customer-card render.

The calculation remains signed: a negative balance represents a net customer credit/advance, rather than silently changing it to zero.

## 4. Customer Ledger PDF summary and pagination

The ledger header showed only bill count, sales total and period payments; it did not prominently show the customer's current overall balance. Its responsive on-screen table rules (`display:block` and horizontal overflow) were not fully neutralized for printing, and print pagination did not explicitly request repeated table headings or keep rows together.

Changes:
- Added prominent Total Balance Due, Sales in Period, Payments in Period and Number of Bills summary values.
- Print CSS forces actual table layout, repeats `thead`/`tfoot` groups and avoids splitting individual rows across pages. Section headings are kept with the following table.

## Files changed
- `app/src/main/assets/www/app.js`
- `app/src/main/assets/www/index.html` (cache-buster)
- `app/src/main/java/com/dukaanbill/app/LocalDatabase.java`
- `app/src/main/java/com/dukaanbill/app/MainActivity.java`
- `app/build.gradle`

No database schema migration, app identity, storage-key change, cloud dependency or user-data reset was introduced.
