# SiddhiBill v3.64.68 — Purchase, persistence, ledger and team-report fixes

Version code: 241  
Version name: 3.64.68

## Fixes

1. **Purchase Edit performance and completeness**
   - `normalizePurchaseRecord()` no longer accesses the lazy `state.purchases` getter when normalizing a single selected invoice.
   - A purchase edit therefore stays on the selected SQLite record instead of materializing the entire 10,000+ purchase history on the WebView thread.
   - Vendor selection is restored by ID, with a safe name-based fallback for older supplier references.
   - A compact vendor-transaction row is never opened as an editable invoice if the full record cannot be fetched.

2. **Bill save warning / partial customer receipts**
   - Added `pksCustomerPayments` to the supported native transaction collections and legacy migration.
   - Linked partial receipts now include the shop key and can be saved/deleted as native transaction records. This removes the known unsupported-collection failure that caused the warning when a bill had a linked partial payment.
   - Customer payments are lazy-loaded from normalized SQLite after migration and are no longer written back as stale legacy `app_state` arrays on Android.
   - Standalone customer payment create/edit, customer rename, sync import and archive import/removal now explicitly persist affected payment records.

3. **Customer and vendor ledger pagination**
   - Removed fixed 18-row HTML table fragments and forced page breaks.
   - Each report section now uses one continuous table with a single `<thead>`. Android WebView's print engine controls physical page breaks and repeats the heading only when the same table continues on a new page.
   - Rows remain protected from splitting where supported by the print engine.

4. **Team Management reports**
   - Historical team members, including inactive members, remain available in reports.
   - Team report queries use the stored shop key on the team member record rather than deriving it from the current shop display name.
   - Current-shop matching supports older team records whose stored shop name matches the configured shop name.

5. **Billing UI**
   - Removed the separate **New Customer** button from the billing page. Customer creation continues through the customer field / save flow.

6. **Customer and Vendor Ledger search**
   - Replaced Android's native `<datalist>` popup with a controlled, scrollable suggestion panel.
   - Search suggestions are filtered as the user types and capped at 25 visible matches; a report requires selecting an exact listed customer/vendor.

## Validation

- JavaScript syntax check passed.
- 16 targeted v3.64.68 source regression assertions passed.
- Existing v3.64.63 customer workflow source checks passed.
- Existing v3.64.58 report source checks passed.
- Supplied 3-Nov-2026 backup was inspected and used for SQLite migration/query checks: 10,000 sales bills, 10,000 purchases, 249,162 inventory movements, 400 customers, 100 vendors and 20 team members.
- Simulated migration of a linked customer receipt into `pksCustomerPayments` passed.
- Backup sales query for 01-Aug-2026 through 31-Oct-2026 returned 10,000 bills across 20 salesperson IDs, total ₹87,140,981.13.
- All 10,000 purchase IDs were unique and all 10,000 purchase vendor IDs matched a vendor-master record.
- ZIP integrity checked after packaging.

## Not verified

Android Gradle compilation, installation and physical-device WebView/PDF printing were not run in this environment. The source-level and backup-database checks do not replace a real device end-to-end test. Build using the repository's GitHub Actions workflow and install over the existing app without clearing data.
