# SiddhiBill v3.64.72 — Team Member PDF blank-page fix

## Targeted change
- Team Member PDF export now receives a longer WebView layout/paint settling window before the native PDF capture (1,600 ms instead of the standard 700 ms).
- Immediately before capture, the Team report WebView is explicitly invalidated and asked to lay out again; the document/body visibility is normalized and a layout reflow is forced.
- The additional wait and reflow are limited to filenames beginning `Team_Member_Report_`. Other PDF/report exports retain their existing 700 ms path and rendering behavior.
- Existing Team report HTML/data selection, payroll calculations, database schema, local records, and offline architecture are unchanged.

## Validation performed
- `node --check app/src/main/assets/www/app.js` passed.
- Updated Team/Ledger source regression assertions passed against v3.64.72 metadata.
- ZIP integrity check passed.

## Not performed
- Android Gradle compilation was not run because Gradle is unavailable in this environment.
- Physical-device PDF generation was not available. Please validate the two supplied Team Member PDF scenarios in the GitHub Actions build/device; this change targets the blank capture timing/layout issue but is not represented as device-confirmed.
