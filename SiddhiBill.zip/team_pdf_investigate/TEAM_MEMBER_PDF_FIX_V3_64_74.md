# SiddhiBill v3.64.74 — Team Member PDF capture fix

- Changed Team Member PDF export to wait for the WebView JavaScript DOM/layout preparation callback before starting capture.
- After the callback, invalidates and requests layout, then allows a short render-settling interval before measuring and capturing.
- Removes the previous ineffective fixed 1.6-second delay that ran the refresh script and capture in the same task without waiting for the script callback.
- Adds explicit validation for empty/invalid WebView Picture dimensions and too-short document captures; these now show an actionable error instead of saving a blank PDF.
- Other report PDF capture timing and rendering paths remain unchanged.

Validation: JavaScript syntax and source-level regression checks are run for this release. Android Gradle/device PDF rendering must still be verified on a device; this environment does not provide an Android device runtime.
