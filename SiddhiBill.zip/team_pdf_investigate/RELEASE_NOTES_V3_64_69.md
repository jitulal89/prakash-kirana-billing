# SiddhiBill v3.64.69 — Purchase Quick Search and SP/MRP per-unit parsing

Version code: 242  
Version name: 3.64.69

## Included

This release is based on v3.64.68 and retains its customer-payment persistence, purchase edit, ledger pagination, Team Management, billing UI and ledger search changes.

### Purchase Quick List
- Added a product search control to the Purchase Quick List, matching the product-search interaction used in Billing.
- Suggestions search product name, item code and barcode; selecting a product fills its unit, last purchase cost, SP/MRP, GST, HSN and barcode where available.
- Added quantity, unit, purchase rate per unit, GST, HSN, barcode and SP/MRP per-unit fields for quickly adding a selected product.
- Selected items are converted to the existing Purchase Quick List pipe-delimited row format and passed through the same parser and draft synchronisation path.
- Extended structured purchase rows with an eighth column: SP/MRP per unit.
- SP/MRP is carried into the purchase draft item as `sellingRate`, saved with the purchase item, and used by the existing product-master selling-price update.
- Existing 4-to-7-column purchase formats and compact text format remain supported.
- The existing checkbox still controls whether the fourth field in pasted Quick List rows is a per-unit purchase rate or a line total. For the new search controls, the entered purchase rate is always per unit and is converted consistently according to that checkbox.

## Regression validation
- JavaScript syntax check.
- Eight-column parser test including SP/MRP.
- Legacy 7-column and compact purchase Quick List parser tests.
- Purchase calculations and inclusive/exclusive tax mode tests.
- v3.64.68 persistence, purchase edit, ledger pagination, team report and search source assertions.
- Customer and report regression source tests.

Android Gradle compilation and physical-device interaction/PDF print validation were not available in this environment. These source tests do not replace a GitHub Actions build and device test.
