# SiddhiBill v3.64.75 – Reports Section Order and Vendor Ledger Balances

## Changes
- Rearranged the Reports section so the sequence is Customer Ledger, Vendor Ledger, Next Payment Follow-up, and Next Service Due.
- Added Vendor Ledger closing balance alongside opening balance and net movement.
- Closing balance is calculated as vendor master opening balance + purchases in the selected period - amounts paid on purchase invoices - separate vendor payments in the selected period.
- Updated app asset cache-busters and Android version to 3.64.75 (versionCode 248).

## Validation
- `node --check app/src/main/assets/www/app.js` passed.
- Report card order assertions passed.
- Vendor ledger opening/closing balance source assertions passed.
- Android Gradle build and device/PDF rendering tests were not run.
