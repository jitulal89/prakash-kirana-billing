# SiddhiBill v3.64.70 — Team Reports and Ledger PDF Pagination

## Fixes

1. Ledger PDF pagination: the Android PDF path captures a long WebView document and slices the raster image into physical A4 pages. CSS `thead { display: table-header-group }` cannot repeat a table header in that raster workflow. The native renderer now inserts a visual clone of a `.ledger-page-table` header only at calculated A4 page boundaries that fall inside that table. It does not split tables by a fixed row count.
2. Team Management data scoping: team module collections now use the existing current-shop matcher, including the shop-name compatibility fallback, instead of a stricter shop-key-only filter. This prevents valid team members, attendance and payments from disappearing when restored data has a legacy shop key but the same shop name.
3. Sales tracking flags are normalized for boolean `true`, numeric `1`, and string `true`/`1`/`yes` values.
4. Native Team Sales summary and detailed bill queries now normalize salesperson ID aliases, date fallback, and shop-key comparison. This supports restored and older records without changing the stored data.

## Data safety

- No database schema version bump.
- No deletion or rewrite of existing customer, bill, purchase, team, attendance or payment records.
- Existing transaction migration remains unchanged.
- Offline-only architecture retained.

## Validation

- `node --check app/src/main/assets/www/app.js` passed.
- `node test_v36470_team_ledger.js` passed.
- The supplied 2-Nov-2026 backup database was extracted and used for a SQLite migration/query test. All 10,000 sales bills migrated into a test copy; the Team Sales query returned 20 salesperson aggregates covering all 10,000 bills; one member detail query returned 511 bills.
- ZIP integrity checked.

## Not performed

Android Gradle compilation and physical-device PDF rendering were not available in this environment. The PDF header overlay and Team Management UI must still be confirmed in the GitHub Actions build and on the user's device. The backup database test used a separate extracted test copy and did not modify the user's backup.
