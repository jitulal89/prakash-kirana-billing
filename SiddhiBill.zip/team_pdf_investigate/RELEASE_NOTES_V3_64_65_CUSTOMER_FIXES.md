# SiddhiBill v3.64.65 — Customer fixes

- Fixes avoidable full customer-payment serialization during ordinary bill generation.
- Limits the invoice's optional last-five-customer-transactions lookup to five recent SQLite bill records.
- Restores View Bill in Customer Transaction History.
- Aligns customer-card due with transaction balances by netting linked partial receipts correctly.
- Adds Total Balance Due and period totals to Customer Ledger PDF.
- Improves ledger PDF pagination with repeating column headings and non-splitting rows.

Version: `3.64.65`  
Version code: `238`  
Base: `3.64.64`

Validation: JavaScript syntax and targeted source regression assertions passed. Android Gradle compilation and physical-device validation were not performed in this environment.
