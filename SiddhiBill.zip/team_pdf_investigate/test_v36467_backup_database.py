#!/usr/bin/env python3
"""Offline SQLite regression checks against a SiddhiBill backup ZIP."""
import json, sqlite3, sys, tempfile, zipfile, shutil, os

def main(zip_path):
    with tempfile.TemporaryDirectory(prefix="siddhibill-v36467-") as td:
        db_path=os.path.join(td,"dukaanbill.db")
        with zipfile.ZipFile(zip_path) as z:
            with z.open("database/dukaanbill.db") as src, open(db_path,"wb") as dst:
                shutil.copyfileobj(src,dst)
        db=sqlite3.connect(db_path)
        db.execute("CREATE TABLE IF NOT EXISTS transaction_records (collection TEXT NOT NULL, record_id TEXT NOT NULL, sort_date TEXT, source_type TEXT, source_id TEXT, shop_key TEXT, product_name TEXT, record_json TEXT NOT NULL, PRIMARY KEY(collection,record_id))")
        for sql in [
            "CREATE INDEX IF NOT EXISTS idx_transaction_records_date ON transaction_records(collection,sort_date)",
            "CREATE INDEX IF NOT EXISTS idx_transaction_records_shop_date ON transaction_records(collection,shop_key,sort_date)",
            "CREATE INDEX IF NOT EXISTS idx_transaction_records_customer ON transaction_records(collection,shop_key,lower(trim(COALESCE(json_extract(record_json,'$.customer'),''))),sort_date)",
            "CREATE INDEX IF NOT EXISTS idx_transaction_records_source ON transaction_records(collection,source_type,source_id)",
            "CREATE INDEX IF NOT EXISTS idx_transaction_records_product ON transaction_records(collection,shop_key,product_name,sort_date)",
        ]: db.execute(sql)
        expected={"pksBills":10000,"pksPurchases":10000,"pksInventoryMovements":249162}
        for collection,count in expected.items():
            id_expr=("COALESCE(json_extract(e.value,'$.shopKey'),'') || '|' || COALESCE(NULLIF(json_extract(e.value,'$.billNo'),''),e.key)"
                     if collection=="pksBills" else "COALESCE(NULLIF(json_extract(e.value,'$.id'),''),e.key)")
            db.execute("BEGIN")
            db.execute("INSERT OR REPLACE INTO transaction_records(collection,record_id,sort_date,source_type,source_id,shop_key,product_name,record_json) "
                       "SELECT ?, "+id_expr+",COALESCE(json_extract(e.value,'$.date'),''),json_extract(e.value,'$.sourceType'),json_extract(e.value,'$.sourceId'),json_extract(e.value,'$.shopKey'),json_extract(e.value,'$.productName'),e.value "
                       "FROM app_state s,json_each(s.state_value) e WHERE s.state_key=?",(collection,collection))
            migrated=db.execute("SELECT changes()").fetchone()[0]
            db.execute("DELETE FROM app_state WHERE state_key=?",(collection,))
            db.execute("INSERT OR REPLACE INTO meta(meta_key,meta_value) VALUES(?, '1')",("transaction_migrated_"+collection,))
            db.commit()
            assert migrated==count,(collection,migrated,count)
            actual=db.execute("SELECT COUNT(*) FROM transaction_records WHERE collection=?",(collection,)).fetchone()[0]
            assert actual==count,(collection,actual,count)
            print("PASS migration",collection,actual)
        shop="default-shop"; start="2026-08-01"; end="2026-11-03"
        # Customer summary used by Customer and Reports tabs.
        customer_count=db.execute("SELECT COUNT(DISTINCT lower(json_extract(record_json,'$.customer'))) FROM transaction_records WHERE collection='pksBills'").fetchone()[0]
        assert customer_count==400,customer_count
        # Sales and purchase paging used by Bill History and Vendor Management.
        sales_page=db.execute("SELECT record_json FROM transaction_records WHERE collection='pksBills' ORDER BY COALESCE(sort_date,'') DESC,rowid DESC LIMIT 50").fetchall()
        purchase_page=db.execute("SELECT record_json FROM transaction_records WHERE collection='pksPurchases' ORDER BY COALESCE(sort_date,'') DESC,rowid DESC LIMIT 50").fetchall()
        assert len(sales_page)==50 and len(purchase_page)==50
        print("PASS history paging sales=50 purchases=50")
        inventory_page=db.execute("SELECT record_json FROM transaction_records WHERE collection='pksInventoryMovements' ORDER BY COALESCE(sort_date,''),rowid LIMIT 100").fetchall()
        assert len(inventory_page)==100
        print("PASS inventory movement page",len(inventory_page))
        # Selected records resolve by their migrated primary keys.
        first_bill=json.loads(db.execute("SELECT record_json FROM transaction_records WHERE collection='pksBills' ORDER BY rowid LIMIT 1").fetchone()[0])
        bill_id=(first_bill.get("shopKey") or "")+"|"+first_bill["billNo"]
        assert db.execute("SELECT 1 FROM transaction_records WHERE collection='pksBills' AND record_id=?",(bill_id,)).fetchone()
        first_purchase=json.loads(db.execute("SELECT record_json FROM transaction_records WHERE collection='pksPurchases' ORDER BY rowid LIMIT 1").fetchone()[0])
        assert db.execute("SELECT 1 FROM transaction_records WHERE collection='pksPurchases' AND record_id=?",(first_purchase["id"],)).fetchone()
        print("PASS selected bill and purchase lookup")
        # Updating an existing bill/purchase replaces the same record ID rather than duplicating it.
        before_bills=db.execute("SELECT COUNT(*) FROM transaction_records WHERE collection='pksBills'").fetchone()[0]
        updated_bill=dict(first_bill);updated_bill["notes"]="v3.64.67 E2E update probe"
        bid=(updated_bill.get("shopKey") or "")+"|"+updated_bill["billNo"]
        db.execute("INSERT OR REPLACE INTO transaction_records(collection,record_id,sort_date,source_type,source_id,shop_key,product_name,record_json) VALUES(?,?,?,?,?,?,?,?)",
                   ("pksBills",bid,updated_bill.get("date",""),updated_bill.get("sourceType",""),updated_bill.get("sourceId",""),updated_bill.get("shopKey",""),updated_bill.get("productName",""),json.dumps(updated_bill)))
        after_bills=db.execute("SELECT COUNT(*) FROM transaction_records WHERE collection='pksBills'").fetchone()[0]
        assert before_bills==after_bills and json.loads(db.execute("SELECT record_json FROM transaction_records WHERE collection='pksBills' AND record_id=?",(bid,)).fetchone()[0])["notes"]=="v3.64.67 E2E update probe"
        print("PASS bill update upserts the selected record without duplicate")
        before_purchases=db.execute("SELECT COUNT(*) FROM transaction_records WHERE collection='pksPurchases'").fetchone()[0]
        updated_purchase=dict(first_purchase);updated_purchase["notes"]="v3.64.67 E2E purchase update probe"
        db.execute("INSERT OR REPLACE INTO transaction_records(collection,record_id,sort_date,source_type,source_id,shop_key,product_name,record_json) VALUES(?,?,?,?,?,?,?,?)",
                   ("pksPurchases",updated_purchase["id"],updated_purchase.get("date",""),updated_purchase.get("sourceType",""),updated_purchase.get("sourceId",""),updated_purchase.get("shopKey",""),updated_purchase.get("productName",""),json.dumps(updated_purchase)))
        after_purchases=db.execute("SELECT COUNT(*) FROM transaction_records WHERE collection='pksPurchases'").fetchone()[0]
        assert before_purchases==after_purchases and json.loads(db.execute("SELECT record_json FROM transaction_records WHERE collection='pksPurchases' AND record_id=?",(updated_purchase["id"],)).fetchone()[0])["notes"]=="v3.64.67 E2E purchase update probe"
        print("PASS purchase update upserts the selected record without duplicate")
        # Invoice numbering remains monotonic across old and new bill-number formats.
        seq_sql="SELECT MAX(CASE WHEN instr(COALESCE(json_extract(record_json,'$.billNo'),''),'/')>0 THEN CAST(substr(json_extract(record_json,'$.billNo'),instr(json_extract(record_json,'$.billNo'),'/')+1) AS INTEGER) ELSE CAST(substr(json_extract(record_json,'$.billNo'),instr(upper(json_extract(record_json,'$.billNo')),upper(?)||'-')+length(?)+1) AS INTEGER) END) FROM transaction_records WHERE collection='pksBills' AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='') AND instr(upper(COALESCE(json_extract(record_json,'$.billNo'),'')),upper(?)||'-')>0"
        legacy_max=db.execute(seq_sql,("SBX","SBX","default-shop","SBX")).fetchone()[0]
        assert legacy_max==10000,legacy_max
        print("PASS legacy invoice sequence SBX next",legacy_max+1)
        # Team sales summary.
        team=db.execute("SELECT COUNT(*),COALESCE(SUM(CAST(json_extract(record_json,'$.total') AS REAL)),0) FROM transaction_records WHERE collection='pksBills' AND sort_date>=? AND sort_date<=? AND COALESCE(shop_key,'')=? AND COALESCE(json_extract(record_json,'$.salespersonId'),'')<>''",(start,end+"\\uffff",shop)).fetchone()
        assert team[0]>0 and team[1]>0,team
        print("PASS team sales summary",team[0],round(team[1],2))
        member=db.execute("SELECT json_extract(record_json,'$.salespersonId') FROM transaction_records WHERE collection='pksBills' AND COALESCE(json_extract(record_json,'$.salespersonId'),'')<>'' LIMIT 1").fetchone()[0]
        detail=db.execute("SELECT record_json FROM transaction_records WHERE collection='pksBills' AND sort_date>=? AND sort_date<=? AND COALESCE(shop_key,'')=? AND COALESCE(json_extract(record_json,'$.salespersonId'),'')=? ORDER BY COALESCE(sort_date,''),rowid",(start,end+"\\uffff",shop,member)).fetchall()
        assert len(detail)>0
        print("PASS team report detail bills",len(detail))
        # Cash payment report rows.
        cash_sales=db.execute("SELECT COUNT(*) FROM transaction_records WHERE collection='pksBills' AND sort_date>=? AND sort_date<=? AND lower(COALESCE(json_extract(record_json,'$.paymentMode'),'Cash'))='cash'",(start,end+"\\uffff")).fetchone()[0]
        cash_purchases=db.execute("SELECT COUNT(*) FROM transaction_records WHERE collection='pksPurchases' AND COALESCE(json_extract(record_json,'$.date'),'')>=? AND COALESCE(json_extract(record_json,'$.date'),'')<=? AND lower(COALESCE(json_extract(record_json,'$.paymentMode'),'Credit'))='cash'",(start,end+"\\uffff")).fetchone()[0]
        assert cash_sales>0 and cash_purchases>0,(cash_sales,cash_purchases)
        print("PASS cash payment report rows",cash_sales,cash_purchases)
        # Customer summary SQL grouping returns all 400 customer names.
        summary=db.execute("SELECT lower(COALESCE(json_extract(record_json,'$.customer'),'')),COUNT(*) FROM transaction_records WHERE collection='pksBills' AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='') GROUP BY lower(COALESCE(json_extract(record_json,'$.customer'),''))",(shop,)).fetchall()
        assert len(summary)==400,len(summary)
        print("PASS customer summary rows",len(summary))
        # A backup containing normalized rows + migration markers + legacy arrays must not duplicate rows.
        for collection in expected:
            legacy_value=db.execute("SELECT state_value FROM app_state WHERE state_key=?",(collection,)).fetchone()
            if legacy_value is not None:
                before=db.execute("SELECT COUNT(*) FROM transaction_records WHERE collection=?",(collection,)).fetchone()[0]
                marked=db.execute("SELECT meta_value FROM meta WHERE meta_key=?",("transaction_migrated_"+collection,)).fetchone()
                normalized=db.execute("SELECT 1 FROM transaction_records WHERE collection=? LIMIT 1",(collection,)).fetchone()
                if marked and marked[0]=="1" and normalized:
                    db.execute("DELETE FROM app_state WHERE state_key=?",(collection,))
                after=db.execute("SELECT COUNT(*) FROM transaction_records WHERE collection=?",(collection,)).fetchone()[0]
                assert before==after,(collection,before,after)
        db.commit()
        print("PASS compatibility backup does not duplicate normalized rows")
        db.close()

if __name__=="__main__":
    if len(sys.argv)!=2:
        raise SystemExit("Usage: python test_v36467_backup_database.py <SiddhiBill_Backup.zip>")
    main(sys.argv[1])
