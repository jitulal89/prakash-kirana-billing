# SiddhiBill v3.64.67 — Regression Stabilisation

- Background preparation of legacy transaction data before opening the main WebView.
- Manual and automatic backups retain normalized SQLite records, migration markers and legacy-compatible arrays.
- Migration is idempotent when a backup contains both normalized records and compatibility arrays.
- Team Management sales summaries and Team Report bill details use scoped native SQLite queries.
- Payment Transactions report reads cash sales and purchases by date from SQLite.
- Legacy array readers can retrieve migrated records through bounded native pages.
- New Customer action is available on the New Bill screen and does not auto-generate a bill.
- Purchase View opens an in-app preview with PDF/Print.
- Invoice numbering continues correctly for legacy `#PREFIX-00001` and current `#PREFIX-YYYY/NNN` formats.

Validation report: `E2E_TEST_REPORT_V3_64_67.md`.

Important: SQLite tests use the supplied 3-Nov-2026 backup. Source regression tests pass. Android Gradle compilation and physical-device interaction were not possible in this workspace because Android SDK/Gradle/adb/emulator are unavailable.
