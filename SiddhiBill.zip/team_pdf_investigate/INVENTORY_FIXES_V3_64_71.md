# SiddhiBill v3.64.71 — Inventory pagination and report fixes

- Inventory stock list sorts low/negative stock first and renders 25 rows per page. Healthy stock label is `In Stock` and uses a green style.
- Stock movement history renders 25 rows per page; native recent-history retrieval cap increased to 10,000 to support paging across larger histories.
- Stock Summary and Stock Valuation are consolidated into Stock Summary.
- Stock Summary and Low Stock & Reorder reports use compact fixed-layout tables and 25-row screen pagination.
- Report selection changes no longer generate reports. View Report is the explicit generation action; Refresh clears the previous report.
- Stock Movement Ledger includes optional product selection. Native SQLite query filters by product name before returning rows, avoiding transfer of unrelated movement records.
- PDF table uses fixed layout, compact typography, repeated table header group and row break protection.

## Validation
- JavaScript syntax check passed (`node --check`).
- Source-level checks confirm pagination, low-stock-first ordering, product-scoped native query and explicit View Report generation.
- Android Gradle compilation and physical-device PDF/UI tests were not run in this environment.
