# SiddhiBill v3.64.73 — Banking & Cash Book (manual first release)

## Delivered
- Added Banking home tile and Banking screen.
- Multiple bank accounts per shop with account name, bank, optional account number/IFSC/branch, account type, signed opening balance, opening date and notes.
- Negative opening balances supported for overdraft accounts.
- Manual Credit, Debit and Balance Adjustment entries. Adjustment direction can increase or decrease balance; adjustment entries are auditable transactions rather than edits to the opening balance.
- Account-wise balance summary and transaction history with SQL LIMIT/OFFSET pagination (25 rows per page), date filters and matched/unmatched marking.
- Month-end statement closing balance capture and calculated-vs-statement difference.
- All banking data is stored in dedicated SQLite tables: bank_accounts, bank_transactions, bank_reconciliations and bank_reconciliation_items. No banking transaction JSON/app_state array is used.
- Existing backup ZIP process copies the complete SQLite database, so these tables are included in backup and restore without serializing thousands of entries into JSON. Database onOpen creates the tables additively for restored/older DBs.
- Offline-only; no bank APIs or network dependencies.

## Validation
- JavaScript syntax check (`node --check app/src/main/assets/www/app.js`) passed.
- Source checks for native bridge, schema, UI, and version metadata passed.
- ZIP integrity check passed.
- Android Gradle compilation and physical-device functional testing were not available in this environment. Build through GitHub Actions and test on a copy of shop data before production use.

## Notes / scope
- Automatic posting from sales, customer payments, purchases or supplier payments is intentionally not included.
- Bank transfers, statement import, PDF/Excel exports and full line-by-line statement import reconciliation are not part of this initial manual release.
- Opening balance is captured at account creation; subsequent corrections must be recorded as Balance Adjustment transactions.
