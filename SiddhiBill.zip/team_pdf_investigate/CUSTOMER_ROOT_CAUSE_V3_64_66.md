# SiddhiBill v3.64.66 — Customer Billing and Reports Root Cause

## 1. Generate Bill hang
- The prior `nextBillNo()` accessed `state.bills.map(...)`. In Android this can force the lazy bill-history collection to load into the WebView during bill generation.
- `customerDue()` also aggregated the in-memory customer payment collection.
- A normal bill save could serialize the complete `pksCustomerPayments` collection when a linked partial payment was created or updated.

### Changes
- Added `LocalDatabase.nextInvoiceSequence()` and the `Android.nextInvoiceSequence()` bridge. Invoice sequence is calculated in SQLite for the active shop and current year without transferring bill rows to JavaScript.
- Added native customer due aggregation. The native credit calculation uses the greater of bill partial-payment amount and linked receipts for that bill, preventing the same receipt from being deducted twice. Standalone receipts are deducted separately.
- On Android, normal bill save skips serializing the full customer-payment collection. Linked partial receipt records are persisted individually in `pksCustomerPayments`; the previous bill-linked receipt is deleted on bill update.
- Browser-only mode retains the previous in-memory fallback.

## 2. Customer and Vendor Ledger selectors
- Replaced large select dropdowns with searchable text inputs backed by datalists. Vendor names resolve to the existing vendor ID before querying the ledger.

## 3. Ledger PDF pagination
- Customer and vendor ledger tables are emitted as explicit 18-row table segments.
- Every segment has its own `<thead>`; subsequent segments begin on a new page. Footer totals are emitted only on the final segment. Print CSS keeps rows intact and repeats table headers.

## 4. Bill and payment history date filters
- Bill History now has From Date and To Date filters.
- Native SQLite bill-history paging accepts both date bounds, so filtering does not operate only on the currently loaded page.
- Customer/vendor transaction history already has From Date and To Date filters for payment and transaction records; those remain active.

## 5. Outstanding Credit report
- Removed the hard-coded top-10 customer truncation.
- Includes every customer with a non-zero balance, including negative balances/advances.
- Displays total outstanding and paginates 20 customers per page.
- Added one-click PDF output through the existing Android HTML-to-PDF bridge.

## Data safety
- No database schema version bump, database reset, uninstall, or cloud dependency.
- Existing bill and payment IDs are retained. Partial-payment persistence is record-level on Android.
