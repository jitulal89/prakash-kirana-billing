# SiddhiBill v3.64.67 — Regression Stabilisation

## Main corrections
- Run legacy transaction-array migration on a background worker before the main WebView is opened, including after backup restore and activation/owner navigation. The user sees a preparation screen instead of a tab/button appearing frozen.
- Preserve the normalized `transaction_records` table and migration markers in manual and automatic backups while retaining legacy `app_state` arrays for compatibility with older SiddhiBill releases.
- Make migration marker handling idempotent: when a compatibility backup contains both normalized rows and legacy arrays, the current build removes only the redundant legacy array instead of importing the same 10k/249k rows again.
- Add bounded native page reads for legacy code paths that still need a full transaction collection. This prevents a migrated collection from appearing empty merely because its former `app_state` key was removed.
- Move Team Management sales summaries and Team Report bill details to date/shop/salesperson-scoped SQLite queries.
- Move cash sales and cash purchases in the Payment Transactions report to date-scoped SQLite queries.
- Make New Customer available directly on the New Bill screen; saving a customer now selects it without unexpectedly triggering bill generation.
- Replace the purchase View alert with an in-app purchase preview and PDF/Print action.
- Preserve invoice sequence continuity for both legacy `#PREFIX-00001` and current `#PREFIX-2026/001` bill numbers.

## Data safety
- No schema-version bump, data reset, uninstall, cloud service, or internet dependency.
- Existing record IDs and local SQLite data are retained.
- Manual and automatic backups retain both current normalized records and backward-compatible legacy arrays.

## Validation performed
- JavaScript syntax check.
- v3.64.67 targeted source regression suite (18 assertions).
- Existing customer, report, transaction-history and vendor native-pagination checks.
- Real uploaded 3-Nov-2026 backup database migration/query test: 10,000 sales bills, 10,000 purchases, 249,162 inventory movements, 400 customers, 100 vendors and 20 team members.
- SQL smoke tests for customer summary, bill/purchase paging, selected bill/purchase lookup, team sales summary and cash payment report rows.
- Compatibility-backup marker test confirms normalized row counts do not duplicate when legacy arrays are also present.
- ZIP integrity test.

## Not yet performed
- Android Gradle compilation and physical-device APK execution. The environment has no Gradle wrapper, Gradle executable, Android SDK, `adb`, or emulator. Therefore the uploaded APK itself could not be installed and tapped through on a device here. The source/database tests do not replace that final device validation.
