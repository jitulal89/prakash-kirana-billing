# SiddhiBill v3.64.66

- Fix Generate Bill performance by replacing full bill-history invoice numbering and full customer-payment serialization with bounded SQLite/record-level operations on Android.
- Align customer due calculations with linked partial receipts and standalone receipts.
- Replace customer/vendor ledger dropdowns with searchable fields.
- Rework customer and vendor ledger PDF tables into explicit pages with repeated headings and intact rows.
- Add From/To date filters to Bill History and native date-scoped pagination.
- Expand Outstanding Credit to all non-zero balances, show total outstanding, paginate 20 records, and add one-click PDF download.

Validation performed: JavaScript syntax; v3.64.66 source assertions; prior customer, report and vendor regression assertions; SQLite JSON1 query smoke tests; ZIP integrity. Android Gradle compilation and physical-device tests were not available in this environment.
