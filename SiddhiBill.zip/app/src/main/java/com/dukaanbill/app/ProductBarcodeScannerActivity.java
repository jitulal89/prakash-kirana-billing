package com.dukaanbill.app;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.ResultPoint;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;
import com.journeyapps.barcodescanner.DefaultDecoderFactory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;

public class ProductBarcodeScannerActivity extends Activity {
    private static volatile ProductBarcodeScannerActivity activeScanner;
    private static final int CAMERA_PERMISSION_REQUEST = 771;
    private DecoratedBarcodeView barcodeView;
    private TextView queueText;
    private TextView countText;
    private boolean cameraStarted = false;
    private String lastCode = "";
    private long lastCodeAt = 0L;

    public static void updateQueue(String json) {
        ProductBarcodeScannerActivity activity = activeScanner;
        if (activity != null) activity.runOnUiThread(() -> activity.renderQueue(json));
    }

    public static void finishScanner() {
        ProductBarcodeScannerActivity activity = activeScanner;
        if (activity != null) activity.runOnUiThread(activity::finish);
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activeScanner = this;
        getWindow().setStatusBarColor(Color.rgb(20, 28, 38));
        getWindow().setNavigationBarColor(Color.rgb(20, 28, 38));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        barcodeView = new DecoratedBarcodeView(this);
        barcodeView.getBarcodeView().setDecoderFactory(new DefaultDecoderFactory(IntentIntegratorFormats.oneD()));
        barcodeView.setStatusText("Keep the phone vertical • Scan product barcode");
        root.addView(barcodeView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 0.48f));

        LinearLayout listHeader = new LinearLayout(this);
        listHeader.setOrientation(LinearLayout.HORIZONTAL);
        listHeader.setGravity(Gravity.CENTER_VERTICAL);
        listHeader.setPadding(dp(16), dp(10), dp(16), dp(6));
        TextView title = new TextView(this);
        title.setText("Quick List");
        title.setTextColor(Color.rgb(25, 35, 45));
        title.setTextSize(18);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        listHeader.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        countText = new TextView(this);
        countText.setText("0 items");
        countText.setTextColor(Color.rgb(80, 90, 100));
        countText.setTextSize(13);
        listHeader.addView(countText);
        root.addView(listHeader);

        ScrollView scroll = new ScrollView(this);
        queueText = new TextView(this);
        queueText.setText("No items scanned yet");
        queueText.setTextColor(Color.rgb(45, 52, 60));
        queueText.setTextSize(14);
        queueText.setLineSpacing(dp(4), 1f);
        queueText.setPadding(dp(16), dp(4), dp(16), dp(12));
        scroll.addView(queueText);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 0.52f));

        Button done = new Button(this);
        done.setText("Review Quick List / Update Bill");
        done.setAllCaps(false);
        done.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams doneParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        doneParams.setMargins(dp(12), dp(4), dp(12), dp(8));
        root.addView(done, doneParams);

        setContentView(root);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            resumeCamera();
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
        }
    }

    private void resumeCamera() {
        if (barcodeView == null || cameraStarted) return;
        barcodeView.decodeContinuous(new BarcodeCallback() {
            @Override public void barcodeResult(BarcodeResult result) {
                if (result == null || result.getText() == null) return;
                String code = result.getText().trim();
                if (code.isEmpty()) return;
                long now = System.currentTimeMillis();
                if (code.equals(lastCode) && now - lastCodeAt < 1600L) return;
                lastCode = code;
                lastCodeAt = now;
                MainActivity.dispatchProductBarcode(code);
            }
            @Override public void possibleResultPoints(List<ResultPoint> resultPoints) {}
        });
        barcodeView.resume();
        cameraStarted = true;
    }

    private void renderQueue(String json) {
        try {
            JSONArray rows = new JSONArray(json == null ? "[]" : json);
            StringBuilder out = new StringBuilder();
            int units = 0;
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row == null) continue;
                String name = row.optString("name", "Product");
                int qty = Math.max(1, row.optInt("qty", 1));
                String unit = row.optString("unit", "pc");
                double rate = row.optDouble("rate", 0);
                units += qty;
                out.append(i + 1).append(". ").append(name).append('\n')
                   .append("     ").append(qty).append(' ').append(unit)
                   .append("     ₹").append(String.format(java.util.Locale.ROOT, "%.2f", rate)).append('\n');
                if (i + 1 < rows.length()) out.append("--------------------------------\n");
            }
            queueText.setText(out.length() == 0 ? "No items scanned yet" : out.toString());
            countText.setText(rows.length() + " products · " + units + " qty");
        } catch (Exception ignored) {
            queueText.setText("Quick List will appear here as products are scanned");
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onResume() {
        super.onResume();
        if (barcodeView != null && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            barcodeView.resume();
        }
    }

    @Override protected void onPause() {
        if (barcodeView != null) barcodeView.pause();
        super.onPause();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) resumeCamera();
            else {
                Toast.makeText(this, "Camera permission is required for barcode scanning", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }

    @Override protected void onDestroy() {
        if (activeScanner == this) activeScanner = null;
        if (barcodeView != null) barcodeView.pause();
        super.onDestroy();
    }

    // Keep the scanner restricted to common retail 1D barcode types.
    private static final class IntentIntegratorFormats {
        static List<BarcodeFormat> oneD() {
            return Arrays.asList(BarcodeFormat.EAN_13, BarcodeFormat.EAN_8,
                    BarcodeFormat.UPC_A, BarcodeFormat.UPC_E, BarcodeFormat.CODE_128,
                    BarcodeFormat.CODE_39, BarcodeFormat.ITF, BarcodeFormat.CODABAR);
        }
    }
}
