package com.dukaanbill.app;

import android.content.Context;
import android.database.Cursor;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Environment;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import androidx.annotation.NonNull;
import androidx.documentfile.provider.DocumentFile;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.OneTimeWorkRequest;
import androidx.work.ExistingWorkPolicy;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Chained best-effort automatic backup using the configured interval, subject to Android scheduling. */
public class AutoBackupWorker extends Worker {
    public AutoBackupWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }
    @NonNull @Override public Result doWork() {
        Result result = runBackup();
        Context c = getApplicationContext();
        String mode = c.getSharedPreferences("siddhibill_auto_backup", Context.MODE_PRIVATE).getString("destination", "");
        if (!mode.isEmpty()) {
            int hours=c.getSharedPreferences("siddhibill_auto_backup", Context.MODE_PRIVATE).getInt("interval_hours",12);
            hours=Math.max(1,Math.min(720,hours));
            OneTimeWorkRequest next = new OneTimeWorkRequest.Builder(AutoBackupWorker.class)
                .setInitialDelay(hours, TimeUnit.HOURS).build();
            WorkManager.getInstance(c).enqueueUniqueWork("siddhibill-auto-backup-test-loop", ExistingWorkPolicy.APPEND_OR_REPLACE, next);
        }
        return result;
    }

    private Result runBackup() {
        Context c=getApplicationContext();
        try {
            android.content.SharedPreferences prefs=c.getSharedPreferences("siddhibill_auto_backup",Context.MODE_PRIVATE);
            String mode=prefs.getString("destination","");
            if(mode.isEmpty()) return Result.success();
            File dbFile=c.getDatabasePath("dukaanbill.db");
            LocalDatabase helper=new LocalDatabase(c);
            try {
                SQLiteDatabase db=helper.getWritableDatabase();
                try(Cursor cursor=db.rawQuery("PRAGMA wal_checkpoint(FULL)",null)){ if(cursor.moveToFirst() && cursor.getInt(0)!=0) return Result.retry(); }
            } finally { helper.close(); }
            if(!dbFile.exists()||dbFile.length()==0) return Result.retry();
            File workDir=new File(c.getCacheDir(),"auto_backups"); if(!workDir.exists()&&!workDir.mkdirs())return Result.retry();
            String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
            File zip=new File(workDir,"SiddhiBill_AutoBackup_"+stamp+".zip");
            LocalDatabase stateHelper=new LocalDatabase(c); String state; try { state=stateHelper.loadState(); } finally { stateHelper.close(); }
            // Build a compatibility copy with the legacy JSON state keys for older app builds.
            File backupDbFile=new File(workDir,"SiddhiBill_AutoBackup_"+stamp+".db");
            try(InputStream in=new FileInputStream(dbFile);OutputStream copyOut=new FileOutputStream(backupDbFile)){byte[] buffer=new byte[1024*1024];int n;while((n=in.read(buffer))>0)copyOut.write(buffer,0,n);}
            SQLiteDatabase backupDb=SQLiteDatabase.openDatabase(backupDbFile.getAbsolutePath(),null,SQLiteDatabase.OPEN_READWRITE);
            try{backupDb.beginTransaction();try{JSONObject snapshot=new JSONObject(state);for(String key:new String[]{"pksBills","pksPurchases","pksInventoryMovements"})if(snapshot.has(key)){ContentValues cv=new ContentValues();cv.put("state_key",key);cv.put("state_value",snapshot.optString(key,"[]"));backupDb.insertWithOnConflict("app_state",null,cv,SQLiteDatabase.CONFLICT_REPLACE);}backupDb.execSQL("DROP TABLE IF EXISTS transaction_records");backupDb.delete("meta","meta_key LIKE ?",new String[]{"transaction_migrated_%"});backupDb.setTransactionSuccessful();}finally{backupDb.endTransaction();}}finally{backupDb.close();}
            try(ZipOutputStream out=new ZipOutputStream(new FileOutputStream(zip))){
                add(out,backupDbFile,"database/dukaanbill.db");
                out.putNextEntry(new ZipEntry("database/app_state.json"));out.write(state.getBytes(StandardCharsets.UTF_8));out.closeEntry();
                JSONObject fullState = new JSONObject(state);
                String settingsJson = fullState.optString("dukaanBillSettings", "{}");
                try { settingsJson = new JSONObject(settingsJson).toString(2); } catch (Exception ignored) { settingsJson = "{}"; }
                out.putNextEntry(new ZipEntry("settings/settings.json"));out.write(settingsJson.getBytes(StandardCharsets.UTF_8));out.closeEntry();
                // Include every persisted state key, not a manually maintained module list.
                JSONObject moduleSnapshot = new JSONObject();
                JSONArray moduleKeyArray = new JSONArray();
                java.util.Iterator<String> stateKeys = fullState.keys();
                while(stateKeys.hasNext()){String key=stateKeys.next();moduleSnapshot.put(key,fullState.opt(key));moduleKeyArray.put(key);}
                out.putNextEntry(new ZipEntry("data/modules_snapshot.json"));out.write(moduleSnapshot.toString(2).getBytes(StandardCharsets.UTF_8));out.closeEntry();
                JSONObject manifest=new JSONObject();manifest.put("app","SiddhiBill");manifest.put("schemaVersion",3);manifest.put("automatic",true);manifest.put("createdAt",new Date().toString());manifest.put("stateKeys",fullState.length());manifest.put("includesSettings",fullState.has("dukaanBillSettings"));manifest.put("moduleKeys",moduleKeyArray);
                JSONArray tableNames=new JSONArray();
                try(SQLiteDatabase readDb=SQLiteDatabase.openDatabase(backupDbFile.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);Cursor tables=readDb.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",null)){while(tables.moveToNext())tableNames.put(tables.getString(0));}
                manifest.put("tables",tableNames);
                out.putNextEntry(new ZipEntry("database/manifest.json"));out.write(manifest.toString(2).getBytes(StandardCharsets.UTF_8));out.closeEntry();
                out.putNextEntry(new ZipEntry("backup_info.txt"));out.write(("SiddhiBill automatic backup\nIncludes complete SQLite database and every persisted app-state key (including expenses and GST compliance), settings, all business modules, and purchase attachments.\n").getBytes(StandardCharsets.UTF_8));out.closeEntry();
                File docs=new File(c.getFilesDir(),"purchase_docs");File[] files=docs.listFiles();if(files!=null)for(File f:files)if(f.isFile())add(out,f,"attachments/"+f.getName());
            }
            if(zip.length()<100)return Result.retry();
            // Validate the compatibility SQLite DB and the completed archive before uploading.
            try(SQLiteDatabase verifyDb=SQLiteDatabase.openDatabase(backupDbFile.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
                Cursor integrity=verifyDb.rawQuery("PRAGMA integrity_check",null)){
                if(!integrity.moveToFirst()||!"ok".equalsIgnoreCase(integrity.getString(0)))return Result.retry();
            }
            try(java.util.zip.ZipFile verifyZip=new java.util.zip.ZipFile(zip)){
                String[] required={"database/dukaanbill.db","database/app_state.json","database/manifest.json","data/modules_snapshot.json","settings/settings.json"};
                for(String entry:required)if(verifyZip.getEntry(entry)==null)return Result.retry();
                ZipEntry snapshotEntry=verifyZip.getEntry("data/modules_snapshot.json");
                if(snapshotEntry==null||snapshotEntry.getSize()<=0)return Result.retry();
            }
            String treeUri=prefs.getString("tree_uri","");if(treeUri.isEmpty())return Result.failure();
            DocumentFile root=DocumentFile.fromTreeUri(c,Uri.parse(treeUri));if(root==null||!root.canWrite())return Result.retry();
            // Regenerate one daily transaction PDF from the current saved state on every backup run.
            // The same date/shop filename is replaced, so hourly backups do not create hourly PDFs.
            String reportState=state;
            String reportDate=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
            byte[] reportPdf=createDailyReportPdf(reportState,reportDate);
            String shopSafe="SiddhiBill";try{JSONObject rootState=new JSONObject(reportState);JSONObject settings=new JSONObject(rootState.optString("dukaanBillSettings","{}"));String shop=settings.optString("shopName","").trim();if(!shop.isEmpty())shopSafe=shop.replaceAll("[^A-Za-z0-9_-]","_");}catch(Exception ignored){}
            String reportName=shopSafe+"_Daily_Report_"+reportDate+".pdf";
            DocumentFile oldReport=root.findFile(reportName);if(oldReport!=null&&!oldReport.delete())throw new Exception("Could not replace daily report PDF");
            DocumentFile reportTarget=root.createFile("application/pdf",reportName);if(reportTarget==null)throw new Exception("Could not create daily report PDF");
            try(OutputStream out=c.getContentResolver().openOutputStream(reportTarget.getUri(),"w")){if(out==null)throw new Exception("Could not open daily report destination");out.write(reportPdf);out.flush();}
            DocumentFile target=root.createFile("application/zip",zip.getName());if(target==null)return Result.retry();
            try(InputStream in=new FileInputStream(zip);OutputStream out=c.getContentResolver().openOutputStream(target.getUri(),"w")){if(out==null)throw new Exception("Could not open backup destination");byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();}
            prefs.edit().putString("last_success",new Date().toString()).putString("last_file",target.getName()).putString("last_daily_report",reportName).apply();
            zip.delete();backupDbFile.delete();return Result.success();
        } catch(Exception e){ android.util.Log.e("SiddhiBillAutoBackup","Automatic backup failed",e);return Result.retry(); }
    }

    private byte[] createDailyReportPdf(String stateJson,String reportDate)throws Exception{
        JSONObject state=new JSONObject(stateJson);JSONObject settings=new JSONObject(state.optString("dukaanBillSettings","{}"));String shop=settings.optString("shopName","");
        JSONArray bills=parseStoredArray(state,"pksBills"),purchases=parseStoredArray(state,"pksPurchases"),customerPayments=parseStoredArray(state,"pksCustomerPayments"),vendorPayments=parseStoredArray(state,"pksVendorPayments"),vendors=parseStoredArray(state,"pksVendors");
        java.util.ArrayList<String> lines=new java.util.ArrayList<>();
        lines.add("DAILY TRANSACTION REPORT");lines.add((shop.isEmpty()?"SiddhiBill":shop)+" | Business date: "+reportDate);lines.add("Updated: "+new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date()));lines.add("");
        double sales=0,purchaseTotal=0,receipts=0,payments=0;int salesCount=0,purchaseCount=0,receiptCount=0,paymentCount=0;
        lines.add("SALES BILLS");lines.add("Bill No | Customer | Total | Paid | Balance");
        if(bills!=null)for(int i=0;i<bills.length();i++){JSONObject b=bills.optJSONObject(i);if(b==null||!reportDate.equals(b.optString("date","")))continue;double total=b.optDouble("total",0),paid=b.optDouble("partialPaymentAmount",0);sales+=total;salesCount++;lines.add(b.optString("billNo","-")+" | "+b.optString("customer","-")+" | "+fmt(total)+" | "+fmt(paid)+" | "+fmt(Math.max(0,total-paid)));}
        lines.add("Sales bills: "+salesCount+"   Total: "+fmt(sales));lines.add("");
        lines.add("PURCHASE BILLS");lines.add("Invoice No | Vendor | Total | Paid | Balance");
        if(purchases!=null)for(int i=0;i<purchases.length();i++){JSONObject b=purchases.optJSONObject(i);if(b==null||!reportDate.equals(b.optString("date","")))continue;double total=b.optDouble("total",0),paid=b.optDouble("paid",0);purchaseTotal+=total;purchaseCount++;String vendor=b.optString("vendorName",b.optString("supplierName","Vendor"));if(vendors!=null){String vid=b.optString("vendorId","");for(int j=0;j<vendors.length();j++){JSONObject v=vendors.optJSONObject(j);if(v!=null&&vid.equals(v.optString("id",""))){vendor=v.optString("name",vendor);break;}}}lines.add(b.optString("invoiceNo",b.optString("billNo","-"))+" | "+vendor+" | "+fmt(total)+" | "+fmt(paid)+" | "+fmt(Math.max(0,total-paid)));}
        lines.add("Purchase bills: "+purchaseCount+"   Total: "+fmt(purchaseTotal));lines.add("");
        lines.add("CUSTOMER PAYMENTS RECEIVED");lines.add("Customer | Reference | Mode | Amount");
        if(customerPayments!=null)for(int i=0;i<customerPayments.length();i++){JSONObject x=customerPayments.optJSONObject(i);if(x==null||!reportDate.equals(x.optString("date","")))continue;double amount=x.optDouble("amount",0);receipts+=amount;receiptCount++;lines.add(x.optString("customer","Customer")+" | "+x.optString("sourceBillNo",x.optString("note",x.optString("id","-")))+" | "+x.optString("mode","-")+" | "+fmt(amount));}
        lines.add("Customer receipts: "+receiptCount+"   Total: "+fmt(receipts));lines.add("");
        lines.add("VENDOR PAYMENTS MADE");lines.add("Vendor | Reference | Mode | Amount");
        if(vendorPayments!=null)for(int i=0;i<vendorPayments.length();i++){JSONObject x=vendorPayments.optJSONObject(i);if(x==null||!reportDate.equals(x.optString("date","")))continue;double amount=x.optDouble("amount",0);payments+=amount;paymentCount++;String vendor=x.optString("vendorName","Vendor");if(vendors!=null){String vid=x.optString("vendorId","");for(int j=0;j<vendors.length();j++){JSONObject v=vendors.optJSONObject(j);if(v!=null&&vid.equals(v.optString("id",""))){vendor=v.optString("name",vendor);break;}}}lines.add(vendor+" | "+x.optString("note",x.optString("id","-"))+" | "+x.optString("mode","-")+" | "+fmt(amount));}
        lines.add("Vendor payments: "+paymentCount+"   Total: "+fmt(payments));lines.add("");lines.add("DAILY SUMMARY");lines.add("Sales bills total: "+fmt(sales));lines.add("Purchase bills total: "+fmt(purchaseTotal));lines.add("Customer payments received: "+fmt(receipts));lines.add("Vendor payments made: "+fmt(payments));lines.add("Note: Sales/purchase values and cash movements are shown separately; this report excludes item-level details.");
        PdfDocument doc=new PdfDocument();Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setTextSize(9f);int pageNo=1;PdfDocument.Page page=null;Canvas canvas=null;int y=0;final int width=595,height=842,left=36,lineHeight=15;
        for(String line:lines){if(page==null||y>height-42){if(page!=null)doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(width,height,pageNo++).create());canvas=page.getCanvas();paint.setTextSize(9f);y=36;}if(line.equals("DAILY TRANSACTION REPORT")||line.equals("SALES BILLS")||line.equals("PURCHASE BILLS")||line.equals("CUSTOMER PAYMENTS RECEIVED")||line.equals("VENDOR PAYMENTS MADE")||line.equals("DAILY SUMMARY")){paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);paint.setTextSize(line.equals("DAILY TRANSACTION REPORT")?15f:10f);}else{paint.setTypeface(android.graphics.Typeface.DEFAULT);paint.setTextSize(8.5f);}String draw=line;while(paint.measureText(draw)>width-left*2&&draw.length()>12){int cut=Math.max(12,(int)(draw.length()*(width-left*2)/paint.measureText(draw)));canvas.drawText(draw.substring(0,cut),left,y,paint);draw=draw.substring(cut);y+=lineHeight;if(y>height-42){doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(width,height,pageNo++).create());canvas=page.getCanvas();y=36;}}canvas.drawText(draw,left,y,paint);y+=lineHeight;}
        if(page!=null)doc.finishPage(page);java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();doc.writeTo(out);doc.close();return out.toByteArray();
    }
    private JSONArray parseStoredArray(JSONObject state,String key){try{return new JSONArray(state.optString(key,"[]"));}catch(Exception e){return new JSONArray();}}
    private String fmt(double value){return String.format(Locale.US,"%.2f",value);}

    private static void add(ZipOutputStream out,File file,String name)throws Exception{out.putNextEntry(new ZipEntry(name));try(InputStream in=new FileInputStream(file)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}out.closeEntry();}
    private static void copy(File src,File dst)throws Exception{try(InputStream in=new FileInputStream(src);OutputStream out=new FileOutputStream(dst)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();}}
}
