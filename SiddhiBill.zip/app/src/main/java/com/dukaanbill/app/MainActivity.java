package com.dukaanbill.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.print.PageRange;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.graphics.Bitmap.CompressFormat;
import android.view.WindowInsets;
import android.widget.Toast;

import androidx.exifinterface.media.ExifInterface;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.android.gms.tasks.Tasks;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.UUID;
import java.security.MessageDigest;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;
import android.util.DisplayMetrics;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import javax.crypto.Mac;
import java.nio.charset.StandardCharsets;
import java.nio.charset.Charset;
import java.util.Set;
import android.app.AlertDialog;
import android.widget.EditText;
import android.text.InputType;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import android.util.Base64;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_BT_PRINT = 7001;
    private String pendingDirectPrintJson;
    private static final int REQ_PURCHASE_DOCUMENT = 9011;
    private static final int REQ_BACKUP_CREATE = 9112;
    private static final int REQ_BACKUP_RESTORE = 9113;
    private static final int REQ_WEB_FILE_CHOOSER = 9114;
    private static final int REQ_SYNC_DOWNLOAD = 9116;
    private byte[] pendingSyncDownloadBytes;
    private ValueCallback<Uri[]> webFileCallback;
    private static final String BACKUP_DB_ENTRY = "database/dukaanbill.db";
    private static final String BACKUP_STATE_ENTRY = "database/app_state.json";
    private static final String BACKUP_IDENTITY_ENTRY = "security/shop_identity.sig";
    private static final String BACKUP_OWNER_ENTRY = "owner/owner_dashboard.json";
    private String pendingOwnerDashboardBackup = "{}";
    // Shop-name password is never stored in the WebView/JavaScript. The release stores only a salted, iterated digest.
    private static final String SHOP_PASSWORD_SALT_HEX = "b3d98978922aaabc368ea51ec188ff8d";
    private static final String SHOP_PASSWORD_DIGEST_HEX = "bc53398cdf28d9799555c3c64bfcf6f4f767040fba3e23bfc48c3dcf7da5a743";
    private static final int SHOP_PASSWORD_ITERATIONS = 200000;
    private static final String OWNER_PUBLIC_KEY_B64 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtY03iAdf43OFBRxNSkevWkJC4nJXLthXn3PBbPahDd5bleS9NemELweCBfQurYtdI4QGGm6dxpNTcPK6gylJAN8Uu3fZ5hlZ+ecvOMxy2yJAwRKUA9Hn/96LfjuBkuHnnVLUA7aXQqwpM0ggWH0TMEvgp/yBbErjwJEZeuonx96gNnNA2a2IKi/DNtjhgeAnyOBkLuswc+Gma9xHWsYuj7phEW1O6cYaBJJ8w28NgLfkuDKg50ln+9kItxpojrYaVOXWr2gSUVxiWd8GNECgU8KOkWco9F45Qx7HS0ydfpYOorDG9l51DrJ76eVls8xDYiYscaEZ8RPrkSw6UmkRsQIDAQAB";
    private static final String DEVICE_KEY_ALIAS = "DukaanBillDeviceKey";
    private static final String OWNER_PREFS = "owner_security";
    private static final int REQ_SCAN_QR = 9901;
    private static final int REQ_QUICKLIST_IMAGE = 9012;
    private static final int REQ_QUICKLIST_CAMERA = 9013;
    private static final int REQ_QUICKLIST_PDF = 9115;
    private Uri quickListCameraUri = null;
    private boolean pendingQuickListCameraLaunch = false;
    private Uri purchaseCameraUri = null;
    private boolean pendingPurchaseCameraLaunch = false;
    private static final int REQ_QUICKLIST_CAMERA_PERMISSION = 9015;
    private static final int REQ_PURCHASE_CAMERA = 9020;
    private static final int REQ_PURCHASE_CAMERA_PERMISSION = 9021;
    private static final String OWNER_PRIVATE_PREF = "encrypted_private";
    private static final String OWNER_SALT_PREF = "salt";
    private static final String OWNER_IV_PREF = "iv";
    // Owner private key is unlocked once per app session; shop setup/approval does not ask for the PIN repeatedly.
    private PrivateKey sessionOwnerPrivateKey;

    private File purchaseDocsDir;
    private LocalDatabase localDb;
    private File pendingBackupZip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Keep the WebView inside the Android system bars. The web UI supplies its own safe margins.
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(true);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(242,244,247));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(36,70,111));
        webView = new WebView(this);
        webView.setFitsSystemWindows(true);
        setContentView(webView);

        purchaseDocsDir = new File(getFilesDir(), "purchase_docs");
        if (!purchaseDocsDir.exists()) purchaseDocsDir.mkdirs();
        localDb = new LocalDatabase(this);
        PDFBoxResourceLoader.init(getApplicationContext());

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Clear WebView HTTP/service-worker cache on each launch. App data lives in native SQLite,
        // so this is safe and prevents an older bundled app.js from shadowing current button handlers.
        webView.clearCache(true);
        webView.clearHistory();
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (webFileCallback != null) webFileCallback.onReceiveValue(null);
                webFileCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, REQ_WEB_FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    webFileCallback = null;
                    Toast.makeText(MainActivity.this, "Could not open file picker: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
        if (isActivated()) webView.loadUrl("file:///android_asset/www/index.html");
        else webView.loadUrl("file:///android_asset/www/activation.html");
        handleIncomingDukaanBill(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingDukaanBill(intent);
    }

    private boolean isActivated() {
        android.content.SharedPreferences p=getSharedPreferences("activation", MODE_PRIVATE);
        if (p.getBoolean("activated", false)) return true; // Preserve existing authorized installations.
        long expiry=p.getLong("trial_expiry", 0L);
        return expiry>System.currentTimeMillis();
    }
    private void setActivated(boolean v) {
        android.content.SharedPreferences.Editor e=getSharedPreferences("activation", MODE_PRIVATE).edit().putBoolean("activated", v);
        if(v) e.remove("trial_start").remove("trial_expiry");
        e.apply();
    }
    // Trial access is never granted by a button tap. It requires an owner-signed,
    // device-bound approval token, matching the permanent activation workflow.
    private String startTrial() {
        android.content.SharedPreferences p=getSharedPreferences("activation", MODE_PRIVATE);
        if(p.getBoolean("activated",false)) return "ALREADY_ACTIVATED";
        long expiry=p.getLong("trial_expiry",0L);
        if(expiry>0L) return expiry>System.currentTimeMillis()?"TRIAL_ACTIVE":"TRIAL_EXPIRED";
        if(p.getBoolean("trial_used",false)) return "TRIAL_EXPIRED";
        return "APPROVAL_REQUIRED";
    }
    private void showActivationPage(String message) {
        runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.loadUrl("file:///android_asset/www/activation.html");
            if(message!=null&&!message.isEmpty()) webView.postDelayed(() -> {
                if(getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).contains("pending_owner_key")) webView.evaluateJavascript("window.finishIncomingOwnerActivation && window.finishIncomingOwnerActivation()",null);
                else webView.evaluateJavascript("window.showActivationMessage && window.showActivationMessage("+JSONObject.quote(message)+")",null);
            },500); });
    }
    private void shareActivationFile(String tokenJson) {
        try {
            JSONObject t=new JSONObject(tokenJson);
            if(!"DUKAAN_ACTIVATION_TOKEN".equals(t.optString("type")) && !"DUKAAN_OWNER_ACTIVATION_TOKEN".equals(t.optString("type"))) throw new Exception("Only signed activation approvals can be shared as .SiddhiBill files.");
            File dir=new File(getCacheDir(),"share"); if(!dir.exists())dir.mkdirs();
            String shop="SiddhiBill_Activation";
            try { JSONObject pay=new JSONObject(new String(unb64(t.getString("payload")),StandardCharsets.UTF_8)); shop=pay.optString("shopName",shop).replaceAll("[^A-Za-z0-9_-]","_"); }catch(Exception ignored){}
            File f=new File(dir,shop+".SiddhiBill"); try(FileOutputStream out=new FileOutputStream(f)){out.write(tokenJson.getBytes(StandardCharsets.UTF_8));out.flush();}
            Uri uri=Uri.parse("content://com.siddhibill.app.share/"+Uri.encode(f.getName()));
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("application/vnd.siddhibill.activation"); i.putExtra(Intent.EXTRA_STREAM,uri); i.putExtra(Intent.EXTRA_SUBJECT,"SiddhiBill Activation"); i.putExtra(Intent.EXTRA_TEXT,"Open this signed SiddhiBill activation file with SiddhiBill."); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); i.setClipData(ClipData.newUri(getContentResolver(),f.getName(),uri)); startActivity(Intent.createChooser(i,"Send SiddhiBill activation file"));
        } catch(Exception e) { Toast.makeText(this,"Could not create activation file: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }
    private PublicKey ownerPublicKey() throws Exception { return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.decode(OWNER_PUBLIC_KEY_B64, Base64.DEFAULT))); }
    private KeyPair deviceKeyPair() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (ks.containsAlias(DEVICE_KEY_ALIAS)) return ((KeyStore.PrivateKeyEntry)ks.getEntry(DEVICE_KEY_ALIAS,null)).getPrivateKey()==null?null:new KeyPair(ks.getCertificate(DEVICE_KEY_ALIAS).getPublicKey(),((KeyStore.PrivateKeyEntry)ks.getEntry(DEVICE_KEY_ALIAS,null)).getPrivateKey());
        KeyPairGenerator g=KeyPairGenerator.getInstance("RSA","AndroidKeyStore");
        g.initialize(new android.security.keystore.KeyGenParameterSpec.Builder(DEVICE_KEY_ALIAS, android.security.keystore.KeyProperties.PURPOSE_SIGN|android.security.keystore.KeyProperties.PURPOSE_VERIFY).setDigests(android.security.keystore.KeyProperties.DIGEST_SHA256).setSignaturePaddings(android.security.keystore.KeyProperties.SIGNATURE_PADDING_RSA_PKCS1).setKeySize(2048).build());
        return g.generateKeyPair();
    }
    private String b64(byte[] b){ return Base64.encodeToString(b,Base64.NO_WRAP); }
    private byte[] unb64(String s){ return Base64.decode(s,Base64.DEFAULT); }
    private String devicePublicKeyB64() throws Exception { return b64(deviceKeyPair().getPublic().getEncoded()); }
    // Android ID is app-signing-key scoped and normally survives reinstall on Android 8+. Used only to avoid duplicate Owner Dashboard entries.
    private String stableDeviceId() { String id=android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID); return id==null?"":id; }
    private String createActivationRequest() throws Exception { return createActivationRequest("SHOP"); }
    private String createActivationRequest(String deviceType) throws Exception {
        JSONObject o=new JSONObject(); o.put("type","DUKAAN_ACTIVATION_REQUEST"); o.put("version",2); o.put("requestId",UUID.randomUUID().toString()); o.put("deviceKey",devicePublicKeyB64()); o.put("deviceIdentifier",stableDeviceId()); o.put("deviceType",deviceType==null?"SHOP":deviceType); o.put("appVersion","3.59.2"); o.put("createdAt",System.currentTimeMillis());
        if("SHOP".equalsIgnoreCase(deviceType)) {
            android.content.SharedPreferences sp=getSharedPreferences("activation",MODE_PRIVATE);
            String setup=sp.getString("pending_shop_setup",null);
            if(setup!=null) {
                try { JSONObject inv=verifyShopSetupInvite(setup); o.put("shopSetupId",inv.optString("setupId")); o.put("shopName",inv.optString("shopName")); o.put("shopMobile",inv.optString("shopMobile")); o.put("managerName",inv.optString("managerName")); o.put("address",inv.optString("address")); o.put("gstin",inv.optString("gstin")); o.put("state",inv.optString("state")); } catch(Exception ignored) {}
            }
        }
        return o.toString();
    }
    private byte[] deriveOwnerKey(String pin, byte[] salt) throws Exception { PBEKeySpec spec=new PBEKeySpec(pin.toCharArray(),salt,120000,256); return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
    private String normalizeOwnerPrivateKeyInput(String input) throws Exception {
        if (input == null) throw new Exception("Owner private key is empty");
        String s=input.trim();
        // Accept raw Base64, PEM, or the complete distributed Owner key text file.
        int begin=s.indexOf("-----BEGIN ");
        if(begin>=0){
            int firstNl=s.indexOf('\n',begin);
            int endMarker=s.indexOf("-----END ", begin);
            if(firstNl>=0 && endMarker>firstNl) s=s.substring(firstNl+1,endMarker);
        }
        StringBuilder b=new StringBuilder();
        String[] lines=s.replace("\r","\n").split("\n+");
        for(String line:lines){
            String t=line.trim();
            if(t.isEmpty() || t.startsWith("-----")) continue;
            // Ignore the two human-readable lines in the supplied key file.
            if(t.equalsIgnoreCase("DUKAAN BILL OWNER PRIVATE KEY") || t.equalsIgnoreCase("KEEP THIS FILE PRIVATE. DO NOT SHARE.")) continue;
            if(t.matches("[A-Za-z0-9+/=]+")) b.append(t);
        }
        String out=b.toString();
        if(out.length()<100 || (out.length()%4)!=0) throw new Exception("Invalid Owner private key. Paste the complete contents of DukaanBill_Owner_Private_Key.txt.");
        return out;
    }
    private void saveOwnerPrivate(String keyB64,String pin) throws Exception {
        String normalized=normalizeOwnerPrivateKeyInput(keyB64);
        byte[] raw=unb64(normalized); PrivateKey pk=KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(raw));
        byte[] challenge="DUKAAN-BILL-OWNER-KEY-CHECK".getBytes(StandardCharsets.UTF_8); Signature sig=Signature.getInstance("SHA256withRSA"); sig.initSign(pk); sig.update(challenge); byte[] signed=sig.sign(); Signature vs=Signature.getInstance("SHA256withRSA"); vs.initVerify(ownerPublicKey()); vs.update(challenge); if(!vs.verify(signed)) throw new Exception("Owner key does not match this Dukaan Bill release");
        byte[] salt=new byte[16]; new java.security.SecureRandom().nextBytes(salt); byte[] iv=new byte[12]; new java.security.SecureRandom().nextBytes(iv); byte[] aes=deriveOwnerKey(pin,salt); Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(aes,"AES"),new GCMParameterSpec(128,iv)); byte[] enc=c.doFinal(raw);
        getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).edit().putString(OWNER_PRIVATE_PREF,b64(enc)).putString(OWNER_SALT_PREF,b64(salt)).putString(OWNER_IV_PREF,b64(iv)).apply();
    }
    private PrivateKey loadOwnerPrivate(String pin) throws Exception { android.content.SharedPreferences p=getSharedPreferences(OWNER_PREFS,MODE_PRIVATE); String e=p.getString(OWNER_PRIVATE_PREF,null); if(e==null)throw new Exception("Owner key is not configured"); byte[] aes=deriveOwnerKey(pin,unb64(p.getString(OWNER_SALT_PREF,""))); Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(aes,"AES"),new GCMParameterSpec(128,unb64(p.getString(OWNER_IV_PREF,"")))); return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(c.doFinal(unb64(e)))); }
    private String encryptOwnerKeyForDevice(String keyB64, String deviceKeyB64) throws Exception {
        PublicKey devicePub=KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(unb64(deviceKeyB64)));
        byte[] raw=unb64(keyB64);
        byte[] aesRaw=new byte[32]; new java.security.SecureRandom().nextBytes(aesRaw);
        byte[] iv=new byte[12]; new java.security.SecureRandom().nextBytes(iv);
        Cipher aes=Cipher.getInstance("AES/GCM/NoPadding"); aes.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(aesRaw,"AES"),new GCMParameterSpec(128,iv));
        byte[] enc=aes.doFinal(raw);
        Cipher rsa=Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding"); rsa.init(Cipher.ENCRYPT_MODE,devicePub,new OAEPParameterSpec("SHA-256","MGF1",java.security.spec.MGF1ParameterSpec.SHA256,PSource.PSpecified.DEFAULT));
        JSONObject e=new JSONObject(); e.put("ek",b64(rsa.doFinal(aesRaw))); e.put("iv",b64(iv)); e.put("data",b64(enc)); return e.toString();
    }
    private String decryptOwnerKeyForThisDevice(String envelope) throws Exception {
        JSONObject e=new JSONObject(envelope); KeyPair kp=deviceKeyPair();
        Cipher rsa=Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding"); rsa.init(Cipher.DECRYPT_MODE,kp.getPrivate(),new OAEPParameterSpec("SHA-256","MGF1",java.security.spec.MGF1ParameterSpec.SHA256,PSource.PSpecified.DEFAULT));
        byte[] aesRaw=rsa.doFinal(unb64(e.getString("ek"))); Cipher aes=Cipher.getInstance("AES/GCM/NoPadding"); aes.init(Cipher.DECRYPT_MODE,new SecretKeySpec(aesRaw,"AES"),new GCMParameterSpec(128,unb64(e.getString("iv")))); return b64(aes.doFinal(unb64(e.getString("data"))));
    }
    private PrivateKey ownerSigningKey() throws Exception {
        if (sessionOwnerPrivateKey == null) throw new Exception("Owner tools are locked. Enter the Owner PIN once to unlock.");
        return sessionOwnerPrivateKey;
    }
    private boolean unlockOwnerSession(String pin) {
        try { sessionOwnerPrivateKey = loadOwnerPrivate(pin); return true; }
        catch (Exception e) { sessionOwnerPrivateKey = null; return false; }
    }
    private String createShopSetupInvite(String shopName,String shopMobile,String managerName,String address,String gstin,String state) throws Exception {
        if(shopName==null || shopName.trim().isEmpty()) throw new Exception("Shop name is required");
        PrivateKey pk=ownerSigningKey();
        JSONObject payload=new JSONObject();
        payload.put("type","DUKAAN_SHOP_SETUP_INVITE_PAYLOAD");
        payload.put("setupId",UUID.randomUUID().toString());
        payload.put("shopName",shopName.trim());
        payload.put("shopMobile",shopMobile==null?"":shopMobile.trim());
        payload.put("managerName",managerName==null?"":managerName.trim());
        payload.put("address",address==null?"":address.trim());
        payload.put("gstin",gstin==null?"":gstin.trim());
        payload.put("state",state==null?"":state.trim());
        payload.put("createdAt",System.currentTimeMillis());
        byte[] data=payload.toString().getBytes(StandardCharsets.UTF_8);
        Signature sig=Signature.getInstance("SHA256withRSA"); sig.initSign(pk); sig.update(data);
        JSONObject invite=new JSONObject(); invite.put("type","DUKAAN_SHOP_SETUP_INVITE"); invite.put("version",1); invite.put("payload",b64(data)); invite.put("signature",b64(sig.sign()));
        return invite.toString();
    }

    private JSONObject verifyShopSetupInvite(String inviteJson) throws Exception {
        JSONObject invite=new JSONObject(inviteJson);
        if(!"DUKAAN_SHOP_SETUP_INVITE".equals(invite.optString("type"))) throw new Exception("Invalid Shop Setup QR");
        byte[] payload=unb64(invite.getString("payload"));
        Signature sig=Signature.getInstance("SHA256withRSA"); sig.initVerify(ownerPublicKey()); sig.update(payload);
        if(!sig.verify(unb64(invite.getString("signature")))) throw new Exception("Shop Setup QR signature is invalid");
        JSONObject p=new JSONObject(new String(payload,StandardCharsets.UTF_8));
        if(!"DUKAAN_SHOP_SETUP_INVITE_PAYLOAD".equals(p.optString("type"))) throw new Exception("Invalid Shop Setup payload");
        return p;
    }

    private String approveActivation(String requestJson) throws Exception { return approveActivation(requestJson, "PERMANENT"); }
    private String approveActivation(String requestJson, String licenceType) throws Exception {
        JSONObject req=new JSONObject(requestJson);
        if(!"DUKAAN_ACTIVATION_REQUEST".equals(req.optString("type"))) throw new Exception("Invalid activation request");
        String deviceKey=req.getString("deviceKey"), requestId=req.getString("requestId"), deviceType=req.optString("deviceType","SHOP");
        JSONObject payloadObj=new JSONObject();
        payloadObj.put("requestId",requestId);
        payloadObj.put("deviceKey",deviceKey);
        payloadObj.put("deviceIdentifier",req.optString("deviceIdentifier",""));
        payloadObj.put("issuedAt",System.currentTimeMillis());
        payloadObj.put("appVersion",req.optString("appVersion","3.52.0"));
        payloadObj.put("deviceType",deviceType);
        String approvedLicence = "TRIAL".equalsIgnoreCase(licenceType) ? "TRIAL" : "PERMANENT";
        payloadObj.put("licenseType", approvedLicence);
        if ("TRIAL".equals(approvedLicence)) {
            long trialStart = System.currentTimeMillis();
            payloadObj.put("trialStart", trialStart);
            payloadObj.put("trialExpiry", trialStart + 7L*24L*60L*60L*1000L);
        }

        if("SHOP".equalsIgnoreCase(deviceType)) {
            JSONObject shop=req.optJSONObject("assignedShop");
            if(shop!=null) {
                String[] keys={"shopId","shopName","shopMobile","managerName","address","gstin","state",
                    "billPrefix","billStart","billTitle","paperSize","bluetoothPrinter",
                    "vendorManagement","taxation","taxInvoicePrefix","taxInvoiceStart",
                    "reverseCharge","tagline","footer","signature","creditFooter","showCustomer","printCustomerMobile","printPaymentMode","fssai","termsConditions","printTermsConditions","customBillField1Label","customBillField1Position","customBillField2Label","customBillField2Position","customBillField3Label","customBillField3Position","showDateFollowUpReport"};
                for(String k:keys) if(shop.has(k)) payloadObj.put(k,shop.opt(k));
            }
        }

        if("OWNER".equalsIgnoreCase(deviceType)){
            payloadObj.put("type","DUKAAN_OWNER_TOKEN_PAYLOAD");
            payloadObj.put("ownerKeyEnvelope",encryptOwnerKeyForDevice(b64(ownerSigningKey().getEncoded()),deviceKey));
        } else payloadObj.put("type","DUKAAN_ACTIVATION_TOKEN_PAYLOAD");

        byte[] payload=payloadObj.toString().getBytes(StandardCharsets.UTF_8);
        PrivateKey pk=ownerSigningKey();
        Signature sig=Signature.getInstance("SHA256withRSA");
        sig.initSign(pk); sig.update(payload);

        JSONObject token=new JSONObject();
        token.put("type", "OWNER".equalsIgnoreCase(deviceType)?"DUKAAN_OWNER_ACTIVATION_TOKEN":"DUKAAN_ACTIVATION_TOKEN");
        token.put("version",2); token.put("payload",b64(payload)); token.put("signature",b64(sig.sign()));
        return token.toString();
    }

    private void applyShopSettingsToAppState(JSONObject p) {
        try {
            JSONObject root=new JSONObject(loadAppState());
            JSONObject settings=root.optJSONObject("dukaanBillSettings");
            if(settings==null) settings=new JSONObject();

            String[] keys={"shopName","shopMobile","address","gstin","fssai","businessState","billPrefix","billTitle",
                    "paperSize","bluetoothPrinter","taxInvoicePrefix","tagline","footer","signature","creditFooter","termsConditions","customBillField1Label","customBillField1Position","customBillField2Label","customBillField2Position","customBillField3Label","customBillField3Position","showDateFollowUpReport"};
            for(String k:keys) if(p.has(k)) settings.put(k,p.optString(k,""));

            if(p.has("billStart")) settings.put("billStart",p.optInt("billStart",1));
            if(p.has("taxInvoiceStart")) settings.put("taxInvoiceStart",p.optInt("taxInvoiceStart",1));
            if(p.has("vendorManagement")) settings.put("vendorManagement",p.optBoolean("vendorManagement",false));
            if(p.has("taxation")) { settings.put("taxation",p.optBoolean("taxation",false)); settings.put("taxationEnabled",p.optBoolean("taxation",false)); }
            if(p.has("printTermsConditions")) settings.put("printTermsConditions",p.optBoolean("printTermsConditions",false));
            if(p.has("reverseCharge")) settings.put("reverseCharge",p.optBoolean("reverseCharge",false));
            if(p.has("showCustomer")) settings.put("showCustomer",p.optBoolean("showCustomer",false));
            if(p.has("printCustomerMobile")) settings.put("printCustomerMobile",p.optBoolean("printCustomerMobile",true));
            if(p.has("printPaymentMode")) settings.put("printPaymentMode",p.optBoolean("printPaymentMode",true));
            if(p.has("showDateFollowUpReport")) settings.put("showDateFollowUpReport",p.optBoolean("showDateFollowUpReport",true));

            if(p.has("shopMobile")) {
                JSONArray a=new JSONArray();
                for(String x:p.optString("shopMobile","").split("[,/;]")) if(!x.trim().isEmpty()) a.put(x.trim());
                settings.put("shopMobiles",a);
            }
            root.put("dukaanBillSettings",settings);
            saveAppState(root.toString());
        } catch(Exception ignored) {}
    }

    private boolean applyActivation(String tokenJson) throws Exception {
        JSONObject t=new JSONObject(tokenJson); String type=t.optString("type");
        if(!"DUKAAN_ACTIVATION_TOKEN".equals(type) && !"DUKAAN_OWNER_ACTIVATION_TOKEN".equals(type)) throw new Exception("Unsupported SiddhiBill activation file type");
        byte[] payload=unb64(t.getString("payload")); String sigB=t.getString("signature");
        Signature s=Signature.getInstance("SHA256withRSA"); s.initVerify(ownerPublicKey()); s.update(payload); if(!s.verify(unb64(sigB)))throw new Exception("Activation signature is invalid");
        JSONObject p=new JSONObject(new String(payload,StandardCharsets.UTF_8)); String localKey=devicePublicKeyB64(); if(!MessageDigest.isEqual(localKey.getBytes(StandardCharsets.UTF_8),p.getString("deviceKey").getBytes(StandardCharsets.UTF_8)))throw new Exception("This activation was issued for another phone");
        if("DUKAAN_OWNER_ACTIVATION_TOKEN".equals(type)){
            getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).edit().putString("pending_owner_key",decryptOwnerKeyForThisDevice(p.getString("ownerKeyEnvelope"))).apply(); return true;
        }
        if("DUKAAN_ACTIVATION_TOKEN".equals(type) && "TRIAL".equalsIgnoreCase(p.optString("licenseType","PERMANENT"))) {
            long issued = p.optLong("trialStart", 0L);
            long expiry = p.optLong("trialExpiry", 0L);
            if (issued <= 0L || expiry <= issued || expiry-issued > 7L*24L*60L*60L*1000L + 60000L) throw new Exception("Trial approval has an invalid expiry.");
            android.content.SharedPreferences existing = getSharedPreferences("activation",MODE_PRIVATE);
            if (existing.getBoolean("trial_used", false) && existing.getLong("trial_start",0L) != issued) throw new Exception("A trial has already been used on this installation.");
            existing.edit().putLong("trial_start",issued).putLong("trial_expiry",expiry).putBoolean("trial_used",true)
                .putString("shop_setup_id",p.optString("shopId",""))
                .putString("shop_name",p.optString("shopName",""))
                .putString("shop_mobile",p.optString("shopMobile",""))
                .putString("shop_manager",p.optString("managerName",""))
                .putString("shop_address",p.optString("address",""))
                .putString("shop_gstin",p.optString("gstin",""))
                .putString("shop_state",p.optString("state",""))
                .remove("pending_shop_setup").apply();
            applyShopSettingsToAppState(p);
            return true;
        }
        if("DUKAAN_ACTIVATION_TOKEN".equals(type)) {
            getSharedPreferences("activation",MODE_PRIVATE).edit()
                .putString("shop_setup_id",p.optString("shopId",""))
                .putString("shop_name",p.optString("shopName",""))
                .putString("shop_mobile",p.optString("shopMobile",""))
                .putString("shop_manager",p.optString("managerName",""))
                .putString("shop_address",p.optString("address",""))
                .putString("shop_gstin",p.optString("gstin",""))
                .putString("shop_state",p.optString("state",""))
                .remove("pending_shop_setup").apply();
            applyShopSettingsToAppState(p);
        }
        setActivated(true); return true;
    }
    private boolean finalizeOwnerActivation(String pin) throws Exception { if(pin==null||pin.length()<6) throw new Exception("Owner PIN must be at least 6 characters"); String k=getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).getString("pending_owner_key",null); if(k==null) throw new Exception("No pending Owner activation"); saveOwnerPrivate(k,pin); sessionOwnerPrivateKey=loadOwnerPrivate(pin); getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).edit().remove("pending_owner_key").apply(); setActivated(true); return true; }
    private String qrDataUrl(String text) throws Exception { BitMatrix m=new MultiFormatWriter().encode(text,BarcodeFormat.QR_CODE,800,800); Bitmap bmp=Bitmap.createBitmap(800,800,Bitmap.Config.ARGB_8888); for(int x=0;x<800;x++)for(int y=0;y<800;y++)bmp.setPixel(x,y,m.get(x,y)?android.graphics.Color.BLACK:android.graphics.Color.WHITE); ByteArrayOutputStream out=new ByteArrayOutputStream(); bmp.compress(CompressFormat.PNG,100,out); bmp.recycle(); return "data:image/png;base64,"+b64(out.toByteArray()); }
    private String billUpiPayload(JSONObject bill, JSONObject cfg) {
        if(cfg==null || !cfg.optBoolean("upiQrEnabled",false)) return "";
        if("merchant".equals(cfg.optString("upiQrSource","upi"))) return "";
        String pa=cfg.optString("upiId","").trim(); if(pa.isEmpty()) return "";
        // Intentionally omit the UPI amount so the customer can enter/change it in their UPI app.
        try{return "upi://pay?pa="+java.net.URLEncoder.encode(pa,"UTF-8")+"&pn="+java.net.URLEncoder.encode(cfg.optString("upiPayeeName",cfg.optString("shopName","Shop")),"UTF-8")+"&cu=INR&tn="+java.net.URLEncoder.encode(bill.optString("billNo","SiddhiBill"),"UTF-8");}catch(Exception e){return "";}
    }
    private Bitmap createQrBitmap(String payload,int size) { try { if(payload==null||payload.isEmpty())return null; BitMatrix m=new MultiFormatWriter().encode(payload,BarcodeFormat.QR_CODE,size,size); Bitmap bmp=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888); for(int x=0;x<size;x++)for(int y=0;y<size;y++)bmp.setPixel(x,y,m.get(x,y)?android.graphics.Color.BLACK:android.graphics.Color.WHITE); return bmp;}catch(Exception e){return null;} }
    private void drawCenteredBillQr(Canvas canvas, Paint paint, JSONObject bill, JSONObject cfg, int centerX, int topY, int size) {
        if(cfg==null||!cfg.optBoolean("upiQrEnabled",false))return;
        Bitmap qr=null; String source=cfg.optString("upiQrSource","upi");
        try { if("merchant".equals(source)){String data=cfg.optString("merchantQrData","");if(data.startsWith("data:image")){String encoded=data.substring(data.indexOf(',')+1);byte[] bytes=Base64.decode(encoded,Base64.DEFAULT);qr=BitmapFactory.decodeByteArray(bytes,0,bytes.length);}} else qr=createQrBitmap(billUpiPayload(bill,cfg),size);
            if(qr!=null){float scale=Math.min((float)size/qr.getWidth(),(float)size/qr.getHeight());float w=qr.getWidth()*scale,h=qr.getHeight()*scale;canvas.drawBitmap(qr,null,new RectF(centerX-w/2f,topY,centerX+w/2f,topY+h),paint);if(cfg.optBoolean("upiPrintAmount",true)){paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(8);canvas.drawText("Scan & Pay - Enter Amount",centerX,topY+(int)h+11,paint);paint.setTextAlign(Paint.Align.LEFT);paint.setTypeface(Typeface.DEFAULT);} }
        }catch(Exception ignored){} finally {if(qr!=null&&!qr.isRecycled())qr.recycle();}
    }
    private void writeThermalBitmap(OutputStream out, Bitmap source) throws Exception {
        if(source==null)return; int target=256; Bitmap scaled=Bitmap.createScaledBitmap(source,target,target,false); int bytesPerRow=(target+7)/8; byte[] raster=new byte[bytesPerRow*target];
        for(int yy=0;yy<target;yy++)for(int xx=0;xx<target;xx++){int color=scaled.getPixel(xx,yy);int gray=(android.graphics.Color.red(color)+android.graphics.Color.green(color)+android.graphics.Color.blue(color))/3;if(gray<160)raster[yy*bytesPerRow+(xx/8)]|=(byte)(0x80>>(xx%8));}
        escCmd(out,0x1B,0x61,0x01);out.write(new byte[]{0x1D,0x76,0x30,0x00,(byte)(bytesPerRow&0xff),(byte)((bytesPerRow>>8)&0xff),(byte)(target&0xff),(byte)((target>>8)&0xff)});out.write(raster);escLine(out,"");escCmd(out,0x1B,0x61,0x00);if(scaled!=source)scaled.recycle();
    }
    private void writeThermalQr(OutputStream out,String payload) throws Exception {
        if(payload==null||payload.isEmpty())return; byte[] data=payload.getBytes(StandardCharsets.UTF_8);
        escCmd(out,0x1B,0x61,0x01); escCmd(out,0x1D,0x28,0x6B,0x04,0x00,0x31,0x41,0x32,0x00); escCmd(out,0x1D,0x28,0x6B,0x03,0x00,0x31,0x43,0x06); escCmd(out,0x1D,0x28,0x6B,0x03,0x00,0x31,0x45,0x30); int n=data.length+3; out.write(new byte[]{0x1D,0x28,0x6B,(byte)(n&0xff),(byte)((n>>8)&0xff),0x31,0x50,0x30});out.write(data);escCmd(out,0x1D,0x28,0x6B,0x03,0x00,0x31,0x51,0x30);escLine(out,"");escCmd(out,0x1B,0x61,0x00);
    }
    private void shareText(String title,String text){ try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,title);i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,title));}catch(Exception e){Toast.makeText(this,"Could not share: "+e.getMessage(),Toast.LENGTH_LONG).show();} }
    private void scanQr(){ try{IntentIntegrator ii=new IntentIntegrator(this);ii.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);ii.setPrompt("Scan Dukaan Bill activation QR");ii.setBeepEnabled(true);ii.setOrientationLocked(false);ii.setRequestCode(REQ_SCAN_QR);ii.initiateScan();}catch(Exception e){Toast.makeText(this,"QR scanner unavailable: "+e.getMessage(),Toast.LENGTH_LONG).show();} }

    private void handleIncomingDukaanBill(Intent intent) {
        if (intent == null) return;
        Uri uri = intent.getData();
        String type = intent.getType();
        if ((type == null || type.trim().isEmpty()) && uri != null) {
            type = getContentResolver().getType(uri);
            String last = uri.getLastPathSegment();
            if ((type == null || type.trim().isEmpty()) && last != null && last.toLowerCase(Locale.ROOT).endsWith(".siddhibill")) type = "application/vnd.siddhibill.activation";
            if ((type == null || type.trim().isEmpty()) && last != null && last.toLowerCase(Locale.ROOT).endsWith(".siddhisync")) type = "application/vnd.siddhibill.sync";
        }
        if (type != null && (type.equalsIgnoreCase("application/octet-stream") || type.equalsIgnoreCase("application/json")) && uri != null) {
            String last = uri.getLastPathSegment();
            if (last != null && last.toLowerCase(Locale.ROOT).endsWith(".siddhibill")) type = "application/vnd.siddhibill.activation";
            if (last != null && last.toLowerCase(Locale.ROOT).endsWith(".siddhisync")) type = "application/vnd.siddhibill.sync";
        }
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            Object stream = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (stream instanceof Uri) uri = (Uri) stream;
        }
        if (uri == null || type == null) return;
        String incomingType = type.toLowerCase(Locale.ROOT);
        if (!incomingType.equals("application/vnd.dukaanbill") && !incomingType.equals("application/octet-stream") && !incomingType.equals("application/vnd.siddhibill.activation") && !incomingType.equals("application/vnd.siddhibill.sync") && !incomingType.equals("application/json")) return;
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) throw new Exception("Could not open Dukaan Bill file");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) {
                if (bos.size() > 30 * 1024 * 1024) throw new Exception("Incoming file is too large (maximum 30 MB)");
                bos.write(buf, 0, n);
            }
            in.close();
            String json = new String(bos.toByteArray(), StandardCharsets.UTF_8);
            JSONObject obj = new JSONObject(json);
            if ("SiddhiBillSync".equals(obj.optString("format", "")) && obj.optJSONObject("data") != null) {
                final String syncJson = json;
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Import SiddhiBill Sync")
                    .setMessage("Import and merge this sync file for shop \"" + obj.optString("shopName", "Unknown") + "\"? Existing records will be retained and matching records merged.")
                    .setNegativeButton("Cancel", (dialog, which) -> Toast.makeText(MainActivity.this, "Sync import cancelled.", Toast.LENGTH_SHORT).show())
                    .setPositiveButton("Import", (dialog, which) -> {
                        if (webView == null) { Toast.makeText(MainActivity.this, "SiddhiBill is not ready. Open the app and tap the sync file again.", Toast.LENGTH_LONG).show(); return; }
                        String encoded = Base64.encodeToString(syncJson.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                        webView.postDelayed(() -> webView.evaluateJavascript("window.importSyncBundleFromText && window.importSyncBundleFromText(decodeURIComponent(escape(atob('" + encoded + "'))))", result -> {
                            if (result != null && result.contains("OK")) Toast.makeText(MainActivity.this, "Sync file imported successfully.", Toast.LENGTH_LONG).show();
                            else Toast.makeText(MainActivity.this, "Sync import could not be completed. Check the sync status in SiddhiBill.", Toast.LENGTH_LONG).show();
                        }), 700);
                    }).show();
                return;
            }
            String incomingTokenType=obj.optString("type","");
            if("DUKAAN_ACTIVATION_TOKEN".equals(incomingTokenType) || "DUKAAN_OWNER_ACTIVATION_TOKEN".equals(incomingTokenType)) {
                applyActivation(json);
                if("DUKAAN_OWNER_ACTIVATION_TOKEN".equals(incomingTokenType)) {
                    showActivationPage("Owner-device approval verified. Create your Owner PIN to finish setup.");
                } else {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,"SiddhiBill activation file verified successfully.",Toast.LENGTH_LONG).show());
                    runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.loadUrl("file:///android_asset/www/index.html"); });
                }
                return;
            }
            if (!"THERMAL_PRINT".equalsIgnoreCase(obj.optString("dukaanBillType", ""))) throw new Exception("Unsupported SiddhiBill file. Select a valid signed .SiddhiBill activation file.");
            final String encoded = Base64.encodeToString(json.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            webView.postDelayed(() -> webView.evaluateJavascript("window.openIncomingThermalBill && window.openIncomingThermalBill(atob('" + encoded + "'))", null), 900);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open SiddhiBill file: " + e.getMessage(), Toast.LENGTH_LONG).show();
            if(!isActivated()) showActivationPage("Activation file rejected. Check that it was issued for this device and has not been modified.");
        }
    }

    private Uri saveToCacheProvider(byte[] data, String filename) throws Exception {
        File dir = new File(getCacheDir(), "share");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create share folder");
        File file = new File(dir, filename);
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(data);
            out.flush();
        }
        return Uri.parse("content://com.siddhibill.app.share/" + Uri.encode(file.getName()));
    }

    private Uri saveForSharing(byte[] data, String filename, String mime) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    mime.equals("application/pdf") ?
                            Environment.DIRECTORY_DOWNLOADS + "/DukaanBill" :
                            Environment.DIRECTORY_PICTURES + "/DukaanBill");
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);

            Uri collection = mime.equals("application/pdf")
                    ? MediaStore.Downloads.EXTERNAL_CONTENT_URI
                    : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

            Uri uri = resolver.insert(collection, values);
            if (uri != null) {
                try (OutputStream out = resolver.openOutputStream(uri)) {
                    if (out == null) throw new Exception("Could not open output stream");
                    out.write(data);
                    out.flush();
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                resolver.update(uri, done, null, null);
                return uri;
            }
        }
        return saveToCacheProvider(data, filename);
    }

    private void shareFile(byte[] data, String filename, String mime, String title) throws Exception {
        Uri uri = saveForSharing(data, filename, mime);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType(mime);
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_TEXT, "DukaanBill - " + title);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        send.setClipData(ClipData.newRawUri(title, uri));
        Intent chooser = Intent.createChooser(send, title);
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(chooser);
    }

    private void drawText(Canvas c, Paint p, String text, float x, float y) {
        c.drawText(text == null ? "" : text, x, y, p);
    }

    private void drawTextRight(Canvas c, Paint p, String text, float rightX, float y) {
        Paint.Align old = p.getTextAlign();
        p.setTextAlign(Paint.Align.RIGHT);
        c.drawText(text == null ? "" : text, rightX, y, p);
        p.setTextAlign(old);
    }

    private Bitmap loadLogo(JSONObject cfg) {
        Bitmap source = null;
        try {
            if (cfg != null) {
                String data = cfg.optString("logoData", "");
                if (data.startsWith("data:")) {
                    int comma = data.indexOf(',');
                    if (comma > 0) {
                        byte[] raw = Base64.decode(data.substring(comma + 1), Base64.DEFAULT);
                        source = BitmapFactory.decodeByteArray(raw, 0, raw.length);
                    }
                }
            }
        } catch (Exception ignored) {}
        if (source == null) {
            try (InputStream in = getAssets().open("www/logo.jpg")) {
                source = BitmapFactory.decodeStream(in);
            } catch (Exception ignored) {}
        }
        if (source == null) return null;

        // The PDF only renders the logo at roughly 68pt.  Do not embed the
        // full-resolution uploaded image in every PDF page; it can make a
        // simple one-page bill exceed 1 MB.  A 320px bitmap is more than
        // sufficient for A4/thermal output while keeping PDFs compact.
        final int maxDimension = 320;
        int w = source.getWidth(), h = source.getHeight();
        if (w <= maxDimension && h <= maxDimension) return source;
        float scale = Math.min((float) maxDimension / w, (float) maxDimension / h);
        int nw = Math.max(1, Math.round(w * scale));
        int nh = Math.max(1, Math.round(h * scale));
        Bitmap scaled = Bitmap.createScaledBitmap(source, nw, nh, true);
        if (scaled != source) source.recycle();
        return scaled;
    }

    private List<String> wrapText(String text, Paint paint, float maxWidth) {
        List<String> lines = new ArrayList<>();
        if (text == null || text.trim().isEmpty()) return lines;
        String normalized = text.trim().replaceAll("\\s+", " ");
        String[] words = normalized.split(" ");
        String line = "";
        for (String word : words) {
            String candidate = line.isEmpty() ? word : line + " " + word;
            if (paint.measureText(candidate) <= maxWidth) {
                line = candidate;
            } else {
                if (!line.isEmpty()) lines.add(line);
                if (paint.measureText(word) <= maxWidth) {
                    line = word;
                } else {
                    String part = "";
                    for (int i = 0; i < word.length(); i++) {
                        String c = part + word.charAt(i);
                        if (paint.measureText(c) > maxWidth && !part.isEmpty()) {
                            lines.add(part);
                            part = String.valueOf(word.charAt(i));
                        } else part = c;
                    }
                    line = part;
                }
            }
        }
        if (!line.isEmpty()) lines.add(line);
        return lines;
    }

    private String shopMobileText(JSONObject cfg) {
        if (cfg == null) return "";
        JSONArray arr = cfg.optJSONArray("shopMobiles");
        if (arr != null && arr.length() > 0) {
            StringBuilder sb = new StringBuilder();
            for (int i=0;i<arr.length();i++) { String v=arr.optString(i,"").trim(); if(!v.isEmpty()){ if(sb.length()>0) sb.append(", "); sb.append(v); } }
            if(sb.length()>0) return sb.toString();
        }
        return cfg.optString("shopMobile", "").trim();
    }

    private float drawPdfHeader(Canvas c, Paint p, Bitmap logo, int pageWidth, JSONObject cfg, JSONObject bill, boolean taxInvoice, String placeOfSupply) {
        // Compact, reference-matched A4 header. Keep the complete header to about 15% of A4 height.
        final float left=35f, right=560f, top=12f, stripBottom=34f, bottom=126f;
        final float shopRight=295f, invoiceRight=405f;
        int black=android.graphics.Color.BLACK;
        int red=android.graphics.Color.rgb(196,32,32);
        String shopName=cfg==null?"DUKAAN BILL":cfg.optString("shopName","DUKAAN BILL");
        String tagline=cfg==null?"":cfg.optString("tagline","");
        String address=cfg==null||!cfg.optBoolean("printShopAddress",true)?"":cfg.optString("address","");
        String mobile=cfg==null||!cfg.optBoolean("printShopMobile",true)?"":shopMobileText(cfg);
        String customer=bill==null?"Walk-in Customer":bill.optString("customer","Walk-in Customer");
        String billNo=bill==null?"":bill.optString("billNo","");
        String date=bill==null?"":formatDate(bill.optString("date",""));
        String customerPhone=bill==null?"":bill.optString("customerPhone","");
        String customerAddress=bill==null?"":bill.optString("customerAddress",bill.optString("address", ""));
        String customerState=bill==null?"":bill.optString("customerState","");
        String customerGstin=bill==null?"":bill.optString("customerGstin","");
        String payment=bill==null?"":bill.optString("paymentMode","");
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.8f); p.setColor(black); p.setTypeface(Typeface.DEFAULT);
        c.drawRect(left,top,right,bottom,p); c.drawLine(left,stripBottom,right,stripBottom,p);
        c.drawLine(shopRight,stripBottom,shopRight,bottom,p); c.drawLine(invoiceRight,stripBottom,invoiceRight,bottom,p);
        c.drawLine(left,99,shopRight,99,p);
        p.setStyle(Paint.Style.FILL); p.setColor(black); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(10.5f);
        p.setTextAlign(Paint.Align.LEFT); drawText(c,p,taxInvoice?"CASH MEMO / TAX INVOICE":"CASH MEMO / BILL",left+8,top+15);
        p.setTextAlign(Paint.Align.CENTER); drawText(c,p,cfg==null?"|| SHREE GANESH ||":cfg.optString("invoiceHeading","|| SHREE GANESH ||"),pageWidth/2f,top+15);
        p.setTextAlign(Paint.Align.RIGHT); drawText(c,p,"ORIGINAL",right-8,top+15);
        // Shop details section: logo at left, text to its right.
        float textX=left+102;
        if(logo!=null && (cfg==null||cfg.optBoolean("printShopLogo",true))){
            float maxW=92,maxH=64,sc=Math.min(maxW/Math.max(1,logo.getWidth()),maxH/Math.max(1,logo.getHeight()));
            float w=logo.getWidth()*sc,h=logo.getHeight()*sc;
            c.drawBitmap(logo,null,new RectF(left+7,stripBottom+5,left+7+w,stripBottom+5+h),p);
            textX=Math.max(textX,left+7+w+8);
        }
        float shopWidth=shopRight-textX-6; p.setTextAlign(Paint.Align.LEFT); p.setColor(red); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(12.5f);
        drawText(c,p,trimText(shopName,Math.max(15,(int)(shopWidth/6.5f))),textX,stripBottom+18);
        p.setColor(black); p.setTextSize(8.5f); float sy=stripBottom+31;
        if(!tagline.trim().isEmpty()){p.setTypeface(Typeface.DEFAULT_BOLD);drawText(c,p,trimText(tagline,38),textX,sy);sy+=13;}
        p.setTypeface(Typeface.DEFAULT);
        if(!address.trim().isEmpty()){for(String line:wrapText(address,p,shopWidth)){if(sy>91)break;drawText(c,p,trimText(line,44),textX,sy);sy+=11;}}
        if(!mobile.isEmpty()&&sy<=94){p.setTypeface(Typeface.DEFAULT_BOLD);drawText(c,p,"Mo: "+mobile,textX,sy);p.setTypeface(Typeface.DEFAULT);}
        // Business statutory details occupy a short, bordered second line.
        p.setTextSize(8f); p.setTextAlign(Paint.Align.LEFT);
        String gstin=cfg==null?"":cfg.optString("gstin",""); String fssai=cfg==null?"":cfg.optString("fssai",""); String state=cfg==null?"":cfg.optString("businessState","");
        String statutory=""; if(!gstin.isEmpty())statutory="GSTIN: "+gstin; if(!fssai.isEmpty())statutory+=(statutory.isEmpty()?"":"   ")+"FSSAI: "+fssai;
        drawText(c,p,trimText(statutory,68),left+8,112);
        drawText(c,p,trimText("State: "+state+"   Place of Supply: "+(placeOfSupply==null?"":placeOfSupply),48),left+235,112);
        // Invoice column.
        p.setColor(black); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(15);
        drawText(c,p,taxInvoice?"TAX INVOICE":"CASH MEMO",(shopRight+invoiceRight)/2f,stripBottom+20);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(9.5f); drawText(c,p,"Invoice No.",(shopRight+invoiceRight)/2f,stripBottom+39);
        p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(10.5f); drawText(c,p,trimText(billNo,17),(shopRight+invoiceRight)/2f,stripBottom+53);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(9.5f); drawText(c,p,"Date",(shopRight+invoiceRight)/2f,stripBottom+70);
        p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(10); drawText(c,p,trimText(date,18),(shopRight+invoiceRight)/2f,stripBottom+84);
        // Customer column.
        float cx=invoiceRight+10; p.setTextAlign(Paint.Align.LEFT); p.setTypeface(Typeface.DEFAULT); p.setTextSize(9.2f);
        p.setTypeface(Typeface.DEFAULT_BOLD); drawText(c,p,"M/s.: "+trimText(customer,27),cx,stripBottom+18); p.setTypeface(Typeface.DEFAULT);
        float cy=stripBottom+32;
        if(taxInvoice && !customerAddress.isEmpty()){for(String line:wrapText(customerAddress,p,right-cx-8)){if(cy>bottom-34)break;drawText(c,p,trimText(line,35),cx,cy);cy+=12;}}
        if(!customerState.isEmpty()&&cy<=bottom-28){drawText(c,p,"State: "+trimText(customerState,26),cx,cy);cy+=12;}
        if(taxInvoice&&!customerGstin.isEmpty()&&cy<=bottom-24){drawText(c,p,"GSTIN: "+trimText(customerGstin,25),cx,cy);cy+=12;}
        if(!customerPhone.isEmpty()&&cy<=bottom-20){drawText(c,p,"Mobile: "+customerPhone,cx,cy);cy+=12;}
        if(!payment.isEmpty()&&cy<=bottom-8)drawText(c,p,"Payment Mode: "+payment,cx,cy);
        p.setStyle(Paint.Style.STROKE); p.setColor(black); p.setTextAlign(Paint.Align.LEFT); p.setTypeface(Typeface.DEFAULT);
        return bottom;
    }

    private String unitAlias(String unit) {
        if(unit==null)return "pc"; String u=unit.trim().toLowerCase(Locale.US);
        if(u.matches("packet|packets|pack|pk|pkt|pks"))return "pk"; if(u.matches("piece|pieces|pc|pcs"))return "pc";
        if(u.matches("kilogram|kilograms|kilo|kilos|kg|kgs"))return "kg"; if(u.matches("gram|grams|gm|g"))return "g";
        if(u.matches("bottle|bottles"))return "bt"; if(u.matches("box|boxes"))return "bx"; if(u.equals("dozen"))return "dz";
        return u.length()>4?u.substring(0,4):u;
    }

    private byte[] createThermalPdfBytes(String json) throws Exception {
        JSONObject b=new JSONObject(json);
        JSONObject cfg=b.optJSONObject("settings");
        JSONObject customFields=b.optJSONObject("customFields");
        JSONArray items=b.optJSONArray("items");
        boolean is58="58mm".equalsIgnoreCase(cfg==null?"80mm":cfg.optString("paperSize","80mm"));
        int width=is58?164:227, margin=is58?8:10;
        int itemCount=items==null?0:items.length();
        String address=cfg==null || !cfg.optBoolean("printShopAddress",true)?"":cfg.optString("address","").trim();
        String tagline=cfg==null?"":cfg.optString("tagline","").trim();
        String customer=b.optString("customer","Walk-in Customer").trim();
        boolean walkIn=customer.isEmpty() || customer.equalsIgnoreCase("Walk-in Customer");
        String phone=b.optString("customerPhone","").trim();
        boolean taxInvoice=b.optBoolean("taxationEnabled",false);
        JSONObject tax=calculateTaxSummary(b,cfg);

        Paint measure=new Paint(Paint.ANTI_ALIAS_FLAG);
        measure.setTextSize(is58?6.8f:8.2f);
        int headerLines=wrapText(address,measure,width-margin*2).size()+wrapText(tagline,measure,width-margin*2).size();
        double configuredRoundOff=b.optDouble("roundOff",0);
        int transactionCount=(b.optBoolean("includeLast5Transactions",false)&&b.optJSONArray("last5Transactions")!=null)?Math.min(5,b.optJSONArray("last5Transactions").length()):0;
        int commentLines=0; if(b.optBoolean("includeOverallComment",false)&&!b.optString("overallComment","").trim().isEmpty()) commentLines=2;
        int height=430 + headerLines*12 + itemCount*(taxInvoice?48:38) + ((!walkIn)?65:0) + (taxInvoice?100:0) + transactionCount*12 + commentLines*10 + (cfg!=null&&cfg.optBoolean("upiQrEnabled",false)?130:0) + (Math.abs(configuredRoundOff)>=0.005?12:0);

        PdfDocument doc=new PdfDocument();
        PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(width,height,1).create());
        Canvas c=page.getCanvas();
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap logo=loadLogo(cfg);
        int y=10;

        p.setColor(android.graphics.Color.BLACK);
        p.setTextAlign(Paint.Align.CENTER);
        if(logo!=null && (cfg==null || cfg.optBoolean("printShopLogo",true))){
            float maxW=is58?38f:52f, maxH=is58?38f:48f;
            float scale=Math.min(maxW/Math.max(1,logo.getWidth()),maxH/Math.max(1,logo.getHeight()));
            float lw=logo.getWidth()*scale, lh=logo.getHeight()*scale;
            c.drawBitmap(logo,null,new RectF(width/2f-lw/2f,y,width/2f+lw/2f,y+lh),p);
            y+=(int)lh+14;
        }

        p.setTypeface(Typeface.DEFAULT_BOLD);
        String thermalShopName=cfg==null?"DUKAAN BILL":cfg.optString("shopName","DUKAAN BILL");
        p.setTextSize(is58?11.5f:14.5f);
        while(p.measureText(thermalShopName)>width*0.90f && p.getTextSize()>(is58?7.0f:8.0f))p.setTextSize(p.getTextSize()-0.5f);
        if(cfg==null || cfg.optBoolean("printShopName",true)) drawText(c,p,thermalShopName,width/2f,y);
        y+=13;

        // Keep the same visible, consistent header rhythm in thermal print.
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(is58?7.0f:8.4f);
        if(!tagline.isEmpty()){
            p.setTypeface(Typeface.DEFAULT_BOLD);
            for(String line:wrapText(tagline,p,width-margin*2)){ drawText(c,p,line,width/2f,y); y+=9; }
            p.setTypeface(Typeface.DEFAULT);
            y+=2;
        }
        if(!address.isEmpty()){
            for(String line:wrapText(address,p,width-margin*2)){ drawText(c,p,line,width/2f,y); y+=9; }
            y+=2;
        }
        String shopMobiles = (cfg==null || cfg.optBoolean("printShopMobile",true))?shopMobileText(cfg):"";
        if(!shopMobiles.isEmpty()){
            p.setTypeface(Typeface.DEFAULT_BOLD);
            for(String line:wrapText("Mo: "+shopMobiles,p,width-margin*2)){ drawText(c,p,line,width/2f,y); y+=9; }
            p.setTypeface(Typeface.DEFAULT);
            y+=2;
        }

        if(taxInvoice && cfg!=null){p.setTypeface(Typeface.DEFAULT);p.setTextSize(is58?6.2f:7.4f);String sg=cfg.optString("gstin","").trim(),sf=cfg.optString("fssai","").trim();if(!sg.isEmpty()){drawText(c,p,"GSTIN: "+sg,width/2f,y);y+=9;}if(!sf.isEmpty()){drawText(c,p,"FSSAI: "+sf,width/2f,y);y+=9;}}
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(is58?8.8f:10.5f);
        y+=6;
        drawText(c,p,taxInvoice?"TAX INVOICE":(cfg==null?"CASH MEMO / BILL":cfg.optString("billTitle","CASH MEMO / BILL")),width/2f,y);
        y+=10;
        p.setStrokeWidth(1);
        c.drawLine(margin,y,width-margin,y,p);
        y+=10;

        // Compact metadata: fixed left/right columns. Left-align the bill number so the # never clips.
        p.setTypeface(Typeface.DEFAULT);
        String billNo=b.optString("billNo","");
        String billLabel="Bill "+(billNo.startsWith("#") ? billNo : "#"+billNo);
        String dateLabel="Dt: "+formatDate(b.optString("date",""));
        float metaGap=is58?5:8;
        float rightX=width-margin;
        float leftMax=(width/2f)-margin-metaGap;
        p.setTextAlign(Paint.Align.LEFT);
        float billSize=is58?6.4f:8.0f;
        p.setTextSize(billSize);
        while(p.measureText(billLabel)>leftMax && billSize>5.0f){billSize-=0.2f;p.setTextSize(billSize);}
        drawText(c,p,billLabel,margin,y);
        p.setTextAlign(Paint.Align.RIGHT);
        float dateSize=is58?6.4f:8.0f;
        p.setTextSize(dateSize);
        while(p.measureText(dateLabel)>leftMax && dateSize>5.0f){dateSize-=0.2f;p.setTextSize(dateSize);}
        drawText(c,p,dateLabel,rightX,y);
        p.setTextAlign(Paint.Align.LEFT);
        y+=10;

        if(!walkIn){
            // Customer and mobile share the same row, aligned left/right like bill/date.
            String customerLabel="Customer: "+customer;
            p.setTextAlign(Paint.Align.LEFT);
            float customerSize=is58?6.0f:7.6f;
            p.setTextSize(customerSize);
            float customerMax=leftMax;
            while(p.measureText(customerLabel)>customerMax && customerSize>4.8f){customerSize-=0.2f;p.setTextSize(customerSize);}
            drawText(c,p,trimText(customerLabel,is58?30:42),margin,y);
            if(!phone.isEmpty()){
                p.setTextAlign(Paint.Align.RIGHT);
                p.setTextSize(is58?6.0f:7.6f);
                drawText(c,p,"Mo: "+phone,rightX,y);
                p.setTextAlign(Paint.Align.LEFT);
            }
            y+=10;
        }
        if(taxInvoice){p.setTextSize(is58?6.2f:7.4f);String customerAddress=b.optString("customerAddress",b.optString("address","")).trim();if(!customerAddress.isEmpty()){for(String line:wrapText("Address: "+customerAddress,p,width-margin*2)){drawText(c,p,line,margin,y);y+=9;}}String customerGstin=b.optString("customerGstin","").trim();if(!customerGstin.isEmpty()){drawText(c,p,"Customer GSTIN: "+customerGstin,margin,y);y+=9;}String customerFssai=b.optString("customerFssai","").trim();if(!customerFssai.isEmpty()){drawText(c,p,"Customer FSSAI: "+customerFssai,margin,y);y+=9;}String customerState=b.optString("customerState","").trim();if(!customerState.isEmpty()){drawText(c,p,"Customer State: "+customerState,margin,y);y+=9;}}
        if (cfg == null || cfg.optBoolean("printPaymentMode", true)) { drawText(c,p,"Pay: "+b.optString("paymentMode","Cash"),margin,y); y+=10; }
        c.drawLine(margin,y,width-margin,y,p);
        y+=10;
        if(taxInvoice){
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextSize(is58?6.5f:7.5f);
            drawText(c,p,"Item name - HSN/SAC",margin,y);
            p.setTypeface(Typeface.DEFAULT);
            y+=11;
        }

        if(items!=null){
            for(int i=0;i<items.length();i++){
                JSONObject it=items.getJSONObject(i);
                String name=it.optString("name",""); if(cfg!=null && cfg.optBoolean("printItemCode",false)){String code=it.optString("itemCode","").trim();if(!code.isEmpty())name=code+" - "+name;}
                String qty=it.optString("qty","");
                String unit=unitAlias(it.optString("unit","piece"));
                double rate=it.optDouble("rate",0);
                double amount=quantityValue(qty,unit)*rate;

                p.setTypeface(Typeface.DEFAULT_BOLD);
                p.setTextSize(is58?8.0f:9.0f);
                String hsn=it.optString("hsn",it.optString("hsnCode","")).trim();
                String itemLine=(i+1)+". "+name+(taxInvoice && !hsn.isEmpty()?" - "+hsn:"");
                for(String itemLinePart:wrapText(itemLine,p,width-margin*2)){drawText(c,p,itemLinePart,margin,y);y+=10;}
                p.setTypeface(Typeface.DEFAULT);
                p.setTextSize(is58?7.0f:8.0f);
                drawText(c,p,qty+" "+unit+" x ₹"+String.format(Locale.US,"%.2f",rate)+(taxInvoice?" • "+String.format(Locale.US,"%.0f%%",it.optDouble("taxRate",0)):""),margin+8,y);
                p.setTextAlign(Paint.Align.RIGHT);
                p.setTypeface(Typeface.DEFAULT_BOLD);
                drawText(c,p,"₹"+String.format(Locale.US,"%.2f",amount),width-margin,y);
                p.setTextAlign(Paint.Align.LEFT);
                y+=14;
                String itemComment=it.optString("comment","").trim();
                if(b.optBoolean("includeItemComments",false)&&!itemComment.isEmpty()){p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.ITALIC));p.setTextSize(is58?6.0f:7.0f);y-=3;for(String commentLine:wrapText("  Note: "+itemComment,p,width-margin*2)){drawText(c,p,commentLine,margin+6,y);y+=8;}p.setTypeface(Typeface.DEFAULT);}
                y+=2;
                c.drawLine(margin,y,width-margin,y,p);
                y+=7;
            }
        }

        double subtotal=b.optDouble("subtotal",0);
        double discount=b.optDouble("discount",0);
        double total=b.optDouble("total",Math.max(0,subtotal-discount));
        String overallComment=b.optString("overallComment","").trim();
        if(b.optBoolean("includeOverallComment",false)&&!overallComment.isEmpty()){p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.ITALIC));p.setTextAlign(Paint.Align.LEFT);p.setTextSize(is58?6.0f:7.0f);y+=4;for(String commentLine:wrapText("Comment: "+overallComment,p,width-margin*2)){drawText(c,p,commentLine,margin,y);y+=9;}p.setTypeface(Typeface.DEFAULT);y+=3;}
        if(taxInvoice){JSONArray groups=tax.optJSONArray("groups");if(groups!=null&&groups.length()>0){p.setTypeface(Typeface.DEFAULT);p.setTextSize(is58?5.8f:6.8f);for(int gi=0;gi<groups.length();gi++){JSONObject g=groups.getJSONObject(gi);String line="GST @"+String.format(Locale.US,"%.0f%%",g.optDouble("rate",0))+"   Taxable: ₹"+String.format(Locale.US,"%.2f",g.optDouble("taxable",0))+"   GST: ₹"+String.format(Locale.US,"%.2f",g.optDouble("tax",0));for(String wrapped:wrapText(line,p,width-margin*2)){drawText(c,p,wrapped,margin,y);y+=9;}y+=2;}}}
        c.drawLine(margin,y,width-margin,y,p);
        y+=12;

        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(is58?7.8f:9.0f);
        float summarySplit=width-margin-(is58?42f:58f);float summaryLabelRight=summarySplit-4f;float summaryValueLeft=summarySplit+4f;
        p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"Subtotal:",summaryLabelRight,y);p.setTextAlign(Paint.Align.LEFT);drawText(c,p,"₹"+String.format(Locale.US,"%.2f",subtotal),summaryValueLeft,y);y+=11;

        if (discount > 0.000001) {
            p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"Discount:",summaryLabelRight,y);p.setTextAlign(Paint.Align.LEFT);drawText(c,p,"-₹"+String.format(Locale.US,"%.2f",discount),summaryValueLeft,y);y+=13;
        }

        if(taxInvoice){ p.setTypeface(Typeface.DEFAULT); p.setTextSize(is58?7.8f:9.0f); p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"Taxable:",summaryLabelRight,y);p.setTextAlign(Paint.Align.LEFT);drawText(c,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("taxable",0)),summaryValueLeft,y);y+=10; if(tax.optBoolean("inter",false)){p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"IGST:",summaryLabelRight,y);p.setTextAlign(Paint.Align.LEFT);drawText(c,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("igst",0)),summaryValueLeft,y);y+=11;}else{p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"CGST:",summaryLabelRight,y);p.setTextAlign(Paint.Align.LEFT);drawText(c,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("cgst",0)),summaryValueLeft,y);y+=10;p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"SGST:",summaryLabelRight,y);p.setTextAlign(Paint.Align.LEFT);drawText(c,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("sgst",0)),summaryValueLeft,y);y+=11;} p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"Total GST:",summaryLabelRight,y);p.setTextAlign(Paint.Align.LEFT);drawText(c,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("tax",0)),summaryValueLeft,y);y+=12; }
        double billRoundOff=b.optDouble("roundOff",0); if(Math.abs(billRoundOff)>=0.005){p.setTypeface(Typeface.DEFAULT);p.setTextSize(is58?7.8f:9.0f);p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"Round Off:",summaryLabelRight,y);p.setTextAlign(Paint.Align.LEFT);drawText(c,p,(billRoundOff>0?"+₹":"-₹")+String.format(Locale.US,"%.2f",Math.abs(billRoundOff)),summaryValueLeft,y);y+=11;}
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(is58?9.8f:11.5f);
        float totalSplit=summarySplit;
        p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"Total Amount:",summaryLabelRight,y);
        p.setTextAlign(Paint.Align.LEFT);drawText(c,p,"₹"+String.format(Locale.US,"%.2f",total),summaryValueLeft,y);
        p.setTextAlign(Paint.Align.LEFT);
        y+=16;
        double partialPayment=b.optDouble("partialPaymentAmount",0);
        double paidAmount=partialPayment>0?partialPayment:b.optDouble("paidAmount",b.optDouble("amountPaid",0));
        double billBalance=Math.max(0,total-paidAmount);
        if(paidAmount>0 || "credit".equalsIgnoreCase(b.optString("paymentMode",""))){
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(is58?7.0f:8.0f);
            p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"Paid:",summaryLabelRight,y);p.setTextAlign(Paint.Align.LEFT);drawText(c,p,"₹"+String.format(Locale.US,"%.2f",paidAmount),summaryValueLeft,y);y+=10;
            p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"Bill Balance:",summaryLabelRight,y);p.setTextAlign(Paint.Align.LEFT);drawText(c,p,"₹"+String.format(Locale.US,"%.2f",billBalance),summaryValueLeft,y);y+=10;
            double customerTotalBalance=billBalance;
            p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"Customer Total Balance:",summaryLabelRight,y);p.setTextAlign(Paint.Align.LEFT);drawText(c,p,"₹"+String.format(Locale.US,"%.2f",customerTotalBalance),summaryValueLeft,y);p.setTextAlign(Paint.Align.LEFT);y+=12;
            p.setTypeface(Typeface.DEFAULT);
        }
        y+=4;
        if(b.optBoolean("includeLast5Transactions",false)){
            JSONArray recent=b.optJSONArray("last5Transactions");
            if(recent!=null&&recent.length()>0){
                p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextAlign(Paint.Align.LEFT);p.setTextSize(is58?4.7f:5.6f);drawText(c,p,"Last 5 Customer Transactions",margin,y);y+=12;
                float usable=width-margin*2;float xDate=margin;float xType=margin+usable*.18f;float xRef=margin+usable*.32f;float xPrev=margin+usable*.62f;float xPay=margin+usable*.78f;float xBal=width-margin;
                drawText(c,p,"Date",xDate,y);drawText(c,p,"Type",xType,y);drawText(c,p,"Bill/Txn No",xRef,y);p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"P.Bal",xPrev+usable*.12f,y);drawText(c,p,"Payment",xPay+usable*.10f,y);drawText(c,p,"Bal",xBal,y);p.setTextAlign(Paint.Align.LEFT);y+=5;
                c.drawLine(margin,y,width-margin,y,p);y+=9;p.setTypeface(Typeface.DEFAULT);p.setTextSize(is58?4.5f:5.2f);
                for(int i=0;i<recent.length()&&i<5;i++){
                    JSONObject tr=recent.optJSONObject(i);if(tr==null)continue;
                    String rawDate=tr.optString("date","");String dt=rawDate.length()>=10?rawDate.substring(8,10)+"/"+monthShort(rawDate.substring(5,7))+"/"+rawDate.substring(0,4):rawDate;
                    String type=tr.optString("type","").replace("Credit sale","Credit").replace("Payment received","Payment");
                    double balance=tr.optDouble("balance",tr.optDouble("balanceDue",0));double debit=tr.optDouble("debit",0);double credit=tr.optDouble("credit",0);double previousBalance=tr.has("previousBalance")?tr.optDouble("previousBalance",0):balance-debit+credit;
                    drawText(c,p,dt,xDate,y);drawText(c,p,trimText(type,7),xType,y);drawText(c,p,trimText(tr.optString("reference",""),is58?11:15),xRef,y);
                    p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,String.format(Locale.US,"%.0f",previousBalance),xPrev+usable*.12f,y);drawText(c,p,String.format(Locale.US,"%.0f",tr.optDouble("paymentAmount",tr.optDouble("amount",0))),xPay+usable*.10f,y);drawText(c,p,String.format(Locale.US,"%.0f",balance),xBal,y);p.setTextAlign(Paint.Align.LEFT);
                    y+=10;c.drawLine(margin,y-3,width-margin,y-3,p);
                }
                y+=4;
            }
        }

        p.setTypeface(Typeface.DEFAULT);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(is58?6.8f:7.8f);
        if(cfg!=null && customFields!=null){String[] keys={"field1","field2","field3"};String[] labelKeys={"customBillField1Label","customBillField2Label","customBillField3Label"};String[] posKeys={"customBillField1Position","customBillField2Position","customBillField3Position"};for(int i=0;i<keys.length;i++){String label=cfg.optString(labelKeys[i],"").trim(),value=customFields.optString(keys[i],"").trim(),pos=cfg.optString(posKeys[i],i==2?"footer":"header").trim().toLowerCase(Locale.US);if(!label.isEmpty()&&!value.isEmpty()&&"footer".equals(pos)){drawText(c,p,label+": "+value,margin,y);y+=10;}}}
        String footer=cfg==null?"":cfg.optString("footer","").trim();
        if(!footer.isEmpty()){
            for(String line:wrapText(footer,p,width-margin*2)){drawText(c,p,line,width/2f,y);y+=9;}
        } else {p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(is58?7.0f:8.0f);drawText(c,p,"Thank you for shopping with us!",width/2f,y);y+=9;}
        y+=8;
        if(cfg!=null&&cfg.optBoolean("upiQrEnabled",false)){drawCenteredBillQr(c,p,b,cfg,width/2,y+4,is58?76:92);y+=is58?96:112;}
        String terms=cfg==null?"":cfg.optString("termsConditions","").trim();
        if(cfg!=null && cfg.optBoolean("printTermsConditions",false) && !terms.isEmpty()){for(String line:wrapText(terms,p,width-margin*2)){drawText(c,p,line,width/2f,y);y+=9;}}

        String signature=cfg==null?"":cfg.optString("signature","").trim();
        if(!signature.isEmpty()){
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextSize(is58?7.0f:8.0f);
            drawText(c,p,signature,width/2f,y);
            y+=10;
            drawText(c,p,"Authorized Signatory",width/2f,y);
            y+=11;
        }

        p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.ITALIC));
        p.setTextAlign(Paint.Align.CENTER);p.setTextSize(is58?5.2f:6.2f);
        String credit=cfg==null?"Bill created by DukaanBill • Contact 8087794271 for more details":cfg.optString("creditFooter","Bill created by DukaanBill • Contact 8087794271 for more details");
        while(p.measureText(credit)>width-margin*2 && p.getTextSize()>(is58?4.2f:5.0f))p.setTextSize(p.getTextSize()-0.2f);
        for(String line:wrapText(credit,p,width-margin*2)){drawText(c,p,line,width/2f,y);y+=8;}
        p.setTextAlign(Paint.Align.LEFT);

        doc.finishPage(page);
        ByteArrayOutputStream bos=new ByteArrayOutputStream();
        doc.writeTo(bos);
        doc.close();
        return bos.toByteArray();
    }

    private byte[] escText(String s) {
        if (s == null) s = "";
        s = s.replace("₹", "Rs.").replace("•", "-").replace("—", "-").replace("–", "-");
        try { return s.getBytes(Charset.forName("CP437")); }
        catch (Exception e) { return s.replaceAll("[^\\x20-\\x7E]", "?").getBytes(StandardCharsets.US_ASCII); }
    }

    private void escWrite(OutputStream out, byte[] b) throws Exception { out.write(b); }
    private void escLine(OutputStream out, String s) throws Exception { escWrite(out, escText(s)); escWrite(out, new byte[]{0x0A}); }
    private void escCmd(OutputStream out, int... bytes) throws Exception { for(int b:bytes) out.write(b & 0xFF); }

    private void writeEscPosBitmap(OutputStream out, Bitmap source, int maxWidth) throws Exception {
        if (source == null) return;
        int w = Math.min(maxWidth, source.getWidth());
        float scale = (float)w / source.getWidth();
        int h = Math.max(1, Math.round(source.getHeight() * scale));
        Bitmap bmp = Bitmap.createScaledBitmap(source, w, h, true);
        int widthBytes = (w + 7) / 8;
        byte[] raster = new byte[widthBytes * h];
        for (int y=0; y<h; y++) {
            for (int x=0; x<w; x++) {
                int px = bmp.getPixel(x,y);
                int r = android.graphics.Color.red(px), g = android.graphics.Color.green(px), b = android.graphics.Color.blue(px);
                int gray = (r*299 + g*587 + b*114) / 1000;
                // Slightly generous threshold keeps the black logo/text clear on thermal paper.
                if (gray < 175) raster[y*widthBytes + (x>>3)] |= (byte)(0x80 >> (x & 7));
            }
        }
        escCmd(out, 0x1D,0x76,0x30,0x00, widthBytes & 0xFF, (widthBytes>>8)&0xFF, h&0xFF, (h>>8)&0xFF);
        // Stream raster data in small chunks. Some Bluetooth SPP printers/phones
        // truncate a single large write after the logo, causing logo-only receipts.
        final int chunkSize = 512;
        for (int offset = 0; offset < raster.length; offset += chunkSize) {
            int count = Math.min(chunkSize, raster.length - offset);
            out.write(raster, offset, count);
            out.flush();
            try { Thread.sleep(2); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
        }
        escCmd(out, 0x0A);
        out.flush();
        try { Thread.sleep(180); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
        if (bmp != source) bmp.recycle();
    }

    private String pairedBluetoothPrintersJson() {
        org.json.JSONArray out = new org.json.JSONArray();
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null || !adapter.isEnabled()) return out.toString();
            if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return out.toString();
            java.util.List<String> names = new java.util.ArrayList<>();
            for (BluetoothDevice d : adapter.getBondedDevices()) {
                String name = d.getName();
                if (name != null && !name.trim().isEmpty()) names.add(name.trim());
            }
            java.util.Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
            for (String name : names) out.put(name);
        } catch (Exception ignored) {}
        return out.toString();
    }

    private BluetoothDevice findThermalPrinter(String preferredModel) throws Exception {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) throw new Exception("Bluetooth is not available on this phone.");
        if (!adapter.isEnabled()) throw new Exception("Please turn on Bluetooth.");
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            pendingDirectPrintJson = pendingDirectPrintJson == null ? "" : pendingDirectPrintJson;
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT_PRINT);
            return null;
        }
        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        String preferred = preferredModel == null ? "auto" : preferredModel.trim();
        for (BluetoothDevice d : bonded) {
            String name = d.getName() == null ? "" : d.getName().trim();
            if (!"auto".equalsIgnoreCase(preferred) && !preferred.isEmpty()) {
                if (name.equalsIgnoreCase(preferred) || name.toUpperCase(Locale.US).contains(preferred.toUpperCase(Locale.US))) return d;
            }
        }
        if (!"auto".equalsIgnoreCase(preferred)) throw new Exception(preferred + " is not paired. Pair it in Android Bluetooth settings first.");
        throw new Exception("Select your thermal printer in Settings > Bluetooth Printer. Auto-select is disabled to avoid connecting to earphones or other devices.");
    }

    private BluetoothSocket openPrinterSocket(BluetoothDevice device) throws Exception {
        UUID spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
        BluetoothSocket socket = null;
        try {
            socket = device.createRfcommSocketToServiceRecord(spp);
            socket.connect();
            return socket;
        } catch (Exception e) {
            try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        }
        try {
            socket = device.createInsecureRfcommSocketToServiceRecord(spp);
            socket.connect();
            return socket;
        } catch (Exception e) {
            try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        }
        try {
            java.lang.reflect.Method m = device.getClass().getMethod("createRfcommSocket", int.class);
            socket = (BluetoothSocket)m.invoke(device, 1);
            socket.connect();
            return socket;
        } catch (Exception e) {
            try { if (socket != null) socket.close(); } catch (Exception ignored) {}
            throw new Exception("Could not connect to " + (device.getName()==null?"printer":device.getName()) + " over Bluetooth. Make sure it is paired and not connected to another phone.");
        }
    }

    private void directThermalPrint80(String json) throws Exception {
        pendingDirectPrintJson = json;
        JSONObject preflight = new JSONObject(json);
        JSONObject preCfg = preflight.optJSONObject("settings");
        String preferredPrinter = preCfg == null ? "auto" : preCfg.optString("bluetoothPrinter", "auto");
        BluetoothDevice device = findThermalPrinter(preferredPrinter);
        if (device == null) return; // permission request is in progress
        BluetoothSocket socket = null;
        OutputStream out = null;
        try {
            socket = openPrinterSocket(device);
            try { Thread.sleep(250); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            out = socket.getOutputStream();
            JSONObject b = new JSONObject(json);
            JSONObject cfg = b.optJSONObject("settings");
            JSONArray items = b.optJSONArray("items");
            boolean tax = b.optBoolean("taxationEnabled", false);
            String shop = cfg == null ? "DUKAAN BILL" : cfg.optString("shopName", "DUKAAN BILL");
            String tagline = cfg == null ? "" : cfg.optString("tagline", "").trim();
            String address = cfg == null || !cfg.optBoolean("printShopAddress", true) ? "" : cfg.optString("address", "").trim();
            String mobiles = cfg == null || !cfg.optBoolean("printShopMobile", true) ? "" : shopMobileText(cfg);
            String customer = b.optString("customer", "Walk-in Customer").trim();
            String phone = b.optString("customerPhone", "").trim();
            boolean printCustomer = cfg == null || cfg.optBoolean("showCustomer", true);
            boolean printCustomerMobile = cfg == null || cfg.optBoolean("printCustomerMobile", true);
            boolean printPaymentMode = cfg == null || cfg.optBoolean("printPaymentMode", true);
            String billNo = b.optString("billNo", "");
            String title = tax ? "TAX INVOICE" : (cfg == null ? "CASH MEMO / BILL" : cfg.optString("billTitle", "CASH MEMO / BILL"));

            escCmd(out,0x1B,0x40); // initialize
            // Slightly darker text for KPC307 thermal output. Double-strike is more reliable than oversized/bold text.
            escCmd(out,0x1B,0x47,0x01); // ESC G 1: double-strike ON
            escCmd(out,0x1B,0x61,0x01); // center
            Bitmap logo=loadLogo(cfg);
            if(logo!=null && (cfg==null || cfg.optBoolean("printShopLogo",true))){ writeEscPosBitmap(out,logo,320); if(!logo.isRecycled()) logo.recycle(); }
            if(cfg==null || cfg.optBoolean("printShopName",true)){escCmd(out,0x1B,0x45,0x01); escCmd(out,0x1B,0x21,shop.length()>23?0x08:0x18); escLine(out,shop); escCmd(out,0x1B,0x21,0x00); escCmd(out,0x1B,0x45,0x00);}
            escCmd(out,0x1B,0x21,0x00); escCmd(out,0x1B,0x45,0x00);
            if(!tagline.isEmpty()) { escLine(out,tagline); escLine(out,""); } // small visual gap between tagline and address
            if(!address.isEmpty()) for(String line:wrapPlain(address,48)) escLine(out,line);
            if(!mobiles.isEmpty()){ escCmd(out,0x1B,0x45,0x01); escLine(out,"Mo: "+mobiles); escCmd(out,0x1B,0x45,0x00); }
            if(tax && cfg!=null){String sg=cfg.optString("gstin","").trim(),sf=cfg.optString("fssai","").trim();if(!sg.isEmpty())escLine(out,"GSTIN: "+sg);if(!sf.isEmpty())escLine(out,"FSSAI: "+sf);}
            escCmd(out,0x1B,0x45,0x01); escLine(out,title); escCmd(out,0x1B,0x45,0x00);
            escLine(out,"-----------------------------------------------");
            escCmd(out,0x1B,0x61,0x00); // left
            escLine(out, receiptTwoColumnLine("Bill: #"+billNo, "Dt: "+formatDate(b.optString("date","")), 48));
            String printedCustomer = printCustomer && !customer.isEmpty() && !customer.equalsIgnoreCase("Walk-in Customer") ? customer : "";
            String printedPhone = printCustomerMobile ? phone : "";
            if(!printedCustomer.isEmpty() && !printedPhone.isEmpty()) {
                // Keep customer on the left and pin the mobile field to the receipt's right edge.
                escLine(out, receiptTwoColumnLine("Customer: " + printedCustomer, "Mo: " + printedPhone, 48));
            } else if(!printedCustomer.isEmpty()) {
                for(String line:wrapPlain("Customer: " + printedCustomer,48)) escLine(out,line);
            } else if(!printedPhone.isEmpty()) {
                escLine(out, receiptAmountLine("Mo:", printedPhone, 48));
            }
            if(tax){String ca=b.optString("customerAddress",b.optString("address","")).trim();if(!ca.isEmpty())for(String line:wrapPlain("Address: "+ca,48))escLine(out,line);String cg=b.optString("customerGstin","").trim();if(!cg.isEmpty())escLine(out,"Customer GSTIN: "+cg);String cf=b.optString("customerFssai","").trim();if(!cf.isEmpty())escLine(out,"Customer FSSAI: "+cf);String cs=b.optString("customerState","").trim();if(!cs.isEmpty())escLine(out,"Customer State: "+cs);}
            if(printPaymentMode) escLine(out,"Pay: "+b.optString("paymentMode","Cash"));
            JSONObject customFields=b.optJSONObject("customFields");
            if(cfg!=null && customFields!=null){String[] keys={"field1","field2","field3"};String[] labelKeys={"customBillField1Label","customBillField2Label","customBillField3Label"};String[] posKeys={"customBillField1Position","customBillField2Position","customBillField3Position"};for(int i=0;i<keys.length;i++){String label=cfg.optString(labelKeys[i],"").trim(),value=customFields.optString(keys[i],"").trim(),pos=cfg.optString(posKeys[i],i==2?"footer":"header").trim().toLowerCase(Locale.US);if(!label.isEmpty()&&!value.isEmpty()&&!("hidden".equals(pos))) { if("footer".equals(pos)) continue; for(String line:wrapPlain(label+": "+value,48))escLine(out,line); }}}
            escLine(out,"-----------------------------------------------");

            if(tax) escLine(out,"Item name - HSN/SAC");
            if(items!=null){
                for(int i=0;i<items.length();i++){
                    JSONObject it=items.getJSONObject(i);
                    String name=it.optString("name",""); if(cfg!=null && cfg.optBoolean("printItemCode",false)){String code=it.optString("itemCode","").trim();if(!code.isEmpty())name=code+" - "+name;}
                    String qty=it.optString("qty","");
                    String unit=unitAlias(it.optString("unit","piece"));
                    double rate=it.optDouble("rate",0);
                    double amount=quantityValue(qty,unit)*rate;
                    String hsn=it.optString("hsn",it.optString("hsnCode", "")).trim();
                    String itemLabel=(i+1)+". "+name+(tax&&!hsn.isEmpty()?" - "+hsn:"");
                    escCmd(out,0x1B,0x45,0x01); for(String itemLine:wrapPlain(itemLabel,48)) escLine(out,itemLine); escCmd(out,0x1B,0x45,0x00);
                    String detail="   "+qty+" "+unit+" x Rs."+String.format(Locale.US,"%.2f",rate)+(tax?"  Tax "+String.format(Locale.US,"%.0f%%",it.optDouble("taxRate",0)):"");
                    String amountText="Rs."+String.format(Locale.US,"%.2f",amount);
                    // Keep quantity/rate directly under the item name and amount flush-right on 80mm (48 columns).
                    int gap=Math.max(1,48-detail.length()-amountText.length());
                    escLine(out,detail+String.format(Locale.US,"%"+gap+"s","")+amountText);
                    String itemComment=it.optString("comment","").trim();
                    if(b.optBoolean("includeItemComments",false)&&!itemComment.isEmpty()) for(String commentLine:wrapPlain("  Note: "+itemComment,48)) escLine(out,commentLine);
                }
            }
            escLine(out,"-----------------------------------------------");
            double subtotal=b.optDouble("subtotal",0), discount=b.optDouble("discount",0), total=b.optDouble("total",Math.max(0,subtotal-discount));
            if(tax){JSONObject ts=calculateTaxSummary(b,cfg);JSONArray groups=ts.optJSONArray("groups");if(groups!=null){for(int gi=0;gi<groups.length();gi++){JSONObject g=groups.getJSONObject(gi);escLine(out,"GST @"+String.format(Locale.US,"%.0f%%",g.optDouble("rate",0))+"   Taxable: Rs."+String.format(Locale.US,"%.2f",g.optDouble("taxable",0)));escLine(out,"   GST: Rs."+String.format(Locale.US,"%.2f",g.optDouble("tax",0)));if(gi<groups.length()-1)escLine(out,"");}}}
            escLine(out,receiptAmountLine("Subtotal:", "Rs."+String.format(Locale.US,"%.2f",subtotal),48));
            if(discount>0.000001) escLine(out,receiptAmountLine("Discount:", "-Rs."+String.format(Locale.US,"%.2f",discount),48));
            if(tax){ JSONObject ts=calculateTaxSummary(b,cfg); escLine(out,receiptAmountLine("Taxable:", "Rs."+String.format(Locale.US,"%.2f",ts.optDouble("taxable",0)),48)); if(ts.optBoolean("inter",false)) escLine(out,receiptAmountLine("IGST:", "Rs."+String.format(Locale.US,"%.2f",ts.optDouble("igst",0)),48)); else { escLine(out,receiptAmountLine("CGST:", "Rs."+String.format(Locale.US,"%.2f",ts.optDouble("cgst",0)),48)); escLine(out,receiptAmountLine("SGST:", "Rs."+String.format(Locale.US,"%.2f",ts.optDouble("sgst",0)),48)); } escLine(out,receiptAmountLine("Total GST:", "Rs."+String.format(Locale.US,"%.2f",ts.optDouble("tax",0)),48)); }
            double billRoundOff=b.optDouble("roundOff",0); if(Math.abs(billRoundOff)>=0.005) escLine(out,receiptAmountLine("Round Off:", (billRoundOff>0?"+Rs.":"-Rs.")+String.format(Locale.US,"%.2f",Math.abs(billRoundOff)),48));
            escCmd(out,0x1B,0x45,0x01); escCmd(out,0x1B,0x21,0x10); escLine(out,receiptAmountLine("TOTAL:", "Rs."+String.format(Locale.US,"%.2f",total),48)); escCmd(out,0x1B,0x21,0x00); escCmd(out,0x1B,0x45,0x00);
            escLine(out,"");
            String overallComment=b.optString("overallComment","").trim();
            if(b.optBoolean("includeOverallComment",false)&&!overallComment.isEmpty()){escCmd(out,0x1B,0x61,0x00);for(String commentLine:wrapPlain("Comment: "+overallComment,48))escLine(out,commentLine);escLine(out,"");}
            double partialPayment=b.optDouble("partialPaymentAmount",0);if(partialPayment>0){escLine(out,receiptAmountLine("Paid:","Rs."+String.format(Locale.US,"%.2f",partialPayment),48));escLine(out,receiptAmountLine("Balance Due:","Rs."+String.format(Locale.US,"%.2f",Math.max(0,total-partialPayment)),48));}
            if(b.optBoolean("includeLast5Transactions",false)){JSONArray recent=b.optJSONArray("last5Transactions");if(recent!=null&&recent.length()>0){escCmd(out,0x1B,0x61,0x00);escLine(out,"Last 5 Customer Transactions");escLine(out,"Date       Type      Bill/Txn No    Pay     Bal");escLine(out,"------------------------------------------------");for(int i=0;i<recent.length()&&i<5;i++){JSONObject tr=recent.optJSONObject(i);if(tr==null)continue;String rawDate=tr.optString("date","");String dt=rawDate.length()>=10?rawDate.substring(8,10)+"/"+monthShort(rawDate.substring(5,7))+"/"+rawDate.substring(0,4):rawDate;String typ=tr.optString("type","").replace("Credit sale","Credit").replace("Payment received","Payment");String ref=tr.optString("reference","");String pay=String.format(Locale.US,"%.0f",tr.optDouble("paymentAmount",tr.optDouble("amount",0)));String bal=String.format(Locale.US,"%.0f",tr.optDouble("balanceDue",tr.optDouble("balance",0)));String line=String.format(Locale.US,"%-11s %-6s %-13s %7s %7s",dt,trimText(typ,6),trimText(ref,13),pay,bal);escLine(out,line);}escLine(out,"");}}
            escCmd(out,0x1B,0x61,0x00);
            if(cfg!=null && customFields!=null){String[] keys={"field1","field2","field3"};String[] labelKeys={"customBillField1Label","customBillField2Label","customBillField3Label"};String[] posKeys={"customBillField1Position","customBillField2Position","customBillField3Position"};for(int i=0;i<keys.length;i++){String label=cfg.optString(labelKeys[i],"").trim(),value=customFields.optString(keys[i],"").trim(),pos=cfg.optString(posKeys[i],i==2?"footer":"header").trim().toLowerCase(Locale.US);if(!label.isEmpty()&&!value.isEmpty()&&"footer".equals(pos))for(String line:wrapPlain(label+": "+value,48))escLine(out,line);}}
            escCmd(out,0x1B,0x61,0x01);
            String footer=cfg==null?"":cfg.optString("footer","").trim(); if(!footer.isEmpty()) for(String line:wrapPlain(footer,48)) escLine(out,line);
            if(cfg!=null&&cfg.optBoolean("upiQrEnabled",false)){String qrPayload=billUpiPayload(b,cfg);if("merchant".equals(cfg.optString("upiQrSource","upi"))){String d=cfg.optString("merchantQrData","");if(d.startsWith("data:image")){try{byte[] im=Base64.decode(d.substring(d.indexOf(',')+1),Base64.DEFAULT);Bitmap bm=BitmapFactory.decodeByteArray(im,0,im.length);if(bm!=null){writeThermalBitmap(out,bm);bm.recycle();}}catch(Exception ignored){}}}else if(!qrPayload.isEmpty()){writeThermalQr(out,qrPayload);if(cfg.optBoolean("upiPrintAmount",true))escLine(out,"Scan & Pay - Enter Amount");}}
            String terms=cfg==null?"":cfg.optString("termsConditions","").trim(); if(cfg!=null && cfg.optBoolean("printTermsConditions",false) && !terms.isEmpty()) for(String line:wrapPlain(terms.replace("•","-"),48)) escLine(out,line);
            String credit=cfg==null?"Bill created by DukaanBill - Contact 8087794271 for more details":cfg.optString("creditFooter","Bill created by DukaanBill - Contact 8087794271 for more details");
            for(String line:wrapPlain(credit.replace("•","-"),48)) escLine(out,line);
            escLine(out,""); escLine(out,""); escLine(out,"");
            escCmd(out,0x1B,0x47,0x00); // double-strike OFF
            escCmd(out,0x1D,0x56,0x00); // full cut
            out.flush();
            runOnUiThread(()->Toast.makeText(MainActivity.this,"Printed directly to "+(device.getName()==null?"printer":device.getName()),Toast.LENGTH_SHORT).show());
        } finally { try{if(out!=null)out.close();}catch(Exception ignored){} try{if(socket!=null)socket.close();}catch(Exception ignored){} }
    }

    private String receiptTwoColumnLine(String left, String right, int width) {
        String l = left == null ? "" : left.trim();
        String r = right == null ? "" : right.trim();
        if (r.length() >= width) return r.substring(Math.max(0, r.length() - width));
        int maxLeft = Math.max(0, width - r.length() - 1);
        if (l.length() > maxLeft) l = l.substring(0, maxLeft);
        int spaces = Math.max(1, width - l.length() - r.length());
        StringBuilder line = new StringBuilder(l);
        for (int i = 0; i < spaces; i++) line.append(' ');
        line.append(r);
        if (line.length() > width) return line.substring(line.length() - width);
        return line.toString();
    }

    private String receiptAmountLine(String label, String amount, int width) {
        String left = label == null ? "" : label.trim();
        String right = amount == null ? "" : amount.trim();
        if (right.length() >= width) return right;
        int spaces = Math.max(1, width - left.length() - right.length());
        StringBuilder sb = new StringBuilder(left);
        for (int i = 0; i < spaces; i++) sb.append(' ');
        sb.append(right);
        String line = sb.toString();
        return line.length() > width ? line.substring(0, width) : line;
    }

    private List<String> wrapPlain(String text,int max){
        List<String> out=new ArrayList<>(); if(text==null||text.trim().isEmpty())return out;
        String s=text.trim().replaceAll("\\s+"," "); while(s.length()>max){int cut=s.lastIndexOf(' ',max);if(cut<1)cut=max;out.add(s.substring(0,cut));s=s.substring(cut).trim();} if(!s.isEmpty())out.add(s);return out;
    }

    private void printBill(String json) throws Exception {
        byte[] pdf=createThermalPdfBytes(json);
        PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
        String name="DukaanBill";
        try{name=new JSONObject(json).optString("billNo","DukaanBill");}catch(Exception ignored){}
        final byte[] data=pdf;
        final String printName=name;
        pm.print(printName,new PrintDocumentAdapter(){
            @Override public void onLayout(android.print.PrintAttributes oldAttrs, android.print.PrintAttributes newAttrs, CancellationSignal cancellationSignal, LayoutResultCallback callback, android.os.Bundle extras){
                if(cancellationSignal.isCanceled()){callback.onLayoutCancelled();return;}
                PrintDocumentInfo info=new PrintDocumentInfo.Builder(printName+".pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build(); callback.onLayoutFinished(info,true);
            }
            @Override public void onWrite(PageRange[] pages, ParcelFileDescriptor destination, CancellationSignal cancellationSignal, WriteResultCallback callback){
                try(FileOutputStream out=new FileOutputStream(destination.getFileDescriptor())){out.write(data);out.flush();callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){callback.onWriteFailed(e.getMessage());}
            }
        },new PrintAttributes.Builder().setMediaSize("58mm".equalsIgnoreCase(new JSONObject(json).optJSONObject("settings").optString("paperSize","80mm")) ? new PrintAttributes.MediaSize("DUKAAN58", "58 mm", 2283, 22000) : new PrintAttributes.MediaSize("DUKAAN80", "80 mm", 3150, 22000)).setColorMode(PrintAttributes.COLOR_MODE_COLOR).build());
    }

    private JSONObject calculateTaxSummary(JSONObject b, JSONObject cfg) throws Exception {
        JSONObject out=new JSONObject();
        boolean enabled=b!=null && b.optBoolean("taxationEnabled",false);
        out.put("enabled",enabled);
        if(!enabled){out.put("taxable",0);out.put("tax",0);out.put("cgst",0);out.put("sgst",0);out.put("igst",0);out.put("inter",false);out.put("groups",new JSONArray());return out;}
        JSONArray items=b.optJSONArray("items");
        double calculatedSubtotal=0;
        if(items!=null){for(int i=0;i<items.length();i++){JSONObject it=items.getJSONObject(i);calculatedSubtotal+=quantityValue(it.optString("qty",""),it.optString("unit","piece"))*it.optDouble("rate",0);}}
        double subtotal=b.has("subtotal")?b.optDouble("subtotal",calculatedSubtotal):calculatedSubtotal;
        double discount=Math.max(0,b.optDouble("discount",0));
        double taxable=0,tax=0;
        TreeMap<Double,double[]> groups=new TreeMap<>();
        if(items!=null){for(int i=0;i<items.length();i++){JSONObject it=items.getJSONObject(i);double gross=quantityValue(it.optString("qty",""),it.optString("unit","piece"))*it.optDouble("rate",0);double net=subtotal>0?gross*(subtotal-discount)/subtotal:gross;double rate=it.optDouble("taxRate",0);boolean inclusive=b.optBoolean("amountsIncludeTax",true);double base=rate>0?(inclusive?net/(1.0+rate/100.0):net):net;double tx=rate>0?(inclusive?net-base:net*rate/100.0):0;taxable+=base;tax+=tx;double[] g=groups.get(rate);if(g==null){g=new double[]{0,0};groups.put(rate,g);}g[0]+=base;g[1]+=tx;}}
        String business=b.optString("businessState",cfg.optString("businessState","")).trim();String pos=b.optString("placeOfSupply",business).trim();boolean inter=!business.isEmpty()&&!pos.isEmpty()&&!business.equalsIgnoreCase(pos);
        out.put("taxable",taxable);out.put("tax",tax);out.put("cgst",inter?0:tax/2.0);out.put("sgst",inter?0:tax/2.0);out.put("igst",inter?tax:0);out.put("inter",inter);
        JSONArray arr=new JSONArray();for(Map.Entry<Double,double[]> e:groups.entrySet()){JSONObject g=new JSONObject();g.put("rate",e.getKey());g.put("taxable",e.getValue()[0]);g.put("tax",e.getValue()[1]);arr.put(g);}out.put("groups",arr);
        return out;
    }

    private Uri createPdf(String json) throws Exception {
        JSONObject b = new JSONObject(json);
        JSONArray items = b.optJSONArray("items");
        JSONObject cfg = b.optJSONObject("settings");
        boolean taxInvoice=b.optBoolean("taxationEnabled",false);
        JSONObject tax=calculateTaxSummary(b,cfg);
        PdfDocument doc = new PdfDocument();
        Bitmap logo = loadLogo(cfg);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int pageNo=1, y;
        PdfDocument.Page page = null;
        Canvas canvas = null;
        int pageWidth=595, pageHeight=842;
        boolean a6Paper = cfg != null && "A6".equalsIgnoreCase(cfg.optString("paperSize", "A4"));
        int outputPageWidth = a6Paper ? 298 : pageWidth;
        int outputPageHeight = a6Paper ? 421 : pageHeight;

        page = doc.startPage(new PdfDocument.PageInfo.Builder(outputPageWidth,outputPageHeight,pageNo).create());
        canvas = page.getCanvas();
        if (a6Paper) canvas.scale(0.5f, 0.5f);
        float headerBottom = drawPdfHeader(canvas,p,logo,pageWidth,cfg,b,taxInvoice,b.optString("placeOfSupply",cfg==null?"":cfg.optString("businessState","")));

        // A4/A6 bill tables use outlined cells. Filled rectangles are created explicitly for headers only.
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.8f);
        p.setColor(android.graphics.Color.BLACK);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(10);
        // Invoice/customer details are already rendered in the compact three-column header.
        // Do not print the legacy duplicate metadata rows below it; this keeps the header near 15% of A4.
        int detailsBottom=(int)headerBottom;
        JSONObject customFields=b.optJSONObject("customFields");int customHeaderCount=0;
        int customHeaderY=detailsBottom+16;
        java.util.List<String> headerFieldTexts=new java.util.ArrayList<>();
        if(cfg!=null&&customFields!=null){String[] keys={"field1","field2","field3"};String[] labelKeys={"customBillField1Label","customBillField2Label","customBillField3Label"};String[] posKeys={"customBillField1Position","customBillField2Position","customBillField3Position"};for(int i=0;i<keys.length;i++){String label=cfg.optString(labelKeys[i],"").trim(),value=customFields.optString(keys[i],"").trim(),pos=cfg.optString(posKeys[i],i==2?"footer":"header");if(!label.isEmpty()&&!value.isEmpty()&&"header".equalsIgnoreCase(pos)){headerFieldTexts.add(label+": "+value);customHeaderCount++;}}}
        if(!headerFieldTexts.isEmpty()){
            float rowTop=customHeaderY-11, rowBottom=customHeaderY+10;
            canvas.drawRect(35,rowTop,560,rowBottom,p);
            if(headerFieldTexts.size()==2) canvas.drawLine(297.5f,rowTop,297.5f,rowBottom,p);
            else if(headerFieldTexts.size()>=3){canvas.drawLine(210,rowTop,210,rowBottom,p);canvas.drawLine(385,rowTop,385,rowBottom,p);}
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(9);
            if(headerFieldTexts.size()==1){p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,headerFieldTexts.get(0),42,customHeaderY+3);}
            else if(headerFieldTexts.size()==2){p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,trimText(headerFieldTexts.get(0),38),42,customHeaderY+3);p.setTextAlign(Paint.Align.RIGHT);drawText(canvas,p,trimText(headerFieldTexts.get(1),38),553,customHeaderY+3);}
            else {p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,trimText(headerFieldTexts.get(0),24),42,customHeaderY+3);p.setTextAlign(Paint.Align.CENTER);drawText(canvas,p,trimText(headerFieldTexts.get(1),24),297.5f,customHeaderY+3);p.setTextAlign(Paint.Align.RIGHT);drawText(canvas,p,trimText(headerFieldTexts.get(2),24),553,customHeaderY+3);}
            p.setTextAlign(Paint.Align.LEFT);customHeaderY+=25;
        }
        // Payment mode is included in the customer panel of the header; avoid a duplicate row.
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(9);
        int baseTableY = Math.max(detailsBottom+20, customHeaderY+8);
        int tableY = Math.max(145, baseTableY);
        // Plain spreadsheet-style table: no shaded header or filled cells.
        p.setStyle(Paint.Style.STROKE); p.setColor(android.graphics.Color.BLACK); p.setStrokeWidth(0.8f);
        canvas.drawRect(35,tableY,560,tableY+22,p);
        float[] itemCols = taxInvoice ? new float[]{35,60,250,295,330,390,445,560} : new float[]{35,60,265,315,375,560};
        for(int ci=1;ci<itemCols.length-1;ci++) canvas.drawLine(itemCols[ci],tableY,itemCols[ci],tableY+25,p);
        p.setColor(android.graphics.Color.BLACK); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(9.0f);
        drawText(canvas,p,"Sr.",41,tableY+14);
        drawText(canvas,p,"Item / HSN",68,tableY+14);
        drawText(canvas,p,"Qty",258,tableY+14);
        if(taxInvoice){drawText(canvas,p,"Unit",298,tableY+14);drawTextRight(canvas,p,"Rate (₹)",386,tableY+14);drawText(canvas,p,"GST %",397,tableY+14);}
        else drawText(canvas,p,"Rate (₹)",320,tableY+14);
        drawTextRight(canvas,p,"Amount (₹)",550,tableY+14);
        p.setColor(android.graphics.Color.BLACK); p.setTypeface(Typeface.DEFAULT); p.setTextSize(9.0f);
        y=tableY+22;

        double calculatedSubtotal=0;
        if(items!=null){
            for(int i=0;i<items.length();i++){
                JSONObject it=items.getJSONObject(i);
                String name=it.optString("name",""); if(cfg!=null && cfg.optBoolean("printItemCode",false)){String code=it.optString("itemCode","").trim();if(!code.isEmpty())name=code+" - "+name;}
                String hsn=it.optString("hsn",it.optString("hsnCode", "")).trim();
                String qty=it.optString("qty","");
                String unit=it.optString("unit","piece");
                double rate=it.optDouble("rate",0);
                double amount=quantityValue(qty,unit)*rate;
                double taxRate=it.optDouble("taxRate",0);
                String itemLine=name+(hsn.isEmpty()?"":" - "+hsn);
                p.setTypeface(Typeface.DEFAULT); p.setTextSize(8.8f);
                float[] rowCols = taxInvoice ? new float[]{35,60,250,295,330,390,445,560} : new float[]{35,60,265,315,375,560};
                // Compact Excel-like row: single item line, one horizontal border, no oversized item boxes.
                float itemTextWidth=taxInvoice?184f:202f;
                while(p.measureText(itemLine)>itemTextWidth && p.getTextSize()>7.0f) p.setTextSize(p.getTextSize()-0.25f);
                float rowHeight=22f;
                String itemComment=it.optString("comment","").trim();
                java.util.List<String> commentLines=java.util.Collections.emptyList();
                if(b.optBoolean("includeItemComments",false)&&!itemComment.isEmpty()){
                    p.setTextSize(8.0f); commentLines=wrapText("Comment: "+itemComment,p,510);
                }
                float needed=rowHeight+(commentLines.isEmpty()?0:commentLines.size()*10f+3f)+2f;
                if(y+needed>770){
                    doc.finishPage(page); pageNo++;
                    page=doc.startPage(new PdfDocument.PageInfo.Builder(outputPageWidth,outputPageHeight,pageNo).create());
                    canvas=page.getCanvas(); if (a6Paper) canvas.scale(0.5f, 0.5f);
                    p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(0.8f);p.setColor(android.graphics.Color.BLACK);
                    float nextHeaderBottom=drawPdfHeader(canvas,p,logo,pageWidth,cfg,b,taxInvoice,b.optString("placeOfSupply",cfg==null?"":cfg.optString("businessState","")));
                    y=(int)nextHeaderBottom+18;
                    if(!headerFieldTexts.isEmpty()) y+=21;
                    p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(9.0f);
                    canvas.drawRect(35,y,560,y+22,p);
                    for(int ci=1;ci<itemCols.length-1;ci++)canvas.drawLine(itemCols[ci],y,itemCols[ci],y+22,p);
                    drawText(canvas,p,"Sr.",41,y+14);drawText(canvas,p,"Item / HSN",68,y+14);drawText(canvas,p,"Qty",258,y+14);
                    if(taxInvoice){drawText(canvas,p,"Unit",298,y+14);drawTextRight(canvas,p,"Rate (₹)",386,y+14);drawText(canvas,p,"GST %",397,y+14);}else drawText(canvas,p,"Rate (₹)",320,y+14);
                    drawTextRight(canvas,p,"Amount (₹)",550,y+14);y+=22;
                }
                float rowTop=y, rowBottom=y+rowHeight;
                p.setTypeface(Typeface.DEFAULT);p.setTextSize(8.8f);p.setColor(android.graphics.Color.BLACK);
                drawText(canvas,p,String.valueOf(i+1),42,y+14);
                drawText(canvas,p,itemLine,68,y+14);
                drawText(canvas,p,trimText(qty,10),258,y+14);
                if(taxInvoice){drawText(canvas,p,trimText(unit,8),298,y+14);drawTextRight(canvas,p,String.format(Locale.US,"%.2f",rate),386,y+14);drawText(canvas,p,String.format(Locale.US,"%.0f%%",taxRate),397,y+14);}
                else drawTextRight(canvas,p,String.format(Locale.US,"%.2f",rate),365,y+14);
                drawTextRight(canvas,p,String.format(Locale.US,"%.2f",amount),550,y+14);
                canvas.drawRect(35,rowTop,560,rowBottom,p);
                for(int ci=1;ci<rowCols.length-1;ci++)canvas.drawLine(rowCols[ci],rowTop,rowCols[ci],rowBottom,p);
                y=rowBottom;
                if(!commentLines.isEmpty()){
                    float commentBottom=y+commentLines.size()*10f+3f;
                    canvas.drawRect(35,y,560,commentBottom,p);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.ITALIC));p.setTextSize(8.0f);
                    float cy=y+11;for(String commentLine:commentLines){drawText(canvas,p,commentLine,42,cy);cy+=10;}
                    y=commentBottom;
                }
                canvas.drawLine(35,y,560,y,p); y+=2;
                p.setTypeface(Typeface.DEFAULT);p.setTextSize(9.0f);
                calculatedSubtotal+=amount;
            }
        }
        double subtotal=b.has("subtotal")?b.optDouble("subtotal",calculatedSubtotal):calculatedSubtotal;
        double discount=b.optDouble("discount",0);
        double finalTotal=b.has("total")?b.optDouble("total",Math.max(0,subtotal-discount)):Math.max(0,subtotal-discount);
        if (y > 690) {
            doc.finishPage(page);
            pageNo++;
            page=doc.startPage(new PdfDocument.PageInfo.Builder(outputPageWidth,outputPageHeight,pageNo).create());
            canvas=page.getCanvas();
            if (a6Paper) canvas.scale(0.5f, 0.5f);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.8f); p.setColor(android.graphics.Color.BLACK);
            float nextHeaderBottom = drawPdfHeader(canvas,p,logo,pageWidth,cfg,b,taxInvoice,b.optString("placeOfSupply",cfg==null?"":cfg.optString("businessState","")));
            y=(int)nextHeaderBottom+22;
        }
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(9);
        // Put the compact GST rate table in the unused left side of the totals
        // area. Its right edge is x=390, using the blank space up to the Rate column above;
        // subtotal/tax totals remain in a clean right-aligned column.
        int summaryTop=y+18;
        String overallComment=b.optString("overallComment","").trim();
        if(b.optBoolean("includeOverallComment",false)&&!overallComment.isEmpty()){
            p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.ITALIC));p.setTextSize(8.0f);
            for(String commentLine:wrapText("Comment: "+overallComment,p,500)){p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,commentLine,42,summaryTop);summaryTop+=12;}
            summaryTop+=4;
        }
        int totalY=summaryTop;
        drawTextRight(canvas,p,"Subtotal:",470,totalY);p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,"₹"+String.format(Locale.US,"%.2f",subtotal),478,totalY);
        totalY+=17;
        if (discount > 0.000001) {
            drawTextRight(canvas,p,"Discount:",470,totalY);p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,"-₹"+String.format(Locale.US,"%.2f",discount),478,totalY);
            totalY+=17;
        }
        int gstTableBottom=summaryTop;
        if(taxInvoice){
            drawTextRight(canvas,p,"Taxable Value:",470,totalY);p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("taxable",0)),478,totalY); totalY+=17;
            if(tax.optBoolean("inter",false)) {
                drawTextRight(canvas,p,"IGST:",470,totalY);p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("igst",0)),478,totalY); totalY+=17;
            } else {
                drawTextRight(canvas,p,"CGST:",470,totalY);p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("cgst",0)),478,totalY); totalY+=17;
                drawTextRight(canvas,p,"SGST:",470,totalY);p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("sgst",0)),478,totalY); totalY+=17;
            }
            drawTextRight(canvas,p,"Total GST:",470,totalY);p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("tax",0)),478,totalY); totalY+=19;
            // Compact GST summary sits beneath the overall comment in the left panel.
            int gstTop=summaryTop+8;
            if(b.optBoolean("includeOverallComment",false)&&!overallComment.isEmpty()) gstTop=summaryTop+8;
            float left=42,right=400; float[] gstCols={42,115,185,255,325,400};
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(8.0f);
            canvas.drawRect(left,gstTop,right,gstTop+18,p);
            drawText(canvas,p,"GST Summary",left+6,gstTop+12);
            float headerTop=gstTop+18;
            canvas.drawRect(left,headerTop,right,headerTop+30,p);
            for(int ci=1;ci<gstCols.length-1;ci++)canvas.drawLine(gstCols[ci],headerTop,gstCols[ci],headerTop+30,p);
            String[] gh={"Taxable","CGST","SGST","IGST","Total GST"};
            for(int ci=0;ci<gh.length;ci++){p.setTextAlign(Paint.Align.CENTER);drawText(canvas,p,gh[ci],(gstCols[ci]+gstCols[ci+1])/2f,headerTop+18);}
            String[] gv={String.format(Locale.US,"%.2f",tax.optDouble("taxable",0)),String.format(Locale.US,"%.2f",tax.optDouble("cgst",0)),String.format(Locale.US,"%.2f",tax.optDouble("sgst",0)),String.format(Locale.US,"%.2f",tax.optDouble("igst",0)),String.format(Locale.US,"%.2f",tax.optDouble("tax",0))};
            float valuesTop=headerTop+30;canvas.drawRect(left,valuesTop,right,valuesTop+19,p);for(int ci=1;ci<gstCols.length-1;ci++)canvas.drawLine(gstCols[ci],valuesTop,gstCols[ci],valuesTop+19,p);
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(7.5f);for(int ci=0;ci<gv.length;ci++){p.setTextAlign(Paint.Align.CENTER);drawText(canvas,p,gv[ci],(gstCols[ci]+gstCols[ci+1])/2f,valuesTop+13);}p.setTextAlign(Paint.Align.LEFT);
            gstTableBottom=(int)valuesTop+22;
            canvas.drawRect(38,y+8,405,gstTableBottom,p);
        }
        // Render transaction history after the totals so it never collides with GST/totals.
        JSONArray recentTransactions=b.optBoolean("includeLast5Transactions",false)?b.optJSONArray("last5Transactions"):null;
        int transactionsBottom=summaryTop;

        // Keep total amount directly below Total GST on the right; transaction history follows the totals.
        totalY=Math.max(totalY,summaryTop+18);
        double billRoundOff=b.optDouble("roundOff",0);
        if(Math.abs(billRoundOff)>=0.005){
            p.setTypeface(Typeface.DEFAULT); p.setTextSize(9);
            drawTextRight(canvas,p,"Round Off:",470,totalY);p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,(billRoundOff>0?"+₹":"-₹")+String.format(Locale.US,"%.2f",Math.abs(billRoundOff)),478,totalY);
            totalY+=17;
        }
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(14);
        p.setTextAlign(Paint.Align.RIGHT);drawText(canvas,p,"Total Amount:",470,totalY);
        p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,"₹"+String.format(Locale.US,"%.2f",finalTotal),478,totalY);p.setTextAlign(Paint.Align.LEFT);
        totalY+=20;
        int commentsBottom=totalY;
        double partialPayment=b.optDouble("partialPaymentAmount",0);
        double totalBalance=Math.max(0,finalTotal-partialPayment);
        if(partialPayment>0 || "Credit".equalsIgnoreCase(b.optString("paymentMode",""))){
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(10.0f);
            p.setTextAlign(Paint.Align.RIGHT);drawText(canvas,p,"Paid:",470,commentsBottom);p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,"₹"+String.format(Locale.US,"%.2f",partialPayment),478,commentsBottom);commentsBottom+=16;
            p.setTextAlign(Paint.Align.RIGHT);drawText(canvas,p,"Total Balance:",470,commentsBottom);p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,"₹"+String.format(Locale.US,"%.2f",totalBalance),478,commentsBottom);commentsBottom+=16;
        }
        // Customer lifetime outstanding is distinct from this bill's balance. Prefer the
        // saved customer-ledger balance if the bill snapshot provides it; otherwise use this bill balance.
        double customerTotalBalance=totalBalance;
        if(partialPayment>0 || "Credit".equalsIgnoreCase(b.optString("paymentMode",""))){
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(10.0f);p.setTextAlign(Paint.Align.RIGHT);drawText(canvas,p,"Customer Total Balance:",470,commentsBottom);p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,"₹"+String.format(Locale.US,"%.2f",customerTotalBalance),478,commentsBottom);commentsBottom+=16;
        }
        if(recentTransactions!=null && recentTransactions.length()>0){
            int ty=Math.max(Math.max(totalY+20,commentsBottom+14),gstTableBottom+16);
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(8.0f);
            drawText(canvas,p,"Last 5 Customer Transactions",42,ty);ty+=15;
            drawText(canvas,p,"Date",42,ty);drawText(canvas,p,"Type",105,ty);drawText(canvas,p,"Bill/Txn No",155,ty);drawTextRight(canvas,p,"P.Bal",355,ty);drawTextRight(canvas,p,"Payment",455,ty);drawTextRight(canvas,p,"Bal",560,ty);
            canvas.drawLine(40,ty+4,560,ty+4,p);ty+=17;
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(7.2f);
            for(int ti=0;ti<recentTransactions.length()&&ti<5;ti++){
                JSONObject tr=recentTransactions.optJSONObject(ti);if(tr==null)continue;
                String rawDate=tr.optString("date","");
                String displayDate=rawDate.length()>=10?rawDate.substring(8,10)+"/"+monthShort(rawDate.substring(5,7))+"/"+rawDate.substring(0,4):rawDate;
                String type=tr.optString("type","").replace("Credit sale","Credit").replace("Payment received","Payment");String ref=tr.optString("reference","");
                double bal=tr.optDouble("balance",tr.optDouble("balanceDue",0));double prev=tr.has("previousBalance")?tr.optDouble("previousBalance",0):bal-tr.optDouble("debit",0)+tr.optDouble("credit",0);
                drawText(canvas,p,displayDate,42,ty);drawText(canvas,p,trimText(type,8),105,ty);drawText(canvas,p,trimText(ref,30),155,ty);
                drawTextRight(canvas,p,String.format(Locale.US,"%.2f",prev),355,ty);
                drawTextRight(canvas,p,String.format(Locale.US,"%.2f",tr.optDouble("paymentAmount",tr.optDouble("amount",0))),455,ty);
                drawTextRight(canvas,p,String.format(Locale.US,"%.2f",bal),560,ty);
                canvas.drawLine(40,ty+4,560,ty+4,p);ty+=15;
            }
            transactionsBottom=ty+4;
        }
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(10);
        int footerY=Math.max(Math.max(y+64,commentsBottom+24),Math.max(gstTableBottom+24,transactionsBottom+20));
        int customFooterIndex=0;if(cfg!=null&&customFields!=null){String[] keys={"field1","field2","field3"};String[] labelKeys={"customBillField1Label","customBillField2Label","customBillField3Label"};String[] posKeys={"customBillField1Position","customBillField2Position","customBillField3Position"};for(int i=0;i<keys.length;i++){String label=cfg.optString(labelKeys[i],"").trim(),value=customFields.optString(keys[i],"").trim(),pos=cfg.optString(posKeys[i],i==2?"footer":"header").trim().toLowerCase(Locale.US);if(!label.isEmpty()&&!value.isEmpty()&&"footer".equals(pos)){drawText(canvas,p,label+": "+value,35,footerY);footerY+=14;customFooterIndex++;}}}
        String footerMsg = cfg == null ? "" : cfg.optString("footer","");
        if (!footerMsg.trim().isEmpty()) {
            p.setTextAlign(Paint.Align.CENTER);
            for (String line : wrapText(footerMsg,p,330)) { drawText(canvas,p,line,300,footerY); footerY+=14; }
            p.setTextAlign(Paint.Align.LEFT);
        }
        if(cfg!=null&&cfg.optBoolean("upiQrEnabled",false)){drawCenteredBillQr(canvas,p,b,cfg,300,footerY+8,92);footerY+=120;}
        String terms=cfg==null?"":cfg.optString("termsConditions","").trim(); if(cfg!=null && cfg.optBoolean("printTermsConditions",false) && !terms.isEmpty()){int termsY=footerY;for(String line:wrapText(terms,p,330)){drawText(canvas,p,line,35,termsY);termsY+=12;}}
        String signature = cfg == null ? "" : cfg.optString("signature","").trim();
        if(!signature.isEmpty()){
            p.setTypeface(Typeface.DEFAULT_BOLD);
            drawText(canvas,p,signature,410,footerY);
            p.setTypeface(Typeface.DEFAULT);
            drawText(canvas,p,"Authorized Signatory",410,footerY+16);
        }
        p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.ITALIC));
        p.setTextSize(8); p.setTextAlign(Paint.Align.CENTER);
        drawText(canvas,p,cfg == null ? "Bill created by DukaanBill • Contact 8087794271 for more details" : cfg.optString("creditFooter","Bill created by DukaanBill • Contact 8087794271 for more details"),pageWidth/2f,812);
        p.setTypeface(Typeface.DEFAULT); p.setTextAlign(Paint.Align.LEFT);

        doc.finishPage(page);
        ByteArrayOutputStream bos=new ByteArrayOutputStream();
        doc.writeTo(bos); doc.close();
        String filename="Bill_"+b.optString("billNo","Bill").replaceAll("[^A-Za-z0-9_-]","_")+".pdf";
        return saveForSharing(bos.toByteArray(),filename,"application/pdf");
    }

    private String trimText(String s,int max){ if(s==null)return ""; return s.length()>max?s.substring(0,max-1)+"…":s; }
    private String formatDate(String d){ if(d==null||d.length()<10)return d; return d.substring(8,10)+"/"+monthShort(d.substring(5,7))+"/"+d.substring(0,4); }
    private String monthShort(String m){String[] months={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};try{int n=Integer.parseInt(m);return n>=1&&n<=12?months[n-1]:m;}catch(Exception e){return m;}}

    private double quantityValue(String q, String defaultUnit){
        if(q==null)return 0;
        String s=q.trim().toLowerCase().replace(",","");
        try{
            java.util.regex.Matcher m=java.util.regex.Pattern.compile(
                    "(\\d+(?:\\.\\d+)?)\\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pack|packs|box|boxes|bottle|bottles|dozen)?",
                    java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s);
            if(!m.find()) return 0;
            double n=Double.parseDouble(m.group(1));
            String u=m.group(2); if(u==null)u=defaultUnit==null?"piece":defaultUnit;
            u=u.toLowerCase();
            if(u.equals("mg")||u.startsWith("milligram"))return n/1000000.0;
            if(u.equals("g")||u.equals("gm")||u.startsWith("gram"))return n/1000.0;
            if(u.equals("ml")||u.startsWith("milliliter")||u.startsWith("millilitre"))return n/1000.0;
            if(u.equals("l")||u.equals("ltr")||u.equals("lt")||u.equals("liter")||u.equals("litre")||u.equals("liters")||u.equals("litres"))return n;
            if(u.equals("dozen")||u.equals("dz"))return n*12.0;
            return n;
        }catch(Exception e){return 0;}
    }

    private File copyToPurchaseStorage(Uri uri, String originalName) throws Exception {
        String safe=UUID.randomUUID().toString()+"_"+(originalName==null?"document":originalName).replaceAll("[^A-Za-z0-9._-]","_");
        File outFile=new File(purchaseDocsDir,safe);
        try(InputStream in=getContentResolver().openInputStream(uri); OutputStream out=new FileOutputStream(outFile)){
            if(in==null)throw new Exception("Could not read selected document");
            byte[] buf=new byte[8192]; int n;
            while((n=in.read(buf))>0)out.write(buf,0,n);
        }
        return outFile;
    }

    private void sendPurchaseProgress(String message){
        try{
            String encoded=android.util.Base64.encodeToString(message.getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
            runOnUiThread(()->webView.evaluateJavascript("window.onPurchaseImportProgress && window.onPurchaseImportProgress(atob('"+encoded+"'))",null));
        }catch(Exception ignored){}
    }

    private void sendPurchaseError(String message){
        try{
            String encoded=android.util.Base64.encodeToString((message==null?"Unknown error":message).getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
            runOnUiThread(()->webView.evaluateJavascript("window.onPurchaseImportError && window.onPurchaseImportError(atob('"+encoded+"'))",null));
        }catch(Exception ignored){}
    }

    private void sendPurchaseResult(String attachmentId,String fileName,String mime,String text){
        try{
            JSONObject o=new JSONObject();
            o.put("attachmentId",attachmentId);
            o.put("fileName",fileName==null?"":fileName);
            o.put("mime",mime==null?"":mime);
            o.put("text",text==null?"":text);
            String encoded=android.util.Base64.encodeToString(o.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
            runOnUiThread(()->webView.evaluateJavascript("window.onPurchaseImportResultBase64 && window.onPurchaseImportResultBase64('"+encoded+"')",null));
        }catch(Exception e){sendPurchaseError(e.getMessage());}
    }

    private void ocrImage(Uri uri, File stored, String fileName, String mime){
        sendPurchaseProgress("Reading invoice photo...");
        try{
            Bitmap bitmap=BitmapFactory.decodeFile(stored.getAbsolutePath());
            if(bitmap==null)throw new Exception("Could not decode the selected image");
            // Normalize phone-camera EXIF orientation before ML Kit so rotated camera photos
            // are recognized consistently with gallery uploads.
            try{
                androidx.exifinterface.media.ExifInterface exif=new androidx.exifinterface.media.ExifInterface(stored.getAbsolutePath());
                int orientation=exif.getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL);
                android.graphics.Matrix matrix=new android.graphics.Matrix();
                if(orientation==androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_90)matrix.postRotate(90f);
                else if(orientation==androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_180)matrix.postRotate(180f);
                else if(orientation==androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_270)matrix.postRotate(270f);
                else if(orientation==androidx.exifinterface.media.ExifInterface.ORIENTATION_FLIP_HORIZONTAL)matrix.preScale(-1f,1f);
                else if(orientation==androidx.exifinterface.media.ExifInterface.ORIENTATION_FLIP_VERTICAL)matrix.preScale(1f,-1f);
                if(!matrix.isIdentity()){
                    Bitmap rotated=Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
                    if(rotated!=bitmap){bitmap.recycle();bitmap=rotated;}
                }
            }catch(Exception ignored){}
            final Bitmap bitmapForOcr=bitmap;
            InputImage image=InputImage.fromBitmap(bitmapForOcr,0);
            TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            recognizer.process(image)
                .addOnSuccessListener(result->{
                    recognizer.close();
                    bitmapForOcr.recycle();
                    sendPurchaseProgress("Invoice photo read. Preparing purchase details...");
                    sendPurchaseResult(stored.getName(),fileName,mime,result.getText());
                })
                .addOnFailureListener(e->{recognizer.close();bitmapForOcr.recycle();sendPurchaseError("OCR failed: "+e.getMessage());});
        }catch(Exception e){sendPurchaseError("Could not read photo: "+e.getMessage());}
    }

    private String extractPdfText(File stored) throws Exception {
        try (PDDocument document = PDDocument.load(stored)) {
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
            String text = stripper.getText(document);
            return text == null ? "" : text;
        }
    }

    private void ocrPdf(Uri uri, File stored, String fileName, String mime){
        sendPurchaseProgress("Opening PDF invoice...");
        final ExecutorService executor=Executors.newSingleThreadExecutor();
        executor.execute(()->{
            try{
                // First try the PDF's native text layer. Most vendor invoices are
                // generated PDFs and this is considerably more accurate than OCR.
                sendPurchaseProgress("Checking the PDF text layer...");
                String directText=extractPdfText(stored);
                if(directText!=null && directText.trim().length()>50){
                    sendPurchaseProgress("PDF text found. Extracted " + directText.trim().length() + " characters.");
                    sendPurchaseResult(stored.getName(),fileName,mime,directText);
                    executor.shutdown();
                    return;
                }

                // Scanned/image-only PDF: fall back to page rendering + ML Kit OCR.
                sendPurchaseProgress("No usable PDF text layer found. Starting OCR...");
                ParcelFileDescriptor pfd=null;
                PdfRenderer renderer=null;
                try{
                    pfd=ParcelFileDescriptor.open(stored,ParcelFileDescriptor.MODE_READ_ONLY);
                    renderer=new PdfRenderer(pfd);
                    int pages=renderer.getPageCount();
                    StringBuilder all=new StringBuilder();
                    sendPurchaseProgress("PDF opened. " + pages + " page(s) found.");
                    TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                    try{
                        for(int index=0; index<pages; index++){
                            sendPurchaseProgress("Reading PDF page " + (index+1) + " of " + pages + "...");
                            PdfRenderer.Page page=renderer.openPage(index);
                            try{
                                float scale=3.0f;
                                int w=Math.max(1600,Math.round(page.getWidth()*scale));
                                int h=Math.max(2200,Math.round(page.getHeight()*scale));
                                float ratio=(float)page.getWidth()/(float)page.getHeight();
                                if((float)w/(float)h > ratio) w=Math.round(h*ratio); else h=Math.round(w/ratio);
                                Bitmap bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
                                Canvas canvas=new Canvas(bmp);
                                canvas.drawColor(android.graphics.Color.WHITE);
                                page.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT);
                                InputImage image=InputImage.fromBitmap(bmp,0);
                                try{
                                    com.google.mlkit.vision.text.Text result=Tasks.await(recognizer.process(image));
                                    String pageText=result==null?"":result.getText();
                                    if(pageText!=null && !pageText.trim().isEmpty()){
                                        all.append("\n").append(pageText);
                                        sendPurchaseProgress("Page " + (index+1) + " read. " + pageText.length() + " characters found...");
                                    }else{
                                        sendPurchaseProgress("Page " + (index+1) + " read, but no text was detected.");
                                    }
                                } finally { bmp.recycle(); }
                            } finally { page.close(); }
                        }
                    } finally { recognizer.close(); }
                    String finalText=all.toString();
                    sendPurchaseProgress("OCR complete. " + finalText.trim().length() + " characters extracted.");
                    sendPurchaseResult(stored.getName(),fileName,mime,finalText);
                } finally {
                    try{if(renderer!=null)renderer.close();}catch(Exception ignored){}
                    try{if(pfd!=null)pfd.close();}catch(Exception ignored){}
                }
            }catch(Exception e){
                sendPurchaseError("Could not read PDF: " + (e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));
            }finally{
                executor.shutdown();
            }
        });
    }

    private void importPurchaseUri(Uri uri){
        try{
            String original=uri.getLastPathSegment();
            if(original==null||original.trim().isEmpty()) original="vendor_bill_"+System.currentTimeMillis();
            String mime=getContentResolver().getType(uri);
            if(mime==null||mime.trim().isEmpty()) mime=original.toLowerCase().endsWith(".pdf")?"application/pdf":"image/jpeg";
            sendPurchaseProgress("Saving the original vendor bill...");
            File stored=copyToPurchaseStorage(uri,original);
            String lower=original.toLowerCase();
            if(mime.equalsIgnoreCase("application/pdf")||lower.endsWith(".pdf")) ocrPdf(uri,stored,original,mime);
            else ocrImage(uri,stored,original,mime);
        }catch(Exception e){sendPurchaseError("Could not import purchase bill: "+e.getMessage());}
    }

    private void openPurchaseAttachment(String id,String mime){
        try{
            File file=new File(purchaseDocsDir,id);
            if(!file.exists())throw new Exception("Attachment not found");
            byte[] data=readAll(file);
            Uri uri=saveToCacheProvider(data,file.getName());
            Intent view=new Intent(Intent.ACTION_VIEW);
            view.setDataAndType(uri,mime==null?"application/octet-stream":mime);
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            view.setClipData(ClipData.newRawUri(file.getName(),uri));
            startActivity(Intent.createChooser(view,"Open Purchase Bill"));
        }catch(Exception e){Toast.makeText(this,"Could not open attachment: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private byte[] readAll(File f)throws Exception{
        try(InputStream in=new FileInputStream(f);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);return out.toByteArray();
        }
    }

    private String loadAppState() {
        try { return localDb.loadState(); } catch (Exception e) { return "{}"; }
    }

    private void saveAppState(String json) {
        try { localDb.saveState(json); } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "Could not save local data: " + e.getMessage(), Toast.LENGTH_LONG).show());
        }
    }

    private void addFileToZip(ZipOutputStream zos, File file, String entryName) throws Exception {
        ZipEntry entry = new ZipEntry(entryName);
        zos.putNextEntry(entry);
        try (InputStream in = new FileInputStream(file)) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
        }
        zos.closeEntry();
    }

    private static byte[] hexToBytes(String hex) {
        byte[] out = new byte[hex.length()/2];
        for (int i=0;i<out.length;i++) out[i]=(byte)Integer.parseInt(hex.substring(i*2,i*2+2),16);
        return out;
    }

    private static String hex(byte[] data) {
        StringBuilder sb=new StringBuilder(data.length*2);
        for(byte b:data) sb.append(String.format(Locale.US,"%02x",b & 0xff));
        return sb.toString();
    }

    private boolean verifyShopNamePasswordInternal(String password) {
        if (password == null) return false;
        try {
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[] salt=hexToBytes(SHOP_PASSWORD_SALT_HEX);
            byte[] h=md.digest(concat(salt, password.getBytes(StandardCharsets.UTF_8)));
            for(int i=0;i<SHOP_PASSWORD_ITERATIONS;i++) h=md.digest(concat(salt,h));
            return MessageDigest.isEqual(h, hexToBytes(SHOP_PASSWORD_DIGEST_HEX));
        } catch(Exception e){ return false; }
    }

    private static byte[] concat(byte[] a, byte[] b) {
        byte[] out=new byte[a.length+b.length];
        System.arraycopy(a,0,out,0,a.length); System.arraycopy(b,0,out,a.length,b.length); return out;
    }

    /** Create a compact integrity signature for the protected shop name.
     *  Restore never asks the user for a password. The signature lets the app detect
     *  casual/manual edits to the shop name inside a backup while keeping restore portable.
     */
    private String shopNameIntegrity(String shopName) throws Exception {
        if (shopName == null) shopName = "";
        byte[] key = hexToBytes(SHOP_PASSWORD_DIGEST_HEX);
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(key, "HmacSHA256"));
        return hex(mac.doFinal(shopName.getBytes(StandardCharsets.UTF_8)));
    }

    private boolean verifyShopNameIntegrity(String shopName, String signature) {
        try {
            if (signature == null || signature.trim().isEmpty()) return false;
            return MessageDigest.isEqual(shopNameIntegrity(shopName).getBytes(StandardCharsets.UTF_8), signature.trim().toLowerCase(Locale.US).getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) { return false; }
    }

    private void verifyBackupDatabase(File dbFile) throws Exception {
        android.database.sqlite.SQLiteDatabase check = android.database.sqlite.SQLiteDatabase.openDatabase(
                dbFile.getAbsolutePath(), null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY);
        try {
            try (android.database.Cursor c = check.rawQuery("PRAGMA integrity_check", null)) {
                if (!c.moveToFirst() || !"ok".equalsIgnoreCase(c.getString(0))) throw new Exception("SQLite integrity check failed; backup was not created.");
            }
            try (android.database.Cursor c = check.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null)) {
                java.util.Set<String> tables = new java.util.HashSet<>();
                while (c.moveToNext()) tables.add(c.getString(0));
                if (!tables.contains("app_state") || !tables.contains("meta")) throw new Exception("Database is missing expected tables; backup was not created.");
            }
        } finally { check.close(); }
    }

    private File createBackupZip() throws Exception {
        File backupDir = new File(getCacheDir(), "backups");
        if (!backupDir.exists() && !backupDir.mkdirs()) throw new Exception("Could not create backup workspace");
        String stamp = new java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new java.util.Date());
        File zip = new File(backupDir, "SiddhiBill_Backup_" + stamp + "_" + (System.currentTimeMillis()%100000) + ".zip");
        // The complete SQLite database contains every table (currently app_state and meta).
        // Checkpoint WAL and close the helper before copying the main DB so committed rows
        // are not left only in a sidecar file.
        String state = localDb.loadState();
        android.database.Cursor checkpoint = null;
        try {
            checkpoint = localDb.getWritableDatabase().rawQuery("PRAGMA wal_checkpoint(FULL)", null);
            if (checkpoint.moveToFirst() && checkpoint.getInt(0) != 0) throw new Exception("SQLite is busy; close other operations and retry backup.");
        } finally { if (checkpoint != null) checkpoint.close(); }
        localDb.close();
        File dbFile = getDatabasePath("dukaanbill.db");
        if (!dbFile.exists() || dbFile.length() == 0) throw new Exception("Local database is missing or empty. Please reopen the app and try again.");
        // Verify the DB is readable and has all expected tables before putting it in the ZIP.
        verifyBackupDatabase(dbFile);
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zip))) {
            addFileToZip(zos, dbFile, BACKUP_DB_ENTRY);
            ZipEntry manifest = new ZipEntry("database/manifest.json");
            zos.putNextEntry(manifest);
            JSONObject manifestJson = new JSONObject();
            manifestJson.put("app", "SiddhiBill");
            manifestJson.put("schemaVersion", 1);
            manifestJson.put("databaseEntry", BACKUP_DB_ENTRY);
            org.json.JSONArray tableNames = new org.json.JSONArray();
            android.database.sqlite.SQLiteDatabase tableDb = android.database.sqlite.SQLiteDatabase.openDatabase(dbFile.getAbsolutePath(), null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY);
            try (android.database.Cursor tableCursor = tableDb.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name", null)) {
                while (tableCursor.moveToNext()) tableNames.put(tableCursor.getString(0));
            } finally { tableDb.close(); }
            manifestJson.put("tables", tableNames);
            manifestJson.put("stateKeys", new JSONObject(state).length());
            zos.write(manifestJson.toString().getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();
            ZipEntry stateEntry = new ZipEntry(BACKUP_STATE_ENTRY);
            zos.putNextEntry(stateEntry);
            zos.write(state.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            zos.closeEntry();

            String shopName = "SIDDHIBILL";
            try { shopName = new JSONObject(state).optString("shopName", shopName); } catch (Exception ignored) {}
            ZipEntry identityEntry = new ZipEntry(BACKUP_IDENTITY_ENTRY);
            zos.putNextEntry(identityEntry);
            JSONObject identity = new JSONObject();
            identity.put("version", 1);
            identity.put("shopNameSignature", shopNameIntegrity(shopName));
            zos.write(identity.toString().getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();

            if (purchaseDocsDir.exists()) {
                File[] files = purchaseDocsDir.listFiles();
                if (files != null) {
                    for (File f : files) if (f.isFile()) addFileToZip(zos, f, "attachments/" + f.getName());
                }
            }
            ZipEntry ownerEntry = new ZipEntry(BACKUP_OWNER_ENTRY);
            zos.putNextEntry(ownerEntry);
            String ownerJson = pendingOwnerDashboardBackup == null ? "{}" : pendingOwnerDashboardBackup;
            zos.write(ownerJson.getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();

            ZipEntry info = new ZipEntry("backup_info.txt");
            zos.putNextEntry(info);
            String text = "SiddhiBill\nBackup created: " + new java.util.Date() + "\nIncludes local SQLite database, app settings, Owner Dashboard shop/device registry (excluding Owner private key), protected shop identity metadata, and purchase invoice attachments.\nRestore does not require a password.\n";
            zos.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            zos.closeEntry();
        }
        return zip;
    }

    private void updateBackupStatus(String message, boolean finished) {
        if (webView != null) {
            final String quoted = JSONObject.quote(message == null ? "" : message);
            runOnUiThread(() -> webView.evaluateJavascript("window.setNativeBackupStatus && window.setNativeBackupStatus(" + quoted + "," + finished + ")", null));
        }
    }

    private void startBackup() {
        updateBackupStatus("Preparing backup file…", false);
        new Thread(() -> {
            try {
                File created = createBackupZip();
                if (created.length() < 100) throw new Exception("Backup ZIP is unexpectedly small; no backup was saved.");
                runOnUiThread(() -> {
                    pendingBackupZip = created;
                    try {
                        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("application/zip");
                        i.putExtra(Intent.EXTRA_TITLE, created.getName());
                        updateBackupStatus("Backup prepared. Choose a folder or cloud location to save the ZIP.", false);
                        startActivityForResult(i, REQ_BACKUP_CREATE);
                    } catch (Exception e) {
                        updateBackupStatus("Could not open the save dialog: " + e.getMessage(), true);
                        Toast.makeText(this, "Could not open backup save dialog: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                updateBackupStatus("Backup failed: " + e.getMessage(), true);
                runOnUiThread(() -> Toast.makeText(this, "Backup failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }, "siddhibill-backup").start();
    }

    private void copyFileToUri(File src, Uri dest) throws Exception {
        try (InputStream in = new FileInputStream(src); OutputStream out = getContentResolver().openOutputStream(dest)) {
            if (out == null) throw new Exception("Could not open backup destination");
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            out.flush();
        }
    }

    private void startRestore() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        startActivityForResult(i, REQ_BACKUP_RESTORE);
    }

    private boolean safeZipPath(String name) {
        if (name == null || name.length() == 0 || name.startsWith("/") || name.contains("\\")) return false;
        return !name.contains("../") && !name.equals("..") && !name.contains("/../");
    }

    private void restoreBackup(Uri uri) throws Exception {
        File restoreDir = new File(getCacheDir(), "restore_" + System.currentTimeMillis());
        if (!restoreDir.mkdirs()) throw new Exception("Could not create restore workspace");
        File zipFile = new File(restoreDir, "backup.zip");
        try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(zipFile)) {
            if (in == null) throw new Exception("Could not read backup file");
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) out.write(b,0,n);
        }
        File restoredDb = new File(restoreDir, "dukaanbill.db");
        File restoredState = new File(restoreDir, "app_state.json");
        File restoredAttachments = new File(restoreDir, "attachments");
        File restoredIdentity = new File(restoreDir, "shop_identity.sig");
        File restoredOwner = new File(restoreDir, "owner_dashboard.json");
        if (!restoredAttachments.mkdirs()) restoredAttachments.mkdirs();
        boolean dbFound=false;
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile))) {
            ZipEntry e;
            byte[] b = new byte[8192];
            while ((e = zis.getNextEntry()) != null) {
                if (e.isDirectory() || !safeZipPath(e.getName())) { zis.closeEntry(); continue; }
                File outFile;
                if (e.getName().equals(BACKUP_DB_ENTRY)) { outFile=restoredDb; dbFound=true; }
                else if (e.getName().equals(BACKUP_STATE_ENTRY)) outFile=restoredState;
                else if (e.getName().equals(BACKUP_IDENTITY_ENTRY)) outFile=restoredIdentity;
                else if (e.getName().equals(BACKUP_OWNER_ENTRY)) outFile=restoredOwner;
                else if (e.getName().startsWith("attachments/")) {
                    String fn=e.getName().substring("attachments/".length());
                    if (fn.contains("/") || fn.length()==0) { zis.closeEntry(); continue; }
                    outFile=new File(restoredAttachments, fn);
                } else { zis.closeEntry(); continue; }
                File parent=outFile.getParentFile(); if(parent!=null&&!parent.exists())parent.mkdirs();
                try(OutputStream out=new FileOutputStream(outFile)){int n;while((n=zis.read(b))>0)out.write(b,0,n);}
                zis.closeEntry();
            }
        }
        if(!dbFound || !restoredDb.exists() || restoredDb.length()==0) throw new Exception("This is not a valid SiddhiBill backup: database is missing or empty.");
        // Validate the incoming database before touching the live database.
        verifyBackupDatabase(restoredDb);
        if (restoredState.exists()) {
            try { new JSONObject(new String(readAll(restoredState), StandardCharsets.UTF_8)); }
            catch (Exception e) { throw new Exception("Backup settings are damaged; existing data was not changed."); }
        }
        // Restore is intentionally password-free. The protected shop-name metadata is used only
        // to detect casual/manual edits to app_state.json. Business data is still restored normally.
        // Older backups without this metadata remain backward-compatible.
        boolean settingsIntegrityValid = true;
        boolean hasIntegrityMetadata = restoredState.exists() && restoredIdentity.exists();
        String currentStateBeforeRestore = localDb.loadState();
        if (hasIntegrityMetadata) {
            try {
                JSONObject st = new JSONObject(new String(readAll(restoredState), StandardCharsets.UTF_8));
                JSONObject id = new JSONObject(new String(readAll(restoredIdentity), StandardCharsets.UTF_8));
                String restoredShopName = st.optString("shopName", "DUKAAN BILL");
                settingsIntegrityValid = verifyShopNameIntegrity(restoredShopName, id.optString("shopNameSignature", ""));
            } catch (Exception ignored) { settingsIntegrityValid = false; }
        }
        localDb.close();
        File currentDb=getDatabasePath("dukaanbill.db");
        File stagedDb=new File(currentDb.getParentFile(), "dukaanbill.restore.tmp");
        File rollbackDb=new File(currentDb.getParentFile(), "dukaanbill.pre_restore.bak");
        if(stagedDb.exists() && !stagedDb.delete()) throw new Exception("Could not prepare restore staging file.");
        try(InputStream in=new FileInputStream(restoredDb);OutputStream out=new FileOutputStream(stagedDb)){
            byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();
        }
        verifyBackupDatabase(stagedDb);
        if (rollbackDb.exists() && !rollbackDb.delete()) throw new Exception("Could not prepare restore rollback file.");
        File wal=new File(currentDb.getAbsolutePath()+"-wal"), shm=new File(currentDb.getAbsolutePath()+"-shm");
        if(wal.exists()) wal.delete(); if(shm.exists()) shm.delete();
        if(currentDb.exists() && !currentDb.renameTo(rollbackDb)) throw new Exception("Could not safely stage current database; existing data was not changed.");
        if(!stagedDb.renameTo(currentDb)) {
            if(rollbackDb.exists()) rollbackDb.renameTo(currentDb);
            throw new Exception("Could not install restored database; previous data was preserved.");
        }
        try {
            localDb=new LocalDatabase(this);
            verifyBackupDatabase(currentDb);
        } catch(Exception restoreOpenError) {
            try { localDb.close(); } catch(Exception ignored) {}
            if(currentDb.exists()) currentDb.delete();
            if(rollbackDb.exists()) rollbackDb.renameTo(currentDb);
            localDb=new LocalDatabase(this);
            throw new Exception("Restored database failed validation; previous data was rolled back. " + restoreOpenError.getMessage());
        }
        if(rollbackDb.exists()) rollbackDb.delete();
        if(hasIntegrityMetadata && !settingsIntegrityValid) {
            // Keep the restored business database, but reject only the tampered settings payload.
            // Do NOT write the complete pre-restore state here, because that would overwrite the
            // restored bills/customers/products as well. Only carry forward the receiving phone's
            // current settings object.
            try {
                JSONObject currentStateObj = new JSONObject(currentStateBeforeRestore);
                JSONObject settingsOnly = new JSONObject();
                if(currentStateObj.has("dukaanBillSettings")) {
                    settingsOnly.put("dukaanBillSettings", currentStateObj.optString("dukaanBillSettings", "{}"));
                }
                localDb.saveState(settingsOnly.toString());
            } catch(Exception ignored) {}
            runOnUiThread(() -> Toast.makeText(this, "Backup restored. Shop settings were kept because the backup settings integrity check failed.", Toast.LENGTH_LONG).show());
        }
        if(purchaseDocsDir.exists()){
            File[] old=purchaseDocsDir.listFiles(); if(old!=null)for(File f:old)if(f.isFile())f.delete();
        } else purchaseDocsDir.mkdirs();
        File[] atts=restoredAttachments.listFiles();
        if(atts!=null)for(File f:atts)if(f.isFile()){
            try(InputStream in=new FileInputStream(f);OutputStream out=new FileOutputStream(new File(purchaseDocsDir,f.getName()))){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}
        }
        if (restoredOwner.exists()) {
            try {
                String ownerJson = new String(readAll(restoredOwner), StandardCharsets.UTF_8);
                new JSONObject(ownerJson);
                pendingOwnerDashboardBackup = ownerJson;
            } catch (Exception ignored) { pendingOwnerDashboardBackup = "{}"; }
        } else pendingOwnerDashboardBackup = "{}";
        getSharedPreferences("app_prefs",MODE_PRIVATE).edit().putBoolean("restored",true).apply();
        runOnUiThread(() -> { Toast.makeText(this, "Backup restored successfully. Reloading app...", Toast.LENGTH_LONG).show(); webView.postDelayed(() -> { webView.reload(); webView.postDelayed(() -> applyPendingOwnerDashboardToWebView(), 900); }, 700); });
    }

    private void applyPendingOwnerDashboardToWebView() {
        if (pendingOwnerDashboardBackup == null || pendingOwnerDashboardBackup.trim().isEmpty() || "{}".equals(pendingOwnerDashboardBackup.trim())) return;
        try {
            final String jsonLiteral = JSONObject.quote(pendingOwnerDashboardBackup);
            webView.evaluateJavascript("window.restoreOwnerDashboard && window.restoreOwnerDashboard(" + jsonLiteral + ");", null);
            pendingOwnerDashboardBackup = "{}";
        } catch (Exception ignored) {}
    }

    private String formatQuickListOcr(com.google.mlkit.vision.text.Text result){
        if(result==null) return "";
        class OcrLine { String text; android.graphics.Rect box; OcrLine(String t, android.graphics.Rect b){text=t;box=b;} int cy(){return box==null?0:(box.top+box.bottom)/2;} int cx(){return box==null?0:box.centerX();} int height(){return box==null?24:Math.max(1,box.height());} }
        java.util.List<OcrLine> lines=new java.util.ArrayList<>();
        for(com.google.mlkit.vision.text.Text.TextBlock b:result.getTextBlocks()){
            for(com.google.mlkit.vision.text.Text.Line l:b.getLines()){
                String t=l.getText()==null?"":l.getText().trim(); if(!t.isEmpty()) lines.add(new OcrLine(t,l.getBoundingBox()));
            }
        }
        if(lines.isEmpty()) return result.getText()==null?"":result.getText();
        java.util.Collections.sort(lines,(a,b)->Integer.compare(a.cy(),b.cy()));
        // Group only lines that share a visual baseline. The old 14-42 px tolerance
        // merged adjacent handwritten rows into one Quick List entry on phone photos.
        java.util.List<java.util.List<OcrLine>> rows=new java.util.ArrayList<>();
        for(OcrLine line:lines){
            java.util.List<OcrLine> best=null; double bestScore=Double.MAX_VALUE;
            for(java.util.List<OcrLine> row:rows){
                int top=Integer.MAX_VALUE,bottom=Integer.MIN_VALUE,avg=0,minHeight=Integer.MAX_VALUE;
                for(OcrLine cell:row){top=Math.min(top,cell.box==null?cell.cy():cell.box.top);bottom=Math.max(bottom,cell.box==null?cell.cy():cell.box.bottom);avg+=cell.cy();minHeight=Math.min(minHeight,cell.height());}
                avg/=row.size();
                int distance=Math.abs(line.cy()-avg);
                int overlap=line.box==null?0:Math.max(0,Math.min(bottom,line.box.bottom)-Math.max(top,line.box.top));
                int smaller=Math.max(1,Math.min(minHeight,line.height()));
                // Do not merge rows just because tall handwriting boxes overlap vertically.
                // Require close baselines; overlap is supporting evidence, not sufficient by itself.
                double overlapRatio=overlap/(double)smaller;
                int tightBaseline=Math.max(3,Math.min(9,(int)Math.round(smaller*0.28)));
                boolean sameBaseline=distance<=tightBaseline || (distance<=Math.max(4,(int)Math.round(smaller*0.42)) && overlapRatio>=0.62);
                double score=distance/(double)Math.max(1,smaller);
                if(sameBaseline && score<bestScore){best=row;bestScore=score;}
            }
            if(best==null){best=new java.util.ArrayList<>();rows.add(best);} best.add(line);
        }
        StringBuilder out=new StringBuilder();
        for(java.util.List<OcrLine> row:rows){
            java.util.Collections.sort(row,(a,b)->Integer.compare(a.cx(),b.cx()));
            StringBuilder line=new StringBuilder();
            for(OcrLine cell:row){if(line.length()>0)line.append(' ');line.append(cell.text);}
            String value=line.toString().trim(); if(value.isEmpty())continue;
            if(out.length()>0)out.append('\n'); out.append(value);
        }
        return out.toString();
    }

    private void sendQuickListOcr(String text){
        String normalized=text==null?"":text.trim();
        webView.post(() -> webView.evaluateJavascript("window.receiveQuickListOCR && window.receiveQuickListOCR("+JSONObject.quote(normalized)+");",null));
    }

    // All Quick List image sources pass through the same orientation, sizing and contrast pipeline.
    // No product-name substitutions or sample-specific OCR corrections are applied here.
    private Bitmap prepareQuickListBitmap(Bitmap source){
        if(source==null)return null;
        Bitmap oriented=source;
        int maxSide=Math.max(source.getWidth(),source.getHeight());
        if(maxSide>2600 || maxSide<1200){
            float scale=maxSide>2600?2600f/maxSide:Math.min(2.0f,1200f/Math.max(1,maxSide));
            Bitmap scaled=Bitmap.createScaledBitmap(source,Math.max(1,Math.round(source.getWidth()*scale)),Math.max(1,Math.round(source.getHeight()*scale)),true);
            if(scaled!=source && !source.isRecycled())source.recycle(); oriented=scaled;
        }
        Bitmap enhanced=Bitmap.createBitmap(oriented.getWidth(),oriented.getHeight(),Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(enhanced); Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        ColorMatrix cm=new ColorMatrix(); cm.setSaturation(0f);
        float contrast=1.18f, offset=-(0.5f*contrast-0.5f)*255f;
        ColorMatrix adjust=new ColorMatrix(new float[]{contrast,0,0,0,offset,0,contrast,0,0,offset,0,0,contrast,0,offset,0,0,0,1,0});
        cm.postConcat(adjust); paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(oriented,0,0,paint); if(oriented!=enhanced&&!oriented.isRecycled())oriented.recycle();
        return enhanced;
    }

    private Bitmap decodeQuickListUri(Uri uri) throws Exception {
        Bitmap decoded;
        try(InputStream in=getContentResolver().openInputStream(uri)){ decoded=BitmapFactory.decodeStream(in); }
        if(decoded==null)throw new Exception("Unsupported or unreadable image");
        int orientation=ExifInterface.ORIENTATION_UNDEFINED;
        try(InputStream exifStream=getContentResolver().openInputStream(uri)){ if(exifStream!=null)orientation=new ExifInterface(exifStream).getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL); }catch(Exception ignored){}
        Matrix matrix=new Matrix();
        switch(orientation){case ExifInterface.ORIENTATION_ROTATE_90:matrix.postRotate(90);break;case ExifInterface.ORIENTATION_ROTATE_180:matrix.postRotate(180);break;case ExifInterface.ORIENTATION_ROTATE_270:matrix.postRotate(270);break;case ExifInterface.ORIENTATION_FLIP_HORIZONTAL:matrix.preScale(-1,1);break;case ExifInterface.ORIENTATION_FLIP_VERTICAL:matrix.preScale(1,-1);break;}
        Bitmap oriented=decoded;
        if(!matrix.isIdentity()){oriented=Bitmap.createBitmap(decoded,0,0,decoded.getWidth(),decoded.getHeight(),matrix,true);if(oriented!=decoded)decoded.recycle();}
        return oriented;
    }

    // Keep a color-preserving candidate as well as the grayscale/contrast-enhanced candidate.
    // Always forcing grayscale/contrast can erase faint pencil strokes or merge nearby strokes.
    private Bitmap prepareQuickListColorBitmap(Bitmap source){
        if(source==null)return null;
        int maxSide=Math.max(source.getWidth(),source.getHeight());
        float scale=1f;
        if(maxSide>2600)scale=2600f/maxSide;
        else if(maxSide<1200)scale=Math.min(2.0f,1200f/Math.max(1,maxSide));
        if(Math.abs(scale-1f)>0.001f){
            Bitmap scaled=Bitmap.createScaledBitmap(source,Math.max(1,Math.round(source.getWidth()*scale)),Math.max(1,Math.round(source.getHeight()*scale)),true);
            if(scaled!=source&&!source.isRecycled())source.recycle();
            return scaled;
        }
        return source;
    }

    private int quickListOcrQuality(String text){
        if(text==null||text.trim().isEmpty())return 0;
        int score=0,lines=0;
        for(String line:text.split("\\r?\\n")){
            String t=line.trim();if(t.isEmpty())continue;lines++;
            score+=Math.min(45,t.length());
            // Reward rows that appear to contain both a unit and a trailing numeric amount.
            if(t.matches("(?i).*\\b(kg|kgs|gm|gram|g|ml|litre|liter|piece|pcs|pair|pack|packet|bottle|box|set)\\b.*\\d+(?:\\.\\d+)?\\s*$"))score+=30;
            if(t.matches(".*\\d.*"))score+=5;
        }
        return score+Math.min(lines,20)*12;
    }

    private void processQuickListBitmap(Bitmap raw){
        if(raw==null){Toast.makeText(this,"Could not open the image.",Toast.LENGTH_LONG).show();return;}
        Bitmap color=prepareQuickListColorBitmap(Bitmap.createBitmap(raw));
        Bitmap enhanced=prepareQuickListBitmap(Bitmap.createBitmap(raw));
        if(!raw.isRecycled())raw.recycle();
        TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(InputImage.fromBitmap(color,0)).addOnSuccessListener(colorResult->{
            String colorText=formatQuickListOcr(colorResult);
            recognizer.process(InputImage.fromBitmap(enhanced,0)).addOnSuccessListener(enhancedResult->{
                String enhancedText=formatQuickListOcr(enhancedResult);
                String selected=quickListOcrQuality(enhancedText)>quickListOcrQuality(colorText)?enhancedText:colorText;
                sendQuickListOcr(selected);
                recognizer.close();if(!color.isRecycled())color.recycle();if(!enhanced.isRecycled())enhanced.recycle();
            }).addOnFailureListener(err->{sendQuickListOcr(colorText);recognizer.close();if(!color.isRecycled())color.recycle();if(!enhanced.isRecycled())enhanced.recycle();});
        }).addOnFailureListener(err->{
            recognizer.process(InputImage.fromBitmap(enhanced,0)).addOnSuccessListener(result->{sendQuickListOcr(formatQuickListOcr(result));recognizer.close();if(!color.isRecycled())color.recycle();if(!enhanced.isRecycled())enhanced.recycle();})
                .addOnFailureListener(err2->{recognizer.close();if(!color.isRecycled())color.recycle();if(!enhanced.isRecycled())enhanced.recycle();runOnUiThread(()->Toast.makeText(this,"Could not read image text. Try a clearer photo.",Toast.LENGTH_LONG).show());});
        });
    }
    private void recognizeQuickListBitmap(Bitmap bmp){ processQuickListBitmap(bmp); }

    private void recognizeQuickListUri(Uri uri){
        try {
            String type=getContentResolver().getType(uri);
            if((type!=null&&type.toLowerCase().contains("pdf"))||String.valueOf(uri).toLowerCase().endsWith(".pdf")){
                recognizeQuickListPdf(uri); return;
            }
            if((type!=null&&type.toLowerCase().startsWith("text/"))||String.valueOf(uri).toLowerCase().endsWith(".txt")){
                StringBuilder content=new StringBuilder();
                try(InputStream in=getContentResolver().openInputStream(uri); java.io.BufferedReader reader=new java.io.BufferedReader(new java.io.InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=reader.readLine())!=null){if(content.length()>0)content.append('\n');content.append(line);}}
                sendQuickListOcr(content.toString()); return;
            }
            Bitmap bitmap=decodeQuickListUri(uri);
            // The camera image is now decoded into memory; remove only our temporary capture.
            String cameraName=uri.getLastPathSegment();
            if(cameraName!=null && cameraName.startsWith("quicklist_capture_")){
                try{new File(new File(getCacheDir(),"share"),cameraName).delete();}catch(Exception ignored){}
            }
            processQuickListBitmap(bitmap);
        } catch(Exception e){ Toast.makeText(this,"Could not open file: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private void recognizeQuickListPdf(Uri uri){
        new Thread(()->{
            ParcelFileDescriptor pfd=null; PdfRenderer renderer=null; TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            try{
                pfd=getContentResolver().openFileDescriptor(uri,"r"); if(pfd==null)throw new Exception("Could not open PDF");
                renderer=new PdfRenderer(pfd); StringBuilder all=new StringBuilder(); int pages=Math.min(renderer.getPageCount(),5);
                for(int i=0;i<pages;i++){
                    PdfRenderer.Page page=renderer.openPage(i); Bitmap bmp=null;
                    try{
                        float scale=Math.min(3f,1800f/Math.max(page.getWidth(),page.getHeight()));
                        bmp=Bitmap.createBitmap(Math.max(1,(int)(page.getWidth()*scale)),Math.max(1,(int)(page.getHeight()*scale)),Bitmap.Config.ARGB_8888);
                        Canvas canvas=new Canvas(bmp);canvas.drawColor(android.graphics.Color.WHITE);page.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT);
                        com.google.mlkit.vision.text.Text result=Tasks.await(recognizer.process(InputImage.fromBitmap(bmp,0)));
                        String text=formatQuickListOcr(result); if(!text.trim().isEmpty()){if(all.length()>0)all.append('\n');all.append(text);}
                    }finally{if(bmp!=null&&!bmp.isRecycled())bmp.recycle();page.close();}
                }
                sendQuickListOcr(all.toString());
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Could not read PDF. Try a clear image or a shorter PDF.",Toast.LENGTH_LONG).show());}
            finally{recognizer.close();try{if(renderer!=null)renderer.close();}catch(Exception ignored){}try{if(pfd!=null)pfd.close();}catch(Exception ignored){}}
        }).start();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == REQ_WEB_FILE_CHOOSER) {
            if (webFileCallback != null) {
                Uri[] results = (resultCode == RESULT_OK && data != null) ? new Uri[]{data.getData()} : null;
                webFileCallback.onReceiveValue(results);
                webFileCallback = null;
            }
            return;
        }
        if(requestCode==REQ_SCAN_QR){
            if(resultCode==RESULT_OK && data!=null){
                IntentResult scanResult = IntentIntegrator.parseActivityResult(resultCode, data);
                if(scanResult != null && scanResult.getContents() != null){
                    String scanned = scanResult.getContents();
                    webView.post(() -> webView.evaluateJavascript("window.onActivationQrScanned && window.onActivationQrScanned(" +
                            JSONObject.quote(scanned) + ");", null));
                }
            }
            return;
        }
        if(requestCode==REQ_QUICKLIST_IMAGE || requestCode==REQ_QUICKLIST_PDF){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null){
                Uri picked=data.getData();
                try{getContentResolver().takePersistableUriPermission(picked,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
                recognizeQuickListUri(picked);
            }
            return;
        }
        if(requestCode==REQ_PURCHASE_CAMERA){
            if(resultCode==RESULT_OK && purchaseCameraUri!=null){
                importPurchaseUri(purchaseCameraUri);
            } else if(purchaseCameraUri!=null){
                try{getContentResolver().delete(purchaseCameraUri,null,null);}catch(Exception ignored){}
            }
            purchaseCameraUri=null;
            return;
        }
        if(requestCode==REQ_QUICKLIST_CAMERA){
            if(resultCode==RESULT_OK){
                if(quickListCameraUri!=null) recognizeQuickListUri(quickListCameraUri);
                else if(data!=null && data.getExtras()!=null && data.getExtras().get("data") instanceof Bitmap) recognizeQuickListBitmap((Bitmap)data.getExtras().get("data"));
                else Toast.makeText(this,"Camera did not return an image. Please try Upload Image.",Toast.LENGTH_LONG).show();
            } else if(quickListCameraUri!=null){try{getContentResolver().delete(quickListCameraUri,null,null);}catch(Exception ignored){}}
            quickListCameraUri=null;
            return;
        }
        if (requestCode == REQ_SYNC_DOWNLOAD && (resultCode != RESULT_OK || data == null || data.getData() == null)) {
            pendingSyncDownloadBytes = null;
            Toast.makeText(this, "Sync file download cancelled.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (requestCode == REQ_BACKUP_CREATE && (resultCode != RESULT_OK || data == null || data.getData() == null)) {
            updateBackupStatus("Backup save cancelled. No file was saved.", true);
            pendingBackupZip = null;
            return;
        }
        if(resultCode!=RESULT_OK || data==null) return;
        if(requestCode==REQ_SYNC_DOWNLOAD && data.getData()!=null){
            try {
                if (pendingSyncDownloadBytes == null || pendingSyncDownloadBytes.length == 0) throw new Exception("Sync data is empty");
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "w")) {
                    if (out == null) throw new Exception("Could not open the selected download location");
                    out.write(pendingSyncDownloadBytes);
                    out.flush();
                }
                Toast.makeText(this, "Sync file downloaded successfully.", Toast.LENGTH_LONG).show();
            } catch(Exception e) {
                Toast.makeText(this, "Could not download sync file: " + e.getMessage(), Toast.LENGTH_LONG).show();
            } finally { pendingSyncDownloadBytes = null; }
        } else if(requestCode==REQ_PURCHASE_DOCUMENT && data.getData()!=null){
            Uri uri=data.getData();
            try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            importPurchaseUri(uri);
        } else if(requestCode==REQ_BACKUP_CREATE){
            if(data!=null && data.getData()!=null){
                try{
                    if(pendingBackupZip==null||!pendingBackupZip.exists())throw new Exception("Backup file is missing");
                    copyFileToUri(pendingBackupZip,data.getData());
                    updateBackupStatus("Backup saved successfully. Keep this ZIP safely in your cloud or another device.", true);
                    Toast.makeText(this,"Backup saved successfully. Keep this ZIP safely in your cloud.",Toast.LENGTH_LONG).show();
                }catch(Exception e){
                    updateBackupStatus("Could not save backup: "+e.getMessage(),true);
                    Toast.makeText(this,"Could not save backup: "+e.getMessage(),Toast.LENGTH_LONG).show();
                }
            } else {
                updateBackupStatus("Backup save cancelled. No file was saved.", true);
            }
            pendingBackupZip=null;
        } else if(requestCode==REQ_BACKUP_RESTORE && data.getData()!=null){
            new Thread(() -> {
                try { restoreBackup(data.getData()); }
                catch(Exception e){runOnUiThread(() -> Toast.makeText(this,"Restore failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}
            }).start();
        }
    }

    private Uri createPurchasePdfForSharing(String json) throws Exception {
        JSONObject purchase = new JSONObject(json);
        byte[] bytes = createPurchasePdfBytes(purchase);
        String invoice = purchase.optString("invoiceNo", "Purchase").replaceAll("[^A-Za-z0-9_-]", "_");
        return saveForSharing(bytes, "SiddhiBill_Purchase_" + invoice + ".pdf", "application/pdf");
    }

    private byte[] createPurchasePdfBytes(JSONObject purchase) throws Exception {
        final int width = 842, height = 595;
        PdfDocument doc = new PdfDocument();
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(android.graphics.Color.BLACK);
        paint.setTextSize(9);
        JSONObject settings = purchase.optJSONObject("settings");
        JSONObject vendor = purchase.optJSONObject("vendorSnapshot");
        if (vendor == null) vendor = new JSONObject();
        JSONArray items = purchase.optJSONArray("items");
        final boolean taxableBill = purchase.optBoolean("taxableBill", true);
        int pageNo = 1;
        PdfDocument.Page page = doc.startPage(new PdfDocument.PageInfo.Builder(width, height, pageNo).create());
        Canvas c = page.getCanvas();
        float y = 38;
        // Purchase PDFs identify the shop as BUYER and the supplier as SELLER.
        // Deliberately do not print the shopkeeper's logo on a supplier purchase bill.
        paint.setColor(android.graphics.Color.rgb(36,70,111));
        paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(20);
        drawText(c, paint, "PURCHASE BILL", 36, y);
        paint.setColor(android.graphics.Color.BLACK); paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(9); y += 22;
        drawText(c, paint, "Invoice No: " + purchase.optString("invoiceNo", "-"), 36, y);
        drawText(c, paint, "Date: " + purchase.optString("date", "-"), 330, y); y += 15;
        drawText(c, paint, "PO No: " + purchase.optString("poNumber", "-"), 36, y);
        drawText(c, paint, "Payment Terms: " + purchase.optString("paymentTerms", "-"), 330, y); y += 22;

        // Buyer = this shop, taken from Settings.
        paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(10);
        drawText(c, paint, "BUYER (YOUR SHOP)", 36, y);
        // Seller = supplier/vendor from the saved purchase snapshot.
        drawText(c, paint, "SELLER (VENDOR)", 430, y); y += 15;
        paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(8);
        String buyerName = settings == null ? "" : settings.optString("shopName", "");
        String buyerAddress = settings == null ? "" : settings.optString("address", "");
        String buyerGstin = settings == null ? "" : settings.optString("gstin", "");
        String buyerState = settings == null ? "" : settings.optString("businessState", "");
        String buyerMobile = settings == null ? "" : settings.optString("shopMobile", "");
        drawText(c, paint, trimText(buyerName, 55), 36, y); drawText(c, paint, trimText(vendor.optString("name", purchase.optString("vendorName", "Vendor")), 55), 430, y); y += 13;
        drawText(c, paint, trimText(buyerAddress, 58), 36, y); drawText(c, paint, trimText(vendor.optString("address", ""), 58), 430, y); y += 13;
        drawText(c, paint, "GSTIN: " + (buyerGstin.isEmpty() ? "-" : buyerGstin), 36, y); drawText(c, paint, "GSTIN: " + vendor.optString("gstin", "-"), 430, y); y += 13;
        drawText(c, paint, "State: " + (buyerState.isEmpty() ? "-" : buyerState), 36, y); drawText(c, paint, "PAN: " + vendor.optString("pan", "-"), 430, y); y += 13;
        drawText(c, paint, "Phone: " + (buyerMobile.isEmpty() ? "-" : buyerMobile), 36, y); drawText(c, paint, "State: " + vendor.optString("state", purchase.optString("supplierState", "-")), 430, y); y += 13;
        if (taxableBill) {
            String buyerFssai = settings == null ? "" : settings.optString("fssai", "").trim();
            JSONObject vendorSnapshot = purchase.optJSONObject("vendorSnapshot");
            String vendorFssai = vendor.optString("fssai", vendorSnapshot == null ? "" : vendorSnapshot.optString("fssai", "")).trim();
            if (!buyerFssai.isEmpty()) drawText(c, paint, "FSSAI: " + buyerFssai, 36, y);
            if (!vendorFssai.isEmpty()) drawText(c, paint, "FSSAI: " + vendorFssai, 430, y);
            if (!buyerFssai.isEmpty() || !vendorFssai.isEmpty()) y += 13;
        }
        y += 5;
        c.drawLine(36, y, width - 36, y, paint); y += 18;

        // Compact, aligned item table. Each data field has its own column.
        paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(7);
        paint.setColor(android.graphics.Color.rgb(235,240,246)); paint.setStyle(Paint.Style.FILL);
        c.drawRect(32, y, width - 32, y + 28, paint);
        paint.setColor(android.graphics.Color.BLACK); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(0.7f);
        c.drawRect(32, y, width - 32, y + 28, paint);
        float[] tableX = new float[]{32,48,320,360,410,480,550,600,660,720,780,810};
        for (float vx : tableX) c.drawLine(vx, y, vx, y + 28, paint);
        paint.setStyle(Paint.Style.FILL); paint.setColor(android.graphics.Color.BLACK);
        paint.setColor(android.graphics.Color.WHITE);
        drawText(c, paint, "#", 36, y + 17);
        drawText(c, paint, "Item", 50, y + 12);
        drawText(c, paint, "HSN/SAC", 50, y + 23);
        drawText(c, paint, "Qty", 330, y + 17);
        drawText(c, paint, "Unit", 365, y + 17);
        drawText(c, paint, "Buy Rate", 420, y + 17);
        drawText(c, paint, "Taxable", 490, y + 17);
        drawText(c, paint, "Tax%", 560, y + 17);
        drawText(c, paint, "CGST", 610, y + 17);
        drawText(c, paint, "SGST", 670, y + 17);
        drawText(c, paint, "IGST", 730, y + 17);
        drawText(c, paint, "Total", 785, y + 17);
        paint.setColor(android.graphics.Color.BLACK); paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(7);
        y += 40;
        double sumTaxable = 0, sumTax = 0, sumGross = 0, sumCgst = 0, sumSgst = 0, sumIgst = 0;
        java.util.Map<String, double[]> taxSummary = new java.util.TreeMap<>();
        if (items != null) {
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i); if (item == null) continue;
                if (y > 485) {
                    doc.finishPage(page); pageNo++;
                    page = doc.startPage(new PdfDocument.PageInfo.Builder(width, height, pageNo).create()); c = page.getCanvas();
                    paint.setColor(android.graphics.Color.BLACK); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(12);
                    drawText(c, paint, "PURCHASE BILL (continued)", 36, 38);
                    paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(7); y = 62;
                }
                String name = item.optString("name", item.optString("description", "Item")); if(settings!=null && settings.optBoolean("printItemCode",false)){String code=item.optString("itemCode","").trim();if(!code.isEmpty())name=code+" - "+name;}
                String hsn = item.optString("hsn", item.optString("hsnCode", ""));
                double qty = item.optDouble("qty", 0);
                double taxable = item.has("taxableAmount") ? item.optDouble("taxableAmount", 0) : item.optDouble("invoiceTaxableAmount", 0);
                double cgst = item.optDouble("cgstAmount", 0), sgst = item.optDouble("sgstAmount", 0), igst = item.optDouble("igstAmount", 0);
                double gst = item.has("totalTaxAmount") ? item.optDouble("totalTaxAmount", cgst + sgst + igst) : cgst + sgst + igst;
                double gross = item.has("lineTotalInclusive") ? item.optDouble("lineTotalInclusive", 0) : item.optDouble("lineTotal", taxable + gst);
                double taxRate = taxableBill ? item.optDouble("taxRate", item.optDouble("gstRate", item.optDouble("cgstRate", 0) + item.optDouble("sgstRate", 0) + item.optDouble("igstRate", 0))) : 0;
                if (!taxableBill) { cgst = 0; sgst = 0; igst = 0; gst = 0; }
                double buyRate = qty > 0 ? taxable / qty : item.optDouble("rate", 0);
                drawText(c, paint, String.valueOf(i + 1), 36, y + 4);
                drawText(c, paint, trimText(name, 48), 50, y + 4);
                drawText(c, paint, trimText(hsn, 18), 50, y + 14);
                drawTextRight(c, paint, String.format(Locale.US, "%.3g", qty), 352, y + 4);
                drawText(c, paint, trimText(item.optString("unit", ""), 10), 365, y + 4);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", buyRate), 470, y + 4);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", taxable), 540, y + 4);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", taxRate), 590, y + 4);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", cgst), 650, y + 4);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", sgst), 710, y + 4);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", igst), 770, y + 4);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", gross), width - 36, y + 4);
                paint.setColor(android.graphics.Color.BLACK); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(0.5f);
                c.drawRect(32, y - 8, width - 32, y + 11, paint);
                for (float vx : tableX) c.drawLine(vx, y - 8, vx, y + 11, paint);
                c.drawLine(32, y + 11, width - 32, y + 11, paint);
                paint.setStyle(Paint.Style.FILL); y += 23;
                sumTaxable += taxable; sumTax += gst; sumGross += gross;
                sumCgst += cgst; sumSgst += sgst; sumIgst += igst;
                String taxKey = String.format(Locale.US, "%.2f", taxRate);
                double[] sums = taxSummary.get(taxKey); if (sums == null) { sums = new double[5]; taxSummary.put(taxKey, sums); }
                sums[0] += taxable; sums[1] += cgst; sums[2] += sgst; sums[3] += igst; sums[4] += gst;
            }
        }
        if (y > 460) { doc.finishPage(page); pageNo++; page = doc.startPage(new PdfDocument.PageInfo.Builder(width, height, pageNo).create()); c = page.getCanvas(); y = 50; }
        paint.setTextSize(9); paint.setTypeface(Typeface.DEFAULT);
        double declaredTaxable = purchase.has("subtotal") ? purchase.optDouble("subtotal", sumTaxable) : sumTaxable;
        double declaredTax = purchase.optDouble("taxAmount", sumTax);
        double charges = purchase.optDouble("otherCharges", 0), discount = purchase.optDouble("invoiceDiscount", 0), tcs = purchase.optDouble("tcsAmount", 0), roundOff = purchase.optDouble("roundOff", 0);
        double total = purchase.optDouble("total", declaredTaxable + declaredTax + charges - discount + tcs + roundOff);
        double paid = purchase.optDouble("paid", 0), pending = Math.max(0, total - paid);
        paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(8);
        if (!taxableBill) {
            drawText(c, paint, "NON-TAXABLE PURCHASE - GST NOT APPLIED", 36, y + 8); y += 24;
        } else {
            drawText(c, paint, "GST BREAKDOWN BY RATE", 36, y + 8); y += 17;
            paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(7);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(0.6f); c.drawRect(32, y, 806, y + 17, paint);
            float[] gstX = new float[]{32,120,270,390,510,630,806}; for (float vx : gstX) c.drawLine(vx, y, vx, y + 17, paint);
            paint.setStyle(Paint.Style.FILL);
            drawText(c, paint, "Rate", 36, y + 11); drawText(c, paint, "Taxable", 145, y + 11);
            drawText(c, paint, "CGST", 290, y + 11); drawText(c, paint, "SGST", 400, y + 11);
            drawText(c, paint, "IGST", 510, y + 11); drawText(c, paint, "Total GST", 640, y + 11); y += 17;
            for (java.util.Map.Entry<String, double[]> entry : taxSummary.entrySet()) {
                double[] values = entry.getValue();
                drawText(c, paint, entry.getKey() + "%", 36, y + 8);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", values[0]), 260, y + 8);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", values[1]), 370, y + 8);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", values[2]), 480, y + 8);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", values[3]), 590, y + 8);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", values[4]), 790, y + 8);
                paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(0.5f); c.drawRect(32, y - 3, 806, y + 11, paint); for (float vx : gstX) c.drawLine(vx, y - 3, vx, y + 11, paint); paint.setStyle(Paint.Style.FILL); y += 14;
            }
            paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setStyle(Paint.Style.STROKE); c.drawRect(32, y, 806, y + 17, paint); for (float vx : gstX) c.drawLine(vx, y, vx, y + 17, paint); paint.setStyle(Paint.Style.FILL);
            drawText(c, paint, "TOTAL", 36, y + 11); drawTextRight(c, paint, String.format(Locale.US, "%.2f", sumTaxable), 260, y + 11);
            drawTextRight(c, paint, String.format(Locale.US, "%.2f", sumCgst), 370, y + 11); drawTextRight(c, paint, String.format(Locale.US, "%.2f", sumSgst), 490, y + 11);
            drawTextRight(c, paint, String.format(Locale.US, "%.2f", sumIgst), 610, y + 11); drawTextRight(c, paint, String.format(Locale.US, "%.2f", sumTax), 790, y + 11); y += 24;
        }
        if (y > 390) { doc.finishPage(page); pageNo++; page = doc.startPage(new PdfDocument.PageInfo.Builder(width, height, pageNo).create()); c = page.getCanvas(); y = 50; paint.setColor(android.graphics.Color.BLACK); }
        String[][] totalsRows = new String[][]{{"Items total (tax-inclusive)", String.format(Locale.US, "%.2f", sumGross)}, {"Taxable amount", String.format(Locale.US, "%.2f", declaredTaxable)}, {taxableBill ? "GST included" : "GST (not applicable)", String.format(Locale.US, "%.2f", taxableBill ? declaredTax : 0)}, {"Other charges", String.format(Locale.US, "%.2f", charges)}, {"Discount", String.format(Locale.US, "-%.2f", discount)}, {"TCS", String.format(Locale.US, "%.2f", tcs)}, {"Round off", String.format(Locale.US, "%.2f", roundOff)}};
        paint.setTextSize(8); paint.setTypeface(Typeface.DEFAULT); paint.setStyle(Paint.Style.STROKE);
        for (String[] row : totalsRows) { c.drawRect(500, y, 806, y + 16, paint); c.drawLine(690, y, 690, y + 16, paint); paint.setStyle(Paint.Style.FILL); drawText(c, paint, row[0], 505, y + 11); drawTextRight(c, paint, row[1], 800, y + 11); y += 16; paint.setStyle(Paint.Style.STROKE); }
        paint.setStyle(Paint.Style.FILL); y += 4;
        paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(13); paint.setStyle(Paint.Style.STROKE); c.drawRect(500, y - 5, 806, y + 15, paint); c.drawLine(690, y - 5, 690, y + 15, paint); paint.setStyle(Paint.Style.FILL);
        drawText(c, paint, "INVOICE TOTAL", 505, y + 8); drawTextRight(c, paint, String.format(Locale.US, "%.2f", total), 800, y + 8); y += 20;
        paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(10);
        drawTextRight(c, paint, "Paid: Rs. " + String.format(Locale.US, "%.2f", paid), width - 36, y); y += 17;
        drawTextRight(c, paint, "Balance pending: Rs. " + String.format(Locale.US, "%.2f", pending), width - 36, y);
        doc.finishPage(page);
        ByteArrayOutputStream out = new ByteArrayOutputStream(); doc.writeTo(out); doc.close(); return out.toByteArray();
    }

    private Uri createBillPdfForSharing(String json) throws Exception {
        JSONObject b = new JSONObject(json);
        JSONObject cfg = b.optJSONObject("settings");
        String paper = cfg == null ? "A4" : cfg.optString("paperSize", "A4");
        if ("58mm".equalsIgnoreCase(paper) || "80mm".equalsIgnoreCase(paper)) {
            byte[] bytes = createThermalPdfBytes(json);
            String filename = "Bill_" + b.optString("billNo", "Bill").replaceAll("[^A-Za-z0-9_-]", "_") + "_" + paper + ".pdf";
            return saveForSharing(bytes, filename, "application/pdf");
        }
        Uri pdf = createPdf(json);
        return pdf;
    }

    private class AndroidBridge {
        @JavascriptInterface public void shareBillImage(String base64Png,String billName,String phone){
            try{byte[] data=Base64.decode(base64Png,Base64.DEFAULT);String safe=(billName==null||billName.trim().isEmpty())?"DukaanBill":billName;shareFile(data,safe+".png","image/png","WhatsApp Bill");}
            catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not share bill image: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void printBill(String json){ try{ MainActivity.this.printBill(json); }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not print bill: "+e.getMessage(),Toast.LENGTH_LONG).show());} }
        @JavascriptInterface public void directThermalPrint80(String json){ try{ MainActivity.this.directThermalPrint80(json); }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Direct print failed: "+e.getMessage(),Toast.LENGTH_LONG).show());} }
        @JavascriptInterface public void openPurchasePdf(String json){
            try{
                Uri uri=createPurchasePdfForSharing(json);
                Intent view=new Intent(Intent.ACTION_VIEW); view.setDataAndType(uri,"application/pdf");
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                view.setClipData(ClipData.newRawUri("SiddhiBill Purchase PDF",uri));
                try { startActivity(view); }
                catch(Exception noViewer){ Intent chooser=Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("application/pdf").putExtra(Intent.EXTRA_STREAM,uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),"Open purchase PDF"); chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(chooser); }
            }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not create purchase PDF: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void openBillPdf(String json){
            try{
                Uri uri=createBillPdfForSharing(json);
                Intent view=new Intent(Intent.ACTION_VIEW);
                view.setDataAndType(uri,"application/pdf");
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                view.setClipData(ClipData.newRawUri("DukaanBill PDF",uri));
                try{
                    startActivity(view);
                }catch(Exception noViewer){
                    // The PDF has already been saved to Downloads/DukaanBill on modern Android.
                    // If there is no PDF viewer, let Android offer any compatible app.
                    Intent chooser=new Intent(Intent.ACTION_VIEW);
                    chooser.setDataAndType(uri,"application/pdf");
                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                    chooser.setClipData(ClipData.newRawUri("DukaanBill PDF",uri));
                    startActivity(Intent.createChooser(chooser,"Open PDF with"));
                }
            }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not create/open PDF: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void shareDukaanBillToWhatsApp(String json){
            try{
                byte[] data=json.getBytes(StandardCharsets.UTF_8);
                Uri uri=saveToCacheProvider(data,"DukaanBill_"+new JSONObject(json).optString("billNo","Bill").replaceAll("[^A-Za-z0-9_-]","_")+".dukaanbill");
                Intent send=new Intent(Intent.ACTION_SEND);
                send.setType("application/vnd.dukaanbill");
                send.putExtra(Intent.EXTRA_STREAM,uri);
                send.putExtra(Intent.EXTRA_TEXT,"Dukaan Bill - Thermal Print");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                send.setClipData(ClipData.newRawUri("Dukaan Bill",uri));
                Intent chooser=Intent.createChooser(send,"Send Dukaan Bill");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(chooser);
            }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not share Dukaan Bill: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public boolean isAppActivated(){ return isActivated(); }
        @JavascriptInterface public String startSevenDayTrial(){ return MainActivity.this.startTrial(); }
        @JavascriptInterface public String approveTrialActivation(String request){try{return MainActivity.this.approveActivation(request,"TRIAL");}catch(Exception e){return "ERROR:"+e.getMessage();}}
        @JavascriptInterface public long trialExpiry(){ return getSharedPreferences("activation",MODE_PRIVATE).getLong("trial_expiry",0L); }
        @JavascriptInterface public String ownerContactNumber(){ return "8087794271"; }
        @JavascriptInterface public void shareActivationFile(String token){ MainActivity.this.shareActivationFile(token); }
        @JavascriptInterface public String createActivationRequest(){ try{return MainActivity.this.createActivationRequest("SHOP");}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public String createShopSetupInvite(String shopName,String shopMobile,String managerName,String address,String gstin,String state){ try{return MainActivity.this.createShopSetupInvite(shopName,shopMobile,managerName,address,gstin,state);}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public boolean unlockOwner(String pin){ return MainActivity.this.unlockOwnerSession(pin); }
        @JavascriptInterface public boolean ownerSessionUnlocked(){ return sessionOwnerPrivateKey != null; }
        @JavascriptInterface public boolean isOwnerDevice(){ return ownerConfigured(); }
        @JavascriptInterface public void updateOwnerShopSettings(String shopName,String shopMobile,String managerName,String address,String gstin,String state){
            try{
                JSONObject root=new JSONObject(MainActivity.this.loadAppState());
                JSONObject settings=root.optJSONObject("dukaanBillSettings");
                if(settings==null) settings=new JSONObject();
                if(shopName!=null && !shopName.trim().isEmpty()) settings.put("shopName",shopName.trim());
                if(shopMobile!=null) { settings.put("shopMobile",shopMobile.trim()); JSONArray a=new JSONArray(); if(!shopMobile.trim().isEmpty()) a.put(shopMobile.trim()); settings.put("shopMobiles",a); }
                if(address!=null) settings.put("address",address.trim());
                if(gstin!=null) settings.put("gstin",gstin.trim());
                if(state!=null) settings.put("businessState",state.trim());
                root.put("dukaanBillSettings",settings);
                MainActivity.this.saveAppState(root.toString());
            }catch(Exception ignored){}
        }
        @JavascriptInterface public String acceptShopSetupInvite(String invite){ try{ JSONObject p=MainActivity.this.verifyShopSetupInvite(invite); getSharedPreferences("activation",MODE_PRIVATE).edit().putString("pending_shop_setup",invite).putString("shop_setup_id",p.optString("setupId")).putString("shop_name",p.optString("shopName")).putString("shop_mobile",p.optString("shopMobile")).putString("shop_manager",p.optString("managerName")).putString("shop_address",p.optString("address")).putString("shop_gstin",p.optString("gstin")).putString("shop_state",p.optString("state")).apply(); return p.toString(); }catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public String pendingShopSetup(){ return getSharedPreferences("activation",MODE_PRIVATE).getString("pending_shop_setup",null); }
        @JavascriptInterface public String getActivatedShopSetup(){ try{ android.content.SharedPreferences p=getSharedPreferences("activation",MODE_PRIVATE); JSONObject o=new JSONObject(); o.put("shopName",p.getString("shop_name","")); o.put("shopMobile",p.getString("shop_mobile","")); o.put("managerName",p.getString("shop_manager","")); o.put("address",p.getString("shop_address","")); o.put("gstin",p.getString("shop_gstin","")); o.put("state",p.getString("shop_state","")); return o.toString(); }catch(Exception e){return "{}";} }
        @JavascriptInterface public void clearPendingShopSetup(){ getSharedPreferences("activation",MODE_PRIVATE).edit().remove("pending_shop_setup").remove("shop_setup_id").apply(); }

        @JavascriptInterface public String createOwnerActivationRequest(){ try{return MainActivity.this.createActivationRequest("OWNER");}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public String finalizeOwnerActivation(String pin){ try{MainActivity.this.finalizeOwnerActivation(pin);return "OK";}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public boolean pendingOwnerActivation(){ return getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).contains("pending_owner_key"); }
        @JavascriptInterface public String generateQr(String text){ try{return qrDataUrl(text);}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public void shareActivationRequest(String text){
            try { Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/918087794271?text="+Uri.encode("SiddhiBill activation request\n\n"+(text==null?"":text)))); startActivity(i); }
            catch(Exception e){shareText("SiddhiBill Activation Request",text);}
        }
        @JavascriptInterface public void shareActivationToken(String text){shareText("SiddhiBill Activation Approval",text);}
        @JavascriptInterface public void openOwnerWhatsApp(){ try { Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/918087794271?text="+Uri.encode("Hello, I need SiddhiBill support/activation."))); startActivity(i); } catch(Exception e){Toast.makeText(MainActivity.this,"Could not open WhatsApp: "+e.getMessage(),Toast.LENGTH_LONG).show();} }
        @JavascriptInterface public void scanActivationQr(){scanQr();}
        @JavascriptInterface public boolean ownerConfigured(){return getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).contains(OWNER_PRIVATE_PREF);}
        @JavascriptInterface public String configureOwner(String privateKeyB64,String pin){try{if(pin==null||pin.length()<6)return "ERROR:Owner PIN must be at least 6 digits/characters";saveOwnerPrivate(privateKeyB64,pin);sessionOwnerPrivateKey=loadOwnerPrivate(pin);setActivated(true);return "OK";}catch(Exception e){return "ERROR:"+e.getMessage();}}
        @JavascriptInterface public String approveActivation(String request){try{return MainActivity.this.approveActivation(request);}catch(Exception e){return "ERROR:"+e.getMessage();}}
        @JavascriptInterface public boolean closeOwnerToBilling(){ if(!isActivated() || !ownerConfigured() || sessionOwnerPrivateKey==null) return false; runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.loadUrl("file:///android_asset/www/index.html"); }); return true; }
        @JavascriptInterface public boolean openOwnerSetupBilling(){ if(!ownerConfigured() || sessionOwnerPrivateKey==null) return false; runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.loadUrl("file:///android_asset/www/index.html"); }); return true; }
        @JavascriptInterface public String applyActivation(String token){try{MainActivity.this.applyActivation(token);return "OK";}catch(Exception e){return "ERROR:"+e.getMessage();}}
        @JavascriptInterface public void openActivatedApp(){ if(isActivated() || (ownerConfigured() && sessionOwnerPrivateKey!=null)){ runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.post(() -> webView.loadUrl("file:///android_asset/www/index.html")); }); } }
        @JavascriptInterface public void openBilling(){ runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.post(() -> webView.loadUrl(isActivated() ? "file:///android_asset/www/index.html" : "file:///android_asset/www/activation.html")); }); }
        @JavascriptInterface public void openOwnerDevice(){
            if(!isActivated() || !ownerConfigured() || sessionOwnerPrivateKey==null){ showActivationPage("Owner access is locked. Verify activation and unlock the Owner PIN first."); return; }
            runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.loadUrl("file:///android_asset/www/index.html"); });
        }
        @JavascriptInterface public void openOwnerMode(){
            // Do not expose the Owner dashboard route from ordinary shop devices.
            if(!isActivated() || !ownerConfigured()) { runOnUiThread(() -> Toast.makeText(MainActivity.this,"Owner Dashboard is available only on a configured Owner device.",Toast.LENGTH_LONG).show()); return; }
            runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.loadUrl("file:///android_asset/www/activation.html?owner=1"); });
        }
        @JavascriptInterface public void sendBillMessage(String phone,String message){
            try{
                String digits=phone==null?"":phone.replaceAll("\\D","");
                if(digits.startsWith("91")&&digits.length()==12) digits=digits.substring(2);
                if(digits.length()!=10) throw new Exception("Invalid 10 digit mobile number");
                Intent sms=new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"+digits));
                sms.putExtra("sms_body", message==null?"":message);
                sms.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(sms);
            }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not open mobile message: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void shareBillPdfToWhatsApp(String json,String phone){
            try{
                String digits=phone==null?"":phone.replaceAll("\\D","");
                if(digits.startsWith("91")&&digits.length()==12) digits=digits.substring(2);
                if(digits.length()!=10) throw new Exception("Invalid 10 digit mobile number");
                Uri uri=createBillPdfForSharing(json);
                Intent send=new Intent(Intent.ACTION_SEND); send.setType("application/pdf");
                send.putExtra(Intent.EXTRA_STREAM,uri); send.putExtra(Intent.EXTRA_TEXT,"DukaanBill - Bill");
                send.putExtra("jid","91"+digits+"@s.whatsapp.net"); send.setPackage("com.whatsapp");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                send.setClipData(ClipData.newRawUri("DukaanBill PDF",uri));
                try{startActivity(send);}catch(Exception noDirect){
                    Intent chat=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/91"+digits+"?text=DukaanBill%20-%20Bill"));
                    chat.setPackage("com.whatsapp"); startActivity(chat);
                    Toast.makeText(MainActivity.this,"WhatsApp chat opened. Attach the PDF if direct attachment is not supported by your WhatsApp version.",Toast.LENGTH_LONG).show();
                }
            }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not open WhatsApp: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public String loadAppState(){ return MainActivity.this.loadAppState(); }
        @JavascriptInterface public void saveAppState(String json){ MainActivity.this.saveAppState(json); }
        @JavascriptInterface public void setOwnerDashboardBackup(String json){
            try { new JSONObject(json == null || json.trim().isEmpty() ? "{}" : json); pendingOwnerDashboardBackup = json == null ? "{}" : json; }
            catch(Exception e){ pendingOwnerDashboardBackup = "{}"; }
        }
        @JavascriptInterface public String getPairedBluetoothPrinters(){ return MainActivity.this.pairedBluetoothPrintersJson(); }
        @JavascriptInterface public void backupData(){ runOnUiThread(MainActivity.this::startBackup); }
        @JavascriptInterface public void backupData(String ownerJson){
            try { new JSONObject(ownerJson == null || ownerJson.trim().isEmpty() ? "{}" : ownerJson); pendingOwnerDashboardBackup = ownerJson == null ? "{}" : ownerJson; }
            catch(Exception e){ pendingOwnerDashboardBackup = "{}"; }
            runOnUiThread(MainActivity.this::startBackup);
        }
        @JavascriptInterface public boolean verifyShopNamePassword(String password){ return MainActivity.this.verifyShopNamePasswordInternal(password); }
        @JavascriptInterface public void restoreData(){ runOnUiThread(MainActivity.this::startRestore); }
        @JavascriptInterface public void shareTextFile(String base64,String filename,String mime){
            try{byte[] bytes=Base64.decode(base64,Base64.DEFAULT);shareFile(bytes,filename==null?"SiddhiBill.csv":filename,mime==null?"text/csv":mime,"Export SiddhiBill CSV");}
            catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not export CSV: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void shareSyncFile(String base64){
            try {
                final byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                if (bytes.length == 0) throw new Exception("Sync data is empty");
                runOnUiThread(() -> {
                    android.widget.LinearLayout options = new android.widget.LinearLayout(MainActivity.this);
                    options.setOrientation(android.widget.LinearLayout.VERTICAL);
                    int pad = (int) (20 * getResources().getDisplayMetrics().density);
                    options.setPadding(pad, pad / 2, pad, pad / 2);
                    android.widget.TextView description = new android.widget.TextView(MainActivity.this);
                    description.setText("Choose how to share or save the sync file.");
                    description.setTextColor(0xFF172B4D);
                    description.setTextSize(16);
                    description.setPadding(0, 0, 0, pad / 2);
                    options.addView(description, new android.widget.LinearLayout.LayoutParams(-1, -2));
                    android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(MainActivity.this)
                        .setTitle("Create Sync File")
                        .setView(options)
                        .setNegativeButton("Cancel", null)
                        .create();
                    String[] labels = new String[]{"WhatsApp", "Share with another app (Drive / Nearby Share)", "Save sync file to this phone"};
                    for (int i = 0; i < labels.length; i++) {
                        final int action = i;
                        android.widget.Button button = new android.widget.Button(MainActivity.this);
                        button.setText(labels[i]);
                        button.setTextColor(0xFF172B4D);
                        button.setAllCaps(false);
                        android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(-1, -2);
                        lp.bottomMargin = Math.max(4, pad / 4);
                        options.addView(button, lp);
                        button.setOnClickListener(v -> {
                            dialog.dismiss();
                            if (action == 0) shareSyncFileToWhatsApp(bytes);
                            else if (action == 1) shareSyncFileToOtherApps(bytes);
                            else saveSyncFileWithPicker(bytes);
                        });
                    }
                    dialog.show();
                });
            } catch(Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Could not create sync file: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
        private void shareSyncFileToWhatsApp(byte[] bytes) {
            try {
                Uri uri = saveToCacheProvider(bytes, "SiddhiBill_Shop_Sync.siddhisync");
                Intent send = new Intent(Intent.ACTION_SEND);
                // Do not use the app-specific vendor MIME type here: WhatsApp rejects it on some versions.
                send.setType("application/octet-stream");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_SUBJECT, "SiddhiBill Shop Sync File");
                send.putExtra(Intent.EXTRA_TEXT, "SiddhiBill shop sync file. Import this file in SiddhiBill on the other phone.");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                send.setClipData(ClipData.newUri(getContentResolver(), "SiddhiBill Shop Sync File", uri));
                send.setPackage("com.whatsapp");
                try {
                    startActivity(send);
                } catch (Exception whatsappUnavailable) {
                    send.setPackage("com.whatsapp.w4b");
                    try { startActivity(send); }
                    catch (Exception businessUnavailable) {
                        send.setPackage(null);
                        startActivity(Intent.createChooser(send, "Share SiddhiBill Sync File"));
                        Toast.makeText(MainActivity.this, "WhatsApp was not available. Choose a file-sharing app.", Toast.LENGTH_LONG).show();
                    }
                }
            } catch(Exception e) {
                Toast.makeText(MainActivity.this, "Could not share sync file: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        private void shareSyncFileToOtherApps(byte[] bytes) {
            try {
                Uri uri = saveToCacheProvider(bytes, "SiddhiBill_Shop_Sync.siddhisync");
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("application/octet-stream");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_SUBJECT, "SiddhiBill Shop Sync File");
                send.putExtra(Intent.EXTRA_TEXT, "SiddhiBill shop sync file. On the other phone, download the file and import it in SiddhiBill.");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                send.setClipData(ClipData.newUri(getContentResolver(), "SiddhiBill Shop Sync File", uri));
                startActivity(Intent.createChooser(send, "Share SiddhiBill Sync File"));
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Could not share sync file: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }

        private void saveSyncFileWithPicker(byte[] bytes) {
            try {
                pendingSyncDownloadBytes = bytes;
                Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                create.addCategory(Intent.CATEGORY_OPENABLE);
                create.setType("application/octet-stream");
                create.putExtra(Intent.EXTRA_TITLE, "SiddhiBill_Shop_Sync.siddhisync");
                create.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                startActivityForResult(create, REQ_SYNC_DOWNLOAD);
            } catch(Exception e) {
                pendingSyncDownloadBytes = null;
                Toast.makeText(MainActivity.this, "Could not open download location: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        @JavascriptInterface public void chooseQuickListSource(){
            runOnUiThread(() -> new android.app.AlertDialog.Builder(MainActivity.this)
                .setTitle("Add list to Quick List")
                .setItems(new String[]{"Camera", "Choose Image, PDF or TXT"}, (dialog, which) -> {
                    if(which==0) takeQuickListPhoto(); else pickQuickListFile();
                }).setNegativeButton("Cancel", null).show());
        }
        @JavascriptInterface public void pickQuickListFile(){
            try{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","application/pdf","text/plain"});
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i,REQ_QUICKLIST_IMAGE);
            }catch(Exception e){Toast.makeText(MainActivity.this,"Could not open files: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
        @JavascriptInterface public void takeQuickListPhoto(){
            // Ask for camera permission explicitly, then launch the external camera on the UI thread.
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    pendingQuickListCameraLaunch = true;
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_QUICKLIST_CAMERA_PERMISSION);
                    return;
                }
                launchQuickListCamera();
            });
        }
        @JavascriptInterface public void pickQuickListImage(){ pickQuickListFile(); }
        @JavascriptInterface public void pickQuickListPdf(){ pickQuickListFile(); }
        @JavascriptInterface public void recognizeQuickListImage(String base64){
            try{byte[] bytes=Base64.decode(base64,Base64.DEFAULT);Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);if(bmp==null)throw new Exception("Invalid image");InputImage image=InputImage.fromBitmap(bmp,0);TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);recognizer.process(image).addOnSuccessListener(result->{String text=formatQuickListOcr(result);webView.post(()->webView.evaluateJavascript("window.receiveQuickListOCR && window.receiveQuickListOCR("+JSONObject.quote(text)+");",null));recognizer.close();bmp.recycle();}).addOnFailureListener(err->{recognizer.close();bmp.recycle();runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not read image text. Try a clearer photo.",Toast.LENGTH_LONG).show());});}
            catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not read image: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void pickPurchaseDocument(){
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","image/jpeg","image/png","image/webp"});startActivityForResult(i,REQ_PURCHASE_DOCUMENT);
        }
        @JavascriptInterface public void capturePurchaseBill(){
            runOnUiThread(()->{
                if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
                    pendingPurchaseCameraLaunch=true;
                    requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_PURCHASE_CAMERA_PERMISSION);
                    return;
                }
                launchPurchaseBillCamera();
            });
        }
        @JavascriptInterface public void openPurchaseAttachment(String id,String mime){openPurchaseAttachment(id,mime);}
    }

    private void launchPurchaseBillCamera(){
        pendingPurchaseCameraLaunch=false;
        try{
            File shareDir=new File(getCacheDir(),"share");
            if(!shareDir.exists()&&!shareDir.mkdirs())throw new Exception("Could not prepare camera storage");
            File capture=new File(shareDir,"purchase_capture_"+System.currentTimeMillis()+".jpg");
            if(!capture.createNewFile())throw new Exception("Could not create camera image");
            purchaseCameraUri=Uri.parse("content://com.siddhibill.app.share/"+capture.getName());
            Intent i=new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT,purchaseCameraUri);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            i.setClipData(android.content.ClipData.newRawUri("Vendor bill camera output",purchaseCameraUri));
            startActivityForResult(i,REQ_PURCHASE_CAMERA);
        }catch(android.content.ActivityNotFoundException e){purchaseCameraUri=null;Toast.makeText(this,"No Camera app is installed. Please choose Upload Photo / PDF instead.",Toast.LENGTH_LONG).show();}
        catch(Exception e){purchaseCameraUri=null;Toast.makeText(this,"Could not open vendor bill camera: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    private void launchQuickListCamera(){
        pendingQuickListCameraLaunch = false;
        try {
            // Ask the camera app to write the full-resolution image to app-private cache.
            // Without EXTRA_OUTPUT Android camera apps commonly return only a tiny thumbnail.
            File shareDir=new File(getCacheDir(),"share");
            if(!shareDir.exists() && !shareDir.mkdirs()) throw new Exception("Could not prepare camera storage");
            File capture=new File(shareDir,"quicklist_capture_"+System.currentTimeMillis()+".jpg");
            if(capture.exists() && !capture.delete()) throw new Exception("Could not prepare camera image");
            if(!capture.createNewFile()) throw new Exception("Could not create camera image");
            quickListCameraUri=Uri.parse("content://com.siddhibill.app.share/"+capture.getName());
            Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT,quickListCameraUri);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            i.setClipData(android.content.ClipData.newRawUri("Quick List camera output",quickListCameraUri));
            startActivityForResult(i, REQ_QUICKLIST_CAMERA);
        } catch (android.content.ActivityNotFoundException e) {
            quickListCameraUri=null;
            Toast.makeText(this, "No Camera app is installed. Please install or enable your phone's Camera app.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            quickListCameraUri=null;
            Toast.makeText(this, "Could not open Camera: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==REQ_QUICKLIST_CAMERA_PERMISSION){
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED && pendingQuickListCameraLaunch){
                launchQuickListCamera();
            } else {
                pendingQuickListCameraLaunch = false;
                Toast.makeText(this, "Camera permission is needed to capture a Quick List photo. You can allow it in Android Settings or choose an existing image.", Toast.LENGTH_LONG).show();
            }
            return;
        }
        if(requestCode==REQ_PURCHASE_CAMERA_PERMISSION){
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED && pendingPurchaseCameraLaunch){launchPurchaseBillCamera();}
            else {pendingPurchaseCameraLaunch=false;Toast.makeText(this,"Camera permission is needed to capture a vendor bill. You can upload a photo/PDF instead.",Toast.LENGTH_LONG).show();}
            return;
        }
        if(requestCode==REQ_BT_PRINT){
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED && pendingDirectPrintJson!=null && !pendingDirectPrintJson.isEmpty()){
                String payload=pendingDirectPrintJson; pendingDirectPrintJson=null;
                new Thread(() -> { try{ directThermalPrint80(payload); } catch(Exception e){ runOnUiThread(() -> Toast.makeText(this,"Direct print failed: "+e.getMessage(),Toast.LENGTH_LONG).show()); } }).start();
            } else { pendingDirectPrintJson=null; Toast.makeText(this,"Bluetooth permission is required for direct printing.",Toast.LENGTH_LONG).show(); }
        }
    }

    @Override public void onBackPressed(){
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("window.handleAndroidBack ? window.handleAndroidBack() : false", value -> {
            if (value == null || "false".equals(value.trim()) || "null".equals(value.trim())) super.onBackPressed();
        });
    }
}

