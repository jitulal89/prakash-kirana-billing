package com.dukaanbill.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONObject;
import org.json.JSONArray;

import java.util.Iterator;

public class LocalDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "dukaanbill.db";
    private static final int DB_VERSION = 1;
    private final java.util.Map<String, String> transactionJsonCache = new java.util.HashMap<>();

    public LocalDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS app_state (state_key TEXT PRIMARY KEY, state_value TEXT NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS meta (meta_key TEXT PRIMARY KEY, meta_value TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS transaction_records (collection TEXT NOT NULL, record_id TEXT NOT NULL, sort_date TEXT, source_type TEXT, source_id TEXT, shop_key TEXT, product_name TEXT, record_json TEXT NOT NULL, PRIMARY KEY(collection, record_id))");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_transaction_records_date ON transaction_records(collection, sort_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_transaction_records_shop_date ON transaction_records(collection, shop_key, sort_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_transaction_records_source ON transaction_records(collection, source_type, source_id)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_transaction_records_product ON transaction_records(collection, shop_key, product_name, sort_date)");
    }

    @Override public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        // Additive tables are ensured without bumping SQLite user_version. This keeps
        // backup databases readable by older SiddhiBill builds that use the legacy
        // app_state JSON keys and would otherwise reject a database downgrade.
        onCreate(db);
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    // Small backup metadata snapshot. Transaction collections are migrated to the
    // normalized table first and exported inside SQLite by MainActivity, avoiding
    // multiple 100+ MB Java strings during large backups.
    public synchronized String loadStateForBackup() throws Exception {
        SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction();
        try {
            for(String collection:new String[]{"pksBills","pksPurchases","pksInventoryMovements"}) migrateLegacyCollection(db,collection);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        // Read app_state values in bounded SQLite substr() chunks. Calling Cursor.getString()
        // on an entire large state_value can exceed Android's CursorWindow (the reported
        // "Row too big to fit" failure), even when transaction arrays are normalized.
        JSONObject out=new JSONObject();
        java.util.ArrayList<String> keys=new java.util.ArrayList<>();
        try(Cursor c=db.rawQuery("SELECT state_key FROM app_state WHERE state_key NOT IN ('pksBills','pksPurchases','pksInventoryMovements') ORDER BY state_key",null)) {
            while(c.moveToNext()) keys.add(c.getString(0));
        }
        final int chunkSize=65536;
        for(String key:keys){
            StringBuilder value=new StringBuilder(); int offset=0;
            while(true){
                String part="";
                try(Cursor c=db.rawQuery("SELECT substr(state_value, ?, ?) FROM app_state WHERE state_key=?",new String[]{String.valueOf(offset+1),String.valueOf(chunkSize),key})){
                    if(c.moveToFirst()) part=c.getString(0)==null?"":c.getString(0);
                }
                if(part.isEmpty()) break;
                value.append(part); int points=Character.codePointCount(part,0,part.length()); offset+=points;
                if(points<chunkSize) break;
            }
            out.put(key,value.toString());
        }
        return out.toString();
    }

    public synchronized String loadState() {
        JSONObject out = new JSONObject();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT state_key,state_value FROM app_state", null)) {
            while (c.moveToNext()) {
                out.put(c.getString(0), c.getString(1));
            }
        } catch (Exception ignored) {}
        try {
            for (String collection : new String[]{"pksBills", "pksPurchases", "pksInventoryMovements"}) {
                JSONArray records = readTransactionArray(db, collection);
                if (records.length() > 0 || !out.has(collection)) out.put(collection, records.toString());
            }
        } catch (Exception ignored) {}
        return out.toString();
    }

    public synchronized String loadStateValue(String key) {
        SQLiteDatabase db=getReadableDatabase();
        try(Cursor c=db.rawQuery("SELECT state_value FROM app_state WHERE state_key=?",new String[]{key})) { return c.moveToFirst()?c.getString(0):null; }
        catch(Exception e){return null;}
    }

    // Read large WebView state in bounded pieces instead of returning one multi-megabyte bridge value.
    public synchronized String getTransactionCountsJson() throws Exception {
        JSONObject out=new JSONObject();SQLiteDatabase db=getReadableDatabase();
        for(String collection:new String[]{"pksBills","pksPurchases","pksInventoryMovements"}){
            long count=0;try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM transaction_records WHERE collection=?",new String[]{collection})){if(c.moveToFirst())count=c.getLong(0);}
            if(count==0){try(Cursor c=db.rawQuery("SELECT state_value FROM app_state WHERE state_key=?",new String[]{collection})){if(c.moveToFirst())try{count=new JSONArray(c.getString(0)).length();}catch(Exception ignored){}}}
            out.put(collection,count);
        }
        return out.toString();
    }

    public synchronized String loadStateKeys() throws Exception {
        JSONArray keys = new JSONArray();
        SQLiteDatabase db = getReadableDatabase();
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        try (Cursor c = db.rawQuery("SELECT state_key FROM app_state ORDER BY state_key", null)) {
            while (c.moveToNext()) { String k=c.getString(0); keys.put(k); seen.add(k); }
        }
        try (Cursor c = db.rawQuery("SELECT DISTINCT collection FROM transaction_records", null)) {
            while (c.moveToNext()) { String k=c.getString(0); if(!seen.contains(k)) keys.put(k); }
        }
        return keys.toString();
    }

    public synchronized String loadStateValueChunk(String key, int offset, int maxLength) throws Exception {
        if (key == null || offset < 0 || maxLength < 1 || maxLength > 262144) throw new IllegalArgumentException("Invalid state chunk request");
        // IMPORTANT: slice inside SQLite. Calling getString() on state_value here
        // would materialize the complete multi-megabyte JSON value for every chunk.
        // offset/maxLength are Unicode code-point positions (not UTF-16 code units).
        SQLiteDatabase db = getReadableDatabase();
        if ("pksBills".equals(key) || "pksPurchases".equals(key) || "pksInventoryMovements".equals(key)) {
            // A restored compatibility backup stores transaction arrays in app_state
            // and may not contain transaction_records. Migrate before reading; otherwise
            // diagnostics can count legacy rows while the UI receives an empty array.
            if (!transactionJsonCache.containsKey(key)) {
                SQLiteDatabase writable = getWritableDatabase();
                writable.beginTransaction();
                try { migrateLegacyCollection(writable, key); writable.setTransactionSuccessful(); }
                finally { writable.endTransaction(); }
                db = getReadableDatabase();
            }
            String cached = transactionJsonCache.get(key);
            if (cached == null) { cached = readTransactionJson(db, key); transactionJsonCache.put(key, cached); }
            int total=cached.codePointCount(0,cached.length());
            if (offset >= total) { transactionJsonCache.remove(key); return ""; }
            int start=cached.offsetByCodePoints(0, offset), end=cached.offsetByCodePoints(start, Math.min(maxLength, total-offset));
            String chunk=cached.substring(start,end);
            if (chunk.codePointCount(0,chunk.length()) < maxLength) transactionJsonCache.remove(key);
            return chunk;
        }
        String sql = "SELECT substr(state_value, ?, ?) FROM app_state WHERE state_key=?";
        try (Cursor c = db.rawQuery(sql, new String[]{String.valueOf(offset + 1), String.valueOf(maxLength), key})) {
            if (!c.moveToFirst()) return "";
            String chunk = c.getString(0);
            return chunk == null ? "" : chunk;
        }
    }

    // Persist one state key without serializing or rewriting unrelated large transaction arrays.
    // Read compact vendor balances directly from the JSON transaction store.
    // JSON1 is available on supported Android SQLite builds; callers fall back safely
    // to the existing full-state path if this query is unavailable.
    public synchronized String loadVendorSummaryJson() throws Exception {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction(); try { migrateLegacyCollection(db, "pksPurchases"); db.setTransactionSuccessful(); } finally { db.endTransaction(); }
        JSONObject out = new JSONObject();
        JSONArray rows = new JSONArray();
        try (Cursor c = db.rawQuery(
                "SELECT json_extract(record_json,'$.vendorId'), " +
                "SUM(COALESCE(CAST(json_extract(record_json,'$.total') AS REAL),0)), " +
                "SUM(COALESCE(CAST(json_extract(record_json,'$.paid') AS REAL),0)), COUNT(*) " +
                "FROM transaction_records WHERE collection='pksPurchases' " +
                "GROUP BY json_extract(record_json,'$.vendorId')", null)) {
            while (c.moveToNext()) {
                JSONObject row = new JSONObject();
                row.put("vendorId", c.isNull(0) ? "" : c.getString(0));
                row.put("purchases", c.getDouble(1));
                row.put("purchasePaid", c.getDouble(2));
                row.put("billCount", c.getInt(3));
                rows.put(row);
            }
        }
        JSONArray paymentRows = new JSONArray();
        double paymentTotal = 0;
        try (Cursor c = db.rawQuery(
                "SELECT json_extract(e.value,'$.vendorId'), COALESCE(SUM(CAST(json_extract(e.value,'$.amount') AS REAL)),0) " +
                "FROM app_state s, json_each(s.state_value) e WHERE s.state_key='pksVendorPayments' " +
                "GROUP BY json_extract(e.value,'$.vendorId')", null)) {
            while (c.moveToNext()) { JSONObject row = new JSONObject(); row.put("vendorId", c.isNull(0) ? "" : c.getString(0)); row.put("paid", c.getDouble(1)); paymentTotal += c.getDouble(1); paymentRows.put(row); }
        }
        out.put("supported", true);
        out.put("vendors", rows);
        out.put("paymentsByVendor", paymentRows);
        out.put("vendorPaymentTotal", paymentTotal);
        return out.toString();
    }

    // Return only one purchase-history page. Search includes invoice/vendor metadata
    // and common item identifiers without transferring the full purchase JSON blob.
    public synchronized String loadPurchasePageJson(int offset, int limit, String search) throws Exception {
        if (offset < 0 || limit < 1 || limit > 200) throw new IllegalArgumentException("Invalid purchase page");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction(); try { migrateLegacyCollection(db, "pksPurchases"); db.setTransactionSuccessful(); } finally { db.endTransaction(); }
        String q = search == null ? "" : search.trim().toLowerCase();
        String where = "collection='pksPurchases'";
        java.util.ArrayList<String> args = new java.util.ArrayList<>();
        if (!q.isEmpty()) {
            where += " AND (lower(COALESCE(json_extract(record_json,'$.invoiceNo'),'')) LIKE ? " +
                    "OR lower(COALESCE(json_extract(record_json,'$.vendorName'),'')) LIKE ? " +
                    "OR lower(COALESCE(json_extract(record_json,'$.date'),'')) LIKE ? " +
                    "OR lower(COALESCE(json_extract(record_json,'$.id'),'')) LIKE ? " +
                    "OR EXISTS (SELECT 1 FROM json_each(json_extract(record_json,'$.items')) i WHERE " +
                    "lower(COALESCE(json_extract(i.value,'$.name'),'')) LIKE ? OR " +
                    "lower(COALESCE(json_extract(i.value,'$.hsn'),'')) LIKE ? OR " +
                    "lower(COALESCE(json_extract(i.value,'$.barcode'),'')) LIKE ?))";
            String like = "%" + q + "%";
            for (int i=0;i<7;i++) args.add(like);
        }
        String[] bind = args.toArray(new String[0]);
        int count = 0;
        try (Cursor c = db.rawQuery("SELECT COUNT(*) FROM transaction_records WHERE " + where, bind)) {
            if (c.moveToFirst()) count = c.getInt(0);
        }
        JSONArray records = new JSONArray();
        java.util.ArrayList<String> pageArgs = new java.util.ArrayList<>(args);
        pageArgs.add(String.valueOf(limit)); pageArgs.add(String.valueOf(offset));
        try (Cursor c = db.rawQuery("SELECT record_json FROM transaction_records WHERE " + where +
                " ORDER BY COALESCE(sort_date,'') DESC, rowid DESC LIMIT ? OFFSET ?", pageArgs.toArray(new String[0]))) {
            while (c.moveToNext()) records.put(new JSONObject(c.getString(0)));
        }
        JSONObject out = new JSONObject(); out.put("supported", true); out.put("total", count); out.put("records", records);
        return out.toString();
    }

    // Read one selected transaction without materializing the complete history array.
    public synchronized String loadTransactionRecordJson(String collection,String recordId) throws Exception {
        if(!isTransactionCollection(collection)) throw new IllegalArgumentException("Unsupported transaction collection");
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,collection);db.setTransactionSuccessful();}finally{db.endTransaction();}
        try(Cursor c=db.rawQuery("SELECT record_json FROM transaction_records WHERE collection=? AND record_id=? LIMIT 1",new String[]{collection,recordId==null?"":recordId})) {return c.moveToFirst()?c.getString(0):"";}
    }

    public synchronized String loadServiceDueBillsJson(String from,String to,String shopKey) throws Exception {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,"pksBills");db.setTransactionSuccessful();}finally{db.endTransaction();}
        JSONArray rows=new JSONArray();
        String sql="SELECT record_json FROM transaction_records WHERE collection='pksBills' AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='') AND COALESCE(json_extract(record_json,'$.customFields.field3'),'')>=? AND COALESCE(json_extract(record_json,'$.customFields.field3'),'')<=? ORDER BY COALESCE(json_extract(record_json,'$.customFields.field3'),''),rowid";
        try(Cursor c=db.rawQuery(sql,new String[]{shopKey,from,to})){while(c.moveToNext())rows.put(new JSONObject(c.getString(0)));}
        return rows.toString();
    }

    // Compact customer credit summary for the Reports landing screen.
    public synchronized String loadCustomerCreditSummaryJson(String shopKey) throws Exception {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,"pksBills");db.setTransactionSuccessful();}finally{db.endTransaction();}
        JSONArray rows=new JSONArray();
        String sql="SELECT COALESCE(json_extract(record_json,'$.customer'),''), SUM(CASE WHEN COALESCE(json_extract(record_json,'$.paymentMode'),'Cash')='Credit' THEN MAX(0,COALESCE(json_extract(record_json,'$.total'),0)-COALESCE(json_extract(record_json,'$.partialPaymentAmount'),0)) ELSE 0 END), MAX(COALESCE(json_extract(record_json,'$.paymentFollowUpDate'),'')), MAX(COALESCE(json_extract(record_json,'$.customerPhone'),'')), MAX(COALESCE(json_extract(record_json,'$.billNo'),'')) FROM transaction_records WHERE collection='pksBills' AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='') GROUP BY lower(COALESCE(json_extract(record_json,'$.customer'),''))";
        try(Cursor c=db.rawQuery(sql,new String[]{shopKey})){while(c.moveToNext()){JSONObject o=new JSONObject();o.put("customer",c.getString(0));o.put("creditSales",c.getDouble(1));o.put("followUpDate",c.getString(2));o.put("customerPhone",c.getString(3));o.put("billNo",c.getString(4));rows.put(o);}}
        return rows.toString();
    }

    // Bounded inventory history for the Inventory screen (latest first, normally 100 rows).
    public synchronized String loadRecentInventoryMovementsJson(String shopKey,int limit) throws Exception {
        if(limit<1)limit=100;if(limit>500)limit=500;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,"pksInventoryMovements");db.setTransactionSuccessful();}finally{db.endTransaction();}
        JSONArray rows=new JSONArray();
        try(Cursor c=db.rawQuery("SELECT record_json FROM transaction_records WHERE collection='pksInventoryMovements' AND shop_key=? AND COALESCE(json_extract(record_json,'$.reversed'),0)=0 ORDER BY COALESCE(sort_date,'') DESC,rowid DESC LIMIT ?",new String[]{shopKey,String.valueOf(limit)})){while(c.moveToNext())rows.put(new JSONObject(c.getString(0)));}
        return rows.toString();
    }

    // Date-scoped movement rows for the Inventory Movement Ledger report only.
    public synchronized String loadInventoryReportMovementsJson(String from,String to,String shopKey) throws Exception {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,"pksInventoryMovements");db.setTransactionSuccessful();}finally{db.endTransaction();}
        JSONArray rows=new JSONArray();String shopClause="*".equals(shopKey)?"":" AND shop_key=?";
        String sql="SELECT record_json FROM transaction_records WHERE collection='pksInventoryMovements' AND COALESCE(sort_date,'')>=? AND COALESCE(sort_date,'')<=? AND COALESCE(json_extract(record_json,'$.reversed'),0)=0"+shopClause+" ORDER BY COALESCE(sort_date,''),rowid";
        String[] args="*".equals(shopKey)?new String[]{from,to+"\uffff"}:new String[]{from,to+"\uffff",shopKey};
        try(Cursor c=db.rawQuery(sql,args)){while(c.moveToNext())rows.put(new JSONObject(c.getString(0)));}
        return rows.toString();
    }

    // Date- and shop-scoped report reads. Reports must not deserialize the complete
    // sales or inventory history on the WebView thread (large shops can have 100k+ movements).
    public synchronized String loadReportRecordsJson(String collection,String from,String to,String shopKey) throws Exception {
        if(!"pksBills".equals(collection) && !"pksInventoryMovements".equals(collection)) throw new IllegalArgumentException("Unsupported report collection");
        SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction(); try { migrateLegacyCollection(db,collection); db.setTransactionSuccessful(); } finally { db.endTransaction(); }
        String where="collection=? AND COALESCE(sort_date,'')>=? AND COALESCE(sort_date,'')<=? AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='')";
        JSONArray rows=new JSONArray();
        try(Cursor c=db.rawQuery("SELECT record_json FROM transaction_records WHERE "+where+" ORDER BY COALESCE(sort_date,'') DESC,rowid DESC",new String[]{collection,from, to+"\uffff",shopKey})) {
            while(c.moveToNext()) rows.put(new JSONObject(c.getString(0)));
        }
        JSONObject out=new JSONObject(); out.put("supported",true); out.put("records",rows); return out.toString();
    }

    public synchronized String loadLatestTaxBillDate(String shopKey) throws Exception {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { migrateLegacyCollection(db,"pksBills"); db.setTransactionSuccessful(); } finally { db.endTransaction(); }
        try(Cursor c=db.rawQuery("SELECT sort_date FROM transaction_records WHERE collection='pksBills' AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='') AND COALESCE(json_extract(record_json,'$.taxationEnabled'),0)!=0 ORDER BY COALESCE(sort_date,'') DESC LIMIT 1",new String[]{shopKey})) {
            return c.moveToFirst()?c.getString(0):"";
        }
    }

    // Page sales history directly from SQLite. This keeps the WebView from loading
    // and sorting every historical bill merely to display the first 50 rows.
    public synchronized String loadSalesPageJson(int offset,int limit,String search) throws Exception {
        if(offset<0)offset=0;if(limit<1)limit=50;if(limit>100)limit=100;
        SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction();try{migrateLegacyCollection(db,"pksBills");db.setTransactionSuccessful();}finally{db.endTransaction();}
        String q=search==null?"":search.trim().toLowerCase(java.util.Locale.ROOT);
        String where="collection='pksBills'";
        String[] args;
        if(q.isEmpty()) args=new String[]{};
        else {where+=" AND instr(lower(record_json),?)>0";args=new String[]{q};}
        long total=0;
        try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM transaction_records WHERE "+where,args)){if(c.moveToFirst())total=c.getLong(0);}
        JSONArray records=new JSONArray();
        String sql="SELECT record_json FROM transaction_records WHERE "+where+" ORDER BY COALESCE(sort_date,'') DESC, rowid DESC LIMIT ? OFFSET ?";
        String[] pageArgs=java.util.Arrays.copyOf(args,args.length+2);pageArgs[args.length]=String.valueOf(limit);pageArgs[args.length+1]=String.valueOf(offset);
        try(Cursor c=db.rawQuery(sql,pageArgs)){while(c.moveToNext())records.put(new JSONObject(c.getString(0)));}
        JSONObject out=new JSONObject();out.put("supported",true);out.put("total",total);out.put("records",records);return out.toString();
    }

    // Fetch only one vendor's purchases and payments for the selected date window.
    // This avoids materializing all 10,000+ purchase invoices and item arrays on the
    // WebView thread when a one-month Vendor Ledger PDF is requested.
    public synchronized String loadVendorLedgerDataJson(String vendorId, String vendorName, String from, String to, String shopKey) throws Exception {
        SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction();
        try { migrateLegacyCollection(db, "pksPurchases"); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); }
        JSONArray purchases=new JSONArray();
        String name=vendorName==null?"":vendorName.trim().replaceAll("\\s+"," ");
        String sql="SELECT record_json FROM transaction_records WHERE collection='pksPurchases' " +
            "AND (CAST(COALESCE(json_extract(record_json,'$.vendorId'),json_extract(record_json,'$.supplierId'),json_extract(record_json,'$.partyId'),'') AS TEXT)=? " +
            "OR LOWER(TRIM(COALESCE(json_extract(record_json,'$.vendorName'),json_extract(record_json,'$.supplierSnapshot.name'),json_extract(record_json,'$.vendor.name'),'')))=LOWER(?)) " +
            "AND substr(COALESCE(NULLIF(sort_date,''),json_extract(record_json,'$.invoiceDate'),''),1,10)>=? " +
            "AND substr(COALESCE(NULLIF(sort_date,''),json_extract(record_json,'$.invoiceDate'),''),1,10)<=? " +
            "AND (COALESCE(shop_key,'')='' OR LOWER(TRIM(shop_key))=LOWER(?)) " +
            "ORDER BY COALESCE(sort_date,'') ASC, record_id ASC";
        try(Cursor c=db.rawQuery(sql,new String[]{vendorId==null?"":vendorId,name,from==null?"":from,to==null?"":to,shopKey==null?"":shopKey.trim()})) {
            while(c.moveToNext()) purchases.put(new JSONObject(c.getString(0)));
        }
        JSONArray payments=new JSONArray();
        try(Cursor c=db.rawQuery("SELECT e.value FROM app_state s, json_each(s.state_value) e WHERE s.state_key='pksVendorPayments' AND (CAST(COALESCE(json_extract(e.value,'$.vendorId'),json_extract(e.value,'$.supplierId'),'') AS TEXT)=? OR LOWER(TRIM(COALESCE(json_extract(e.value,'$.vendorName'),'')))=LOWER(?)) AND substr(COALESCE(json_extract(e.value,'$.date'),''),1,10)>=? AND substr(COALESCE(json_extract(e.value,'$.date'),''),1,10)<=? AND (COALESCE(json_extract(e.value,'$.shopKey'),'')='' OR LOWER(TRIM(json_extract(e.value,'$.shopKey')))=LOWER(?)) ORDER BY COALESCE(json_extract(e.value,'$.date'),''), e.key",
                new String[]{vendorId==null?"":vendorId,name,from==null?"":from,to==null?"":to,shopKey==null?"":shopKey.trim()})) {
            while(c.moveToNext()) payments.put(new JSONObject(c.getString(0)));
        }
        JSONObject out=new JSONObject();out.put("supported",true);out.put("purchases",purchases);out.put("payments",payments);
        return out.toString();
    }

    public synchronized String loadVendorPurchasesJson(String vendorId) throws Exception {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction(); try { migrateLegacyCollection(db, "pksPurchases"); db.setTransactionSuccessful(); } finally { db.endTransaction(); }
        JSONArray rows = new JSONArray();
        try (Cursor c = db.rawQuery(
                "SELECT record_json FROM transaction_records " +
                "WHERE collection='pksPurchases' AND CAST(json_extract(record_json,'$.vendorId') AS TEXT)=? " +
                "ORDER BY COALESCE(sort_date,'') DESC, rowid DESC",
                new String[]{vendorId == null ? "" : vendorId})) {
            while (c.moveToNext()) rows.put(new JSONObject(c.getString(0)));
        }
        return rows.toString();
    }

    private boolean isTransactionCollection(String collection) { return "pksBills".equals(collection) || "pksPurchases".equals(collection) || "pksInventoryMovements".equals(collection); }

    private String transactionId(String collection, JSONObject record) throws Exception {
        if ("pksBills".equals(collection)) {
            String no=record.optString("billNo", "");
            String shop=record.optString("shopKey", "");
            return shop + "|" + no;
        }
        String id=record.optString("id", "");
        if (id.isEmpty()) throw new IllegalArgumentException("Transaction record is missing id");
        return id;
    }

    private String readTransactionJson(SQLiteDatabase db,String collection) throws Exception {
        StringBuilder out=new StringBuilder("["); boolean first=true; int count=0;
        try(Cursor c=db.rawQuery("SELECT record_json FROM transaction_records WHERE collection=? ORDER BY COALESCE(sort_date,'') DESC, rowid DESC",new String[]{collection})) {
            while(c.moveToNext()) { if(!first)out.append(','); out.append(c.getString(0)); first=false; count++; }
        }
        if(count>0) return out.append(']').toString();
        try(Cursor c=db.rawQuery("SELECT state_value FROM app_state WHERE state_key=?",new String[]{collection})) { if(c.moveToFirst()) return c.getString(0); }
        return "[]";
    }

    private JSONArray readTransactionArray(SQLiteDatabase db, String collection) throws Exception {
        JSONArray out=new JSONArray();
        try (Cursor c=db.rawQuery("SELECT record_json FROM transaction_records WHERE collection=? ORDER BY COALESCE(sort_date,'') DESC, rowid DESC", new String[]{collection})) {
            while(c.moveToNext()) out.put(new JSONObject(c.getString(0)));
        }
        if(out.length()==0) {
            try(Cursor c=db.rawQuery("SELECT state_value FROM app_state WHERE state_key=?", new String[]{collection})) {
                if(c.moveToFirst()) { JSONArray legacy=new JSONArray(c.getString(0)); for(int i=0;i<legacy.length();i++) out.put(legacy.optJSONObject(i)); }
            }
        }
        return out;
    }

    private void migrateLegacyCollection(SQLiteDatabase db, String collection) throws Exception {
        String marker="transaction_migrated_"+collection;
        boolean marked=false;
        try(Cursor c=db.rawQuery("SELECT meta_value FROM meta WHERE meta_key=?",new String[]{marker})) {
            marked=c.moveToFirst() && "1".equals(c.getString(0));
        }
        // Restoring a legacy-compatible backup can reintroduce app_state JSON arrays
        // while retaining a migration marker from a newer database. In that case the
        // marker must not hide restored history: import/merge the legacy array again.
        boolean legacyPresent=false;
        try(Cursor c=db.rawQuery("SELECT 1 FROM app_state WHERE state_key=? LIMIT 1",new String[]{collection})) { legacyPresent=c.moveToFirst(); }
        if(marked && !legacyPresent) return;
        // Let SQLite's JSON1 expand the legacy array in one set-based operation.
        // This avoids parsing and inserting thousands of records individually on
        // the WebView bridge thread during the first post-upgrade bill save.
        String idExpr = "pksBills".equals(collection)
                ? "COALESCE(json_extract(e.value,'$.shopKey'),'') || '|' || COALESCE(NULLIF(json_extract(e.value,'$.billNo'),''),e.key)"
                : "COALESCE(NULLIF(json_extract(e.value,'$.id'),''),e.key)";
        db.execSQL("INSERT OR REPLACE INTO transaction_records(collection,record_id,sort_date,source_type,source_id,shop_key,product_name,record_json) " +
                "SELECT ?, " + idExpr + ", COALESCE(json_extract(e.value,'$.date'),''), json_extract(e.value,'$.sourceType'), json_extract(e.value,'$.sourceId'), json_extract(e.value,'$.shopKey'), json_extract(e.value,'$.productName'), e.value " +
                "FROM app_state s, json_each(s.state_value) e WHERE s.state_key=?",
                new Object[]{collection, collection});
        db.delete("app_state", "state_key=?", new String[]{collection});
        ContentValues markerValue=new ContentValues(); markerValue.put("meta_key",marker); markerValue.put("meta_value","1");
        db.insertWithOnConflict("meta",null,markerValue,SQLiteDatabase.CONFLICT_REPLACE);
    }

    private void upsertTransactionInDb(SQLiteDatabase db,String collection,JSONObject record) throws Exception {
        String id=transactionId(collection,record);
        ContentValues cv=new ContentValues(); cv.put("collection",collection); cv.put("record_id",id);
        cv.put("sort_date",record.optString("date", "")); cv.put("source_type",record.optString("sourceType", "")); cv.put("source_id",record.optString("sourceId", "")); cv.put("shop_key",record.optString("shopKey", "")); cv.put("product_name",record.optString("productName", "")); cv.put("record_json",record.toString());
        db.insertWithOnConflict("transaction_records",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }

    public synchronized void saveTransactionRecord(String collection,String json) throws Exception {
        if(!isTransactionCollection(collection)) throw new IllegalArgumentException("Unsupported transaction collection");
        JSONObject record=new JSONObject(json); SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { migrateLegacyCollection(db,collection); upsertTransactionInDb(db,collection,record); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); transactionJsonCache.remove(collection); }
    }

    public synchronized void deleteTransactionRecord(String collection,String recordId) throws Exception {
        if(!isTransactionCollection(collection)) throw new IllegalArgumentException("Unsupported transaction collection");
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { migrateLegacyCollection(db,collection); db.delete("transaction_records","collection=? AND record_id=?",new String[]{collection,recordId}); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); transactionJsonCache.remove(collection); }
    }

    public synchronized String replaceInventorySource(String sourceType,String sourceId,String shopKey,String newRowsJson) throws Exception {
        JSONArray rows=new JSONArray(newRowsJson==null?"[]":newRowsJson); SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try {
            migrateLegacyCollection(db,"pksInventoryMovements");
            java.util.LinkedHashSet<String> affected=new java.util.LinkedHashSet<>();
            try(Cursor c=db.rawQuery("SELECT DISTINCT product_name FROM transaction_records WHERE collection='pksInventoryMovements' AND source_type=? AND source_id=? AND shop_key=? AND COALESCE(json_extract(record_json,'$.reversed'),0)=0",new String[]{sourceType,sourceId,shopKey})) {
                while(c.moveToNext()) if(c.getString(0)!=null&&!c.getString(0).isEmpty()) affected.add(c.getString(0));
            }
            for(int i=0;i<rows.length();i++){JSONObject r=rows.optJSONObject(i);if(r!=null&&!r.optString("productName","").isEmpty())affected.add(r.optString("productName"));}
            String now=String.valueOf(System.currentTimeMillis());
            db.execSQL("UPDATE transaction_records SET record_json=json_set(record_json,'$.reversed',json('true'),'$.reversedAt',?) " +
                    "WHERE collection='pksInventoryMovements' AND source_type=? AND source_id=? AND shop_key=? AND COALESCE(json_extract(record_json,'$.reversed'),0)=0",
                    new Object[]{now,sourceType,sourceId,shopKey});
            // New rows are inserted after the reversal so the current source remains active.
            for(int i=0;i<rows.length();i++){JSONObject r=rows.optJSONObject(i);if(r!=null)upsertTransactionInDb(db,"pksInventoryMovements",r);}
            JSONArray summaries=new JSONArray();
            for(String product:affected){double qty=0,value=0;
                try(Cursor c=db.rawQuery("SELECT record_json FROM transaction_records WHERE collection='pksInventoryMovements' AND shop_key=? AND product_name=? AND COALESCE(json_extract(record_json,'$.reversed'),0)=0 ORDER BY COALESCE(sort_date,''), COALESCE(json_extract(record_json,'$.createdAt'),''), rowid",new String[]{shopKey,product})) {
                    while(c.moveToNext()){JSONObject m=new JSONObject(c.getString(0));double q=m.optDouble("qty",0),cost=Math.max(0,m.optDouble("unitCost",0));if(q>0){qty+=q;value+=q*cost;}else if(q<0){double avg=qty>0?value/qty:cost;qty+=q;value=Math.max(0,value+q*avg);}}
                }
                JSONObject summary=new JSONObject();summary.put("productName",product);summary.put("stockQty",Math.round(qty*1000000d)/1000000d);summary.put("averageCost",qty>0?Math.round(value/qty*1000000d)/1000000d:0);summaries.put(summary);
            }
            db.setTransactionSuccessful(); return summaries.toString();
        } finally { db.endTransaction(); transactionJsonCache.remove("pksInventoryMovements"); }
    }

    public synchronized void saveTransactionRecords(String collection,String jsonArray) throws Exception {
        if(!isTransactionCollection(collection)) throw new IllegalArgumentException("Unsupported transaction collection");
        JSONArray records=new JSONArray(jsonArray==null?"[]":jsonArray); SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { migrateLegacyCollection(db,collection); for(int i=0;i<records.length();i++){JSONObject r=records.optJSONObject(i);if(r!=null)upsertTransactionInDb(db,collection,r);} db.setTransactionSuccessful(); }
        finally { db.endTransaction(); transactionJsonCache.remove(collection); }
    }

    public synchronized void deleteTransactionRecords(String collection,String idsJson) throws Exception {
        if(!isTransactionCollection(collection)) throw new IllegalArgumentException("Unsupported transaction collection");
        JSONArray ids=new JSONArray(idsJson==null?"[]":idsJson); SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { migrateLegacyCollection(db,collection); for(int i=0;i<ids.length();i++) db.delete("transaction_records","collection=? AND record_id=?",new String[]{collection,ids.optString(i)}); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); transactionJsonCache.remove(collection); }
    }

    public synchronized void saveStateValue(String key, String value) throws Exception {
        if (key == null || key.trim().isEmpty()) throw new IllegalArgumentException("Invalid state key");
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("state_key", key);
        cv.put("state_value", value == null ? "" : value);
        db.insertWithOnConflict("app_state", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public synchronized void saveState(String json) throws Exception {
        JSONObject obj = new JSONObject(json == null ? "{}" : json);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                if ("pksBills".equals(key) || "pksPurchases".equals(key) || "pksInventoryMovements".equals(key)) {
                    JSONArray a = new JSONArray(obj.optString(key, "[]"));
                    db.delete("transaction_records", "collection=?", new String[]{key});
                    for (int i=0;i<a.length();i++) { JSONObject r=a.optJSONObject(i); if(r!=null) upsertTransactionInDb(db,key,r); }
                    db.delete("app_state", "state_key=?", new String[]{key});
                    ContentValues migrated=new ContentValues(); migrated.put("meta_key","transaction_migrated_"+key); migrated.put("meta_value","1"); db.insertWithOnConflict("meta",null,migrated,SQLiteDatabase.CONFLICT_REPLACE);
                    transactionJsonCache.remove(key);
                    continue;
                }
                ContentValues cv = new ContentValues();
                cv.put("state_key", key);
                cv.put("state_value", obj.optString(key, ""));
                db.insertWithOnConflict("app_state", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }
}
