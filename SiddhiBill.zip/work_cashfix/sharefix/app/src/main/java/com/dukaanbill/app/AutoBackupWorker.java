package com.dukaanbill.app;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Environment;
import androidx.annotation.NonNull;
import androidx.documentfile.provider.DocumentFile;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.OneTimeWorkRequest;
import androidx.work.ExistingWorkPolicy;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** TEMPORARY TEST MODE: chained best-effort backup every 2 minutes, subject to Android scheduling. */
public class AutoBackupWorker extends Worker {
    public AutoBackupWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }
    @NonNull @Override public Result doWork() {
        Result result = runBackup();
        Context c = getApplicationContext();
        String mode = c.getSharedPreferences("siddhibill_auto_backup", Context.MODE_PRIVATE).getString("destination", "");
        if (!mode.isEmpty()) {
            OneTimeWorkRequest next = new OneTimeWorkRequest.Builder(AutoBackupWorker.class)
                .setInitialDelay(2, TimeUnit.MINUTES).build();
            WorkManager.getInstance(c).enqueueUniqueWork("siddhibill-auto-backup-test-loop", ExistingWorkPolicy.APPEND_OR_REPLACE, next);
        }
        return result;
    }

    private Result runBackup() {
        Context c=getApplicationContext();
        try {
            android.content.SharedPreferences prefs=c.getSharedPreferences("siddhibill_auto_backup",Context.MODE_PRIVATE);
            String mode=prefs.getString("destination","");
            if(mode.isEmpty()) return Result.success();
            File dbFile=c.getDatabasePath("dukaanbill.db");
            LocalDatabase helper=new LocalDatabase(c);
            try {
                SQLiteDatabase db=helper.getWritableDatabase();
                try(Cursor cursor=db.rawQuery("PRAGMA wal_checkpoint(FULL)",null)){ if(cursor.moveToFirst() && cursor.getInt(0)!=0) return Result.retry(); }
            } finally { helper.close(); }
            if(!dbFile.exists()||dbFile.length()==0) return Result.retry();
            File workDir=new File(c.getCacheDir(),"auto_backups"); if(!workDir.exists()&&!workDir.mkdirs())return Result.retry();
            String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
            File zip=new File(workDir,"SiddhiBill_AutoBackup_"+stamp+".zip");
            try(ZipOutputStream out=new ZipOutputStream(new FileOutputStream(zip))){
                add(out,dbFile,"database/dukaanbill.db");
                LocalDatabase stateHelper=new LocalDatabase(c); String state; try { state=stateHelper.loadState(); } finally { stateHelper.close(); }
                out.putNextEntry(new ZipEntry("database/app_state.json"));out.write(state.getBytes(StandardCharsets.UTF_8));out.closeEntry();
                JSONObject manifest=new JSONObject();manifest.put("app","SiddhiBill");manifest.put("schemaVersion",1);manifest.put("automatic",true);manifest.put("createdAt",new Date().toString());
                out.putNextEntry(new ZipEntry("database/manifest.json"));out.write(manifest.toString(2).getBytes(StandardCharsets.UTF_8));out.closeEntry();
                File docs=new File(c.getFilesDir(),"purchase_docs");File[] files=docs.listFiles();if(files!=null)for(File f:files)if(f.isFile())add(out,f,"attachments/"+f.getName());
            }
            if(zip.length()<100)return Result.retry();
            if("device".equals(mode)){
                File base=c.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);if(base==null)base=new File(c.getFilesDir(),"Documents");
                File dir=new File(base,"SiddhiBill/AutoBackups");if(!dir.exists()&&!dir.mkdirs())return Result.retry();
                File dest=new File(dir,zip.getName());copy(zip,dest);
                prefs.edit().putString("last_success",new Date().toString()).putString("last_file",dest.getAbsolutePath()).apply();
            } else if("drive".equals(mode)){
                String tree=prefs.getString("tree_uri","");if(tree.isEmpty())return Result.failure();
                DocumentFile root=DocumentFile.fromTreeUri(c,Uri.parse(tree));if(root==null||!root.canWrite())return Result.retry();
                DocumentFile target=root.createFile("application/zip",zip.getName());if(target==null)return Result.retry();
                try(InputStream in=new FileInputStream(zip);OutputStream out=c.getContentResolver().openOutputStream(target.getUri(),"w")){if(out==null)throw new Exception("Could not open Drive destination");byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();}
                prefs.edit().putString("last_success",new Date().toString()).putString("last_file",target.getName()).apply();
            } else return Result.failure();
            zip.delete();return Result.success();
        } catch(Exception e){ android.util.Log.e("SiddhiBillAutoBackup","Automatic backup failed",e);return Result.retry(); }
    }
    private static void add(ZipOutputStream out,File file,String name)throws Exception{out.putNextEntry(new ZipEntry(name));try(InputStream in=new FileInputStream(file)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}out.closeEntry();}
    private static void copy(File src,File dst)throws Exception{try(InputStream in=new FileInputStream(src);OutputStream out=new FileOutputStream(dst)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();}}
}
