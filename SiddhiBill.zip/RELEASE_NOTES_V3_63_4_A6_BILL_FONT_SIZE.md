# SiddhiBill v3.63.4 — A6 Bill Readability

- Increased A6 bill text size by 45% in the native PDF renderer, including shop name, invoice heading, invoice number/date, customer/header details, item table, totals, GST labels and footer text.
- A4 and thermal print text sizing is unchanged.
- Preserved A6 page dimensions and existing bill layout/data logic.

Validation: source changes reviewed; ZIP integrity and JavaScript syntax checks run. APK build and physical-device print testing were not performed.
