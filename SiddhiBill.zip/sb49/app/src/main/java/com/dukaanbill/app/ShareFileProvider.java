package com.dukaanbill.app;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileNotFoundException;

public class ShareFileProvider extends ContentProvider {
    private File shareDir;

    @Override
    public boolean onCreate() {
        shareDir = new File(getContext().getCacheDir(), "share");
        if (!shareDir.exists()) shareDir.mkdirs();
        return true;
    }

    private File getSafeFile(Uri uri) throws FileNotFoundException {
        String name = uri.getLastPathSegment();
        if (name == null || name.contains("/") || name.contains("..")) {
            throw new FileNotFoundException("Invalid file");
        }

        File file = new File(shareDir, name);
        try {
            String base = shareDir.getCanonicalPath() + File.separator;
            String target = file.getCanonicalPath();
            if (!target.startsWith(base)) {
                throw new FileNotFoundException("Invalid path");
            }
        } catch (java.io.IOException e) {
            throw new FileNotFoundException("Invalid path");
        }

        if (!file.exists()) {
            throw new FileNotFoundException("File not found");
        }
        return file;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        // Camera apps need write access to the app-private Quick List capture URI.
        String name=uri.getLastPathSegment();
        if(name==null || name.contains("/") || name.contains("..")) throw new FileNotFoundException("Invalid file");
        File file=new File(shareDir,name);
        try {
            String base=shareDir.getCanonicalPath()+File.separator;
            if(!file.getCanonicalPath().startsWith(base)) throw new FileNotFoundException("Invalid path");
        } catch(java.io.IOException e){throw new FileNotFoundException("Invalid path");}
        if(mode!=null && (mode.contains("w") || mode.contains("t"))) {
            int flags=ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE | ParcelFileDescriptor.MODE_WRITE_ONLY;
            try{return ParcelFileDescriptor.open(file,flags);}catch(java.io.FileNotFoundException e){throw e;}
        }
        if(!file.exists()) throw new FileNotFoundException("File not found");
        return ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public String getType(Uri uri) {
        String name = uri.getLastPathSegment();
        String ext = MimeTypeMap.getFileExtensionFromUrl(name == null ? "" : name);

        if ("pdf".equalsIgnoreCase(ext)) return "application/pdf";
        if ("png".equalsIgnoreCase(ext)) return "image/png";
        if ("jpg".equalsIgnoreCase(ext) || "jpeg".equalsIgnoreCase(ext)) return "image/jpeg";
        if ("dukaanbill".equalsIgnoreCase(ext)) return "application/vnd.dukaanbill";
        if ("siddhibill".equalsIgnoreCase(ext)) return "application/vnd.siddhibill.activation";
        if ("siddhisync".equalsIgnoreCase(ext)) return "application/vnd.siddhibill.sync";
        return "application/octet-stream";
    }

    @Override
    public Cursor query(
            Uri uri,
            String[] projection,
            String selection,
            String[] selectionArgs,
            String sortOrder) {
        try {
            File f = getSafeFile(uri);
            MatrixCursor c = new MatrixCursor(
                    new String[]{"_display_name", "_size"}
            );
            c.addRow(new Object[]{f.getName(), f.length()});
            return c;
        } catch (FileNotFoundException e) {
            return null;
        }
    }

    @Override
    public int delete(
            Uri uri,
            String selection,
            String[] selectionArgs) {
        try {
            return getSafeFile(uri).delete() ? 1 : 0;
        } catch (FileNotFoundException e) {
            return 0;
        }
    }

    @Override
    public int update(
            Uri uri,
            ContentValues values,
            String selection,
            String[] selectionArgs) {
        return 0;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }
}
