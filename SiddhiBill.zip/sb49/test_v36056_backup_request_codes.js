const fs = require('fs');
const path = require('path');
const root = __dirname;
const java = fs.readFileSync(path.join(root,'app/src/main/java/com/dukaanbill/app/MainActivity.java'),'utf8');
const gradle = fs.readFileSync(path.join(root,'app/build.gradle'),'utf8');
function code(name){const m=java.match(new RegExp('private\\s+static\\s+final\\s+int\\s+'+name+'\\s*=\\s*(\\d+)'));if(!m)throw Error('Missing request code '+name);return Number(m[1]);}
const names=['REQ_PURCHASE_DOCUMENT','REQ_BACKUP_CREATE','REQ_BACKUP_RESTORE','REQ_WEB_FILE_CHOOSER','REQ_QUICKLIST_IMAGE','REQ_QUICKLIST_CAMERA','REQ_QUICKLIST_PDF','REQ_QUICKLIST_CAMERA_PERMISSION','REQ_PURCHASE_CAMERA','REQ_PURCHASE_CAMERA_PERMISSION'];
const values=names.map(code);
if(new Set(values).size!==values.length) throw Error('Activity result request codes must be unique: '+JSON.stringify(Object.fromEntries(names.map((n,i)=>[n,values[i]]))));
if(code('REQ_BACKUP_CREATE')===code('REQ_QUICKLIST_IMAGE')) throw Error('Backup save must not be handled as Quick List image picker');
if(code('REQ_BACKUP_RESTORE')===code('REQ_QUICKLIST_CAMERA')) throw Error('Restore picker must not be handled as camera result');
if(!gradle.includes('versionCode 109')||!gradle.includes("versionName '3.60.56'")) throw Error('Version metadata not updated');
console.log('SiddhiBill v3.60.56 backup/restore request-code collision tests passed.');
