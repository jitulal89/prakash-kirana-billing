const fs=require('fs');const path=require('path');const root=__dirname;const js=fs.readFileSync(path.join(root,'app/src/main/assets/www/app.js'),'utf8');const java=fs.readFileSync(path.join(root,'app/src/main/java/com/dukaanbill/app/MainActivity.java'),'utf8');
function ok(v,m){if(!v)throw new Error(m)}
ok(js.includes('unitCatalog:units,customUnits:units'),'sync bundle must include unitCatalog and legacy customUnits');
ok(js.includes("Array.isArray(b.data.unitCatalog)&&b.data.unitCatalog.length?b.data.unitCatalog:(Array.isArray(b.data.customUnits)?b.data.customUnits:[])"),'sync import must fall back to legacy units when current unitCatalog is empty');
ok(js.includes('String(d.position||"").trim().toLowerCase()===wanted'),'custom field placement must be case-insensitive in HTML/PDF preview');
ok(js.includes('prior.aliases=[...new Set([...prior.aliases,...aliases])]'),'sync import must merge aliases without losing local aliases');
ok(java.includes('int customFieldsBottom = customHeaderCount > 0 ? metaY + 92 + customHeaderCount*14 + 10 : baseTableY;'),'PDF reserves space for custom header fields');
ok(java.includes('"header".equalsIgnoreCase(pos)'),'PDF header placement is case-insensitive');
ok(java.includes('"footer".equalsIgnoreCase(pos)'),'PDF footer placement is case-insensitive');
ok(java.includes('"footer".equalsIgnoreCase(pos)') && java.includes('wrapPlain(label+": "+value,48)'),'thermal receipt prints footer fields');
console.log('v3.60.58 custom fields and units sync checks passed');
