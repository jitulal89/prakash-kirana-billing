# SiddhiBill v3.60.59 — Bill Field Placement and Unit Sync Fallback

- Custom bill field placement in the HTML bill/PDF view is now case-insensitive (`header`, `Header`, `FOOTER`, etc.). This avoids configured fields being omitted when placement values differ only by letter case.
- Sync import now falls back to the legacy `customUnits` array when `unitCatalog` exists but is empty. Previously an empty `unitCatalog` array masked valid legacy unit backup data.
- Version code 112, version name 3.60.59.

Validation: source-level regression tests and JavaScript syntax checks only. PDF rendering, APK build, and physical 80mm thermal-printer output still require device verification.
