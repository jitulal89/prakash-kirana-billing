# SiddhiBill v3.63.0 — Collapsible Settings, Team and Broker Sections

- Settings remains a single page and is grouped into collapsible sections.
- Settings sections start collapsed; existing Save Settings controls remain at the bottom.
- Team Management and Broker Management cards can each be expanded/collapsed with a right-aligned arrow; sections start collapsed.
- Existing controls and report page behavior are retained.
- Version code 180.

Validation: JavaScript syntax and ZIP integrity checks performed. Android APK build and device testing were not performed.
