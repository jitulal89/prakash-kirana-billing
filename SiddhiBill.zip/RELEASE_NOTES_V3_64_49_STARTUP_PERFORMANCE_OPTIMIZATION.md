# SiddhiBill v3.64.49 – Startup Performance Optimization

Base: v3.64.48 Startup Migration & Save Profiling
Version code: 222

## Changes
- Removed sales-history traversal from the startup mobile-number migration. The legacy phone normalization now runs when Sales History is opened.
- Split vendor master normalization from purchase-history schema normalization.
- Purchase history is now loaded and normalized on demand when the Purchasing screen is opened, rather than during startup.
- Replaced the startup full-state `save()` with targeted persistence of the four small master/settings keys changed by startup normalization: products, customers, vendors, and settings.
- Kept ordinary full-state saves unchanged for user-initiated operations and existing workflows.
- Updated app.js cache-busting version to 3.64.49.

## Data safety
- No database schema changes.
- No transaction records are deleted or rewritten by the startup optimization.
- Existing full backup/restore and ordinary save paths are retained.
- Purchase schema normalization is deferred, not removed; it runs when Purchasing is opened.

## Validation
- JavaScript syntax validation: passed.
- ZIP integrity validation: passed after packaging.
- Android Gradle build and physical-device validation: not performed in this environment.
