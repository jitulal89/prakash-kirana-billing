const fs=require('fs'),vm=require('vm'),cp=require('child_process');
const src=fs.readFileSync(__dirname+'/app/src/main/assets/www/app.js','utf8');
function part(a,b){const i=src.indexOf(a),j=src.indexOf(b,i);if(i<0||j<0)throw Error('Missing '+a);return src.slice(i,j)}
const ctx={console,enrichPurchaseItemFromMaster:item=>item,state:{products:[]},roundMoney:n=>Math.round((Number(n)||0)*100)/100,toInputDate:s=>s};vm.createContext(ctx);
vm.runInContext(part('function parsePurchaseInvoiceTable(','function purchaseOcrEntryLine(')+part('function purchaseOcrEntryLine(','function parsePurchaseOcrRows(')+part('function parsePurchaseOcrMetadata(','function parsePurchaseInvoiceTable('),ctx);
const raw=cp.execFileSync('pdftotext',['-layout','/mnt/data/1000024866_RBIN033136_INV (1)(1).pdf','-'],{encoding:'utf8'});
const rows=ctx.parsePurchaseInvoiceTable(raw).map(ctx.purchaseOcrEntryLine).map(r=>r.split(','));
if(rows.length!==13)throw Error('Expected 13 rows');
const expectedTax=[18,18,18,5,5,5,18,18,18,18,18,18,18];
for(let i=0;i<rows.length;i++){
 const [item,qty,unit,total,tax,hsn]=rows[i];
 if(!item||!(Number(qty)>0)||!(Number(total)>0)||Number(tax)!==expectedTax[i]||!/^\d{8}$/.test(hsn))throw Error(`Wrong focus columns row ${i+1}: ${rows[i].join('|')}`);
}
if(rows[0][1]!=='16'||rows[1][1]!=='96'||rows[2][1]!=='96'||rows[3][1]!=='36'||rows[7][1]!=='25'||rows[12][1]!=='400')throw Error('Whole-bill UOM quantity selection failed');
if(rows.some(r=>Number(r[3])===0))throw Error('Zero line total found');
if(rows[9][0]!=='Harpic Original 500ML+20%EXTRA FR')throw Error('Wrapped product description was lost: '+rows[9][0]);
console.log('PASS: focus-column Quick List output has Item, bill-level UOM/QTY, inclusive Total, combined GST and HSN/SAC for all 13 rows');
console.log('PASS: CGST + SGST combines to 18% or 5%; zero IGST is ignored; scheme discount percentages excluded');
console.log('PASS: every line has positive total, HSN/SAC, correct expected GST, and no discount column leakage');
console.log('PASS: wrapped item description Harpic Original 500ML+20%EXTRA FR retained');
