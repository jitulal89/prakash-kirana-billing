# v3.64.64 — Vendor Management and Purchase Workflow Fix

- Purchase Edit, View and PDF now resolve the selected purchase by its exact SQLite record ID.
- Vendor Transactions now requests compact transaction rows for only the selected vendor and current shop.
- Legacy supplierId/partyId and supplier-name records are included in vendor transaction matching.
- Vendor transaction View Purchase now opens `pksPurchases`; it no longer incorrectly queries sales bills.
- Android no longer falls back to parsing the entire purchase history when the native vendor summary is unavailable.
- Purchase history remains paginated; existing database and stored records are preserved.

See `VENDOR_ROOT_CAUSE_V3_64_64.md` for the full call-site audit, root causes, fixes and test notes.
