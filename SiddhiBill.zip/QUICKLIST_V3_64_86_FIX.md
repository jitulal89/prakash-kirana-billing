# SiddhiBill v3.64.86 — Quick List newline and Add List event fix

- Corrected Add to Quick List so appended entries use actual newline separators in the textarea.
- Corrected Add List click binding so the click event is not passed as the text override to the parser. This prevents `[object PointerEvent]` from becoming a bill item.
- Preserved both Quick List actions and existing duplicate-choice behaviour.
- Version: 3.64.86 (versionCode 259).
