# SiddhiBill v3.64.98 — Customer Payment Balance Refresh

## Fix
- Customer balance cards could remain stale after a receipt was entered or edited from Customer Payment / Transaction History.
- The WebView payment aggregate cache relied on array identity even though payment rows are mutated in place.
- The native customer bill summary was also retained across payment saves, allowing the customer card to display an old standalone-payment total.

## Change
- Added a single customer-balance cache invalidation helper that clears both the JavaScript payment aggregate and native bill/payment summary cache.
- Invoke it after a customer receipt has been persisted successfully and before re-rendering Customers / Payment Follow-up / Transaction History.
- Also invalidate after bill save updates linked partial-payment records.
- No bill/payment records are rewritten by the refresh; balance is recalculated from the existing SQLite transaction records.

## Validation
- `node --check app/src/main/assets/www/app.js` passed.
- `node test_v36498_customer_payment_refresh.js` passed.
- `node test_v36496_shared_80mm_credit_history.js` passed.
- Android Gradle build and physical-device testing were not run.
