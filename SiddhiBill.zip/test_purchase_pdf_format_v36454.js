const fs=require('fs'); const p='app/src/main/java/com/dukaanbill/app/MainActivity.java'; const s=fs.readFileSync(p,'utf8');
function ok(v,m){if(!v)throw new Error(m)}
ok(s.includes('paint.setColor(android.graphics.Color.BLACK);\n        drawText(c, paint, "#", 36, y + 17);'),'Purchase PDF headers must use visible black text');
ok(s.includes('String.format(Locale.US, "%.3f", qty).replaceAll("0+$", "").replaceAll("\\\\.$", "")'),'Quantity must avoid scientific notation and trim trailing zeros');
ok(s.includes('y += 8;\n        drawTextRight(c, paint, "Paid: Rs. "'),'Paid row must have separation after invoice total');
console.log('PASS: purchase PDF headers, quantity formatting and totals spacing');
