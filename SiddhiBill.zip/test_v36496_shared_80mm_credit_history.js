const fs = require('fs');
const java = fs.readFileSync('app/src/main/java/com/dukaanbill/app/MainActivity.java','utf8');
const assert = (v,m) => { if(!v) throw new Error(m); };
assert(java.includes('private boolean isCreditSaleTransaction(JSONObject tr)'), 'shared credit classifier missing');
assert(java.includes('label.contains("credit") || mode.contains("credit") || type.contains("credit")'), 'credit classifier must inspect label, paymentMode and type');
assert(java.includes('private double historyPaidAmount(JSONObject tr, double billAmount)'), 'shared paid amount resolver missing');
assert((java.match(/isCreditSaleTransaction\(tr\)/g)||[]).length >= 3, 'all 80mm/native history renderers must use shared credit classifier');
assert(java.includes('double paidTxn=historyPaidAmount(tr,txnAmount);'), '80mm PDF must use actual paid amount');
assert(java.includes('double paid=historyPaidAmount(tr,billAmt);'), 'thermal paths must use actual paid amount');
assert(!java.includes('boolean credit=txnTypeLower.contains("credit")'), 'old type-only 80mm PDF classification remains');
// Expected outcomes for the reported records: credit bills use recorded payments, not bill totals.
const paid = (mode, bill, recorded) => mode.trim().toLowerCase().includes('credit') ? Math.max(0, recorded) : bill;
assert(paid('Credit',100,0)===0, 'unpaid credit bill must show zero paid');
assert(paid(' Credit ',95,50)===50, 'partially paid credit bill must show actual payment');
assert(paid('Cash',275,0)===275, 'cash bill remains fully paid');
console.log('v3.64.96 shared 80mm credit history regression checks passed');
