# SiddhiBill v3.64.90 – Customer and Vendor Ledger Native PDF

## Changes
- Customer Ledger PDF now uses the same Android native `PdfDocument` engine introduced in v3.64.89.
- Vendor Ledger PDF now uses that same native engine.
- Existing customer/vendor selection, date filters, bill/purchase/payment calculations, item details, opening/closing balance calculations, and report data retrieval are unchanged.
- Ledger summary cards are now parsed into native PDF KPI cards.
- Existing PDF filename conventions and SiddhiBill duplicate-check/save/open flow are retained.
- Existing HTML print fallback remains for environments without the native PDF bridge.
- Version: 3.64.90; version code: 263.

## Validation
- JavaScript syntax check and targeted source-routing assertions passed.
- Existing customer ledger item-comment regression test passed.
- Legacy historical tests that assert their original old app version numbers are not applicable to this newer source and fail only on those stale version assertions.
- Android Gradle compilation and actual device PDF rendering remain to be verified through GitHub Actions and on-device testing.
