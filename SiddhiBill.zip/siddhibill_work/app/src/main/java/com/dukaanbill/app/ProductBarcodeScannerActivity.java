package com.dukaanbill.app;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;

import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.ResultPoint;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;
import com.journeyapps.barcodescanner.DefaultDecoderFactory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class ProductBarcodeScannerActivity extends Activity {
    private static volatile ProductBarcodeScannerActivity activeScanner;
    private static final int CAMERA_PERMISSION_REQUEST = 771;
    private DecoratedBarcodeView barcodeView;
    private LinearLayout queueRows;
    private TextView countText;
    private boolean cameraStarted = false;
    private String lastCode = "";
    private long lastCodeAt = 0L;
    private JSONArray queue = new JSONArray();
    private LinearLayout root;

    public static void updateQueue(String json) {
        ProductBarcodeScannerActivity activity = activeScanner;
        if (activity != null) activity.runOnUiThread(() -> activity.renderQueue(json));
    }
    public static void finishScanner() {
        ProductBarcodeScannerActivity activity = activeScanner;
        if (activity != null) activity.runOnUiThread(activity::finish);
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activeScanner = this;
        getWindow().setStatusBarColor(Color.rgb(20, 28, 38));
        getWindow().setNavigationBarColor(Color.rgb(20, 28, 38));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        root.setFocusableInTouchMode(true);

        barcodeView = new DecoratedBarcodeView(this);
        barcodeView.getBarcodeView().setDecoderFactory(new DefaultDecoderFactory(IntentIntegratorFormats.oneD()));
        barcodeView.setStatusText("Keep the phone vertical • Scan product barcode");
        root.addView(barcodeView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 0.40f));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(8), dp(14), dp(5));
        TextView title = new TextView(this);
        title.setText("Quick List");
        title.setTextColor(Color.rgb(25, 35, 45));
        title.setTextSize(19);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        countText = new TextView(this);
        countText.setText("0 products · 0 qty");
        countText.setTextColor(Color.rgb(80, 90, 100));
        countText.setTextSize(13);
        header.addView(countText);
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        queueRows = new LinearLayout(this);
        queueRows.setOrientation(LinearLayout.VERTICAL);
        queueRows.setPadding(dp(10), dp(2), dp(10), dp(8));
        scroll.addView(queueRows);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        Button update = new Button(this);
        update.setText("Update Bill");
        update.setAllCaps(false);
        update.setTextSize(16);
        update.setOnClickListener(v -> {
            MainActivity.dispatchBarcodeScannerUpdate();
            finish();
        });
        LinearLayout.LayoutParams updateParams = new LinearLayout.LayoutParams(-1, dp(54));
        updateParams.setMargins(dp(10), dp(2), dp(10), dp(4));
        root.addView(update, updateParams);

        setContentView(root);
        // Keep the fixed action button above Android's gesture/3-button navigation area.
        ViewCompat.setOnApplyWindowInsetsListener(getWindow().getDecorView(), (view, insets) -> {
            androidx.core.graphics.Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            root.setPadding(0, bars.top, 0, bars.bottom + dp(6));
            return insets;
        });
        renderQueue("[]");
        // The JS queue survives when the scanner activity is temporarily closed for product creation.
        MainActivity.dispatchBarcodeScannerReady();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            resumeCamera();
        } else requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
    }

    private void resumeCamera() {
        if (barcodeView == null || cameraStarted) return;
        barcodeView.decodeContinuous(new BarcodeCallback() {
            @Override public void barcodeResult(BarcodeResult result) {
                if (result == null || result.getText() == null) return;
                String code = result.getText().trim();
                if (code.isEmpty()) return;
                long now = System.currentTimeMillis();
                if (code.equals(lastCode) && now - lastCodeAt < 1600L) return;
                lastCode = code;
                lastCodeAt = now;
                MainActivity.dispatchProductBarcode(code);
            }
            @Override public void possibleResultPoints(List<ResultPoint> resultPoints) {}
        });
        barcodeView.resume();
        cameraStarted = true;
    }

    private void renderQueue(String json) {
        try { queue = new JSONArray(json == null ? "[]" : json); }
        catch (Exception e) { queue = new JSONArray(); }
        queueRows.removeAllViews();
        int totalQty = 0;
        for (int i = 0; i < queue.length(); i++) {
            JSONObject item = queue.optJSONObject(i);
            if (item == null) continue;
            totalQty += Math.max(0, item.optInt("qty", 1));
            queueRows.addView(createItemRow(i, item));
        }
        countText.setText(queue.length() + " products · " + totalQty + " qty");
        if (queue.length() == 0) {
            TextView empty = new TextView(this);
            empty.setText("Scan a product to add it here");
            empty.setTextColor(Color.GRAY);
            empty.setPadding(dp(6), dp(10), dp(6), dp(10));
            queueRows.addView(empty);
        }
    }

    private View createItemRow(int index, JSONObject item) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(8), dp(6), dp(8), dp(8));
        card.setBackgroundColor(Color.rgb(246, 248, 250));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.setMargins(0, 0, 0, dp(7));
        card.setLayoutParams(cardParams);

        TextView name = new TextView(this);
        name.setText((index + 1) + ". " + item.optString("name", "Product"));
        name.setTextColor(Color.rgb(25, 35, 45));
        name.setTextSize(16);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(name);

        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.HORIZONTAL);
        fields.setGravity(Gravity.CENTER_VERTICAL);
        EditText qty = field(String.valueOf(Math.max(1, item.optInt("qty", 1))), InputType.TYPE_CLASS_NUMBER, "Qty");
        EditText unit = field(item.optString("unit", "piece"), InputType.TYPE_CLASS_TEXT, "Unit");
        EditText rate = field(String.format(Locale.ROOT, "%.2f", item.optDouble("rate", 0)), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL, "Rate");
        fields.addView(qty, new LinearLayout.LayoutParams(0, dp(44), 0.85f));
        fields.addView(unit, new LinearLayout.LayoutParams(0, dp(44), 1.1f));
        fields.addView(rate, new LinearLayout.LayoutParams(0, dp(44), 1.2f));
        Button minus = smallButton("−");
        Button plus = smallButton("+");
        Button remove = smallButton("×");
        fields.addView(minus, new LinearLayout.LayoutParams(dp(38), dp(42)));
        fields.addView(plus, new LinearLayout.LayoutParams(dp(38), dp(42)));
        fields.addView(remove, new LinearLayout.LayoutParams(dp(38), dp(42)));
        card.addView(fields);

        Runnable commit = () -> {
            int q = parseQty(qty.getText().toString());
            String u = unit.getText().toString().trim();
            if (u.isEmpty()) u = "piece";
            double r = parseRate(rate.getText().toString());
            JSONObject updated = queue.optJSONObject(index);
            if (updated != null) {
                try {
                    updated.put("qty", q); updated.put("unit", u); updated.put("rate", r);
                    MainActivity.dispatchBarcodeScannerEdit(index, q, u, r);
                    countText.setText(queue.length() + " products · " + totalQuantity() + " qty");
                } catch (Exception ignored) {}
            }
        };
        qty.setOnFocusChangeListener((v, hasFocus) -> { if (!hasFocus) commit.run(); });
        unit.setOnFocusChangeListener((v, hasFocus) -> { if (!hasFocus) commit.run(); });
        rate.setOnFocusChangeListener((v, hasFocus) -> { if (!hasFocus) commit.run(); });
        qty.setOnEditorActionListener((v, action, event) -> { commit.run(); return false; });
        unit.setOnEditorActionListener((v, action, event) -> { commit.run(); return false; });
        rate.setOnEditorActionListener((v, action, event) -> { commit.run(); return false; });
        minus.setOnClickListener(v -> {
            int q = Math.max(1, parseQty(qty.getText().toString()) - 1);
            qty.setText(String.valueOf(q)); commit.run();
        });
        plus.setOnClickListener(v -> {
            int q = parseQty(qty.getText().toString()) + 1;
            qty.setText(String.valueOf(q)); commit.run();
        });
        remove.setOnClickListener(v -> MainActivity.dispatchBarcodeScannerRemove(index));
        return card;
    }

    private EditText field(String value, int inputType, String hint) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setText(value);
        edit.setHint(hint);
        edit.setTextSize(14);
        edit.setInputType(inputType);
        edit.setPadding(dp(5), 0, dp(5), 0);
        edit.setTextColor(Color.rgb(35, 45, 55));
        return edit;
    }
    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text); b.setAllCaps(false); b.setTextSize(18);
        b.setPadding(0, 0, 0, 0);
        return b;
    }
    private int parseQty(String s) {
        try { return Math.max(1, Integer.parseInt(s.trim())); } catch (Exception e) { return 1; }
    }
    private double parseRate(String s) {
        try { double d = Double.parseDouble(s.trim()); return Double.isFinite(d) && d >= 0 ? d : 0; } catch (Exception e) { return 0; }
    }
    private int totalQuantity() {
        int total = 0;
        for (int i = 0; i < queue.length(); i++) total += Math.max(0, queue.optJSONObject(i) == null ? 0 : queue.optJSONObject(i).optInt("qty", 1));
        return total;
    }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onResume() {
        super.onResume();
        if (barcodeView != null && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) barcodeView.resume();
    }
    @Override protected void onPause() {
        if (barcodeView != null) barcodeView.pause();
        super.onPause();
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) resumeCamera();
            else { Toast.makeText(this, "Camera permission is required for barcode scanning", Toast.LENGTH_LONG).show(); finish(); }
        }
    }
    @Override protected void onDestroy() {
        if (activeScanner == this) activeScanner = null;
        if (barcodeView != null) barcodeView.pause();
        super.onDestroy();
    }
    private static final class IntentIntegratorFormats {
        static List<BarcodeFormat> oneD() {
            return Arrays.asList(BarcodeFormat.EAN_13, BarcodeFormat.EAN_8, BarcodeFormat.UPC_A,
                    BarcodeFormat.UPC_E, BarcodeFormat.CODE_128, BarcodeFormat.CODE_39,
                    BarcodeFormat.ITF, BarcodeFormat.CODABAR);
        }
    }
}
