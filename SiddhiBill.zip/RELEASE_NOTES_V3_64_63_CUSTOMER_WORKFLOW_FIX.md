# SiddhiBill v3.64.63 — Customer Workflow Stability Fix

## Scope
Customer-side fixes only, based on v3.64.62:
1. Existing sales bill Update no longer needs to materialize the full bill history to calculate customer balance.
2. Bill Print/PDF preparation uses compact customer summaries and customer-scoped transaction reads.
3. New bill generation no longer triggers a full sales-history JSON load during customer balance calculation.
4. Customer Master listing no longer loops over/deserializes every sales bill; bill-only customers are represented from a compact SQLite summary.
5. Customer Ledger reads only the selected customer's bills in the selected date range. Customer transaction history and View Bill use customer-scoped/native record reads.

## Root cause analysis
The Android WebView state layer deliberately lazy-loads `pksBills`, but multiple customer workflows still accessed `state.bills` directly:
- `customerDue()` filtered the full `state.bills` array. This was called while constructing a new bill's customer balance and when preparing the print customer dialog.
- `getCustomerRecords()` iterated the complete bill history. `renderCustomers()` then repeatedly filtered that array for each customer's sales and latest bill date.
- `openCustomerLedgerPdf()` loaded and filtered all bills before selecting one customer's date range.
- Customer transaction history also materialized all bills and performed a second full-array lookup to open a selected bill.

Because the lazy getter performs synchronous SQLite chunk reads and JSON parsing on the WebView JavaScript thread, these operations could make the interface appear hung. The same root cause explains why the issue surfaced in several customer workflows rather than one isolated button.

## Changes made
- Extended the native compact customer credit summary with total sales, bill count, and latest bill date.
- Added `loadCustomerBills` native bridge backed by indexed SQLite filtering on customer, shop, and optional date range.
- Reworked customer due calculation to use the compact summary and customer payment records.
- Reworked Customer Master listing/sorting to use summaries instead of `state.bills` scans.
- Reworked Customer Ledger PDF data retrieval to load only the selected customer's bills for the chosen period.
- Reworked customer transaction history and View Bill lookup to use customer-scoped/native record retrieval.
- Customer name changes update linked bill records directly in SQLite instead of scanning the full bill array.
- Preserved the browser-only fallback behaviour.
- No database reset, schema version bump, storage-key change, app identity change, or deletion of existing data.

## Validation
- JavaScript syntax check: passed.
- Targeted source regression assertions: included with this release.
- ZIP integrity: checked after packaging.
- Android Gradle build/device runtime: not run in this environment; run the supplied source through the existing GitHub Actions workflow and verify on the target Android device.

## Important qualification
This addresses the confirmed synchronous full-history access paths found in the v3.64.62 source. The Android print/PDF bridge and actual device behaviour still require a build and device test to certify end-to-end success.
