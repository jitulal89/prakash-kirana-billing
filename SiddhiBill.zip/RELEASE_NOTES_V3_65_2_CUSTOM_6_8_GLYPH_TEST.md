# SiddhiBill v3.65.2 — Font B custom 6/8 glyph test

## Scope
- Adds ESC/POS user-defined character patterns for ASCII digits `6` and `8` in Font B (9 x 17 dots).
- Selects the custom character set only during the native-text thermal item table and transaction history sections.
- Returns to the resident character set and Font A after those sections.
- Keeps native ESC/POS text; does not rasterize the item table or receipt.
- Does not add character spacing.

## Printer target
Posiflow KPC307-UEWB, 80 mm. The printer manual identifies ESC/POS compatibility. Custom-character command acceptance must still be confirmed by a physical print on this firmware.

## Validation limits
- Source-level checks and ZIP integrity only.
- Android Gradle build and physical printer test were not run.
- If the printer firmware ignores `ESC &` / `ESC %`, it should continue using its resident digits; the custom glyph appearance is not guaranteed until physically tested.
