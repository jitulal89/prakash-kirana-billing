const fs = require('fs');
const java = fs.readFileSync('app/src/main/java/com/dukaanbill/app/MainActivity.java','utf8');
const build = fs.readFileSync('app/build.gradle','utf8');
const glyph = java.slice(java.indexOf('private void defineThermalNumericGlyphsFontB'), java.indexOf('private void writeThermalItemTableText'));
const item = java.slice(java.indexOf('private void writeThermalItemTableText'), java.indexOf('private void writeThermalGstSummaryText'));
const txn = java.slice(java.indexOf('private void writeThermalTransactionsText'), java.indexOf('private void writeThermalItemTableBitmap'));
function ok(v,m){if(!v)throw new Error(m);}
ok(glyph.includes('0x1B,0x26,0x03,0x36,0x36,0x09'),'Font B custom 6 definition missing');
ok(glyph.includes('0x1B,0x26,0x03,0x38,0x38,0x09'),'Font B custom 8 definition missing');
ok(glyph.includes('0x1B,0x25,0x01'),'custom character set selection missing');
ok(item.includes('defineThermalNumericGlyphsFontB(out);'),'custom glyphs not enabled for item table');
ok(txn.includes('defineThermalNumericGlyphsFontB(out);'),'custom glyphs not enabled for transactions');
ok(item.includes('0x1B,0x25,0x00'),'item section does not restore resident character set');
ok(txn.includes('0x1B,0x25,0x00'),'transaction section does not restore resident character set');
ok(java.includes('writeThermalItemTableText(out,items,tax,b,cfg);'),'native text item table call missing');
ok(!java.includes('writeThermalItemTableBitmap(out,items,tax,b,cfg);'),'item table must not be bitmap rendered');
ok(build.includes('versionCode 275') && build.includes('versionName "3.65.2"'),'version not updated');
console.log('PASS: custom Font B 6/8 glyph commands, scoped character-set restore, native thermal text, version 3.65.2');
