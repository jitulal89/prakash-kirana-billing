SiddhiBill v3.60.76
Build workflow: .github/workflows/build-apk.yml
The APK was not locally compiled because Gradle and the Android SDK are unavailable in this workspace. Commit/push this source package to the GitHub repository and run the Build APK workflow. Install the resulting APK and test WhatsApp sharing, Download/Save As, and importing the .siddhisync file on a second phone.
