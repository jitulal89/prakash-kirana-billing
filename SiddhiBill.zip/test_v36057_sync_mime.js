const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, 'app');
const main = fs.readFileSync(path.join(root, 'src/main/java/com/dukaanbill/app/MainActivity.java'), 'utf8');
const provider = fs.readFileSync(path.join(root, 'src/main/java/com/dukaanbill/app/ShareFileProvider.java'), 'utf8');
const manifest = fs.readFileSync(path.join(root, 'src/main/AndroidManifest.xml'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'build.gradle'), 'utf8');
function ok(cond, msg) { if (!cond) throw new Error(msg); }
ok(main.includes('"SiddhiBill_Shop_Sync.siddhisync","application/vnd.siddhibill.sync"'), 'sync share uses custom MIME');
ok(main.includes('incomingType.equals("application/vnd.siddhibill.sync")'), 'sync MIME accepted on incoming share');
ok(provider.includes('"siddhisync".equalsIgnoreCase(ext)) return "application/vnd.siddhibill.sync"'), 'provider returns sync MIME');
ok((manifest.match(/application\/vnd\.siddhibill\.sync/g)||[]).length >= 2, 'manifest accepts sync MIME for incoming VIEW/SEND');
ok(gradle.includes("versionName '3.60.75'"), 'version bumped');
console.log('v3.60.57 sync MIME regression checks passed');
