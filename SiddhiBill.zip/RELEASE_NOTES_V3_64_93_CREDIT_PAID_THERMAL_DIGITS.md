# SiddhiBill v3.64.93 – Credit Paid Amount and Thermal Digit Readability

## Fixes
- Customer recent-transaction data now reports the actual amount received for credit sales (linked/partial receipts), including zero when unpaid.
- Non-credit sales are treated as settled at the invoice total when no separate partial-payment field exists.
- The same payment amount semantics are used in native thermal receipt and native PDF transaction summaries; native renderers now read the transaction label (Credit/Bill) as well as the transaction type.
- Direct 80mm thermal item and last-five-transaction tables now use raster-rendered monospace glyphs for more distinguishable numeric characters, including 6 and 8.
- Existing invoice totals, customer balances, payment records, and invoice history are not rewritten.

## Version
- versionName: 3.64.93
- versionCode: 266

## Validation
- `node --check app/src/main/assets/www/app.js` passed.
- `node test_v36493_paid_amount_thermal_font.js` passed.
- Android Gradle/device printing tests have not been run in this environment.
