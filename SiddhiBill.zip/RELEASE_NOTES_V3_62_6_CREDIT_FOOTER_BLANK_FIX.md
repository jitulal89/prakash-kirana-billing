# SiddhiBill v3.62.6 — Bill Credit Footer Blank Fix

- Settings now preserve an intentionally blank Bill Credit Footer instead of replacing it with the default message.
- Reopening Settings keeps the field blank when it was saved blank.
- HTML bill preview/PDF and native PDF/thermal print paths omit the credit footer when the saved value is empty.
- Existing installations without a saved `creditFooter` setting continue to receive the prior default; a deliberately saved empty string remains empty.

Validation: JavaScript syntax check and ZIP integrity check passed. APK build and physical-device printing were not performed.
