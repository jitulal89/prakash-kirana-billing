"""Regression checks for v3.64.59 backup and vendor-ledger behavior.
Run with: python test_v36459_backup_storage_vendor_regression.py <backup.zip>
"""
import json, sqlite3, sys, tempfile, zipfile, os

if len(sys.argv) != 2:
    raise SystemExit("Pass the synthetic SiddhiBill backup ZIP path")
with zipfile.ZipFile(sys.argv[1]) as z:
    db_name = next(n for n in z.namelist() if n.endswith("dukaanbill.db"))
    fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
    with open(path, "wb") as f: f.write(z.read(db_name))
try:
    c = sqlite3.connect(path)
    expected = {"pksBills": 10000, "pksPurchases": 10000, "pksInventoryMovements": 249162}
    for key, count in expected.items():
        raw = c.execute("SELECT state_value FROM app_state WHERE state_key=?", (key,)).fetchone()[0]
        actual = len(json.loads(raw))
        assert actual == count, (key, actual, count)
        print(f"PASS {key}: {actual}")
    purchases = json.loads(c.execute("SELECT state_value FROM app_state WHERE state_key='pksPurchases'").fetchone()[0])
    vendors = json.loads(c.execute("SELECT state_value FROM app_state WHERE state_key='pksVendors'").fetchone()[0])
    vendor = next(v for v in vendors if v.get("name") == "Test Supplier 002")
    name = " ".join(vendor["name"].lower().split())
    rows = [p for p in purchases if str(p.get("vendorId") or "").strip() == str(vendor.get("id") or "").strip() or " ".join(str(p.get("vendorName") or p.get("supplierSnapshot", {}).get("name") or "").lower().split()) == name]
    items = sum(len(p.get("items") or []) for p in rows)
    assert len(rows) == 100 and items == 1257, (len(rows), items)
    print(f"PASS vendor fallback: {len(rows)} invoices / {items} item rows")
finally:
    try: c.close()
    except Exception: pass
    os.unlink(path)
