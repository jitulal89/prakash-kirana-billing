SiddhiBill v3.63.2 — Weekly-off extra pay rate correction

- Corrected monthly-salary payroll extra-day calculation.
- Extra days worked beyond expected working days are now paid at monthly salary divided by the actual number of calendar days in the selected month.
- Example: ₹26,000 monthly salary, 30-day month, 26 expected working days, and all 30 days worked: 4 extra days × (₹26,000 / 30) = ₹3,466.67 extra pay; total earned = ₹29,466.67.
- Base monthly salary remains capped at one full monthly salary; additional extra-work earnings/commission entries continue to be added separately.

Validation: JavaScript syntax and ZIP integrity checks only. No APK build or physical-device testing performed.
