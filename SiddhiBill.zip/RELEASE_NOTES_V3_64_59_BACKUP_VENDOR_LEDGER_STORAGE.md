# SiddhiBill v3.64.59 – Backup, Vendor Ledger and Storage Management

## Included changes
- Large backup generation now migrates transaction collections to normalized SQLite rows and rebuilds legacy JSON arrays inside the backup-copy database using SQLite JSON functions. This avoids constructing full sales, purchase and inventory JSON arrays multiple times in Java heap memory.
- Backup remains compatible with legacy restore flows: the ZIP database contains `pksBills`, `pksPurchases` and `pksInventoryMovements` JSON state keys. The live database is not converted back to legacy storage.
- Vendor Ledger now matches purchase/payment records by vendor ID and falls back to normalized supplier/vendor names and supplier snapshots when IDs are absent or inconsistent. Item amount calculation has additional field fallbacks.
- Settings now includes Storage Diagnostics for database, app files, cache, WebView data/cache, backup archives, attachments and transaction counts.
- Safe cache cleanup clears WebView cache and selected temporary cache folders only. It deliberately preserves the database, business records, purchase attachments, backup archives and archive workspace.
- Version updated to 3.64.59 (versionCode 232).

## Validation performed
- JavaScript syntax check (`node --check app.js`) passed.
- SQLite JSON export regression against synthetic data passed:
  - Sales bills: 10,000
  - Purchase bills: 10,000
  - Inventory movements: 249,162
- Vendor-name fallback sample passed for Test Supplier 002: 100 purchase invoices and 1,257 item rows matched.
- ZIP integrity and source file checks are performed at packaging.

## Not verified in this environment
- Android Gradle build (Gradle/Gradle wrapper is not available in this environment).
- Physical-device restore, backup creation, PDF printing and cache cleanup.
- End-to-end restore from the exact 44 MB synthetic ZIP on an Android device.

## Safety notes
- Do not use Android Settings > Clear storage for this test.
- Storage cleanup preserves backup archives and all business data. It is limited to WebView cache and known temporary folders.
