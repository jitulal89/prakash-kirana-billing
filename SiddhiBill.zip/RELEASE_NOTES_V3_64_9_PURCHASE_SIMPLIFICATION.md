# SiddhiBill v3.64.9 — Purchase Bill Simplification

- Purchase bill total is now calculated from item rows, charges, discount, TCS and round-off; the duplicate editable invoice-total override is removed from the form.
- Non-credit payment modes (Cash, UPI, Bank Transfer, Cheque, Card) are treated as paid in full so they do not remain pending. Credit alone permits entering a payment amount and calculating the balance.
- Added optional payment reference/UTR fields for UPI, bank transfer and card, plus optional cheque number/date fields.
- Saving a purchase keeps the saved bill on screen. The Save button no longer starts a new bill; use the explicit **New Bill** button at the top.
- Purchase PDF continues to distinguish taxable and non-taxable purchases; the non-taxable version suppresses GST breakdown and labels the bill as non-taxable.

Validation: JavaScript syntax check and ZIP integrity check performed. Android build/device testing and visual PDF verification were not performed.
