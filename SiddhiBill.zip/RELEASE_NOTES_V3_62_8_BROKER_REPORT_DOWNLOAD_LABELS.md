# SiddhiBill v3.62.8 — Broker display and report PDF flow

- Billing broker dropdown now displays broker names only; commission rates remain available in Broker Management and the broker ledger report.
- Broker and Team report actions are labelled Download / Preview PDF.
- On Android, report generation opens the native Android Print interface; choose **Save as PDF** to save the PDF. Status text explains this flow.
- Version code 178, version name 3.62.8.

Validation: JavaScript syntax check and ZIP integrity check. APK build/device validation not performed.
