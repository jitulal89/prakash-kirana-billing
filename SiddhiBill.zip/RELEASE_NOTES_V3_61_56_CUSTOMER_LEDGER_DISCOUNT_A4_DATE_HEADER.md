# SiddhiBill v3.61.56 — Customer Ledger Discount and A4 Date Header

- Added a bill-level Discount column to the Customer Ledger Sales Bills table.
- Added the sum of saved bill-level discounts to the Sales Bills Total row. Uses each bill's saved `discount` value once; does not derive or add item-level discounts.
- Updated the third custom billing field markup so the date field can be right-aligned in print output. Print CSS allows wrapping and prevents clipping/truncation of the full date.
- Updated app version metadata to 3.61.56 and the frontend cache-busting query.

Validation: JavaScript syntax and ZIP integrity checks run; targeted source assertions cover the new discount column, total, and date-field print styles. No Android APK build or device test was performed.
