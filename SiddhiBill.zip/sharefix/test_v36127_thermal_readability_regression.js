const fs = require('fs');
const java = fs.readFileSync('app/src/main/java/com/dukaanbill/app/MainActivity.java', 'utf8');
function assert(ok, msg) { if (!ok) throw new Error(msg); }
assert(java.includes('private void writeThermalItemTableBitmap'), 'thermal item table renderer missing');
assert(java.includes('private void writeThermalGstSummaryBitmap'), 'thermal GST summary renderer missing');
assert(java.includes('private void writeThermalTransactionsBitmap'), 'thermal transactions renderer missing');
assert(java.includes('final int w=576, left=3, right=w-3;'), 'thermal item table must use 576-dot width');
assert(java.includes('java.util.ArrayList<Integer> heights=new java.util.ArrayList<>(); heights.add(38);'), 'item header height regression');
assert(java.includes('heights.add(42+extra)'), 'item row height regression');
assert(java.includes('final int titleH=38,rowH=40;'), 'GST summary row height regression');
assert(java.includes('final int w=576,left=3,right=w-3,headerH=66,rowH=104;'), 'transaction row height regression');
assert(java.includes('p.setTextSize(20f); c.drawText("GST RATE SUMMARY"'), 'GST summary font regression');
assert(java.includes('c.drawLine(left,y,right,y,p)'), 'solid thermal grid lines missing');
console.log('PASS: thermal item/GST/transactions width, font, row-height and solid-grid checks');
