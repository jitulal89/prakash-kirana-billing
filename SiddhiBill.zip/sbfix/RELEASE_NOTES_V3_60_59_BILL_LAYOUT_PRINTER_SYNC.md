SiddhiBill v3.60.59 source patch

Changes:
- Reduced canvas bill spacing between customer details and configured header custom fields.
- Sync bundle now includes supported shop settings as well as business records and unit aliases. Device-specific logo data, Bluetooth selection, activation and owner key are excluded/preserved locally.
- Sync import falls back to legacy customUnits if unitCatalog is empty, then merges aliases.
- Bluetooth auto-selection no longer connects to the first arbitrary paired device. Users must choose a specific paired printer in Settings.
- Thermal custom field position matching is normalized for whitespace and case, and both header/footer fields are emitted in their configured sections.

Validation: app.js passes node --check. Existing custom billing fields and backup-flow regression tests pass. The legacy units test contains an assertion for the prior implementation and requires updating to test empty-current-array fallback. Android APK build and physical printer/PDF verification have not been performed.
