# SiddhiBill v3.60.57 — Sync File MIME Fix

- Fixed Android sharing failure when creating a shop sync file by replacing generic `application/octet-stream` with `application/vnd.siddhibill.sync`.
- Updated ShareFileProvider to report the dedicated MIME type for `.siddhisync` files.
- Added Android intent-filter support for receiving SiddhiBill sync files.
- Preserved sync bundle contents and import workflow.

Validation: source regression checks, JavaScript syntax check, and ZIP integrity check. Android APK build and physical-device share/import round-trip were not performed in this environment.
