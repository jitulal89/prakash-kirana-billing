# SiddhiBill v3.60.78 — PDF metadata spacing and configurable date-based follow-up report

## Changes
- A4/A6 native PDF: payment mode is now right-aligned on its own row after customer and configured header details. It no longer shares the mobile-number row. The item table is positioned below that row.
- Reports: date-based follow-up section title and reminder message use the configured date field label (for example, Next Payment Follow Up Date), instead of always saying service due. The report still reads the configured date value saved on each bill.
- Settings: added `Build the date-based follow-up report` checkbox. Unchecking hides this report card; existing installations default to enabled for compatibility.
- Shop settings activation/sync allowlist includes the new report toggle.

## Validation
Source-level regression checks cover the changed HTML, JavaScript settings persistence/report label, and native PDF layout positioning. APK build and device PDF rendering still need to be verified in GitHub Actions/on-device.
