# SiddhiBill v3.64.35 — Blank Direct PDF Fix

## Root cause addressed
Android WebView normally draws only the visible viewport when drawing a WebView onto an external Canvas. The previous direct PDF renderer attempted to draw the full-height WebView into PdfDocument pages, resulting in blank pages with only a scrollbar artifact.

## Changes
- Enables `WebView.enableSlowWholeDocumentDraw()` at the beginning of `MainActivity.onCreate()`, before the app creates its first WebView.
- Keeps direct in-app `PdfDocument` generation and direct saving to the existing SiddhiBill report folders.
- Keeps A4 Portrait for every report.
- Allows report HTML JavaScript/DOM initialization to complete instead of stripping script blocks; waits 1.2 seconds after page load before rendering.
- Disables scrollbars in the temporary report WebView.
- Does not change bill PDF generation or business/report data calculations.

## Validation
- Existing JavaScript syntax and regression tests are run as part of packaging.
- Android Gradle build and actual PDF output on device still require GitHub Actions and device verification.
