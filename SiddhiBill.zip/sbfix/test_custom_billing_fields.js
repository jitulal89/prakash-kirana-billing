const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, 'app/src/main/assets/www');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
for (const id of ['setCustomField1Label','setCustomField1Position','setCustomField2Label','setCustomField2Position','setCustomField3Label','setCustomField3Position','customBillingFields']) {
  if (!html.includes(`id="${id}"`)) throw new Error(`Missing UI field ${id}`);
}
for (const token of ['customBillField1Label','customBillField2Label','customBillField3Label','customFields:readCustomBillFields()','renderCustomBillInputs(b.customFields||{})','customBillFieldsMarkup(b,"header")','customBillFieldsMarkup(b,"footer")','customHeader.forEach','customFooter.forEach']) {
  if (!js.includes(token)) throw new Error(`Missing implementation token ${token}`);
}
console.log('Custom billing fields regression passed');
