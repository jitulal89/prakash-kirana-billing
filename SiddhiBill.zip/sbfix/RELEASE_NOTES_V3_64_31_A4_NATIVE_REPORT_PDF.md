# SiddhiBill v3.64.31 — Proper A4 Report PDF Rendering

## Fix
- Replaced screen/WebView snapshot-style report output with Android WebView's native `PrintDocumentAdapter` PDF renderer.
- Generates paginated A4 PDF documents from the report HTML and its actual report data.
- Automatically selects A4 landscape for wide reports (more than five table header cells) or templates explicitly requesting landscape; other reports use A4 portrait.
- Applies print-only layout rules: hides navigation/action controls, removes auto-print scripts, fits tables to page width, wraps long cell values, repeats table headers, and avoids splitting table rows where possible.
- Keeps the existing SiddhiBill Downloads folder routing, duplicate-file confirmation, and PDF open/share flow.

## Validation
- JavaScript syntax check passed.
- Customer Ledger item-comments regression passed.
- Profit & Loss report regression passed.
- Owner settings / reports / printer regression passed.
- Android Gradle build and on-device PDF rendering still require validation in GitHub Actions and on the user's device.
