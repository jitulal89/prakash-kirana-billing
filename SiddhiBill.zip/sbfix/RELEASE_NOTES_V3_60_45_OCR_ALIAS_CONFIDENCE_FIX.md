# SiddhiBill v3.60.45 — OCR Alias and Purchase Master Matching Fix

## Changes in this release

- Confirmed OCR aliases now match when followed by punctuation or invoice suffixes such as `+20%EXTRA FR`; the suffix is retained in the displayed description.
- Purchase Product Master fallback can use the original OCR text and confirmed alias target, so missing unit, GST and HSN/SAC can be recovered without stripping the full supplier description.
- `Each` and `EA` normalize to the Piece unit in purchase/Quick List parsing. The internal unit normalization uses the existing lowercase `piece` catalogue entry so the normal unit selector remains compatible.
- Added regression coverage proving the same confirmed alias resolves consistently through Quick List and Purchase OCR, including suffix preservation, metadata fallback, and rejection of an ambiguous near-tie.
- App version bumped to 3.60.45 (versionCode 100).

## Regression tests

All 18 JavaScript test files passed in the source test suite, including:

- Attached supplier PDF text extraction and 13-row invoice regression.
- 10th item Harpic Original, line total ₹2,446.42, GST 18%.
- Invoice totals: taxable ₹9,176.70; GST ₹1,532.76; round-off −₹0.46; total ₹10,709.00.
- Purchase save/edit calculations, taxable/non-taxable handling, vendor OCR review, GST columns and Quick List parsing.
- Shared OCR vocabulary: confirmed aliases across both OCR entry paths, alias suffix preservation, Product Master fallback, and ambiguity rejection.

## Verification limitations

- JavaScript syntax check passed.
- Android APK build and physical-device test were not run because this source archive does not include `gradlew` and the environment does not have a system Gradle executable.
- Camera/file-picker OCR, actual Android screen appearance, and native PDF rendering still require installation/device verification. They are not marked as device-tested.
- This release is based on the latest source ZIP available in the current files, v3.60.44; a v3.60.59 source archive was not available in the files inspected for this change.
