SiddhiBill v3.60.62 — A4 / 80mm layout package

Changes in this package:
- Mobile billing item layout now places Qty, Unit, Rate and Amount/Delete in the primary row, with Tax and HSN/SAC beneath.
- Product card action buttons are kept horizontally aligned on narrow screens.
- Print stylesheet improves A4 bill metadata spacing, table layout and wrapping.
- 80mm canvas bill output now includes available customer phone/address and tax-related customer/shop GSTIN, state/place of supply and FSSAI values.

Validation:
- app.js JavaScript syntax check passed.
- This is a source package; no Android APK build, PDF render comparison or physical printer test was run.
- Tax invoice customer-name enforcement and settings UI fields for customer address/FSSAI should be verified against the app's existing data-entry screens before production use.
