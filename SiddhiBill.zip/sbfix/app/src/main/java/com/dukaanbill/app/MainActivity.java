package com.dukaanbill.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.print.PageRange;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.graphics.Bitmap.CompressFormat;
import android.view.WindowInsets;
import android.view.View;
import android.widget.Toast;

import androidx.exifinterface.media.ExifInterface;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.android.gms.tasks.Tasks;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.UUID;
import java.security.MessageDigest;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;
import android.util.DisplayMetrics;
import android.util.Log;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import javax.crypto.Mac;
import java.nio.charset.StandardCharsets;
import java.nio.charset.Charset;
import java.util.Set;
import android.app.AlertDialog;
import android.widget.EditText;
import android.text.InputType;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import android.util.Base64;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_BT_PRINT = 7001;
    private String pendingDirectPrintJson;
    private static final int REQ_PURCHASE_DOCUMENT = 9011;
    private static final int REQ_BACKUP_CREATE = 9112;
    private static final int REQ_BACKUP_RESTORE = 9113;
    private static final int REQ_WEB_FILE_CHOOSER = 9114;
    private static final int REQ_SYNC_DOWNLOAD = 9116;
    private static final int REQ_ARCHIVE_CREATE = 9120;
    private static final int REQ_ARCHIVE_IMPORT = 9121;
    private static final int REQ_AUTO_BACKUP_FOLDER = 9122;
    private static final int REQ_ARCHIVE_PDF_CREATE = 9123;
    private static final int REQ_EXPORT_FILE_CREATE = 9124;
    private byte[] pendingExportBytes;
    private String pendingExportFilename;
    private byte[] pendingSyncDownloadBytes;
    private ValueCallback<Uri[]> webFileCallback;
    private static final String BACKUP_DB_ENTRY = "database/dukaanbill.db";
    private static final String BACKUP_STATE_ENTRY = "database/app_state.json";
    private static final String BACKUP_IDENTITY_ENTRY = "security/shop_identity.sig";
    private static final String BACKUP_OWNER_ENTRY = "owner/owner_dashboard.json";
    private String pendingOwnerDashboardBackup = "{}";
    // Shop-name password is never stored in the WebView/JavaScript. The release stores only a salted, iterated digest.
    private static final String SHOP_PASSWORD_SALT_HEX = "b3d98978922aaabc368ea51ec188ff8d";
    private static final String SHOP_PASSWORD_DIGEST_HEX = "bc53398cdf28d9799555c3c64bfcf6f4f767040fba3e23bfc48c3dcf7da5a743";
    private static final int SHOP_PASSWORD_ITERATIONS = 200000;
    private static final String OWNER_PUBLIC_KEY_B64 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtY03iAdf43OFBRxNSkevWkJC4nJXLthXn3PBbPahDd5bleS9NemELweCBfQurYtdI4QGGm6dxpNTcPK6gylJAN8Uu3fZ5hlZ+ecvOMxy2yJAwRKUA9Hn/96LfjuBkuHnnVLUA7aXQqwpM0ggWH0TMEvgp/yBbErjwJEZeuonx96gNnNA2a2IKi/DNtjhgeAnyOBkLuswc+Gma9xHWsYuj7phEW1O6cYaBJJ8w28NgLfkuDKg50ln+9kItxpojrYaVOXWr2gSUVxiWd8GNECgU8KOkWco9F45Qx7HS0ydfpYOorDG9l51DrJ76eVls8xDYiYscaEZ8RPrkSw6UmkRsQIDAQAB";
    private static final String DEVICE_KEY_ALIAS = "DukaanBillDeviceKey";
    private static final String OWNER_PREFS = "owner_security";
    private static final int REQ_SCAN_QR = 9901;
    private static final int REQ_QUICKLIST_IMAGE = 9012;
    private static final int REQ_QUICKLIST_CAMERA = 9013;
    private static final int REQ_QUICKLIST_PDF = 9115;
    private Uri quickListCameraUri = null;
    private boolean pendingQuickListCameraLaunch = false;
    private Uri purchaseCameraUri = null;
    private boolean pendingPurchaseCameraLaunch = false;
    private static final int REQ_QUICKLIST_CAMERA_PERMISSION = 9015;
    private static final int REQ_PURCHASE_CAMERA = 9020;
    private static final int REQ_PURCHASE_CAMERA_PERMISSION = 9021;
    private static final String OWNER_PRIVATE_PREF = "encrypted_private";
    private static final String OWNER_SALT_PREF = "salt";
    private static final String OWNER_IV_PREF = "iv";
    // Owner private key is unlocked once per app session; shop setup/approval does not ask for the PIN repeatedly.
    private PrivateKey sessionOwnerPrivateKey;

    private File purchaseDocsDir;
    private LocalDatabase localDb;
    private File pendingBackupZip;
    private File pendingArchiveZip;
    private File pendingArchivePdf;
    private String pendingAutoBackupMode = "device";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        WebView.enableSlowWholeDocumentDraw(); // Must be enabled before the app's first WebView is created.
        super.onCreate(savedInstanceState);
        // Keep the WebView inside the Android system bars. The web UI supplies its own safe margins.
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(true);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(242,244,247));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(36,70,111));
        webView = new WebView(this);
        webView.setFitsSystemWindows(true);
        setContentView(webView);

        purchaseDocsDir = new File(getFilesDir(), "purchase_docs");
        if (!purchaseDocsDir.exists()) purchaseDocsDir.mkdirs();
        localDb = new LocalDatabase(this);
        scheduleAutoBackup();
        PDFBoxResourceLoader.init(getApplicationContext());

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Clear WebView HTTP/service-worker cache on each launch. App data lives in native SQLite,
        // so this is safe and prevents an older bundled app.js from shadowing current button handlers.
        webView.clearCache(true);
        webView.clearHistory();
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (webFileCallback != null) webFileCallback.onReceiveValue(null);
                webFileCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, REQ_WEB_FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    webFileCallback = null;
                    Toast.makeText(MainActivity.this, "Could not open file picker: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
        if (isActivated()) webView.loadUrl("file:///android_asset/www/index.html");
        else webView.loadUrl("file:///android_asset/www/activation.html");
        handleIncomingDukaanBill(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingDukaanBill(intent);
    }

    private boolean isActivated() {
        android.content.SharedPreferences p=getSharedPreferences("activation", MODE_PRIVATE);
        if (p.getBoolean("activated", false)) return true; // Preserve existing authorized installations.
        long expiry=p.getLong("trial_expiry", 0L);
        return expiry>System.currentTimeMillis();
    }
    private void setActivated(boolean v) {
        android.content.SharedPreferences.Editor e=getSharedPreferences("activation", MODE_PRIVATE).edit().putBoolean("activated", v);
        if(v) e.remove("trial_start").remove("trial_expiry");
        e.apply();
    }
    // Trial access is never granted by a button tap. It requires an owner-signed,
    // device-bound approval token, matching the permanent activation workflow.
    private String startTrial() {
        android.content.SharedPreferences p=getSharedPreferences("activation", MODE_PRIVATE);
        if(p.getBoolean("activated",false)) return "ALREADY_ACTIVATED";
        long expiry=p.getLong("trial_expiry",0L);
        if(expiry>0L) return expiry>System.currentTimeMillis()?"TRIAL_ACTIVE":"TRIAL_EXPIRED";
        if(p.getBoolean("trial_used",false)) return "TRIAL_EXPIRED";
        return "APPROVAL_REQUIRED";
    }
    private void showActivationPage(String message) {
        runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.loadUrl("file:///android_asset/www/activation.html");
            if(message!=null&&!message.isEmpty()) webView.postDelayed(() -> {
                if(getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).contains("pending_owner_key")) webView.evaluateJavascript("window.finishIncomingOwnerActivation && window.finishIncomingOwnerActivation()",null);
                else webView.evaluateJavascript("window.showActivationMessage && window.showActivationMessage("+JSONObject.quote(message)+")",null);
            },500); });
    }
    private void shareActivationFile(String tokenJson) {
        try {
            JSONObject t=new JSONObject(tokenJson);
            if(!"DUKAAN_ACTIVATION_TOKEN".equals(t.optString("type")) && !"DUKAAN_OWNER_ACTIVATION_TOKEN".equals(t.optString("type"))) throw new Exception("Only signed activation approvals can be shared as .SiddhiBill files.");
            File dir=new File(getCacheDir(),"share"); if(!dir.exists())dir.mkdirs();
            String shop="SiddhiBill_Activation";
            try { JSONObject pay=new JSONObject(new String(unb64(t.getString("payload")),StandardCharsets.UTF_8)); shop=pay.optString("shopName",shop).replaceAll("[^A-Za-z0-9_-]","_"); }catch(Exception ignored){}
            File f=new File(dir,shop+".SiddhiBill"); try(FileOutputStream out=new FileOutputStream(f)){out.write(tokenJson.getBytes(StandardCharsets.UTF_8));out.flush();}
            Uri uri=Uri.parse("content://com.siddhibill.app.share/"+Uri.encode(f.getName()));
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("application/vnd.siddhibill.activation"); i.putExtra(Intent.EXTRA_STREAM,uri); i.putExtra(Intent.EXTRA_SUBJECT,"SiddhiBill Activation"); i.putExtra(Intent.EXTRA_TEXT,"Open this signed SiddhiBill activation file with SiddhiBill."); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); i.setClipData(ClipData.newUri(getContentResolver(),f.getName(),uri)); startActivity(Intent.createChooser(i,"Send SiddhiBill activation file"));
        } catch(Exception e) { Toast.makeText(this,"Could not create activation file: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }
    private PublicKey ownerPublicKey() throws Exception { return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.decode(OWNER_PUBLIC_KEY_B64, Base64.DEFAULT))); }
    private KeyPair deviceKeyPair() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (ks.containsAlias(DEVICE_KEY_ALIAS)) return ((KeyStore.PrivateKeyEntry)ks.getEntry(DEVICE_KEY_ALIAS,null)).getPrivateKey()==null?null:new KeyPair(ks.getCertificate(DEVICE_KEY_ALIAS).getPublicKey(),((KeyStore.PrivateKeyEntry)ks.getEntry(DEVICE_KEY_ALIAS,null)).getPrivateKey());
        KeyPairGenerator g=KeyPairGenerator.getInstance("RSA","AndroidKeyStore");
        g.initialize(new android.security.keystore.KeyGenParameterSpec.Builder(DEVICE_KEY_ALIAS, android.security.keystore.KeyProperties.PURPOSE_SIGN|android.security.keystore.KeyProperties.PURPOSE_VERIFY).setDigests(android.security.keystore.KeyProperties.DIGEST_SHA256).setSignaturePaddings(android.security.keystore.KeyProperties.SIGNATURE_PADDING_RSA_PKCS1).setKeySize(2048).build());
        return g.generateKeyPair();
    }
    private String b64(byte[] b){ return Base64.encodeToString(b,Base64.NO_WRAP); }
    private byte[] unb64(String s){ return Base64.decode(s,Base64.DEFAULT); }
    private String devicePublicKeyB64() throws Exception { return b64(deviceKeyPair().getPublic().getEncoded()); }
    // Android ID is app-signing-key scoped and normally survives reinstall on Android 8+. Used only to avoid duplicate Owner Dashboard entries.
    private String stableDeviceId() { String id=android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID); return id==null?"":id; }
    private String createActivationRequest() throws Exception { return createActivationRequest("SHOP"); }
    private String createActivationRequest(String deviceType) throws Exception {
        JSONObject o=new JSONObject(); o.put("type","DUKAAN_ACTIVATION_REQUEST"); o.put("version",2); o.put("requestId",UUID.randomUUID().toString()); o.put("deviceKey",devicePublicKeyB64()); o.put("deviceIdentifier",stableDeviceId()); o.put("deviceType",deviceType==null?"SHOP":deviceType); o.put("appVersion","3.59.2"); o.put("createdAt",System.currentTimeMillis());
        if("SHOP".equalsIgnoreCase(deviceType)) {
            android.content.SharedPreferences sp=getSharedPreferences("activation",MODE_PRIVATE);
            String setup=sp.getString("pending_shop_setup",null);
            if(setup!=null) {
                try { JSONObject inv=verifyShopSetupInvite(setup); o.put("shopSetupId",inv.optString("setupId")); o.put("shopName",inv.optString("shopName")); o.put("shopMobile",inv.optString("shopMobile")); o.put("managerName",inv.optString("managerName")); o.put("address",inv.optString("address")); o.put("gstin",inv.optString("gstin")); o.put("state",inv.optString("state")); } catch(Exception ignored) {}
            }
        }
        return o.toString();
    }
    private byte[] deriveOwnerKey(String pin, byte[] salt) throws Exception { PBEKeySpec spec=new PBEKeySpec(pin.toCharArray(),salt,120000,256); return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
    private String normalizeOwnerPrivateKeyInput(String input) throws Exception {
        if (input == null) throw new Exception("Owner private key is empty");
        String s=input.trim();
        // Accept raw Base64, PEM, or the complete distributed Owner key text file.
        int begin=s.indexOf("-----BEGIN ");
        if(begin>=0){
            int firstNl=s.indexOf('\n',begin);
            int endMarker=s.indexOf("-----END ", begin);
            if(firstNl>=0 && endMarker>firstNl) s=s.substring(firstNl+1,endMarker);
        }
        StringBuilder b=new StringBuilder();
        String[] lines=s.replace("\r","\n").split("\n+");
        for(String line:lines){
            String t=line.trim();
            if(t.isEmpty() || t.startsWith("-----")) continue;
            // Ignore the two human-readable lines in the supplied key file.
            if(t.equalsIgnoreCase("DUKAAN BILL OWNER PRIVATE KEY") || t.equalsIgnoreCase("KEEP THIS FILE PRIVATE. DO NOT SHARE.")) continue;
            if(t.matches("[A-Za-z0-9+/=]+")) b.append(t);
        }
        String out=b.toString();
        if(out.length()<100 || (out.length()%4)!=0) throw new Exception("Invalid Owner private key. Paste the complete contents of DukaanBill_Owner_Private_Key.txt.");
        return out;
    }
    private void saveOwnerPrivate(String keyB64,String pin) throws Exception {
        String normalized=normalizeOwnerPrivateKeyInput(keyB64);
        byte[] raw=unb64(normalized); PrivateKey pk=KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(raw));
        byte[] challenge="DUKAAN-BILL-OWNER-KEY-CHECK".getBytes(StandardCharsets.UTF_8); Signature sig=Signature.getInstance("SHA256withRSA"); sig.initSign(pk); sig.update(challenge); byte[] signed=sig.sign(); Signature vs=Signature.getInstance("SHA256withRSA"); vs.initVerify(ownerPublicKey()); vs.update(challenge); if(!vs.verify(signed)) throw new Exception("Owner key does not match this Dukaan Bill release");
        byte[] salt=new byte[16]; new java.security.SecureRandom().nextBytes(salt); byte[] iv=new byte[12]; new java.security.SecureRandom().nextBytes(iv); byte[] aes=deriveOwnerKey(pin,salt); Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(aes,"AES"),new GCMParameterSpec(128,iv)); byte[] enc=c.doFinal(raw);
        getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).edit().putString(OWNER_PRIVATE_PREF,b64(enc)).putString(OWNER_SALT_PREF,b64(salt)).putString(OWNER_IV_PREF,b64(iv)).apply();
    }
    private PrivateKey loadOwnerPrivate(String pin) throws Exception { android.content.SharedPreferences p=getSharedPreferences(OWNER_PREFS,MODE_PRIVATE); String e=p.getString(OWNER_PRIVATE_PREF,null); if(e==null)throw new Exception("Owner key is not configured"); byte[] aes=deriveOwnerKey(pin,unb64(p.getString(OWNER_SALT_PREF,""))); Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(aes,"AES"),new GCMParameterSpec(128,unb64(p.getString(OWNER_IV_PREF,"")))); return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(c.doFinal(unb64(e)))); }
    private String encryptOwnerKeyForDevice(String keyB64, String deviceKeyB64) throws Exception {
        PublicKey devicePub=KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(unb64(deviceKeyB64)));
        byte[] raw=unb64(keyB64);
        byte[] aesRaw=new byte[32]; new java.security.SecureRandom().nextBytes(aesRaw);
        byte[] iv=new byte[12]; new java.security.SecureRandom().nextBytes(iv);
        Cipher aes=Cipher.getInstance("AES/GCM/NoPadding"); aes.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(aesRaw,"AES"),new GCMParameterSpec(128,iv));
        byte[] enc=aes.doFinal(raw);
        Cipher rsa=Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding"); rsa.init(Cipher.ENCRYPT_MODE,devicePub,new OAEPParameterSpec("SHA-256","MGF1",java.security.spec.MGF1ParameterSpec.SHA256,PSource.PSpecified.DEFAULT));
        JSONObject e=new JSONObject(); e.put("ek",b64(rsa.doFinal(aesRaw))); e.put("iv",b64(iv)); e.put("data",b64(enc)); return e.toString();
    }
    private String decryptOwnerKeyForThisDevice(String envelope) throws Exception {
        JSONObject e=new JSONObject(envelope); KeyPair kp=deviceKeyPair();
        Cipher rsa=Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding"); rsa.init(Cipher.DECRYPT_MODE,kp.getPrivate(),new OAEPParameterSpec("SHA-256","MGF1",java.security.spec.MGF1ParameterSpec.SHA256,PSource.PSpecified.DEFAULT));
        byte[] aesRaw=rsa.doFinal(unb64(e.getString("ek"))); Cipher aes=Cipher.getInstance("AES/GCM/NoPadding"); aes.init(Cipher.DECRYPT_MODE,new SecretKeySpec(aesRaw,"AES"),new GCMParameterSpec(128,unb64(e.getString("iv")))); return b64(aes.doFinal(unb64(e.getString("data"))));
    }
    private PrivateKey ownerSigningKey() throws Exception {
        if (sessionOwnerPrivateKey == null) throw new Exception("Owner tools are locked. Enter the Owner PIN once to unlock.");
        return sessionOwnerPrivateKey;
    }
    private boolean unlockOwnerSession(String pin) {
        try { sessionOwnerPrivateKey = loadOwnerPrivate(pin); return true; }
        catch (Exception e) { sessionOwnerPrivateKey = null; return false; }
    }
    private String createShopSetupInvite(String shopName,String shopMobile,String managerName,String address,String gstin,String state) throws Exception {
        if(shopName==null || shopName.trim().isEmpty()) throw new Exception("Shop name is required");
        PrivateKey pk=ownerSigningKey();
        JSONObject payload=new JSONObject();
        payload.put("type","DUKAAN_SHOP_SETUP_INVITE_PAYLOAD");
        payload.put("setupId",UUID.randomUUID().toString());
        payload.put("shopName",shopName.trim());
        payload.put("shopMobile",shopMobile==null?"":shopMobile.trim());
        payload.put("managerName",managerName==null?"":managerName.trim());
        payload.put("address",address==null?"":address.trim());
        payload.put("gstin",gstin==null?"":gstin.trim());
        payload.put("state",state==null?"":state.trim());
        payload.put("createdAt",System.currentTimeMillis());
        byte[] data=payload.toString().getBytes(StandardCharsets.UTF_8);
        Signature sig=Signature.getInstance("SHA256withRSA"); sig.initSign(pk); sig.update(data);
        JSONObject invite=new JSONObject(); invite.put("type","DUKAAN_SHOP_SETUP_INVITE"); invite.put("version",1); invite.put("payload",b64(data)); invite.put("signature",b64(sig.sign()));
        return invite.toString();
    }

    private JSONObject verifyShopSetupInvite(String inviteJson) throws Exception {
        JSONObject invite=new JSONObject(inviteJson);
        if(!"DUKAAN_SHOP_SETUP_INVITE".equals(invite.optString("type"))) throw new Exception("Invalid Shop Setup QR");
        byte[] payload=unb64(invite.getString("payload"));
        Signature sig=Signature.getInstance("SHA256withRSA"); sig.initVerify(ownerPublicKey()); sig.update(payload);
        if(!sig.verify(unb64(invite.getString("signature")))) throw new Exception("Shop Setup QR signature is invalid");
        JSONObject p=new JSONObject(new String(payload,StandardCharsets.UTF_8));
        if(!"DUKAAN_SHOP_SETUP_INVITE_PAYLOAD".equals(p.optString("type"))) throw new Exception("Invalid Shop Setup payload");
        return p;
    }

    private String approveActivation(String requestJson) throws Exception { return approveActivation(requestJson, "PERMANENT"); }
    private String approveActivation(String requestJson, String licenceType) throws Exception {
        JSONObject req=new JSONObject(requestJson);
        if(!"DUKAAN_ACTIVATION_REQUEST".equals(req.optString("type"))) throw new Exception("Invalid activation request");
        String deviceKey=req.getString("deviceKey"), requestId=req.getString("requestId"), deviceType=req.optString("deviceType","SHOP");
        JSONObject payloadObj=new JSONObject();
        payloadObj.put("requestId",requestId);
        payloadObj.put("deviceKey",deviceKey);
        payloadObj.put("deviceIdentifier",req.optString("deviceIdentifier",""));
        payloadObj.put("issuedAt",System.currentTimeMillis());
        payloadObj.put("appVersion",req.optString("appVersion","3.52.0"));
        payloadObj.put("deviceType",deviceType);
        String approvedLicence = "TRIAL".equalsIgnoreCase(licenceType) ? "TRIAL" : "PERMANENT";
        payloadObj.put("licenseType", approvedLicence);
        if ("TRIAL".equals(approvedLicence)) {
            long trialStart = System.currentTimeMillis();
            payloadObj.put("trialStart", trialStart);
            payloadObj.put("trialExpiry", trialStart + 7L*24L*60L*60L*1000L);
        }

        if("SHOP".equalsIgnoreCase(deviceType)) {
            JSONObject shop=req.optJSONObject("assignedShop");
            if(shop!=null) {
                String[] keys={"shopId","shopName","shopMobile","managerName","address","gstin","state",
                    "billPrefix","billStart","billTitle","paperSize","bluetoothPrinter",
                    "vendorManagement","taxation","taxInvoicePrefix","taxInvoiceStart",
                    "reverseCharge","tagline","footer","signature","creditFooter","showCustomer","printCustomerMobile","printPaymentMode","fssai","termsConditions","printTermsConditions","customBillField1Label","customBillField1Position","customBillField2Label","customBillField2Position","customBillField3Label","customBillField3Position","showDateFollowUpReport"};
                for(String k:keys) if(shop.has(k)) payloadObj.put(k,shop.opt(k));
            }
        }

        if("OWNER".equalsIgnoreCase(deviceType)){
            payloadObj.put("type","DUKAAN_OWNER_TOKEN_PAYLOAD");
            payloadObj.put("ownerKeyEnvelope",encryptOwnerKeyForDevice(b64(ownerSigningKey().getEncoded()),deviceKey));
        } else payloadObj.put("type","DUKAAN_ACTIVATION_TOKEN_PAYLOAD");

        byte[] payload=payloadObj.toString().getBytes(StandardCharsets.UTF_8);
        PrivateKey pk=ownerSigningKey();
        Signature sig=Signature.getInstance("SHA256withRSA");
        sig.initSign(pk); sig.update(payload);

        JSONObject token=new JSONObject();
        token.put("type", "OWNER".equalsIgnoreCase(deviceType)?"DUKAAN_OWNER_ACTIVATION_TOKEN":"DUKAAN_ACTIVATION_TOKEN");
        token.put("version",2); token.put("payload",b64(payload)); token.put("signature",b64(sig.sign()));
        return token.toString();
    }

    private void applyShopSettingsToAppState(JSONObject p) {
        try {
            JSONObject root=new JSONObject(loadAppState());
            JSONObject settings=root.optJSONObject("dukaanBillSettings");
            if(settings==null) settings=new JSONObject();

            String[] keys={"shopName","shopMobile","address","gstin","fssai","businessState","billPrefix","billTitle",
                    "paperSize","bluetoothPrinter","taxInvoicePrefix","tagline","footer","signature","creditFooter","termsConditions","customBillField1Label","customBillField1Position","customBillField2Label","customBillField2Position","customBillField3Label","customBillField3Position","showDateFollowUpReport"};
            for(String k:keys) if(p.has(k)) settings.put(k,p.optString(k,""));

            if(p.has("billStart")) settings.put("billStart",p.optInt("billStart",1));
            if(p.has("taxInvoiceStart")) settings.put("taxInvoiceStart",p.optInt("taxInvoiceStart",1));
            if(p.has("vendorManagement")) settings.put("vendorManagement",p.optBoolean("vendorManagement",false));
            if(p.has("taxation")) { settings.put("taxation",p.optBoolean("taxation",false)); settings.put("taxationEnabled",p.optBoolean("taxation",false)); }
            if(p.has("printTermsConditions")) settings.put("printTermsConditions",p.optBoolean("printTermsConditions",false));
            if(p.has("reverseCharge")) settings.put("reverseCharge",p.optBoolean("reverseCharge",false));
            if(p.has("showCustomer")) settings.put("showCustomer",p.optBoolean("showCustomer",false));
            if(p.has("printCustomerMobile")) settings.put("printCustomerMobile",p.optBoolean("printCustomerMobile",true));
            if(p.has("printPaymentMode")) settings.put("printPaymentMode",p.optBoolean("printPaymentMode",true));
            if(p.has("showDateFollowUpReport")) settings.put("showDateFollowUpReport",p.optBoolean("showDateFollowUpReport",true));

            if(p.has("shopMobile")) {
                JSONArray a=new JSONArray();
                for(String x:p.optString("shopMobile","").split("[,/;]")) if(!x.trim().isEmpty()) a.put(x.trim());
                settings.put("shopMobiles",a);
            }
            root.put("dukaanBillSettings",settings);
            saveAppState(root.toString());
        } catch(Exception ignored) {}
    }

    private boolean applyActivation(String tokenJson) throws Exception {
        JSONObject t=new JSONObject(tokenJson); String type=t.optString("type");
        if(!"DUKAAN_ACTIVATION_TOKEN".equals(type) && !"DUKAAN_OWNER_ACTIVATION_TOKEN".equals(type)) throw new Exception("Unsupported SiddhiBill activation file type");
        byte[] payload=unb64(t.getString("payload")); String sigB=t.getString("signature");
        Signature s=Signature.getInstance("SHA256withRSA"); s.initVerify(ownerPublicKey()); s.update(payload); if(!s.verify(unb64(sigB)))throw new Exception("Activation signature is invalid");
        JSONObject p=new JSONObject(new String(payload,StandardCharsets.UTF_8)); String localKey=devicePublicKeyB64(); if(!MessageDigest.isEqual(localKey.getBytes(StandardCharsets.UTF_8),p.getString("deviceKey").getBytes(StandardCharsets.UTF_8)))throw new Exception("This activation was issued for another phone");
        if("DUKAAN_OWNER_ACTIVATION_TOKEN".equals(type)){
            getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).edit().putString("pending_owner_key",decryptOwnerKeyForThisDevice(p.getString("ownerKeyEnvelope"))).apply(); return true;
        }
        if("DUKAAN_ACTIVATION_TOKEN".equals(type) && "TRIAL".equalsIgnoreCase(p.optString("licenseType","PERMANENT"))) {
            long issued = p.optLong("trialStart", 0L);
            long expiry = p.optLong("trialExpiry", 0L);
            if (issued <= 0L || expiry <= issued || expiry-issued > 7L*24L*60L*60L*1000L + 60000L) throw new Exception("Trial approval has an invalid expiry.");
            android.content.SharedPreferences existing = getSharedPreferences("activation",MODE_PRIVATE);
            if (existing.getBoolean("trial_used", false) && existing.getLong("trial_start",0L) != issued) throw new Exception("A trial has already been used on this installation.");
            existing.edit().putLong("trial_start",issued).putLong("trial_expiry",expiry).putBoolean("trial_used",true)
                .putString("shop_setup_id",p.optString("shopId",""))
                .putString("shop_name",p.optString("shopName",""))
                .putString("shop_mobile",p.optString("shopMobile",""))
                .putString("shop_manager",p.optString("managerName",""))
                .putString("shop_address",p.optString("address",""))
                .putString("shop_gstin",p.optString("gstin",""))
                .putString("shop_state",p.optString("state",""))
                .remove("pending_shop_setup").apply();
            applyShopSettingsToAppState(p);
            return true;
        }
        if("DUKAAN_ACTIVATION_TOKEN".equals(type)) {
            getSharedPreferences("activation",MODE_PRIVATE).edit()
                .putString("shop_setup_id",p.optString("shopId",""))
                .putString("shop_name",p.optString("shopName",""))
                .putString("shop_mobile",p.optString("shopMobile",""))
                .putString("shop_manager",p.optString("managerName",""))
                .putString("shop_address",p.optString("address",""))
                .putString("shop_gstin",p.optString("gstin",""))
                .putString("shop_state",p.optString("state",""))
                .remove("pending_shop_setup").apply();
            applyShopSettingsToAppState(p);
        }
        setActivated(true); return true;
    }
    private boolean finalizeOwnerActivation(String pin) throws Exception { if(pin==null||pin.length()<6) throw new Exception("Owner PIN must be at least 6 characters"); String k=getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).getString("pending_owner_key",null); if(k==null) throw new Exception("No pending Owner activation"); saveOwnerPrivate(k,pin); sessionOwnerPrivateKey=loadOwnerPrivate(pin); getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).edit().remove("pending_owner_key").apply(); setActivated(true); return true; }
    private String qrDataUrl(String text) throws Exception { BitMatrix m=new MultiFormatWriter().encode(text,BarcodeFormat.QR_CODE,800,800); Bitmap bmp=Bitmap.createBitmap(800,800,Bitmap.Config.ARGB_8888); for(int x=0;x<800;x++)for(int y=0;y<800;y++)bmp.setPixel(x,y,m.get(x,y)?android.graphics.Color.BLACK:android.graphics.Color.WHITE); ByteArrayOutputStream out=new ByteArrayOutputStream(); bmp.compress(CompressFormat.PNG,100,out); bmp.recycle(); return "data:image/png;base64,"+b64(out.toByteArray()); }
    private String billUpiPayload(JSONObject bill, JSONObject cfg) {
        if(cfg==null || !cfg.optBoolean("upiQrEnabled",false)) return "";
        if("merchant".equals(cfg.optString("upiQrSource","upi"))) return "";
        String pa=cfg.optString("upiId","").trim(); if(pa.isEmpty()) return "";
        // Intentionally omit the UPI amount so the customer can enter/change it in their UPI app.
        try{return "upi://pay?pa="+java.net.URLEncoder.encode(pa,"UTF-8")+"&pn="+java.net.URLEncoder.encode(cfg.optString("upiPayeeName",cfg.optString("shopName","Shop")),"UTF-8")+"&cu=INR&tn="+java.net.URLEncoder.encode(bill.optString("billNo","SiddhiBill"),"UTF-8");}catch(Exception e){return "";}
    }
    private Bitmap createQrBitmap(String payload,int size) { try { if(payload==null||payload.isEmpty())return null; BitMatrix m=new MultiFormatWriter().encode(payload,BarcodeFormat.QR_CODE,size,size); Bitmap bmp=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888); for(int x=0;x<size;x++)for(int y=0;y<size;y++)bmp.setPixel(x,y,m.get(x,y)?android.graphics.Color.BLACK:android.graphics.Color.WHITE); return bmp;}catch(Exception e){return null;} }
    private void drawCenteredBillQr(Canvas canvas, Paint paint, JSONObject bill, JSONObject cfg, int centerX, int topY, int size) {
        if(cfg==null||!cfg.optBoolean("upiQrEnabled",false))return;
        Bitmap qr=null; String source=cfg.optString("upiQrSource","upi");
        try { if("merchant".equals(source)){String data=cfg.optString("merchantQrData","");if(data.startsWith("data:image")){String encoded=data.substring(data.indexOf(',')+1);byte[] bytes=Base64.decode(encoded,Base64.DEFAULT);qr=BitmapFactory.decodeByteArray(bytes,0,bytes.length);}} else qr=createQrBitmap(billUpiPayload(bill,cfg),size);
            if(qr!=null){float scale=Math.min((float)size/qr.getWidth(),(float)size/qr.getHeight());float w=qr.getWidth()*scale,h=qr.getHeight()*scale;canvas.drawBitmap(qr,null,new RectF(centerX-w/2f,topY,centerX+w/2f,topY+h),paint);if(cfg.optBoolean("upiPrintAmount",true)){paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(9.5f);paint.setColor(android.graphics.Color.BLACK);drawText(canvas,paint,"Scan & Pay - Enter Amount",centerX,topY+(int)h+13);paint.setTextAlign(Paint.Align.LEFT);paint.setTypeface(Typeface.DEFAULT);} }
        }catch(Exception ignored){} finally {if(qr!=null&&!qr.isRecycled())qr.recycle();}
    }
    private void writeThermalBitmap(OutputStream out, Bitmap source) throws Exception {
        if(source==null)return; int target=256; Bitmap scaled=Bitmap.createScaledBitmap(source,target,target,false); int bytesPerRow=(target+7)/8; byte[] raster=new byte[bytesPerRow*target];
        for(int yy=0;yy<target;yy++)for(int xx=0;xx<target;xx++){int color=scaled.getPixel(xx,yy);int gray=(android.graphics.Color.red(color)+android.graphics.Color.green(color)+android.graphics.Color.blue(color))/3;if(gray<160)raster[yy*bytesPerRow+(xx/8)]|=(byte)(0x80>>(xx%8));}
        escCmd(out,0x1B,0x61,0x01);out.write(new byte[]{0x1D,0x76,0x30,0x00,(byte)(bytesPerRow&0xff),(byte)((bytesPerRow>>8)&0xff),(byte)(target&0xff),(byte)((target>>8)&0xff)});out.write(raster);escLine(out,"");escCmd(out,0x1B,0x61,0x00);if(scaled!=source)scaled.recycle();
    }
    private void writeThermalQr(OutputStream out,String payload) throws Exception {
        if(payload==null||payload.isEmpty())return; byte[] data=payload.getBytes(StandardCharsets.UTF_8);
        escCmd(out,0x1B,0x61,0x01); escCmd(out,0x1D,0x28,0x6B,0x04,0x00,0x31,0x41,0x32,0x00); escCmd(out,0x1D,0x28,0x6B,0x03,0x00,0x31,0x43,0x06); escCmd(out,0x1D,0x28,0x6B,0x03,0x00,0x31,0x45,0x30); int n=data.length+3; out.write(new byte[]{0x1D,0x28,0x6B,(byte)(n&0xff),(byte)((n>>8)&0xff),0x31,0x50,0x30});out.write(data);escCmd(out,0x1D,0x28,0x6B,0x03,0x00,0x31,0x51,0x30);escLine(out,"");escCmd(out,0x1B,0x61,0x00);
    }
    private void shareText(String title,String text){ try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,title);i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,title));}catch(Exception e){Toast.makeText(this,"Could not share: "+e.getMessage(),Toast.LENGTH_LONG).show();} }
    private void scanQr(){ try{IntentIntegrator ii=new IntentIntegrator(this);ii.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);ii.setPrompt("Scan Dukaan Bill activation QR");ii.setBeepEnabled(true);ii.setOrientationLocked(false);ii.setRequestCode(REQ_SCAN_QR);ii.initiateScan();}catch(Exception e){Toast.makeText(this,"QR scanner unavailable: "+e.getMessage(),Toast.LENGTH_LONG).show();} }

    private void handleIncomingDukaanBill(Intent intent) {
        if (intent == null) return;
        Uri uri = intent.getData();
        String type = intent.getType();
        if ((type == null || type.trim().isEmpty()) && uri != null) {
            type = getContentResolver().getType(uri);
            String last = uri.getLastPathSegment();
            if ((type == null || type.trim().isEmpty()) && last != null && last.toLowerCase(Locale.ROOT).endsWith(".siddhibill")) type = "application/vnd.siddhibill.activation";
            if ((type == null || type.trim().isEmpty()) && last != null && last.toLowerCase(Locale.ROOT).endsWith(".siddhisync")) type = "application/vnd.siddhibill.sync";
        }
        if (type != null && (type.equalsIgnoreCase("application/octet-stream") || type.equalsIgnoreCase("application/json")) && uri != null) {
            String last = uri.getLastPathSegment();
            if (last != null && last.toLowerCase(Locale.ROOT).endsWith(".siddhibill")) type = "application/vnd.siddhibill.activation";
            if (last != null && last.toLowerCase(Locale.ROOT).endsWith(".siddhisync")) type = "application/vnd.siddhibill.sync";
        }
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            Object stream = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (stream instanceof Uri) uri = (Uri) stream;
        }
        if (uri == null || type == null) return;
        String incomingType = type.toLowerCase(Locale.ROOT);
        if (!incomingType.equals("application/vnd.dukaanbill") && !incomingType.equals("application/octet-stream") && !incomingType.equals("application/vnd.siddhibill.activation") && !incomingType.equals("application/vnd.siddhibill.sync") && !incomingType.equals("application/json")) return;
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) throw new Exception("Could not open Dukaan Bill file");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) {
                if (bos.size() > 30 * 1024 * 1024) throw new Exception("Incoming file is too large (maximum 30 MB)");
                bos.write(buf, 0, n);
            }
            in.close();
            String json = new String(bos.toByteArray(), StandardCharsets.UTF_8);
            JSONObject obj = new JSONObject(json);
            if ("SiddhiBillSync".equals(obj.optString("format", "")) && obj.optJSONObject("data") != null) {
                final String syncJson = json;
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Import SiddhiBill Sync")
                    .setMessage("Import and merge this sync file for shop \"" + obj.optString("shopName", "Unknown") + "\"? Existing records will be retained and matching records merged.")
                    .setNegativeButton("Cancel", (dialog, which) -> Toast.makeText(MainActivity.this, "Sync import cancelled.", Toast.LENGTH_SHORT).show())
                    .setPositiveButton("Import", (dialog, which) -> {
                        if (webView == null) { Toast.makeText(MainActivity.this, "SiddhiBill is not ready. Open the app and tap the sync file again.", Toast.LENGTH_LONG).show(); return; }
                        String encoded = Base64.encodeToString(syncJson.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                        webView.postDelayed(() -> webView.evaluateJavascript("window.importSyncBundleFromText && window.importSyncBundleFromText(decodeURIComponent(escape(atob('" + encoded + "'))))", result -> {
                            if (result != null && result.contains("OK")) Toast.makeText(MainActivity.this, "Sync file imported successfully.", Toast.LENGTH_LONG).show();
                            else Toast.makeText(MainActivity.this, "Sync import could not be completed. Check the sync status in SiddhiBill.", Toast.LENGTH_LONG).show();
                        }), 700);
                    }).show();
                return;
            }
            String incomingTokenType=obj.optString("type","");
            if("DUKAAN_ACTIVATION_TOKEN".equals(incomingTokenType) || "DUKAAN_OWNER_ACTIVATION_TOKEN".equals(incomingTokenType)) {
                applyActivation(json);
                if("DUKAAN_OWNER_ACTIVATION_TOKEN".equals(incomingTokenType)) {
                    showActivationPage("Owner-device approval verified. Create your Owner PIN to finish setup.");
                } else {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,"SiddhiBill activation file verified successfully.",Toast.LENGTH_LONG).show());
                    runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.loadUrl("file:///android_asset/www/index.html"); });
                }
                return;
            }
            if (!"THERMAL_PRINT".equalsIgnoreCase(obj.optString("dukaanBillType", ""))) throw new Exception("Unsupported SiddhiBill file. Select a valid signed .SiddhiBill activation file.");
            final String encoded = Base64.encodeToString(json.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            webView.postDelayed(() -> webView.evaluateJavascript("window.openIncomingThermalBill && window.openIncomingThermalBill(atob('" + encoded + "'))", null), 900);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open SiddhiBill file: " + e.getMessage(), Toast.LENGTH_LONG).show();
            if(!isActivated()) showActivationPage("Activation file rejected. Check that it was issued for this device and has not been modified.");
        }
    }

    private Uri saveToCacheProvider(byte[] data, String filename) throws Exception {
        File dir = new File(getCacheDir(), "share");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create share folder");
        File file = new File(dir, filename);
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(data);
            out.flush();
        }
        return Uri.parse("content://com.siddhibill.app.share/" + Uri.encode(file.getName()));
    }

    private String siddhiBillFolderFor(String filename) {
        String n = filename == null ? "" : filename.toLowerCase(Locale.ROOT);
        if (n.contains("customer_ledger") || n.contains("customer-ledger")) return "Customer-Ledger";
        if (n.contains("team_member") || n.contains("team_report") || n.contains("payroll")) return "Team-Reports";
        if (n.contains("broker")) return "Broker-Reports";
        if (n.contains("gst") || n.contains("gstr")) return "GST-Reports";
        if (n.contains("profit_loss") || n.contains("profit-loss")) return "Profit-and-Loss";
        if (n.contains("vendor_ledger") || n.contains("vendor-ledger") || n.contains("supplier_ledger")) return "Vendor-Ledger";
        if (n.contains("inventory") || n.contains("stock_summary") || n.contains("stock_valuation") || n.contains("stock_movement")) return "Inventory-Reports";
        if (n.contains("bill_") || n.startsWith("bill") || n.contains("invoice") || n.contains("purchase")) return "Bills";
        if (n.contains("backup") || n.contains("archive")) return "Backups";
        if (n.contains("ledger")) return "Ledgers";
        if (n.contains("report")) return "Other-Reports";
        return "Other-Reports";
    }

    private Uri saveForSharing(byte[] data, String filename, String mime) throws Exception {
        String folder = siddhiBillFolderFor(filename);
        boolean imageMime = mime != null && mime.startsWith("image/");
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    (imageMime ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS) + "/SiddhiBill/" + folder);
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);

            Uri collection = imageMime
                    ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    : MediaStore.Downloads.EXTERNAL_CONTENT_URI;

            Uri uri = resolver.insert(collection, values);
            if (uri != null) {
                try (OutputStream out = resolver.openOutputStream(uri)) {
                    if (out == null) throw new Exception("Could not open output stream");
                    out.write(data);
                    out.flush();
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                resolver.update(uri, done, null, null);
                return uri;
            }
        }
        return saveToCacheProvider(data, filename);
    }

    private void shareFile(byte[] data, String filename, String mime, String title) throws Exception {
        Uri uri = saveForSharing(data, filename, mime);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType(mime);
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_TEXT, "DukaanBill - " + title);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        send.setClipData(ClipData.newRawUri(title, uri));
        Intent chooser = Intent.createChooser(send, title);
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(chooser);
    }

    private void drawOutlineRect(Canvas canvas, Paint paint, float left, float top, float right, float bottom) {
        if (canvas == null || paint == null) return;
        Paint.Style oldStyle = paint.getStyle();
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawRect(left, top, right, bottom, paint);
        paint.setStyle(oldStyle);
    }

    // Bill values omit unnecessary .00, but retain two decimal places for fractional amounts.
    private String formatBillValue(double value) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return "0";
        double rounded = Math.round(value * 100.0d) / 100.0d;
        if (Math.abs(rounded - Math.rint(rounded)) < 0.000001d) {
            return String.format(Locale.US, "%.0f", rounded);
        }
        return String.format(Locale.US, "%.2f", rounded);
    }

    private String formatBillQuantity(String value) {
        if (value == null) return "";
        String trimmed = value.trim();
        if (trimmed.isEmpty()) return trimmed;
        try { return formatBillValue(Double.parseDouble(trimmed)); }
        catch (NumberFormatException ignored) { return trimmed; }
    }

    private void drawText(Canvas c, Paint p, String text, float x, float y) {
        Paint.Style oldStyle = p.getStyle();
        p.setStyle(Paint.Style.FILL);
        c.drawText(text == null ? "" : text, x, y, p);
        p.setStyle(oldStyle);
    }

    /** Draw a PDF field with a bold label and regular-weight value. */
    private void drawLabelValue(Canvas c, Paint p, String label, String value, float x, float y) {
        Typeface oldTypeface = p.getTypeface();
        Paint.Align oldAlign = p.getTextAlign();
        Paint.Style oldStyle = p.getStyle();
        p.setTextAlign(Paint.Align.LEFT);
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        String safeLabel = label == null ? "" : label;
        String safeValue = value == null ? "" : value;
        drawText(c, p, safeLabel, x, y);
        float valueX = x + p.measureText(safeLabel);
        p.setTypeface(Typeface.DEFAULT);
        drawText(c, p, safeValue, valueX, y);
        p.setTypeface(oldTypeface);
        p.setTextAlign(oldAlign);
        p.setStyle(oldStyle);
    }

    private void drawTextRight(Canvas c, Paint p, String text, float rightX, float y) {
        Paint.Align oldAlign = p.getTextAlign();
        Paint.Style oldStyle = p.getStyle();
        p.setStyle(Paint.Style.FILL);
        p.setTextAlign(Paint.Align.RIGHT);
        c.drawText(text == null ? "" : text, rightX, y, p);
        p.setTextAlign(oldAlign);
        p.setStyle(oldStyle);
    }

    private void drawCenteredFitText(Canvas c, Paint p, String text, float centerX, float y, float maxWidth) {
        Paint.Align oldAlign = p.getTextAlign();
        float oldSize = p.getTextSize();
        String value = text == null ? "" : text;
        float minSize = Math.max(5.5f, oldSize * 0.65f);
        while (p.measureText(value) > maxWidth && p.getTextSize() > minSize) p.setTextSize(Math.max(minSize, p.getTextSize() - 0.5f));
        p.setTextAlign(Paint.Align.CENTER);
        drawText(c, p, value, centerX, y);
        p.setTextAlign(oldAlign);
        p.setTextSize(oldSize);
    }

    private Bitmap loadLogo(JSONObject cfg) {
        Bitmap source = null;
        try {
            if (cfg != null) {
                String data = cfg.optString("logoData", "");
                if (data.startsWith("data:")) {
                    int comma = data.indexOf(',');
                    if (comma > 0) {
                        byte[] raw = Base64.decode(data.substring(comma + 1), Base64.DEFAULT);
                        source = BitmapFactory.decodeByteArray(raw, 0, raw.length);
                    }
                }
            }
        } catch (Exception ignored) {}
        if (source == null) {
            try (InputStream in = getAssets().open("www/logo.jpg")) {
                source = BitmapFactory.decodeStream(in);
            } catch (Exception ignored) {}
        }
        if (source == null) return null;

        // The PDF only renders the logo at roughly 68pt.  Do not embed the
        // full-resolution uploaded image in every PDF page; it can make a
        // simple one-page bill exceed 1 MB.  A 320px bitmap is more than
        // sufficient for A4/thermal output while keeping PDFs compact.
        final int maxDimension = 320;
        int w = source.getWidth(), h = source.getHeight();
        if (w <= maxDimension && h <= maxDimension) return source;
        float scale = Math.min((float) maxDimension / w, (float) maxDimension / h);
        int nw = Math.max(1, Math.round(w * scale));
        int nh = Math.max(1, Math.round(h * scale));
        Bitmap scaled = Bitmap.createScaledBitmap(source, nw, nh, true);
        if (scaled != source) source.recycle();
        return scaled;
    }

    private List<String> wrapText(String text, Paint paint, float maxWidth) {
        List<String> lines = new ArrayList<>();
        if (text == null || text.trim().isEmpty()) return lines;
        String normalizedText = text.replace("\\r\\n", "\\n").replace('\r', '\n');
        String[] paragraphs = normalizedText.split("\\n", -1);
        for (String paragraph : paragraphs) {
            String normalized = paragraph.trim().replaceAll("\\s+", " ");
            if (normalized.isEmpty()) { lines.add(""); continue; }
            String[] words = normalized.split(" ");
            String line = "";
            for (String word : words) {
                String candidate = line.isEmpty() ? word : line + " " + word;
                if (paint.measureText(candidate) <= maxWidth) {
                    line = candidate;
                } else {
                    if (!line.isEmpty()) lines.add(line);
                    if (paint.measureText(word) <= maxWidth) {
                        line = word;
                    } else {
                        String part = "";
                        for (int i = 0; i < word.length(); i++) {
                            String candidatePart = part + word.charAt(i);
                            if (paint.measureText(candidatePart) > maxWidth && !part.isEmpty()) {
                                lines.add(part);
                                part = String.valueOf(word.charAt(i));
                            } else part = candidatePart;
                        }
                        line = part;
                    }
                }
            }
            if (!line.isEmpty()) lines.add(line);
        }
        return lines;
    }

    /** Wrap an address so the first line leaves room for its label, while continuation lines start at the address block's left edge. */
    private List<String> wrapLabeledAddress(String text, Paint paint, float maxWidth, float labelWidth) {
        List<String> lines = new ArrayList<>();
        if (text == null || text.trim().isEmpty()) return lines;
        String remaining = text.trim().replaceAll("\\s+", " ");
        float firstWidth = Math.max(20f, maxWidth - labelWidth);
        boolean first = true;
        while (!remaining.isEmpty()) {
            float allowed = first ? firstWidth : maxWidth;
            int split = remaining.length();
            while (split > 0 && paint.measureText(remaining.substring(0, split)) > allowed) {
                int space = remaining.lastIndexOf(' ', split - 1);
                if (space <= 0) {
                    split = Math.min(remaining.length(), Math.max(1, split));
                    while (split > 1 && paint.measureText(remaining.substring(0, split)) > allowed) split--;
                    break;
                }
                split = space;
            }
            String line = remaining.substring(0, split).trim();
            if (line.isEmpty()) break;
            lines.add(line);
            remaining = remaining.substring(line.length()).trim();
            first = false;
        }
        return lines;
    }

    private String shopMobileText(JSONObject cfg) {
        if (cfg == null) return "";
        JSONArray arr = cfg.optJSONArray("shopMobiles");
        if (arr != null && arr.length() > 0) {
            StringBuilder sb = new StringBuilder();
            for (int i=0;i<arr.length();i++) { String v=arr.optString(i,"").trim(); if(!v.isEmpty()){ if(sb.length()>0) sb.append(", "); sb.append(v); } }
            if(sb.length()>0) return sb.toString();
        }
        return cfg.optString("shopMobile", "").trim();
    }

    private void setPdfTextSize(Paint p, float size, JSONObject cfg) {
        // A6 currently uses a half-scale A4 coordinate system. Compensate text
        // sizing so the A6 bill remains readable on the physical page.
        boolean a6 = cfg != null && "A6".equalsIgnoreCase(cfg.optString("paperSize", "A4"));
        p.setTextSize(size * (a6 ? 1.16f : 1.0f));
    }

    private float drawPdfHeader(Canvas c, Paint p, Bitmap logo, int pageWidth, JSONObject cfg, JSONObject bill, boolean taxInvoice, String placeOfSupply) {
        // Compact, reference-matched A4 header. Keep the complete header to about 15% of A4 height.
        boolean a6Header = cfg != null && "A6".equalsIgnoreCase(cfg.optString("paperSize", "A4"));
        final float left=35f, right=560f, top=a6Header?24f:12f, stripBottom=(a6Header?46f:34f), bottom=taxInvoice?(a6Header?152f:140f):(a6Header?122f:110f);
        final float shopRight=310f, invoiceRight=405f;
        int black=android.graphics.Color.BLACK;
        int red=android.graphics.Color.rgb(196,32,32);
        String shopName=cfg==null?"DUKAAN BILL":cfg.optString("shopName","DUKAAN BILL");
        String tagline=cfg==null?"":cfg.optString("tagline","");
        String address=cfg==null||!cfg.optBoolean("printShopAddress",true)?"":cfg.optString("address","");
        String mobile=cfg==null||!cfg.optBoolean("printShopMobile",true)?"":shopMobileText(cfg);
        String customer=bill==null?"Walk-in Customer":bill.optString("customer","Walk-in Customer");
        String billNo=bill==null?"":bill.optString("billNo","");
        String date=bill==null?"":formatDate(bill.optString("date",""));
        String customerPhone=bill==null?"":bill.optString("customerPhone","");
        String customerAddress=bill==null?"":bill.optString("customerAddress",bill.optString("address", ""));
        String customerState=bill==null?"":bill.optString("customerState","");
        String customerGstin=bill==null?"":bill.optString("customerGstin","");
        String payment=bill==null?"":bill.optString("paymentMode","");
        boolean shopNameOn = cfg == null || cfg.optBoolean("printShopName", true);
        boolean shopAddressOn = cfg == null || cfg.optBoolean("printShopAddress", true);
        boolean shopMobileOn = cfg == null || cfg.optBoolean("printShopMobile", true);
        boolean shopLogoOn = cfg == null || cfg.optBoolean("printShopLogo", true);
        boolean allShopDetailsOff = !shopNameOn && !shopAddressOn && !shopMobileOn && !shopLogoOn;
        boolean onlyShopNameOn = shopNameOn && !shopAddressOn && !shopMobileOn && !shopLogoOn;
        if (allShopDetailsOff || onlyShopNameOn) {
            // A4/A6 PDF: two-column layout. Customer is left-aligned, invoice metadata right-aligned.
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.8f); p.setColor(black); p.setTypeface(Typeface.DEFAULT);
            drawOutlineRect(c,p,left,top,right,bottom);
            float mid=(left+right)/2f;
            c.drawLine(mid,top,mid,bottom,p);
            p.setStyle(Paint.Style.FILL); p.setColor(black); p.setTextAlign(Paint.Align.LEFT);
            p.setTypeface(Typeface.DEFAULT_BOLD); setPdfTextSize(p, 10.5f, cfg);
            drawText(c,p,"CUSTOMER DETAILS",left+8,top+16);
            float cy=top+34;
            if (onlyShopNameOn) {
                p.setColor(red); p.setTypeface(Typeface.DEFAULT_BOLD); setPdfTextSize(p, 11.5f, cfg);
                float maxShopWidth=mid-left-16;
                String visibleShopName=shopName==null||shopName.trim().isEmpty()?"Your Shop":shopName.trim();
                drawCenteredFitText(c,p,visibleShopName,left+8+maxShopWidth/2f,cy,maxShopWidth);
                cy+=17; // visible separation between shop name and customer name
            }
            p.setColor(black); p.setTypeface(Typeface.DEFAULT_BOLD); setPdfTextSize(p, 9.2f, cfg);
            drawText(c,p,"Name: "+trimText(customer,30),left+8,cy); cy+=13;
            p.setTypeface(Typeface.DEFAULT); setPdfTextSize(p, 8.5f, cfg);
            if(!customerPhone.isEmpty() && cy<bottom-8){drawLabelValue(c,p,"Mobile: ",trimText(customerPhone,25),left+8,cy);cy+=12;}
            if(taxInvoice && !customerAddress.isEmpty() && cy<bottom-8){float addressX=left+8;float labelW=p.measureText("Address: ");java.util.List<String> addressLines=wrapLabeledAddress(customerAddress,p,Math.max(20,mid-left-16),labelW);if(!addressLines.isEmpty()){drawLabelValue(c,p,"Address: ",trimText(addressLines.get(0),35),addressX,cy);cy+=11;for(int ai=1;ai<addressLines.size()&&cy<bottom-6;ai++){drawText(c,p,trimText(addressLines.get(ai),35),addressX,cy);cy+=11;}}}
            if(taxInvoice && !customerGstin.isEmpty() && cy<bottom-6){drawLabelValue(c,p,"Customer GSTIN: ",trimText(customerGstin,22),left+8,cy);cy+=11;}
            if(taxInvoice && !customerState.isEmpty() && cy<bottom-6){drawText(c,p,"State: "+trimText(customerState,25),left+8,cy);}

            float rx=mid+8, rwidth=right-mid-16;
            p.setColor(black); p.setTypeface(Typeface.DEFAULT_BOLD); setPdfTextSize(p, 12.5f, cfg);
            drawCenteredFitText(c,p,taxInvoice?"TAX INVOICE":"CASH MEMO",mid+rwidth/2f,top+18,rwidth);
            p.setTypeface(Typeface.DEFAULT_BOLD); setPdfTextSize(p, 9.2f, cfg);
            drawLabelValue(c,p,"Invoice: ",trimText(billNo,24),rx,top+36);
            p.setTypeface(Typeface.DEFAULT); setPdfTextSize(p, 8.8f, cfg);
            drawLabelValue(c,p,"Date: ",trimText(date,24),rx,top+49);
            if(!payment.isEmpty()) drawLabelValue(c,p,"Payment: ",trimText(payment,20),rx,top+62);
            if(taxInvoice) {
                String gstin=cfg==null?"":cfg.optString("gstin","");
                String fssai=cfg==null?"":cfg.optString("fssai","");
                String state=cfg==null?"":cfg.optString("businessState","");
                float sy=top+75;
                if(!gstin.isEmpty() && sy<bottom-6){drawLabelValue(c,p,"GSTIN: ",trimText(gstin,24),rx,sy);sy+=11;}
                if(!fssai.isEmpty() && sy<bottom-6){drawLabelValue(c,p,"FSSAI: ",trimText(fssai,24),rx,sy);sy+=11;}
                if((!state.isEmpty() || (placeOfSupply!=null&&!placeOfSupply.trim().isEmpty())) && sy<bottom-6)
                    drawText(c,p,"State/Supply: "+trimText(state+(placeOfSupply==null||placeOfSupply.trim().isEmpty()?"":" / "+placeOfSupply),34),rx,sy);
            }
            p.setStyle(Paint.Style.STROKE); p.setColor(black); p.setTextAlign(Paint.Align.LEFT); p.setTypeface(Typeface.DEFAULT);
            return bottom;
        }
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.8f); p.setColor(black); p.setTypeface(Typeface.DEFAULT);
        drawOutlineRect(c,p,left,top,right,bottom); c.drawLine(left,stripBottom,right,stripBottom,p);
        c.drawLine(shopRight,stripBottom,shopRight,bottom,p); c.drawLine(invoiceRight,stripBottom,invoiceRight,bottom,p);
        if(taxInvoice){c.drawLine(left,a6Header?111:99,shopRight,a6Header?111:99,p);c.drawLine(left,a6Header?142:130,shopRight,a6Header?142:130,p);}
        p.setStyle(Paint.Style.FILL); p.setColor(black); p.setTypeface(Typeface.DEFAULT_BOLD); setPdfTextSize(p, 10.5f, cfg);
        p.setTextAlign(Paint.Align.LEFT); drawText(c,p,taxInvoice?"TAX INVOICE":"CASH MEMO / BILL",left+8,top+15);
        // Keep the top strip clean: omit the decorative SHREE GANESH heading and ORIGINAL copy label.
        // Shop details section: logo at left, text to its right.
        float textX=left+102;
        if(logo!=null && (cfg==null||cfg.optBoolean("printShopLogo",true))){
            float maxW=92,maxH=64,sc=Math.min(maxW/Math.max(1,logo.getWidth()),maxH/Math.max(1,logo.getHeight()));
            float w=logo.getWidth()*sc,h=logo.getHeight()*sc;
            c.drawBitmap(logo,null,new RectF(left+7,stripBottom+5,left+7+w,stripBottom+5+h),p);
            textX=Math.max(textX,left+7+w+8);
        }
        float shopWidth=shopRight-textX-6; p.setTextAlign(Paint.Align.LEFT); p.setColor(red); p.setTypeface(Typeface.DEFAULT_BOLD); float shopNameSize=12.0f; setPdfTextSize(p, shopNameSize, cfg);
        if(cfg==null || cfg.optBoolean("printShopName",true)) {
            String visibleShopName=shopName==null||shopName.trim().isEmpty()?"Your Shop":shopName.trim();
            while(p.measureText(visibleShopName)>shopWidth && shopNameSize>8.0f) { shopNameSize-=0.5f; setPdfTextSize(p, shopNameSize, cfg); }
            drawText(c,p,visibleShopName,textX,stripBottom+18);
        }
        p.setColor(black); setPdfTextSize(p, 8.5f, cfg); float sy=stripBottom+31;
        if(!tagline.trim().isEmpty()){p.setTypeface(Typeface.DEFAULT_BOLD);drawText(c,p,trimText(tagline,38),textX,sy);sy+=13;}
        p.setTypeface(Typeface.DEFAULT);
        if(!address.trim().isEmpty()){
            p.setTypeface(Typeface.DEFAULT_BOLD);drawText(c,p,"Address: ",textX,sy);float ax=textX+p.measureText("Address: ");p.setTypeface(Typeface.DEFAULT);
            float addressMaxY=(taxInvoice?(a6Header?120:108):(a6Header?134:122));
            for(String line:wrapText(address,p,Math.max(20,shopWidth-(ax-textX)))){if(sy>addressMaxY)break;drawText(c,p,line,ax,sy);sy+=11;}
        }
        if(!mobile.isEmpty()&&sy<=94){p.setTypeface(Typeface.DEFAULT_BOLD);drawLabelValue(c,p,"MO: ",mobile,textX,sy);p.setTypeface(Typeface.DEFAULT);}
        // Business statutory details occupy a short, bordered second line.
        setPdfTextSize(p, 8f, cfg); p.setTextAlign(Paint.Align.LEFT);
        String gstin=cfg==null?"":cfg.optString("gstin",""); String fssai=cfg==null?"":cfg.optString("fssai",""); String state=cfg==null?"":cfg.optString("businessState","");
        if(taxInvoice){
            float statutoryX=left+8, statutoryY=a6Header?124:112;
            if(!gstin.isEmpty()){drawLabelValue(c,p,"GSTIN: ",trimText(gstin,24),statutoryX,statutoryY);statutoryX+=p.measureText("GSTIN: "+trimText(gstin,24))+10;}
            if(!fssai.isEmpty())drawLabelValue(c,p,"FSSAI: ",trimText(fssai,24),statutoryX,statutoryY);
            // GST/FSSAI/state/supply details are suppressed on non-GST bills.
            setPdfTextSize(p, 7.2f, cfg);
            if(!state.isEmpty() || (placeOfSupply!=null&&!placeOfSupply.trim().isEmpty())) {
                String supply=placeOfSupply==null?"":placeOfSupply;
                drawLabelValue(c,p,"STATE: ",trimText(state,20),left+8,a6Header?136:122);
                float supplyX=left+8+p.measureText("STATE: "+trimText(state,20))+8;
                drawLabelValue(c,p,"SUPPLY: ",trimText(supply,20),supplyX,a6Header?136:122);
            }
        }
        // Invoice column.
        p.setColor(black); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextAlign(Paint.Align.CENTER); setPdfTextSize(p, 12.5f, cfg);
        drawText(c,p,taxInvoice?"TAX INVOICE":"CASH MEMO",(shopRight+invoiceRight)/2f,stripBottom+20);
        p.setTypeface(Typeface.DEFAULT); setPdfTextSize(p, 9.5f, cfg); drawText(c,p,taxInvoice?"INVOICE NO.":"BILL NO.",(shopRight+invoiceRight)/2f,stripBottom+(taxInvoice?39:35));
        p.setTypeface(Typeface.DEFAULT_BOLD); setPdfTextSize(p, 9.5f, cfg); drawText(c,p,trimText(billNo,17),(shopRight+invoiceRight)/2f,stripBottom+(taxInvoice?53:47));
        p.setTypeface(Typeface.DEFAULT); setPdfTextSize(p, 9.5f, cfg); drawText(c,p,"DATE",(shopRight+invoiceRight)/2f,stripBottom+(taxInvoice?70:61));
        p.setTypeface(Typeface.DEFAULT_BOLD); setPdfTextSize(p, 10, cfg); drawText(c,p,trimText(date,18),(shopRight+invoiceRight)/2f,stripBottom+(taxInvoice?84:74));
        // Customer column.
        float cx=invoiceRight+10; p.setTextAlign(Paint.Align.LEFT); p.setTypeface(Typeface.DEFAULT); setPdfTextSize(p, 9.2f, cfg);
        p.setTypeface(Typeface.DEFAULT_BOLD); drawText(c,p,"M/S.: "+trimText(customer,27),cx,stripBottom+18); p.setTypeface(Typeface.DEFAULT);
        float cy=stripBottom+32;
        if(taxInvoice && !customerAddress.isEmpty()){
            // Address continuation lines align with the left edge of the ADDRESS label (the letter A).
            p.setTypeface(Typeface.DEFAULT_BOLD);
            float labelW=p.measureText("ADDRESS: ");
            p.setTypeface(Typeface.DEFAULT);
            float addressWidth=Math.max(20,right-cx-8);
            java.util.List<String> addressLines=wrapLabeledAddress(customerAddress,p,addressWidth,labelW);
            if(!addressLines.isEmpty()){
                drawLabelValue(c,p,"ADDRESS: ",addressLines.get(0),cx,cy);
                cy+=12;
                for(int ai=1;ai<addressLines.size()&&cy<=bottom-10;ai++){
                    drawText(c,p,addressLines.get(ai),cx,cy);
                    cy+=12;
                }
            }
        }
        setPdfTextSize(p, 8.4f, cfg);
        if(taxInvoice&&!customerState.isEmpty()&&cy<=bottom-10){drawLabelValue(c,p,"STATE: ",trimText(customerState,27),cx,cy);cy+=10;}
        if(taxInvoice&&!customerGstin.isEmpty()&&cy<=bottom-10){drawLabelValue(c,p,"GSTIN: ",trimText(customerGstin,27),cx,cy);cy+=10;}
        String customerFssai=bill==null?"":bill.optString("customerFssai","");
        if(taxInvoice&&!customerFssai.trim().isEmpty()&&cy<=bottom-10){drawLabelValue(c,p,"FSSAI: ",trimText(customerFssai.trim(),27),cx,cy);cy+=10;}
        if(!customerPhone.isEmpty()&&cy<=bottom-10){drawLabelValue(c,p,"MO: ",customerPhone,cx,cy);cy+=10;}
        if(!payment.isEmpty()&&cy<=bottom-6)drawLabelValue(c,p,"PAYMENT: ",trimText(payment,25),cx,cy);
        p.setStyle(Paint.Style.STROKE); p.setColor(black); p.setTextAlign(Paint.Align.LEFT); p.setTypeface(Typeface.DEFAULT);
        return bottom;
    }

    private float drawPdfContinuationHeader(Canvas c, Paint p, int pageWidth, JSONObject cfg, JSONObject bill) {
        // A6 continuation pages use a small identity strip, leaving more room for remaining items.
        final float left=35f, right=560f, top=24f, bottom=62f;
        int black=android.graphics.Color.BLACK;
        String shop=cfg==null?"SiddhiBill":cfg.optString("shopName","SiddhiBill").trim();
        String billNo=bill==null?"":bill.optString("billNo","");
        String date=bill==null?"":formatDate(bill.optString("date",""));
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(0.8f);p.setColor(black);drawOutlineRect(c,p,left,top,right,bottom);
        p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextAlign(Paint.Align.LEFT);setPdfTextSize(p,10f,cfg);
        drawText(c,p,trimText(shop,42),left+7,top+14);
        p.setTypeface(Typeface.DEFAULT);setPdfTextSize(p,8.2f,cfg);
        drawText(c,p,"CONTINUED · INVOICE NO: "+trimText(billNo,22),left+7,top+28);
        p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"DATE: "+date,right-7,top+28);
        p.setStyle(Paint.Style.STROKE);p.setColor(black);p.setTextAlign(Paint.Align.LEFT);
        return bottom;
    }

    private String unitAlias(String unit) {
        if(unit==null)return "pc"; String u=unit.trim().toLowerCase(Locale.US);
        if(u.matches("packet|packets|pack|pk|pkt|pks"))return "pk"; if(u.matches("piece|pieces|pc|pcs"))return "pc";
        if(u.matches("kilogram|kilograms|kilo|kilos|kg|kgs"))return "kg"; if(u.matches("gram|grams|gm|g"))return "g";
        if(u.matches("bottle|bottles"))return "bt"; if(u.matches("box|boxes"))return "bx"; if(u.equals("dozen"))return "dz";
        return u.length()>4?u.substring(0,4):u;
    }

    private byte[] createThermalPdfBytes(String json) throws Exception {
        JSONObject b = new JSONObject(json);
        JSONObject cfg = b.optJSONObject("settings");
        JSONObject customFields = b.optJSONObject("customFields");
        JSONArray items = b.optJSONArray("items");
        boolean is58 = "58mm".equalsIgnoreCase(cfg == null ? "80mm" : cfg.optString("paperSize", "80mm"));
        final int width = is58 ? 164 : 227;
        final int margin = is58 ? 7 : 9;
        final int right = width - margin;
        final boolean taxInvoice = b.optBoolean("taxationEnabled", false);
        final JSONObject tax = calculateTaxSummary(b, cfg);
        final int itemCount = items == null ? 0 : items.length();
        int height = 390 + itemCount * (taxInvoice ? 46 : 36);
        if (b.optBoolean("includeItemComments", false) && items != null) {
            for (int i=0;i<items.length();i++) {
                JSONObject item=items.optJSONObject(i);
                if(item!=null&&!item.optString("comment","").trim().isEmpty()) height+=12;
            }
        }
        JSONArray gstGroups = tax.optJSONArray("groups");
        int gstCount = taxInvoice && gstGroups != null ? gstGroups.length() : 0;
        height += gstCount * 17 + (taxInvoice ? 28 : 0);
        JSONArray transactions = b.optBoolean("includeLast5Transactions", false) ? b.optJSONArray("last5Transactions") : null;
        int txnCount = transactions == null ? 0 : Math.min(5, transactions.length());
        height += txnCount * 35 + (txnCount > 0 ? 20 : 0);
        String overallComment = b.optString("overallComment", "").trim();
        if (b.optBoolean("includeOverallComment", false) && !overallComment.isEmpty()) height += 24 + Math.max(0, wrapPlain(overallComment, is58 ? 26 : 38).size()-1) * 9;
        String configuredTermsForHeight = cfg == null ? "" : cfg.optString("termsConditions", "").trim();
        if (cfg != null && cfg.optBoolean("printTermsConditions", false) && !configuredTermsForHeight.isEmpty()) height += 16 + Math.max(0, wrapPlain(configuredTermsForHeight, is58 ? 27 : 40).size()-1) * 9;
        if (cfg != null && cfg.optBoolean("upiQrEnabled", false)) height += is58 ? 100 : 116;
        PdfDocument doc = new PdfDocument();
        PdfDocument.Page page = doc.startPage(new PdfDocument.PageInfo.Builder(width, Math.max(height, 420), 1).create());
        Canvas c = page.getCanvas();
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(android.graphics.Color.BLACK); p.setStrokeWidth(0.65f); p.setStyle(Paint.Style.STROKE);
        Bitmap logo = loadLogo(cfg);
        float y = 8f;
        if (logo != null && (cfg == null || cfg.optBoolean("printShopLogo", true))) {
            float maxW = is58 ? 36f : 47f, maxH = is58 ? 32f : 39f;
            float sc = Math.min(maxW / Math.max(1, logo.getWidth()), maxH / Math.max(1, logo.getHeight()));
            float lw = logo.getWidth() * sc, lh = logo.getHeight() * sc;
            c.drawBitmap(logo, null, new RectF((width-lw)/2f, y, (width+lw)/2f, y+lh), p);
            y += (int)lh + 2;
        }
        p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD);
        String shop = cfg == null ? "DUKAAN BILL" : cfg.optString("shopName", "DUKAAN BILL").trim();
        p.setTextSize(is58 ? 9.5f : 12f);
        while (p.measureText(shop) > width - margin * 2 && p.getTextSize() > 7f) p.setTextSize(p.getTextSize() - 0.5f);
        if (cfg == null || cfg.optBoolean("printShopName", true)) { drawText(c,p,shop,width/2f,y+10); y+=13; }
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(is58 ? 6.3f : 7.4f);
        String tagline = cfg == null ? "" : cfg.optString("tagline", "").trim();
        if (!tagline.isEmpty()) { for (String line : wrapText(tagline,p,width-margin*2)) { drawText(c,p,line,width/2f,y+8); y+=9; } }
        String address = cfg == null || !cfg.optBoolean("printShopAddress",true) ? "" : cfg.optString("address","").trim();
        if (!address.isEmpty()) { for (String line : wrapText(address,p,width-margin*2)) { drawText(c,p,line,width/2f,y+8); y+=9; } }
        String mobiles = cfg == null || !cfg.optBoolean("printShopMobile",true) ? "" : shopMobileText(cfg);
        if (!mobiles.isEmpty()) { p.setTypeface(Typeface.DEFAULT_BOLD); drawText(c,p,"MO: "+mobiles,width/2f,y+8); p.setTypeface(Typeface.DEFAULT); y+=10; }
        if (taxInvoice && cfg != null) {
            String gstin=cfg.optString("gstin","").trim(), fssai=cfg.optString("fssai","").trim();
            if(!gstin.isEmpty()){drawLabelValue(c,p,"GSTIN: ",gstin,width/2f,y+8);y+=9;}
            if(!fssai.isEmpty()){drawLabelValue(c,p,"FSSAI: ",fssai,width/2f,y+8);y+=9;}
        }
        y+=3; p.setStyle(Paint.Style.STROKE); drawOutlineRect(c,p,margin,y,right,y+17); p.setStyle(Paint.Style.FILL);
        p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(is58?8f:9.5f); drawText(c,p,taxInvoice?"TAX INVOICE / BILL":(cfg==null?"CASH MEMO / BILL":cfg.optString("billTitle","CASH MEMO / BILL")),width/2f,y+12); y+=17;
        // Compact thermal metadata: paired bill/date row followed by full-width customer fields.
        String billNo=b.optString("billNo",""); String date=formatDate(b.optString("date",""));
        String customer=b.optString("customer","Walk-in Customer").trim(); String phone=b.optString("customerPhone","").trim();
        String customerAddress=b.optString("customerAddress",b.optString("address","")).trim();
        int rowH=is58?12:14; float mid=width/2f;
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(is58?5.8f:6.6f); p.setTextAlign(Paint.Align.LEFT);
        p.setStyle(Paint.Style.STROKE); drawOutlineRect(c,p,margin,y,right,y+rowH); c.drawLine(mid,y,mid,y+rowH,p); p.setStyle(Paint.Style.FILL);
        drawLabelValue(c,p,"Bill No: #",trimText(billNo,is58?21:28),margin+3,y+rowH-3);
        drawText(c,p,trimText("Date: "+date,is58?22:29),mid+3,y+rowH-3); y+=rowH;
        if(!customer.isEmpty()&&!"Walk-in Customer".equalsIgnoreCase(customer)){p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+rowH);p.setStyle(Paint.Style.FILL);drawLabelValue(c,p,"Customer: ",trimText(customer,is58?27:40),margin+3,y+rowH-3);y+=rowH;}
        if(!customerAddress.isEmpty()){for(String line:wrapText("Address: "+customerAddress,p,width-margin*2-6)){p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+rowH);p.setStyle(Paint.Style.FILL);drawText(c,p,line,margin+3,y+rowH-3);y+=rowH;}}
        if(!phone.isEmpty()){p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+rowH);p.setStyle(Paint.Style.FILL);drawLabelValue(c,p,"Mobile: ",trimText(phone,is58?29:43),margin+3,y+rowH-3);y+=rowH;}
        if(taxInvoice){String customerGstin=b.optString("customerGstin","").trim();String customerFssai=b.optString("customerFssai","").trim();String customerState=b.optString("customerState","").trim();
            if(!customerGstin.isEmpty()){p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+rowH);p.setStyle(Paint.Style.FILL);drawLabelValue(c,p,"Customer GSTIN: ",trimText(customerGstin,is58?22:37),margin+3,y+rowH-3);y+=rowH;}
            if(!customerFssai.isEmpty()){p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+rowH);p.setStyle(Paint.Style.FILL);drawLabelValue(c,p,"Customer FSSAI: ",trimText(customerFssai,is58?22:37),margin+3,y+rowH-3);y+=rowH;}
            if(!customerState.isEmpty()){p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+rowH);p.setStyle(Paint.Style.FILL);drawLabelValue(c,p,"Customer State: ",trimText(customerState,is58?22:37),margin+3,y+rowH-3);y+=rowH;}
        }
        String paymentMode=b.optString("paymentMode","Cash").trim(); if(!paymentMode.isEmpty()){p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+rowH);p.setStyle(Paint.Style.FILL);drawLabelValue(c,p,"Payment: ",trimText(paymentMode,is58?29:43),margin+3,y+rowH-3);y+=rowH;}
        JSONObject cf=customFields;
        if(cfg!=null&&cf!=null){String[] keys={"field1","field2","field3"};String[] labels={"customBillField1Label","customBillField2Label","customBillField3Label"};String[] pos={"customBillField1Position","customBillField2Position","customBillField3Position"};for(int i=0;i<3;i++){String l=cfg.optString(labels[i],"").trim(),v=cf.optString(keys[i],"").trim();if(!l.isEmpty()&&!v.isEmpty()&&"header".equalsIgnoreCase(cfg.optString(pos[i],i==2?"footer":"header"))){if(l.toLowerCase(Locale.US).contains("warranty"))v=formatDate(v);String customLine=l+": "+v;for(String line:wrapText(customLine,p,width-margin*2-6)){p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+rowH);p.setStyle(Paint.Style.FILL);p.setTextSize(is58?5.8f:6.6f);drawText(c,p,trimText(line,is58?38:53),margin+3,y+rowH-3);y+=rowH;}}}}
        y+=2;
        // Spreadsheet-style item grid: white background, thin black borders, no filled cells.
        float[] cols;
        if(taxInvoice) cols=is58?new float[]{margin,margin+10,margin+50,margin+65,margin+78,margin+96,margin+114,right}:new float[]{margin,margin+13,margin+73,margin+93,margin+111,margin+138,margin+163,right};
        else cols=is58?new float[]{margin,margin+10,margin+58,margin+73,margin+89,margin+111,right}:new float[]{margin,margin+16,margin+91,margin+113,margin+137,margin+169,right};
        int headH=is58?15:17; p.setStyle(Paint.Style.STROKE); drawOutlineRect(c,p,margin,y,right,y+headH);
        for(int k=1;k<cols.length-1;k++)c.drawLine(cols[k],y,cols[k],y+headH,p);
        p.setStyle(Paint.Style.FILL); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(is58?5.7f:6.7f); p.setTextAlign(Paint.Align.CENTER);
        String[] heads=taxInvoice?new String[]{"Sr.","Item / HSN","Qty","Unit","Rate","GST","Amount"}:new String[]{"Sr.","Item","Qty","Unit","Rate","Amount"};
        for(int k=0;k<heads.length;k++)drawText(c,p,heads[k],(cols[k]+cols[k+1])/2f,y+headH-4);
        y+=headH;
        if(items!=null)for(int i=0;i<items.length();i++){
            JSONObject it=items.optJSONObject(i); if(it==null)continue;
            String name=it.optString("name","").trim(); String hsn=it.optString("hsn",it.optString("hsnCode","")).trim();
            String qty=formatBillQuantity(it.optString("qty",""));String unit=unitAlias(it.optString("unit","piece"));double rate=it.optDouble("rate",0);double amount=quantityValue(qty,unit)*rate;
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(is58?5.8f:6.8f);
            float nameWidth=(cols[2]-cols[1])-4f;
            java.util.List<String> nameLines=wrapText(name,p,nameWidth);
            if(nameLines.size()>2){java.util.List<String> keep=new java.util.ArrayList<>();keep.add(nameLines.get(0));keep.add(nameLines.get(1));nameLines=keep;}
            int itemLines=Math.max(1,nameLines.size())+(taxInvoice&&!hsn.isEmpty()?1:0);
            int rh=is58?Math.max(17,8+itemLines*7):Math.max(20,8+itemLines*8);
            p.setStyle(Paint.Style.STROKE); drawOutlineRect(c,p,margin,y,right,y+rh);for(int k=1;k<cols.length-1;k++)c.drawLine(cols[k],y,cols[k],y+rh,p);
            p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.DEFAULT);p.setTextSize(is58?5.8f:6.8f);p.setTextAlign(Paint.Align.CENTER);drawText(c,p,String.valueOf(i+1),(cols[0]+cols[1])/2f,y+rh/2f+2);
            p.setTextAlign(Paint.Align.LEFT);
            float itemY=y+(is58?8:10);
            for(String nameLine:nameLines){drawText(c,p,nameLine,cols[1]+2,itemY);itemY+=is58?7:8;}
            if(taxInvoice&&!hsn.isEmpty()){p.setTextSize(is58?5.0f:6.0f);drawText(c,p,"HSN: "+hsn,cols[1]+2,itemY);p.setTextSize(is58?5.8f:6.8f);}
            float valueY=y+rh/2f+2;
            drawTextRight(c,p,trimText(qty,5),cols[3]-2,valueY);drawTextRight(c,p,trimText(unit,5),cols[4]-2,valueY);
            p.setTextAlign(Paint.Align.RIGHT);
            if(taxInvoice){
                drawText(c,p,formatBillValue(rate),cols[5]-2,valueY);
                drawTextRight(c,p,String.format(Locale.US,"%.0f%%",it.optDouble("taxRate",0)),cols[6]-2,valueY);
            } else {
                p.setTextAlign(Paint.Align.RIGHT);
                drawText(c,p,formatBillValue(rate),cols[5]-3,valueY);
                p.setTextAlign(Paint.Align.LEFT);
            }
            p.setTextSize(is58?5.0f:6.0f);
            drawTextRight(c,p,formatBillValue(amount),right-2,valueY);
            p.setTextAlign(Paint.Align.LEFT);p.setTextSize(is58?5.8f:6.8f);y+=rh;
            String comment=it.optString("comment","").trim();if(b.optBoolean("includeItemComments",false)&&!comment.isEmpty()){int ch=12;p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+ch);p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.DEFAULT);p.setTextSize(is58?5.6f:6.5f);drawText(c,p,trimText("Comment: "+comment,is58?37:52),margin+3,y+ch-3);y+=ch;}
        }
        double subtotal=b.optDouble("subtotal",0),discount=b.optDouble("discount",0),total=b.optDouble("total",Math.max(0,subtotal-discount));String paymentModeForBalance=b.optString("paymentMode","").trim();boolean creditBill=paymentModeForBalance.toLowerCase(Locale.US).contains("credit");boolean hasPaid=b.has("partialPaymentAmount")||b.has("paidAmount")||b.has("amountPaid");double paid=hasPaid?b.optDouble("partialPaymentAmount",b.optDouble("paidAmount",b.optDouble("amountPaid",0))):0;if(!creditBill&&paid<=0.000001)paid=total;double billBalance=Math.max(0,total-paid);double totalBalance=b.optDouble("customerTotalBalance",billBalance);
        java.util.List<String[]> totals=new java.util.ArrayList<>();totals.add(new String[]{"Subtotal",formatBillValue(subtotal)});if(discount>0.000001)totals.add(new String[]{"Discount","-"+formatBillValue(discount)});if(taxInvoice){totals.add(new String[]{"Taxable Amount",formatBillValue(tax.optDouble("taxable",0))});totals.add(new String[]{"Total GST",formatBillValue(tax.optDouble("tax",0))});}totals.add(new String[]{"Total Amount",formatBillValue(total)});totals.add(new String[]{"Paid",formatBillValue(paid)});if(creditBill){totals.add(new String[]{"Bill Balance",formatBillValue(billBalance)});totals.add(new String[]{"Total Balance",formatBillValue(Math.max(0,totalBalance))});}
        int totalRowH=is58?13:15;float split=margin+(right-margin)*0.56f;
        for(String[] row:totals){p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+totalRowH);c.drawLine(split,y,split,y+totalRowH,p);p.setStyle(Paint.Style.FILL);boolean bold="Total Amount".equals(row[0])||"Bill Balance".equals(row[0])||"Total Balance".equals(row[0]);p.setTypeface(bold?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);p.setTextSize(is58?6f:7f);p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,row[0],split-3,y+totalRowH-4);drawText(c,p,row[1],right-3,y+totalRowH-4);p.setTextAlign(Paint.Align.LEFT);y+=totalRowH;}
        String thermalTerms=cfg==null?"":cfg.optString("termsConditions","").trim();
        boolean showThermalTerms=cfg!=null&&cfg.optBoolean("printTermsConditions",false)&&!thermalTerms.isEmpty();
        if((b.optBoolean("includeOverallComment",false)&&!overallComment.isEmpty())||showThermalTerms){
            int panelTop=(int)y;
            int commentLines=(b.optBoolean("includeOverallComment",false)&&!overallComment.isEmpty())?wrapPlain(overallComment,is58?26:38).size():0;
            int commentH=commentLines>0?12+commentLines*9:0;
            int termsLines=showThermalTerms?wrapPlain(thermalTerms,is58?27:40).size():0;
            int termsH=termsLines>0?12+termsLines*9:0;
            p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,panelTop,right,panelTop+commentH+termsH);p.setStyle(Paint.Style.FILL);
            if(commentH>0){p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(is58?6f:7f);drawText(c,p,"Overall Comment:",margin+3,panelTop+8);p.setTypeface(Typeface.DEFAULT);int lineY=panelTop+17;for(String line:wrapPlain(overallComment,is58?26:38)){drawText(c,p,line,margin+3,lineY);lineY+=9;}}
            if(showThermalTerms){int ty=panelTop+commentH;if(commentH>0){p.setStyle(Paint.Style.STROKE);c.drawLine(margin,ty,right,ty,p);p.setStyle(Paint.Style.FILL);}p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(is58?5.7f:6.7f);drawText(c,p,"Terms & Conditions:",margin+3,ty+9);p.setTypeface(Typeface.DEFAULT);int lineY=ty+18;for(String line:wrapPlain(thermalTerms,is58?27:40)){drawText(c,p,line,margin+3,lineY);lineY+=9;}}
            y+=commentH+termsH;
        }
        // GST rate-wise summary, rather than repeating overall CGST/SGST/IGST totals.
        if(taxInvoice&&gstGroups!=null&&gstGroups.length()>0){
            boolean interState=tax.optBoolean("inter",false);
            p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+14);p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(is58?6f:7f);p.setTextAlign(Paint.Align.LEFT);drawText(c,p,"GST RATE SUMMARY",margin+3,y+10);y+=14;
            float usable=right-margin; float[] gx=interState?new float[]{margin,margin+usable*.20f,margin+usable*.58f,right}:new float[]{margin,margin+usable*.18f,margin+usable*.50f,margin+usable*.75f,right};
            int gh=is58?13:14; p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+gh);for(int k=1;k<gx.length-1;k++)c.drawLine(gx[k],y,gx[k],y+gh,p);p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(is58?4.8f:5.8f);p.setTextAlign(Paint.Align.CENTER);
            String[] ghead=interState?new String[]{"Rate","Taxable","IGST"}:new String[]{"Rate","Taxable","CGST","SGST"};for(int k=0;k<ghead.length;k++)drawText(c,p,ghead[k],(gx[k]+gx[k+1])/2f,y+gh-3);y+=gh;
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(is58?4.8f:5.8f);
            for(int gi=0;gi<gstGroups.length();gi++){JSONObject g=gstGroups.optJSONObject(gi);if(g==null)continue;p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+gh);for(int k=1;k<gx.length-1;k++)c.drawLine(gx[k],y,gx[k],y+gh,p);p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);String[] vals=interState?new String[]{String.format(Locale.US,"%.0f%%",g.optDouble("rate",0)),formatBillValue(g.optDouble("taxable",0)),formatBillValue(g.optDouble("tax",0))}:new String[]{String.format(Locale.US,"%.0f%%",g.optDouble("rate",0)),formatBillValue(g.optDouble("taxable",0)),formatBillValue(g.optDouble("tax",0)/2.0),formatBillValue(g.optDouble("tax",0)/2.0)};for(int k=0;k<vals.length;k++)drawText(c,p,trimText(vals[k],is58?10:14),(gx[k]+gx[k+1])/2f,y+gh-3);y+=gh;}
        }
        if(txnCount>0){
            y+=4;float balCol=margin+(right-margin)*0.68f;p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+13);c.drawLine(balCol,y,balCol,y+13,p);p.setStyle(Paint.Style.FILL);
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(is58?5.5f:6.4f);p.setTextAlign(Paint.Align.LEFT);drawText(c,p,"Last 5 Customer Transactions",margin+3,y+9);p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"Total Balance",right-3,y+9);p.setTextAlign(Paint.Align.LEFT);y+=13;
            p.setTypeface(Typeface.DEFAULT);
            for(int i=0;i<txnCount;i++){
                JSONObject tr=transactions.optJSONObject(i);if(tr==null)continue;
                String dt=formatDate(tr.optString("date",""));
                String type=tr.optString("type","").replace("Credit sale","Credit").replace("Payment received","Payment");
                String ref=tr.optString("reference","");
                String txnTypeLower=type.toLowerCase(Locale.US);
                boolean credit=txnTypeLower.contains("credit");
                boolean paymentTxn=txnTypeLower.contains("payment")||txnTypeLower.contains("receipt")||txnTypeLower.equals("pay");
                boolean saleTxn=!paymentTxn&&(credit||txnTypeLower.contains("sale")||txnTypeLower.contains("cash")||txnTypeLower.contains("bill"));
                double txnAmount=saleTxn?tr.optDouble("billTotal",tr.optDouble("total",tr.optDouble("amount",0))):0;
                double paidTxn=credit?tr.optDouble("paymentAmount",tr.optDouble("paid",0)):(saleTxn?txnAmount:tr.optDouble("paymentAmount",tr.optDouble("amount",0)));
                double previousBal=tr.optDouble("previousBalance",tr.optDouble("previous_balance",0));
                double bal=tr.optDouble("balance",tr.optDouble("balanceDue",0));
                int txnRowH=34;p.setStyle(Paint.Style.STROKE);drawOutlineRect(c,p,margin,y,right,y+txnRowH);p.setStyle(Paint.Style.FILL);
                p.setTextSize(is58?5.0f:5.8f);p.setTextAlign(Paint.Align.LEFT);
                drawText(c,p,trimText(dt+" · "+type,is58?14:20),margin+3,y+9);
                drawText(c,p,trimText("P.Bal: "+formatBillValue(previousBal),is58?18:24),margin+3,y+22);
                float midCol=margin+(right-margin)*0.48f;drawText(c,p,trimText(ref,is58?14:22),midCol,y+9);
                p.setTextAlign(Paint.Align.RIGHT);p.setTypeface(Typeface.DEFAULT_BOLD);drawText(c,p,"Bill: "+formatBillValue(txnAmount),right-3,y+9);p.setTypeface(Typeface.DEFAULT);drawText(c,p,"Paid: "+formatBillValue(paidTxn),right-3,y+20);p.setTypeface(Typeface.DEFAULT_BOLD);drawText(c,p,"T.Bal: "+formatBillValue(bal),right-3,y+31);p.setTypeface(Typeface.DEFAULT);p.setTextAlign(Paint.Align.LEFT);
                y+=txnRowH;
            }
        }
        y+=5;p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(is58?7f:8.5f);drawText(c,p,"Thank you for shopping with us!",width/2f,y+9);y+=14;
        if(cfg!=null&&cfg.optBoolean("upiQrEnabled",false)){int qrSize=is58?62:78;drawCenteredBillQr(c,p,b,cfg,(int)(width/2f),(int)(y+4),qrSize);y+=qrSize+(cfg.optBoolean("upiPrintAmount",true)?22:8);}
        String footer=cfg==null?"":cfg.optString("footer","").trim();if(!footer.isEmpty()&&!footer.equalsIgnoreCase("Thank you for shopping with us!")&&!footer.equalsIgnoreCase("Thank you for shopping with us")){p.setTypeface(Typeface.DEFAULT);p.setTextSize(is58?5.5f:6.5f);for(String line:wrapText(footer,p,width-margin*2)){drawText(c,p,line,width/2f,y+8);y+=9;}}
        y+=3;
        p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.ITALIC));p.setTextSize(is58?5.1f:6.0f);String creator=cfg==null?"Bill created by SiddhiBill • Contact 8087794271":cfg.optString("creditFooter","Bill created by SiddhiBill • Contact 8087794271").trim();if(!creator.isEmpty())for(String line:wrapText(creator,p,width-margin*2)){drawText(c,p,line,width/2f,y+8);y+=9;}
        doc.finishPage(page);ByteArrayOutputStream out=new ByteArrayOutputStream();doc.writeTo(out);doc.close();if(logo!=null&&!logo.isRecycled())logo.recycle();return out.toByteArray();
    }

    // ESC/POS helpers used by the direct 80 mm thermal-print path.
    // Keep these methods on MainActivity so all print paths resolve the same implementation.
    private void escCmd(OutputStream out, int... values) throws java.io.IOException {
        if (out == null || values == null) return;
        for (int value : values) out.write(value & 0xFF);
    }

    private void escLine(OutputStream out, String line) throws java.io.IOException {
        if (out == null) return;
        String safe = line == null ? "" : line;
        out.write(safe.getBytes(java.nio.charset.Charset.forName("UTF-8")));
        out.write(new byte[]{0x0D, 0x0A});
    }

    /**
     * Prints a logo as a monochrome ESC/POS raster image (GS v 0).
     * The image is resized proportionally to maxWidth and converted to 1-bit black/white.
     */
    private void writeEscPosBitmap(OutputStream out, Bitmap source, int maxWidth) throws java.io.IOException {
        if (out == null || source == null || source.isRecycled()) return;
        int targetWidth = Math.max(8, Math.min(maxWidth, source.getWidth()));
        targetWidth = (targetWidth / 8) * 8;
        int targetHeight = Math.max(1, Math.round(source.getHeight() * (targetWidth / (float) source.getWidth())));
        Bitmap scaled = Bitmap.createScaledBitmap(source, targetWidth, targetHeight, true);
        int widthBytes = (targetWidth + 7) / 8;
        byte[] raster = new byte[widthBytes * targetHeight];
        for (int y = 0; y < targetHeight; y++) {
            for (int x = 0; x < targetWidth; x++) {
                int color = scaled.getPixel(x, y);
                int alpha = android.graphics.Color.alpha(color);
                int luminance = (android.graphics.Color.red(color) * 299
                        + android.graphics.Color.green(color) * 587
                        + android.graphics.Color.blue(color) * 114) / 1000;
                // Transparent pixels are white; a threshold keeps thermal logos crisp.
                if (alpha > 16 && luminance < 170) {
                    raster[y * widthBytes + (x / 8)] |= (byte) (0x80 >> (x % 8));
                }
            }
        }
        if (scaled != source && !scaled.isRecycled()) scaled.recycle();
        out.write(new byte[]{0x1D, 0x76, 0x30, 0x00,
                (byte) (widthBytes & 0xFF), (byte) ((widthBytes >> 8) & 0xFF),
                (byte) (targetHeight & 0xFF), (byte) ((targetHeight >> 8) & 0xFF)});
        out.write(raster);
        out.write(new byte[]{0x0D, 0x0A});
        out.flush();
    }

    // Native ESC/POS text tables. Keep receipt content in printer text mode (not a scaled bitmap).
    // The KP307-UEWB's standard ESC/POS profile does not expose a portable vector-line command;
    // use full-width native rule characters for separators and avoid rasterizing/shrinking table text.
    private String thermalAscii(String value) {
        if (value == null) return "";
        return value.replace("₹", "Rs.").replace("•", "-").replace("–", "-").replace("—", "-")
                .replaceAll("[^\\x20-\\x7E]", "?").replaceAll("\\s+", " ").trim();
    }
    private String thermalFit(String value, int width, boolean right) {
        String v=thermalAscii(value);
        if(v.length()>width) v=v.substring(0,Math.max(0,width-1))+"~";
        if(v.length()<width){String pad=repeatChar(' ',width-v.length());v=right?pad+v:v+pad;}
        return v;
    }
    private String repeatChar(char ch,int count){StringBuilder b=new StringBuilder(Math.max(0,count));for(int i=0;i<count;i++)b.append(ch);return b.toString();}
    private java.util.List<String> thermalWrap(String value,int width){
        java.util.ArrayList<String> out=new java.util.ArrayList<>();String v=thermalAscii(value);
        if(v.isEmpty()){out.add("");return out;}
        while(v.length()>width){int cut=v.lastIndexOf(' ',width);if(cut<1)cut=width;out.add(v.substring(0,cut).trim());v=v.substring(cut).trim();}
        if(!v.isEmpty())out.add(v);return out;
    }
    private void thermalRule(OutputStream out) throws Exception {
        // Solid 576-dot rule. Do not append CR/LF here: the raster command advances
        // the paper for the rule itself, and an extra CR/LF creates a blank line after it.
        if (out == null) return;
        final int widthBytes = 72;
        final int height = 2;
        escCmd(out, 0x1D, 0x76, 0x30, 0x00, widthBytes & 0xFF, (widthBytes >> 8) & 0xFF,
                height & 0xFF, (height >> 8) & 0xFF);
        byte[] solid = new byte[widthBytes * height];
        java.util.Arrays.fill(solid, (byte) 0xFF);
        out.write(solid);
        out.flush();
    }
    private void thermalRuleGap(OutputStream out) throws Exception {
        // Add a subtle 1 mm feed after item separators so adjacent rows do not look cramped.
        // ESC J feeds n vertical dots; 8 dots is approximately 1 mm on a 203 dpi printer.
        escCmd(out, 0x1B, 0x4A, 8);
    }
    private void writeThermalItemTableText(OutputStream out, JSONArray items, boolean tax, JSONObject bill, JSONObject cfg) throws Exception {
        // Native Font A text, fixed 48-column layout. Keep item names on their own line
        // so descriptions remain readable and numeric columns stay aligned.
        // Keep a subtle ~1 mm gap after the solid separator before the column labels.
        thermalRuleGap(out);
        escCmd(out,0x1B,0x21,0x00); escCmd(out,0x1B,0x45,0x01);
        String header = thermalFit("NO",2,false)+" "+thermalFit("ITEM/HSN",14,false)+" "+thermalFit("QTY",4,true)+" "+thermalFit("UNIT",4,true)+" "+thermalFit("RATE",6,true);
        if(tax) header += " "+thermalFit("GST",4,true)+" "+thermalFit("AMOUNT",7,true);
        else header += " "+thermalFit("AMOUNT",11,true);
        escLine(out,header.substring(0,Math.min(48,header.length())));
        escCmd(out,0x1B,0x45,0x00); thermalRule(out); thermalRuleGap(out);
        if(items!=null) for(int i=0;i<items.length();i++){
            JSONObject it=items.optJSONObject(i);if(it==null)continue;
            String name=it.optString("name","").trim();
            if(cfg!=null&&cfg.optBoolean("printItemCode",false)){String code=it.optString("itemCode","").trim();if(!code.isEmpty())name=code+" - "+name;}
            String qty=formatBillQuantity(it.optString("qty",""));String unit=unitAlias(it.optString("unit","piece"));
            double rate=it.optDouble("rate",0), amount=quantityValue(qty,unit)*rate;
            String gst=String.format(Locale.US,"%.0f",it.optDouble("taxRate",0));
            // Keep the first part of the item name on the numeric row, then print any
            // remaining name on indented continuation rows instead of truncating it.
            java.util.List<String> nameLines=thermalWrap(name,14);
            String firstName=nameLines.isEmpty()?"":nameLines.get(0);
            String line=thermalFit(String.valueOf(i+1),2,true)+" "+thermalFit(firstName,14,false)+" "+thermalFit(qty,4,true)+" "+thermalFit(unit,4,true)+" "+thermalFit(formatBillValue(rate),6,true);
            if(tax) line+=" "+thermalFit(gst,4,true)+" "+thermalFit(formatBillValue(amount),7,true);
            else line+=" "+thermalFit(formatBillValue(amount),11,true);
            escLine(out,line.substring(0,Math.min(48,line.length())));
            for(int ni=1;ni<nameLines.size();ni++) escLine(out,"   "+nameLines.get(ni));
            String hsn=it.optString("hsn",it.optString("hsnCode","")).trim();
            if(tax&&!hsn.isEmpty()) for(String ln:thermalWrap(hsn,45))escLine(out,"   "+ln);
            String comment=it.optString("comment","").trim();if(bill.optBoolean("includeItemComments",false)&&!comment.isEmpty())for(String ln:thermalWrap("Note: "+comment,45))escLine(out,"   "+ln);
            thermalRule(out); thermalRuleGap(out);
        }
        escCmd(out,0x1B,0x21,0x00);
    }
    private void writeThermalGstSummaryText(OutputStream out, JSONObject summary) throws Exception {
        if(summary==null)return;JSONArray groups=summary.optJSONArray("groups");if(groups==null||groups.length()==0)return;
        boolean inter=summary.optBoolean("inter",false);
        escCmd(out,0x1B,0x45,0x01);escCmd(out,0x1B,0x21,0x10);escLine(out,"GST RATE SUMMARY");escCmd(out,0x1B,0x21,0x00);escCmd(out,0x1B,0x45,0x00);
        thermalRule(out); thermalRuleGap(out);
        String gstHeader=thermalFit("RATE",6,false)+" "+thermalFit("TAXABLE",12,true)+(inter?" "+thermalFit("IGST",27,true):" "+thermalFit("CGST",12,true)+" "+thermalFit("SGST",12,true));
        escLine(out,gstHeader.substring(0,Math.min(48,gstHeader.length())));thermalRule(out);thermalRuleGap(out);
        for(int i=0;i<groups.length();i++){
            JSONObject g=groups.optJSONObject(i);if(g==null)continue;double rate=g.optDouble("rate",0),taxable=g.optDouble("taxable",0),tax=g.optDouble("tax",0);
            String row=thermalFit(String.format(Locale.US,"%.0f%%",rate),6,false)+" "+thermalFit(formatBillValue(taxable),12,true);
            if(inter)row+=" "+thermalFit(formatBillValue(tax),27,true);
            else row+=" "+thermalFit(formatBillValue(tax/2.0),12,true)+" "+thermalFit(formatBillValue(tax/2.0),12,true);
            escLine(out,row.substring(0,Math.min(48,row.length())));
        }
        thermalRule(out); thermalRuleGap(out);
    }
    private void writeThermalTransactionsText(OutputStream out, JSONArray recent) throws Exception {
        if(recent==null||recent.length()==0)return;
        escCmd(out,0x1B,0x45,0x01);escCmd(out,0x1B,0x21,0x10);escLine(out,"LAST 5 TRANSACTIONS");escCmd(out,0x1B,0x21,0x00);escCmd(out,0x1B,0x45,0x00);
        thermalRule(out); thermalRuleGap(out);
        escLine(out,thermalFit("DATE / TYPE",17,false)+" "+thermalFit("BILL / TXN NO.",18,false)+" "+thermalFit("AMOUNT",11,true));
        thermalRule(out); thermalRuleGap(out);
        int count=Math.min(5,recent.length());
        for(int i=0;i<count;i++){
            JSONObject tr=recent.optJSONObject(i);if(tr==null)continue;
            String raw=tr.optString("date","");String dt=raw.length()>=10?raw.substring(8,10)+"/"+raw.substring(5,7)+"/"+raw.substring(2,4):raw;
            String typ=tr.optString("type","").trim();String lt=typ.toLowerCase(Locale.US);if(lt.contains("credit"))typ="Cr.";else if(lt.contains("cash"))typ="Cash";else if(lt.contains("payment"))typ="Pay";else if(lt.contains("upi"))typ="UPI";
            String ref=tr.optString("reference","");boolean sale=lt.contains("credit")||lt.contains("sale")||lt.contains("cash");
            boolean paymentTxn=lt.contains("payment")||lt.contains("receipt")||lt.equals("pay");
            boolean saleTxn=!paymentTxn&&(sale||lt.contains("bill"));
            double billAmt=saleTxn?tr.optDouble("billTotal",tr.optDouble("total",tr.optDouble("amount",0))):0;
            double paid=lt.contains("credit")?tr.optDouble("paymentAmount",tr.optDouble("paid",0)):(saleTxn?billAmt:tr.optDouble("paymentAmount",tr.optDouble("paid",tr.optDouble("amount",0))));
            double prev=tr.optDouble("previousBalance",tr.optDouble("previous_balance",0));
            double bal=tr.optDouble("balance",tr.optDouble("balanceDue",0));
            // Date/reference plus compact amount rows. P.Bal is printed for every transaction.
            escLine(out,thermalFit(dt+" "+typ,17,false)+" "+thermalFit(ref,30,false));
            escLine(out,thermalFit("Bill: "+formatBillValue(billAmt),16,false)+" "+thermalFit("Paid: "+formatBillValue(paid),15,false)+" "+thermalFit("P.Bal: "+formatBillValue(prev),15,true));
            escLine(out,thermalFit("",16,false)+" "+thermalFit("",15,false)+" "+thermalFit("T.Bal: "+formatBillValue(bal),15,true));
            thermalRule(out); thermalRuleGap(out);
        }
    }

    // Raster-rendered thermal tables: real solid grid lines, independent of printer font metrics.
    // The PDF renderer is intentionally untouched. 384 dots is a conservative printable width
    // for common 80 mm ESC/POS printers and avoids text-mode wrapping of table borders.
    private void writeThermalItemTableBitmap(OutputStream out, JSONArray items, boolean tax, JSONObject bill, JSONObject cfg) throws Exception {
        final int w=576, left=3, right=w-3;
        // Use the full printable width of a typical 80 mm / 576-dot ESC/POS printer.
        final int[] widths = tax ? new int[]{28,166,58,48,70,58,142} : new int[]{28,200,58,48,70,166};
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(Color.BLACK); p.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.NORMAL)); p.setTextSize(20f); p.setStrokeWidth(2.0f);
        java.util.ArrayList<String[]> rows=new java.util.ArrayList<>();
        rows.add(tax?new String[]{"Sr.","Item / HSN","Qty","Unit","Rate","GST","Amount"}:new String[]{"Sr.","Item / HSN","Qty","Unit","Rate","Amount"});
        java.util.ArrayList<Integer> heights=new java.util.ArrayList<>(); heights.add(46);
        if(items!=null) for(int i=0;i<items.length();i++){
            JSONObject it=items.optJSONObject(i); if(it==null)continue;
            String name=it.optString("name","").trim(); if(cfg!=null&&cfg.optBoolean("printItemCode",false)){String code=it.optString("itemCode","").trim();if(!code.isEmpty())name=code+" - "+name;}
            String hsn=it.optString("hsn",it.optString("hsnCode","")).trim(); String qty=formatBillQuantity(it.optString("qty","")); String unit=unitAlias(it.optString("unit","piece")); double rate=it.optDouble("rate",0); double amount=quantityValue(qty,unit)*rate;
            rows.add(new String[]{String.valueOf(i+1),name,qty,unit,formatBillValue(rate),tax?String.format(Locale.US,"%.0f%%",it.optDouble("taxRate",0)):"",formatBillValue(amount)});
            int extra=(tax&&!hsn.isEmpty()?21:0)+(bill.optBoolean("includeItemComments",false)&&!it.optString("comment","").trim().isEmpty()?21:0); heights.add(52+extra);
        }
        int totalH=0; for(int h:heights) totalH+=h; Bitmap bmp=Bitmap.createBitmap(w,Math.max(1,totalH+2),Bitmap.Config.ARGB_8888); Canvas c=new Canvas(bmp); c.drawColor(Color.WHITE);
        int y=0; int cols=tax?7:6;
        for(int ri=0;ri<rows.size();ri++){
            int rh=heights.get(ri); p.setTypeface(ri==0?Typeface.create(Typeface.MONOSPACE,Typeface.BOLD):Typeface.create(Typeface.MONOSPACE,Typeface.NORMAL));
            c.drawLine(left,y,right,y,p); int x=left; c.drawLine(x,y,x,y+rh,p);
            String[] row=rows.get(ri);
            for(int ci=0;ci<cols;ci++){
                int cw=widths[ci]; c.drawLine(x+cw,y,x+cw,y+rh,p);
                String value=(!tax&&ri>0&&ci==5)?row[6]:row[ci];
                if(ri==0){p.setTextSize(19f); String h=ci==1?(tax?"Item / HSN":"Item / HSN"):value; c.drawText(trimText(h,ci==1?17:9),x+3,y+30,p);}
                else if(ci==1){p.setTextSize(24f); c.drawText(trimText(value,Math.max(5,(cw-6)/13)),x+3,y+31,p);}
                else {p.setTextSize(22f); float tw=p.measureText(value); while(tw>cw-8 && p.getTextSize()>17f){p.setTextSize(p.getTextSize()-1f);tw=p.measureText(value);} c.drawText(value,Math.max(x+3,x+cw-tw-4),y+31,p);}
                x+=cw;
            }
            c.drawLine(left,y+rh,right,y+rh,p);
            if(ri>0){JSONObject it=items.optJSONObject(ri-1); int tx=left+widths[0]+2; int lineY=y+31;
                if(tax){String hsn=it.optString("hsn",it.optString("hsnCode","")).trim();if(!hsn.isEmpty()){p.setTextSize(19f);lineY+=23;c.drawText("HSN: "+hsn,tx,lineY,p);}}
                String comment=it.optString("comment","").trim();if(bill.optBoolean("includeItemComments",false)&&!comment.isEmpty()){p.setTextSize(19f);lineY+=23;c.drawText("Comment: "+trimText(comment,38),tx,lineY,p);}
            }
            y+=rh;
        }
        writeEscPosBitmap(out,bmp,576); bmp.recycle();
    }
    // GST rate summary rendered as a real raster table to mirror the PDF column structure.
    // Intra-state: Rate | Taxable | CGST | SGST. Inter-state: Rate | Taxable | IGST.
    private void writeThermalGstSummaryBitmap(OutputStream out, JSONObject summary) throws Exception {
        if (summary == null) return;
        JSONArray groups = summary.optJSONArray("groups");
        if (groups == null || groups.length() == 0) return;
        final int w=576, left=3, right=w-3;
        boolean inter=summary.optBoolean("inter",false);
        int[] widths=inter?new int[]{105,210,255}:new int[]{78,180,160,152};
        String[] headers=inter?new String[]{"Rate","Taxable","IGST"}:new String[]{"Rate","Taxable","CGST","SGST"};
        final int titleH=44,rowH=48;
        int h=titleH+rowH*(groups.length()+1)+2;
        Bitmap bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); Canvas c=new Canvas(bmp); c.drawColor(Color.WHITE);
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(Color.BLACK); p.setStrokeWidth(2.0f);
        p.setStyle(Paint.Style.STROKE); c.drawRect(left,0,right,titleH,p);
        p.setStyle(Paint.Style.FILL); p.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.BOLD)); p.setTextSize(24f); c.drawText("GST RATE SUMMARY",left+6,30,p);
        int y=titleH; int cols=headers.length;
        for(int r=0;r<=groups.length();r++){
            p.setStyle(Paint.Style.STROKE); c.drawRect(left,y,right,y+rowH,p); int x=left;
            for(int k=0;k<cols-1;k++){x+=widths[k];c.drawLine(x,y,x,y+rowH,p);}
            p.setStyle(Paint.Style.FILL); p.setTextSize(22f); p.setTypeface(Typeface.create(Typeface.MONOSPACE,r==0?Typeface.BOLD:Typeface.NORMAL));
            String[] vals;
            if(r==0) vals=headers;
            else {JSONObject g=groups.optJSONObject(r-1);if(g==null){y+=rowH;continue;}double rate=g.optDouble("rate",0),taxable=g.optDouble("taxable",0),tax=g.optDouble("tax",0);vals=inter?new String[]{String.format(Locale.US,"%.0f%%",rate),formatBillValue(taxable),formatBillValue(tax)}:new String[]{String.format(Locale.US,"%.0f%%",rate),formatBillValue(taxable),formatBillValue(tax/2.0),formatBillValue(tax/2.0)};}
            x=left; for(int k=0;k<cols;k++){int cw=widths[k];String v=vals[k];if(k==0)c.drawText(v,x+6,y+31,p);else{float tw=p.measureText(v);while(tw>cw-10&&p.getTextSize()>17f){p.setTextSize(p.getTextSize()-1f);tw=p.measureText(v);}c.drawText(v,x+cw-tw-6,y+31,p);}x+=cw;} y+=rowH;
        }
        writeEscPosBitmap(out,bmp,576);bmp.recycle();
    }

    private void writeThermalTransactionsBitmap(OutputStream out, JSONArray recent) throws Exception {
        if(recent==null||recent.length()==0)return;
        final int w=576,left=3,right=w-3,headerH=78,rowH=118; int count=Math.min(5,recent.length());
        Bitmap bmp=Bitmap.createBitmap(w,headerH+count*rowH+2,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(bmp);c.drawColor(Color.WHITE);
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(Color.BLACK);p.setStrokeWidth(1.5f);p.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.BOLD));p.setTextSize(25f);
        c.drawText("LAST 5 TRANSACTIONS",left+4,29,p);c.drawLine(left,38,right,38,p);p.setTextSize(19f);c.drawText("DATE / TYPE",left+4,65,p);c.drawText("BILL / TXN NO.",175,65,p);p.setTextAlign(Paint.Align.RIGHT);c.drawText("AMOUNT (Rs)",right-4,65,p);p.setTextAlign(Paint.Align.LEFT);c.drawLine(left,headerH,right,headerH,p);
        int y=headerH;for(int i=0;i<count;i++){JSONObject tr=recent.optJSONObject(i);if(tr==null)continue;String raw=tr.optString("date","");String dt=raw.length()>=10?raw.substring(8,10)+"/"+raw.substring(5,7)+"/"+raw.substring(2,4):raw;String typ=tr.optString("type","").trim();String lt=typ.toLowerCase(Locale.US);if(lt.contains("credit"))typ="Cr.";else if(lt.contains("cash"))typ="Cash";else if(lt.contains("payment"))typ="Pay";else if(lt.contains("upi"))typ="UPI";String ref=tr.optString("reference","");boolean sale=lt.contains("credit")||lt.contains("sale")||lt.contains("cash")||lt.contains("bill");boolean paymentTxn=lt.contains("payment")||lt.contains("receipt")||lt.equals("pay");sale=sale&&!paymentTxn;double billAmt=sale?tr.optDouble("billTotal",tr.optDouble("total",tr.optDouble("amount",0))):0;double paid=lt.contains("credit")?tr.optDouble("paymentAmount",tr.optDouble("paid",0)):(sale?billAmt:tr.optDouble("paymentAmount",tr.optDouble("paid",tr.optDouble("amount",0))));double prev=tr.optDouble("previousBalance",tr.optDouble("previous_balance",0));double bal=tr.optDouble("balance",tr.optDouble("balanceDue",0));
            p.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.NORMAL));p.setTextSize(22f);c.drawText(trimText(dt+" "+typ,12),left+4,y+31,p);c.drawText(trimText(ref,15),165,y+31,p);p.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.BOLD));p.setTextAlign(Paint.Align.RIGHT);p.setTextSize(22f);c.drawText("Bill: "+formatBillValue(billAmt),right-5,y+31,p);p.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.NORMAL));p.setTextSize(21f);c.drawText("P.Bal: "+formatBillValue(prev),left+4,y+65,p);p.setTextAlign(Paint.Align.RIGHT);c.drawText("Paid: "+formatBillValue(paid),right-5,y+65,p);p.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.BOLD));p.setTextSize(22f);c.drawText("T.Bal: "+formatBillValue(bal),right-5,y+99,p);p.setTextAlign(Paint.Align.LEFT);p.setStyle(Paint.Style.STROKE);c.drawLine(left,y+rowH,right,y+rowH,p);y+=rowH;}
        writeEscPosBitmap(out,bmp,576);bmp.recycle();
    }

    /** Returns paired Bluetooth devices for the settings WebView bridge as JSON. */
    private String pairedBluetoothPrintersJson() {
        JSONArray result = new JSONArray();
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) return result.toString();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                return result.toString();
            }
            java.util.Set<BluetoothDevice> devices = adapter.getBondedDevices();
            if (devices == null) return result.toString();
            for (BluetoothDevice device : devices) {
                if (device == null) continue;
                JSONObject item = new JSONObject();
                item.put("name", device.getName() == null ? "Bluetooth device" : device.getName());
                item.put("address", device.getAddress() == null ? "" : device.getAddress());
                result.put(item);
            }
        } catch (Exception ignored) {
            // A permission denial or Bluetooth adapter error should not crash the JS bridge.
        }
        return result.toString();
    }

    private BluetoothDevice findThermalPrinter(String preferredPrinter) {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null || !adapter.isEnabled()) return null;
            java.util.Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            if (bonded == null || bonded.isEmpty()) return null;
            String preferred = preferredPrinter == null ? "auto" : preferredPrinter.trim();
            for (BluetoothDevice device : bonded) {
                if (device == null) continue;
                String name = device.getName() == null ? "" : device.getName().trim();
                String address = device.getAddress() == null ? "" : device.getAddress().trim();
                if (!preferred.isEmpty() && !"auto".equalsIgnoreCase(preferred)
                        && (preferred.equalsIgnoreCase(address) || preferred.equalsIgnoreCase(name))) {
                    return device;
                }
            }
            if ("auto".equalsIgnoreCase(preferred) || preferred.isEmpty()) {
                for (BluetoothDevice device : bonded) {
                    if (device == null) continue;
                    String name = device.getName() == null ? "" : device.getName().toLowerCase(Locale.US);
                    if (name.contains("printer") || name.contains("thermal") || name.contains("pos")
                            || name.contains("kpc") || name.contains("receipt")) return device;
                }
                // If there is exactly one paired device, let the user-selected pairing be used.
                if (bonded.size() == 1) return bonded.iterator().next();
            }
        } catch (SecurityException ignored) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this,
                    "Allow Bluetooth permission and select a paired thermal printer.", Toast.LENGTH_LONG).show());
        } catch (Exception ignored) {
            // Return null; caller will not attempt a socket connection.
        }
        return null;
    }

    private BluetoothSocket openPrinterSocket(BluetoothDevice device) throws Exception {
        if (device == null) throw new IllegalArgumentException("No paired thermal printer was found.");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            throw new SecurityException("Bluetooth Connect permission is required.");
        }
        UUID spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
        BluetoothSocket socket = device.createRfcommSocketToServiceRecord(spp);
        socket.connect();
        return socket;
    }

    private void directThermalPrint80(String json) throws Exception {
        pendingDirectPrintJson = json;
        JSONObject preflight = new JSONObject(json);
        JSONObject preCfg = preflight.optJSONObject("settings");
        String preferredPrinter = preCfg == null ? "auto" : preCfg.optString("bluetoothPrinter", "auto");
        BluetoothDevice device = findThermalPrinter(preferredPrinter);
        if (device == null) return; // permission request is in progress
        BluetoothSocket socket = null;
        OutputStream out = null;
        try {
            socket = openPrinterSocket(device);
            try { Thread.sleep(250); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            out = socket.getOutputStream();
            JSONObject b = new JSONObject(json);
            JSONObject cfg = b.optJSONObject("settings");
            JSONArray items = b.optJSONArray("items");
            boolean tax = b.optBoolean("taxationEnabled", false);
            String shop = cfg == null ? "DUKAAN BILL" : cfg.optString("shopName", "DUKAAN BILL");
            String tagline = cfg == null ? "" : cfg.optString("tagline", "").trim();
            String address = cfg == null || !cfg.optBoolean("printShopAddress", true) ? "" : cfg.optString("address", "").trim();
            String mobiles = cfg == null || !cfg.optBoolean("printShopMobile", true) ? "" : shopMobileText(cfg);
            String customer = b.optString("customer", "Walk-in Customer").trim();
            String phone = b.optString("customerPhone", "").trim();
            boolean printCustomer = cfg == null || cfg.optBoolean("showCustomer", true);
            boolean printCustomerMobile = cfg == null || cfg.optBoolean("printCustomerMobile", true);
            boolean printPaymentMode = cfg == null || cfg.optBoolean("printPaymentMode", true);
            String billNo = b.optString("billNo", "");
            boolean estimate = b.optBoolean("isEstimate", false) || "estimate".equalsIgnoreCase(b.optString("documentType", ""));
            String title = estimate ? "ESTIMATE" : (tax ? "TAX INVOICE" : (cfg == null ? "CASH MEMO / BILL" : cfg.optString("billTitle", "CASH MEMO / BILL")));

            escCmd(out,0x1B,0x40); // initialize
            // Slightly darker text for KPC307 thermal output. Double-strike is more reliable than oversized/bold text.
            escCmd(out,0x1B,0x47,0x01); // ESC G 1: double-strike ON
            escCmd(out,0x1B,0x61,0x01); // center
            Bitmap logo=loadLogo(cfg);
            if(logo!=null && (cfg==null || cfg.optBoolean("printShopLogo",true))){ writeEscPosBitmap(out,logo,320); if(!logo.isRecycled()) logo.recycle(); }
            if(cfg==null || cfg.optBoolean("printShopName",true)){escCmd(out,0x1B,0x45,0x01); escCmd(out,0x1B,0x21,shop.length()>23?0x08:0x18); escLine(out,shop); escCmd(out,0x1B,0x21,0x00); escCmd(out,0x1B,0x45,0x00);}
            escCmd(out,0x1B,0x21,0x00); escCmd(out,0x1B,0x45,0x00);
            if(!tagline.isEmpty()) { escLine(out,tagline); escLine(out,""); } // small visual gap between tagline and address
            if(!address.isEmpty()) for(String line:wrapPlain(address,48)) escLine(out,line);
            if(!mobiles.isEmpty()){ escCmd(out,0x1B,0x45,0x01); escLine(out,"MO: "+mobiles); escCmd(out,0x1B,0x45,0x00); }
            if(!estimate && tax && cfg!=null){String sg=cfg.optString("gstin","").trim(),sf=cfg.optString("fssai","").trim();if(!sg.isEmpty())escLine(out,"GSTIN: "+sg);if(!sf.isEmpty())escLine(out,"FSSAI: "+sf);}
            escCmd(out,0x1B,0x45,0x01); escLine(out,title); escCmd(out,0x1B,0x45,0x00);
            thermalRule(out); thermalRuleGap(out);
            escCmd(out,0x1B,0x61,0x00); // left
            escLine(out, receiptTwoColumnLine((estimate?"Estimate: #":"Bill: #")+billNo, "Dt: "+formatDate(b.optString("date","")), 48));
            String printedCustomer = printCustomer && !customer.isEmpty() && !customer.equalsIgnoreCase("Walk-in Customer") ? customer : "";
            String printedPhone = printCustomerMobile ? phone : "";
            if(!printedCustomer.isEmpty() && !printedPhone.isEmpty()) {
                // Keep customer on the left and pin the mobile field to the receipt's right edge.
                escLine(out, receiptTwoColumnLine("Customer: " + printedCustomer, "Mo: " + printedPhone, 48));
            } else if(!printedCustomer.isEmpty()) {
                for(String line:wrapPlain("Customer: " + printedCustomer,48)) escLine(out,line);
            } else if(!printedPhone.isEmpty()) {
                escLine(out, receiptAmountLine("Mo:", printedPhone, 48));
            }
            if(tax){String ca=b.optString("customerAddress",b.optString("address","")).trim();if(!ca.isEmpty())for(String line:wrapPlain("Address: "+ca,48))escLine(out,line);String cg=b.optString("customerGstin","").trim();if(!cg.isEmpty())escLine(out,"Customer GSTIN: "+cg);String cf=b.optString("customerFssai","").trim();if(!cf.isEmpty())escLine(out,"Customer FSSAI: "+cf);String cs=b.optString("customerState","").trim();if(!cs.isEmpty())escLine(out,"Customer State: "+cs);}
            if(!estimate && printPaymentMode) escLine(out,"Pay: "+b.optString("paymentMode","Cash"));
            JSONObject customFields=b.optJSONObject("customFields");
            if(cfg!=null && customFields!=null){String[] keys={"field1","field2","field3"};String[] labelKeys={"customBillField1Label","customBillField2Label","customBillField3Label"};String[] posKeys={"customBillField1Position","customBillField2Position","customBillField3Position"};for(int i=0;i<keys.length;i++){String label=cfg.optString(labelKeys[i],"").trim(),value=customFields.optString(keys[i],"").trim(),pos=cfg.optString(posKeys[i],i==2?"footer":"header").trim().toLowerCase(Locale.US);if(label.toLowerCase(Locale.US).contains("warranty")&&!value.isEmpty())value=formatDate(value);if(!label.isEmpty()&&!value.isEmpty()&&!("hidden".equals(pos))) { if("footer".equals(pos)) continue; for(String line:wrapPlain(label+": "+value,48))escLine(out,line); }}}
            thermalRule(out);

            // Native printer text keeps item descriptions readable; PDF rendering remains unchanged.
            writeThermalItemTableText(out,items,tax,b,cfg);
            thermalRule(out); thermalRuleGap(out);
            double subtotal=b.optDouble("subtotal",0), discount=b.optDouble("discount",0), total=b.optDouble("total",Math.max(0,subtotal-discount));
            escLine(out,receiptAmountLine("Subtotal:", "Rs."+formatBillValue(subtotal),48));
            if(discount>0.000001) escLine(out,receiptAmountLine("Discount:", "-Rs."+formatBillValue(discount),48));
            if(tax){ JSONObject ts=calculateTaxSummary(b,cfg); escLine(out,receiptAmountLine("Taxable:", "Rs."+formatBillValue(ts.optDouble("taxable",0)),48)); if(ts.optBoolean("inter",false)) escLine(out,receiptAmountLine("IGST:", "Rs."+formatBillValue(ts.optDouble("igst",0)),48)); else { escLine(out,receiptAmountLine("CGST:", "Rs."+formatBillValue(ts.optDouble("cgst",0)),48)); escLine(out,receiptAmountLine("SGST:", "Rs."+formatBillValue(ts.optDouble("sgst",0)),48)); } escLine(out,receiptAmountLine("Total GST:", "Rs."+formatBillValue(ts.optDouble("tax",0)),48)); }
            double billRoundOff=b.optDouble("roundOff",0); if(Math.abs(billRoundOff)>=0.005) escLine(out,receiptAmountLine("Round Off:", (billRoundOff>0?"+Rs.":"-Rs.")+formatBillValue(Math.abs(billRoundOff)),48));
            escCmd(out,0x1B,0x45,0x01); escCmd(out,0x1B,0x21,0x10); escLine(out,receiptAmountLine("TOTAL:", "Rs."+formatBillValue(total),48)); escCmd(out,0x1B,0x21,0x00); escCmd(out,0x1B,0x45,0x00);
            double receiptPaid=0; boolean creditReceipt=false;
            String modeForReceipt=b.optString("paymentMode","Cash").trim();creditReceipt=modeForReceipt.toLowerCase(Locale.US).contains("credit");
            boolean hasReceiptPayment=b.has("partialPaymentAmount")||b.has("paidAmount")||b.has("amountPaid");
            receiptPaid=hasReceiptPayment?b.optDouble("partialPaymentAmount",b.optDouble("paidAmount",b.optDouble("amountPaid",0))):0;
            if(!creditReceipt&&receiptPaid<=0.000001)receiptPaid=total;
            if(!estimate) escLine(out,receiptAmountLine("Paid:","Rs."+formatBillValue(receiptPaid),48));
            if(!estimate && creditReceipt){double receiptBillBalance=Math.max(0,total-receiptPaid);double receiptTotalBalance=b.optDouble("customerTotalBalance",receiptBillBalance);escLine(out,receiptAmountLine("Bill Balance:","Rs."+formatBillValue(receiptBillBalance),48));escLine(out,receiptAmountLine("Total Balance:","Rs."+formatBillValue(Math.max(0,receiptTotalBalance)),48));}
            escLine(out,"");
            String overallComment=b.optString("overallComment","").trim();
            if(b.optBoolean("includeOverallComment",false)&&!overallComment.isEmpty()){escCmd(out,0x1B,0x61,0x00);for(String commentLine:wrapPlain("Comment: "+overallComment,48))escLine(out,commentLine);escLine(out,"");}
            if(tax){JSONObject ts=calculateTaxSummary(b,cfg);writeThermalGstSummaryText(out,ts);escLine(out,"");}
            if(b.optBoolean("includeLast5Transactions",false)){JSONArray recent=b.optJSONArray("last5Transactions");if(recent!=null&&recent.length()>0){writeThermalTransactionsText(out,recent);escLine(out,"");}}
            escCmd(out,0x1B,0x61,0x00);
            if(cfg!=null && customFields!=null){String[] keys={"field1","field2","field3"};String[] labelKeys={"customBillField1Label","customBillField2Label","customBillField3Label"};String[] posKeys={"customBillField1Position","customBillField2Position","customBillField3Position"};for(int i=0;i<keys.length;i++){String label=cfg.optString(labelKeys[i],"").trim(),value=customFields.optString(keys[i],"").trim(),pos=cfg.optString(posKeys[i],i==2?"footer":"header").trim().toLowerCase(Locale.US);if(label.toLowerCase(Locale.US).contains("warranty")&&!value.isEmpty())value=formatDate(value);if(!label.isEmpty()&&!value.isEmpty()&&"footer".equals(pos))for(String line:wrapPlain(label+": "+value,48))escLine(out,line);}}
            escCmd(out,0x1B,0x61,0x01);
            String footer=cfg==null?"":cfg.optString("footer","").trim(); if(!footer.isEmpty()) for(String line:wrapPlain(footer,48)) escLine(out,line);
            if(cfg!=null&&cfg.optBoolean("upiQrEnabled",false)){String qrPayload=billUpiPayload(b,cfg);if("merchant".equals(cfg.optString("upiQrSource","upi"))){String d=cfg.optString("merchantQrData","");if(d.startsWith("data:image")){try{byte[] im=Base64.decode(d.substring(d.indexOf(',')+1),Base64.DEFAULT);Bitmap bm=BitmapFactory.decodeByteArray(im,0,im.length);if(bm!=null){writeThermalBitmap(out,bm);bm.recycle();}}catch(Exception ignored){}}}else if(!qrPayload.isEmpty()){writeThermalQr(out,qrPayload);if(cfg.optBoolean("upiPrintAmount",true))escLine(out,"Scan & Pay - Enter Amount");}}
            String terms=cfg==null?"":cfg.optString("termsConditions","").trim(); if(cfg!=null && cfg.optBoolean("printTermsConditions",false) && !terms.isEmpty()) for(String line:wrapPlain(terms.replace("•","-"),48)) escLine(out,line);
            String credit=cfg==null?"Bill created by DukaanBill - Contact 8087794271 for more details":cfg.optString("creditFooter","Bill created by DukaanBill - Contact 8087794271 for more details").trim();
            if(!credit.isEmpty()){escCmd(out,0x1B,0x61,0x01); // center the final creator/contact footer line
            for(String line:wrapPlain(credit.replace("•","-"),48)) escLine(out,line);}
            escCmd(out,0x1B,0x61,0x00);
            escLine(out,""); escLine(out,""); escLine(out,"");
            escCmd(out,0x1B,0x47,0x00); // double-strike OFF
            escCmd(out,0x1D,0x56,0x00); // full cut
            out.flush();
            runOnUiThread(()->Toast.makeText(MainActivity.this,"Printed directly to "+(device.getName()==null?"printer":device.getName()),Toast.LENGTH_SHORT).show());
        } finally { try{if(out!=null)out.close();}catch(Exception ignored){} try{if(socket!=null)socket.close();}catch(Exception ignored){} }
    }

    private String receiptTwoColumnLine(String left, String right, int width) {
        String l = left == null ? "" : left.trim();
        String r = right == null ? "" : right.trim();
        if (r.length() >= width) return r.substring(Math.max(0, r.length() - width));
        int maxLeft = Math.max(0, width - r.length() - 1);
        if (l.length() > maxLeft) l = l.substring(0, maxLeft);
        int spaces = Math.max(1, width - l.length() - r.length());
        StringBuilder line = new StringBuilder(l);
        for (int i = 0; i < spaces; i++) line.append(' ');
        line.append(r);
        if (line.length() > width) return line.substring(line.length() - width);
        return line.toString();
    }

    private String receiptAmountLine(String label, String amount, int width) {
        String left = label == null ? "" : label.trim();
        String right = amount == null ? "" : amount.trim();
        if (right.length() >= width) return right;
        int spaces = Math.max(1, width - left.length() - right.length());
        StringBuilder sb = new StringBuilder(left);
        for (int i = 0; i < spaces; i++) sb.append(' ');
        sb.append(right);
        String line = sb.toString();
        return line.length() > width ? line.substring(0, width) : line;
    }

    private List<String> wrapPlain(String text,int max) {
        List<String> out = new ArrayList<>();
        if (text == null || text.trim().isEmpty()) return out;
        String normalized = text.replace("\\r\\n", "\\n").replace('\r', '\n');
        for (String paragraph : normalized.split("\\n", -1)) {
            String s = paragraph.trim().replaceAll("\\s+", " ");
            if (s.isEmpty()) { out.add(""); continue; }
            while (s.length() > max) {
                int cut = s.lastIndexOf(' ', max);
                if (cut < 1) cut = max;
                out.add(s.substring(0, cut));
                s = s.substring(cut).trim();
            }
            if (!s.isEmpty()) out.add(s);
        }
        return out;
    }

    private void printBill(String json) throws Exception {
        byte[] pdf=createThermalPdfBytes(json);
        PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
        String name="DukaanBill";
        try{name=new JSONObject(json).optString("billNo","DukaanBill");}catch(Exception ignored){}
        final byte[] data=pdf;
        final String printName=name;
        pm.print(printName,new PrintDocumentAdapter(){
            @Override public void onLayout(android.print.PrintAttributes oldAttrs, android.print.PrintAttributes newAttrs, CancellationSignal cancellationSignal, LayoutResultCallback callback, android.os.Bundle extras){
                if(cancellationSignal.isCanceled()){callback.onLayoutCancelled();return;}
                PrintDocumentInfo info=new PrintDocumentInfo.Builder(printName+".pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build(); callback.onLayoutFinished(info,true);
            }
            @Override public void onWrite(PageRange[] pages, ParcelFileDescriptor destination, CancellationSignal cancellationSignal, WriteResultCallback callback){
                try(FileOutputStream out=new FileOutputStream(destination.getFileDescriptor())){out.write(data);out.flush();callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){callback.onWriteFailed(e.getMessage());}
            }
        },new PrintAttributes.Builder().setMediaSize("58mm".equalsIgnoreCase(new JSONObject(json).optJSONObject("settings").optString("paperSize","80mm")) ? new PrintAttributes.MediaSize("DUKAAN58", "58 mm", 2283, 22000) : new PrintAttributes.MediaSize("DUKAAN80", "80 mm", 3150, 22000)).setColorMode(PrintAttributes.COLOR_MODE_COLOR).build());
    }

    private JSONObject calculateTaxSummary(JSONObject b, JSONObject cfg) throws Exception {
        JSONObject out=new JSONObject();
        boolean enabled=b!=null && b.optBoolean("taxationEnabled",false);
        out.put("enabled",enabled);
        if(!enabled){out.put("taxable",0);out.put("tax",0);out.put("cgst",0);out.put("sgst",0);out.put("igst",0);out.put("inter",false);out.put("groups",new JSONArray());return out;}
        JSONArray items=b.optJSONArray("items");
        double calculatedSubtotal=0;
        if(items!=null){for(int i=0;i<items.length();i++){JSONObject it=items.getJSONObject(i);calculatedSubtotal+=quantityValue(it.optString("qty",""),it.optString("unit","piece"))*it.optDouble("rate",0);}}
        double subtotal=b.has("subtotal")?b.optDouble("subtotal",calculatedSubtotal):calculatedSubtotal;
        double discount=Math.max(0,b.optDouble("discount",0));
        double taxable=0,tax=0;
        TreeMap<Double,double[]> groups=new TreeMap<>();
        if(items!=null){for(int i=0;i<items.length();i++){JSONObject it=items.getJSONObject(i);double gross=quantityValue(it.optString("qty",""),it.optString("unit","piece"))*it.optDouble("rate",0);double net=subtotal>0?gross*(subtotal-discount)/subtotal:gross;double rate=it.optDouble("taxRate",0);boolean inclusive=b.optBoolean("amountsIncludeTax",true);double base=rate>0?(inclusive?net/(1.0+rate/100.0):net):net;double tx=rate>0?(inclusive?net-base:net*rate/100.0):0;taxable+=base;tax+=tx;double[] g=groups.get(rate);if(g==null){g=new double[]{0,0};groups.put(rate,g);}g[0]+=base;g[1]+=tx;}}
        String business=b.optString("businessState",cfg.optString("businessState","")).trim();String pos=b.optString("placeOfSupply",business).trim();boolean inter=!business.isEmpty()&&!pos.isEmpty()&&!business.equalsIgnoreCase(pos);
        out.put("taxable",taxable);out.put("tax",tax);out.put("cgst",inter?0:tax/2.0);out.put("sgst",inter?0:tax/2.0);out.put("igst",inter?tax:0);out.put("inter",inter);
        JSONArray arr=new JSONArray();for(Map.Entry<Double,double[]> e:groups.entrySet()){JSONObject g=new JSONObject();g.put("rate",e.getKey());g.put("taxable",e.getValue()[0]);g.put("tax",e.getValue()[1]);arr.put(g);}out.put("groups",arr);
        return out;
    }

    private Uri createPdf(String json) throws Exception {
        JSONObject b = new JSONObject(json);
        JSONArray items = b.optJSONArray("items");
        JSONObject cfg = b.optJSONObject("settings");
        boolean taxInvoice=b.optBoolean("taxationEnabled",false);
        JSONObject tax=calculateTaxSummary(b,cfg);
        PdfDocument doc = new PdfDocument();
        Bitmap logo = loadLogo(cfg);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int pageNo=1, y;
        PdfDocument.Page page = null;
        Canvas canvas = null;
        int pageWidth=595, pageHeight=842;
        boolean a6Paper = cfg != null && "A6".equalsIgnoreCase(cfg.optString("paperSize", "A4"));
        int outputPageWidth = a6Paper ? 298 : pageWidth;
        int outputPageHeight = a6Paper ? 421 : pageHeight;

        page = doc.startPage(new PdfDocument.PageInfo.Builder(outputPageWidth,outputPageHeight,pageNo).create());
        canvas = page.getCanvas();
        if (a6Paper) canvas.scale(0.5f, 0.5f);
        // Reference-matched invoice palette: pale blue table headers/key totals, soft grey comments.
        final int invoiceHeaderFill = android.graphics.Color.rgb(232, 242, 249);
        final int invoiceAccentFill = android.graphics.Color.rgb(211, 235, 247);
        final int invoiceCommentFill = android.graphics.Color.rgb(242, 244, 246);
        final int invoiceGrid = android.graphics.Color.rgb(75, 82, 88);
        float headerBottom = drawPdfHeader(canvas,p,logo,pageWidth,cfg,b,taxInvoice,b.optString("placeOfSupply",cfg==null?"":cfg.optString("businessState","")));

        // A4/A6 bill tables use outlined cells. Filled rectangles are created explicitly for headers only.
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.8f);
        p.setColor(android.graphics.Color.BLACK);
        p.setTypeface(Typeface.DEFAULT);
        setPdfTextSize(p, 10, cfg);
        // Invoice/customer details are already rendered in the compact three-column header.
        // Do not print the legacy duplicate metadata rows below it; this keeps the header near 15% of A4.
        int detailsBottom=(int)headerBottom;
        JSONObject customFields=b.optJSONObject("customFields");int customHeaderCount=0;
        int customHeaderY=detailsBottom+13;
        java.util.List<String> headerFieldTexts=new java.util.ArrayList<>();
        if(cfg!=null&&customFields!=null){String[] keys={"field1","field2","field3"};String[] labelKeys={"customBillField1Label","customBillField2Label","customBillField3Label"};String[] posKeys={"customBillField1Position","customBillField2Position","customBillField3Position"};for(int i=0;i<keys.length;i++){String label=cfg.optString(labelKeys[i],"").trim(),value=customFields.optString(keys[i],"").trim(),pos=cfg.optString(posKeys[i],i==2?"footer":"header");if(!label.isEmpty()&&!value.isEmpty()&&"header".equalsIgnoreCase(pos)){if(label.toLowerCase(Locale.US).contains("warranty"))value=formatDate(value);headerFieldTexts.add(label+": "+value);customHeaderCount++;}}}
        if(!headerFieldTexts.isEmpty()){
            float rowTop=customHeaderY-11, rowBottom=customHeaderY+10;
            drawOutlineRect(canvas,p,35,rowTop,560,rowBottom);
            if(headerFieldTexts.size()==2) canvas.drawLine(297.5f,rowTop,297.5f,rowBottom,p);
            else if(headerFieldTexts.size()>=3){canvas.drawLine(210,rowTop,210,rowBottom,p);canvas.drawLine(385,rowTop,385,rowBottom,p);}
            p.setTypeface(Typeface.DEFAULT);setPdfTextSize(p, 9, cfg);
            if(headerFieldTexts.size()==1){p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,headerFieldTexts.get(0),42,customHeaderY+3);}
            else if(headerFieldTexts.size()==2){p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,trimText(headerFieldTexts.get(0),38),42,customHeaderY+3);p.setTextAlign(Paint.Align.RIGHT);drawText(canvas,p,trimText(headerFieldTexts.get(1),38),553,customHeaderY+3);}
            else {p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,trimText(headerFieldTexts.get(0),24),42,customHeaderY+3);p.setTextAlign(Paint.Align.CENTER);drawText(canvas,p,trimText(headerFieldTexts.get(1),24),297.5f,customHeaderY+3);p.setTextAlign(Paint.Align.RIGHT);drawText(canvas,p,trimText(headerFieldTexts.get(2),24),553,customHeaderY+3);}
            p.setTextAlign(Paint.Align.LEFT);customHeaderY+=25;
        }
        // Payment mode is included in the customer panel of the header; avoid a duplicate row.
        p.setTypeface(Typeface.DEFAULT_BOLD);
        setPdfTextSize(p, 9, cfg);
        int tableY = headerFieldTexts.isEmpty() ? detailsBottom+4 : customHeaderY-11; // 4px below custom-field row
        // Reference style: pale-blue column header with clear black grid lines.
        p.setStyle(Paint.Style.FILL); p.setColor(invoiceHeaderFill); canvas.drawRect(35,tableY,560,tableY+22,p);
        p.setStyle(Paint.Style.STROKE); p.setColor(invoiceGrid); p.setStrokeWidth(0.8f);
        drawOutlineRect(canvas,p,35,tableY,560,tableY+22);
        float[] itemCols = taxInvoice ? new float[]{35,60,195,250,290,330,390,445,560} : new float[]{35,60,270,325,370,430,560};
        for(int ci=1;ci<itemCols.length-1;ci++) canvas.drawLine(itemCols[ci],tableY,itemCols[ci],tableY+22,p);
        p.setColor(android.graphics.Color.BLACK); p.setTypeface(Typeface.DEFAULT_BOLD); setPdfTextSize(p, 9.0f, cfg);
        drawText(canvas,p,"SR.",41,tableY+14);
        drawCenteredFitText(canvas,p,"ITEM",(itemCols[1]+itemCols[2])/2f,tableY+14,itemCols[2]-itemCols[1]-8f);
        if(taxInvoice) drawTextRight(canvas,p,"HSN/SAC",itemCols[3]-5,tableY+14);
        drawText(canvas,p,"QTY",taxInvoice?(itemCols[3]+itemCols[4])/2f:(itemCols[2]+itemCols[3])/2f,tableY+14);
        drawTextRight(canvas,p,"UNIT",(taxInvoice?itemCols[5]:itemCols[4])-5,tableY+14);
        drawTextRight(canvas,p,"RATE (₹)",taxInvoice?itemCols[6]-5:itemCols[5]-5,tableY+14);
        if(taxInvoice)drawTextRight(canvas,p,"GST",itemCols[7]-5,tableY+14);
        drawTextRight(canvas,p,"AMOUNT (₹)",555,tableY+14);
        p.setColor(android.graphics.Color.BLACK); p.setTypeface(Typeface.DEFAULT); setPdfTextSize(p, 9.0f, cfg);
        y=tableY+22;

        double calculatedSubtotal=0;
        if(items!=null){
            for(int i=0;i<items.length();i++){
                JSONObject it=items.getJSONObject(i);
                String name=it.optString("name",""); if(cfg!=null && cfg.optBoolean("printItemCode",false)){String code=it.optString("itemCode","").trim();if(!code.isEmpty())name=code+" - "+name;}
                String hsn=it.optString("hsn",it.optString("hsnCode", "")).trim();
                String qty=formatBillQuantity(it.optString("qty",""));
                String unit=it.optString("unit","piece");
                double rate=it.optDouble("rate",0);
                double amount=quantityValue(qty,unit)*rate;
                double taxRate=it.optDouble("taxRate",0);
                String itemLine=name;
                p.setTypeface(Typeface.DEFAULT); setPdfTextSize(p, 8.8f, cfg);
                float[] rowCols = itemCols;
                // Reserve the Item column only for the item name. Put HSN on its own
                // second/third line so it can never run into Qty or Unit columns.
                float itemTextWidth=(taxInvoice?itemCols[2]:itemCols[2])-itemCols[1]-8f;
                java.util.List<String> itemNameLines=wrapText(itemLine,p,itemTextWidth);
                if(itemNameLines.size()>2){java.util.List<String> firstTwo=new java.util.ArrayList<>();firstTwo.add(itemNameLines.get(0));firstTwo.add(itemNameLines.get(1));itemNameLines=firstTwo;}
                int itemLineCount=Math.max(1,itemNameLines.size())+(!hsn.isEmpty()&&taxInvoice?1:0);
                // Compact A4 item rows: keep multi-line names/HSN readable without excess vertical padding.
                float rowHeight=itemLineCount>2?34f:(itemLineCount>1?26f:18f);
                String itemComment=it.optString("comment","").trim();
                java.util.List<String> commentLines=java.util.Collections.emptyList();
                if(b.optBoolean("includeItemComments",false)&&!itemComment.isEmpty()){
                    setPdfTextSize(p, 8.0f, cfg); commentLines=wrapText("Comment: "+itemComment,p,510);
                }
                float needed=rowHeight+(commentLines.isEmpty()?0:commentLines.size()*10f+3f)+2f;
                if(y+needed>770){
                    doc.finishPage(page); pageNo++;
                    page=doc.startPage(new PdfDocument.PageInfo.Builder(outputPageWidth,outputPageHeight,pageNo).create());
                    canvas=page.getCanvas(); if (a6Paper) canvas.scale(0.5f, 0.5f);
                    p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(0.8f);p.setColor(invoiceGrid);
                    float nextHeaderBottom=a6Paper?drawPdfContinuationHeader(canvas,p,pageWidth,cfg,b):drawPdfHeader(canvas,p,logo,pageWidth,cfg,b,taxInvoice,b.optString("placeOfSupply",cfg==null?"":cfg.optString("businessState","")));
                    y=(int)nextHeaderBottom+12;
                    if(!headerFieldTexts.isEmpty()) y+=21;
                    p.setStyle(Paint.Style.FILL);p.setColor(invoiceHeaderFill);canvas.drawRect(35,y,560,y+22,p);
                    p.setStyle(Paint.Style.STROKE);p.setColor(invoiceGrid);p.setTypeface(Typeface.DEFAULT_BOLD);setPdfTextSize(p, 9.0f, cfg);
                    drawOutlineRect(canvas,p,35,y,560,y+22);
                    for(int ci=1;ci<itemCols.length-1;ci++)canvas.drawLine(itemCols[ci],y,itemCols[ci],y+22,p);
                    drawText(canvas,p,"SR.",41,y+14);drawCenteredFitText(canvas,p,"ITEM",(itemCols[1]+itemCols[2])/2f,y+14,itemCols[2]-itemCols[1]-8f);if(taxInvoice)drawTextRight(canvas,p,"HSN/SAC",itemCols[3]-5,y+14);drawText(canvas,p,"QTY",taxInvoice?(itemCols[3]+itemCols[4])/2f:(itemCols[2]+itemCols[3])/2f,y+14);drawTextRight(canvas,p,"UNIT",(taxInvoice?itemCols[5]:itemCols[4])-5,y+14);drawTextRight(canvas,p,"RATE (₹)",taxInvoice?itemCols[6]-5:itemCols[5]-5,y+14);if(taxInvoice)drawTextRight(canvas,p,"GST",itemCols[7]-5,y+14);
                    drawTextRight(canvas,p,"Amount (₹)",555,y+14);y+=22;
                }
                float rowTop=y, rowBottom=y+rowHeight;
                p.setTypeface(Typeface.DEFAULT);setPdfTextSize(p, 8.8f, cfg);p.setColor(android.graphics.Color.BLACK);
                drawText(canvas,p,String.valueOf(i+1),42,y+14);
                float itemBaseline=y+11;
                if(itemNameLines.size()>1){
                    drawText(canvas,p,itemNameLines.get(0),68,itemBaseline);
                    drawText(canvas,p,itemNameLines.get(1),68,itemBaseline+9);
                } else {
                    drawText(canvas,p,itemNameLines.isEmpty()?itemLine:itemNameLines.get(0),68,itemBaseline);
                }
                if(!hsn.isEmpty()&&taxInvoice){
                    setPdfTextSize(p, 7.8f, cfg);p.setTextAlign(Paint.Align.CENTER);
                    drawText(canvas,p,trimText(hsn,12),(itemCols[2]+itemCols[3])/2f,y+rowHeight/2f+3f);
                    p.setTextAlign(Paint.Align.LEFT);setPdfTextSize(p, 8.8f, cfg);
                }
                float valueBaseline=y+rowHeight/2f+3f;
                drawTextRight(canvas,p,trimText(qty,10),taxInvoice?itemCols[4]-5:itemCols[3]-5,valueBaseline);
                drawTextRight(canvas,p,trimText(unit,8),taxInvoice?itemCols[5]-5:itemCols[4]-5,valueBaseline);
                drawTextRight(canvas,p,formatBillValue(rate),taxInvoice?itemCols[6]-5:itemCols[5]-5,valueBaseline);
                if(taxInvoice)drawTextRight(canvas,p,String.format(Locale.US,"%.0f%%",taxRate),itemCols[7]-5,valueBaseline);
                drawTextRight(canvas,p,formatBillValue(amount),555,valueBaseline);
                drawOutlineRect(canvas,p,35,rowTop,560,rowBottom);
                for(int ci=1;ci<rowCols.length-1;ci++)canvas.drawLine(rowCols[ci],rowTop,rowCols[ci],rowBottom,p);
                y=(int)Math.ceil(rowBottom);
                if(!commentLines.isEmpty()){
                    float commentBottom=y+commentLines.size()*10f+3f;
                    p.setStyle(Paint.Style.FILL);p.setColor(invoiceCommentFill);canvas.drawRect(35,y,560,commentBottom,p);
                    p.setStyle(Paint.Style.STROKE);p.setColor(invoiceGrid);drawOutlineRect(canvas,p,35,y,560,commentBottom);p.setStyle(Paint.Style.FILL);p.setColor(android.graphics.Color.BLACK);p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.ITALIC));setPdfTextSize(p, 8.0f, cfg);
                    float cy=y+11;for(String commentLine:commentLines){drawText(canvas,p,commentLine,42,cy);cy+=10;}
                    y=(int)Math.ceil(commentBottom);
                }
                canvas.drawLine(35,y,560,y,p); y+=2;
                p.setTypeface(Typeface.DEFAULT);setPdfTextSize(p, 9.0f, cfg);
                calculatedSubtotal+=amount;
            }
        }
        double subtotal=b.has("subtotal")?b.optDouble("subtotal",calculatedSubtotal):calculatedSubtotal;
        double discount=b.optDouble("discount",0);
        double finalTotal=b.has("total")?b.optDouble("total",Math.max(0,subtotal-discount)):Math.max(0,subtotal-discount);
        if (y > 690) {
            doc.finishPage(page);
            pageNo++;
            page=doc.startPage(new PdfDocument.PageInfo.Builder(outputPageWidth,outputPageHeight,pageNo).create());
            canvas=page.getCanvas();
            if (a6Paper) canvas.scale(0.5f, 0.5f);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.8f); p.setColor(android.graphics.Color.BLACK);
            float nextHeaderBottom = a6Paper?drawPdfContinuationHeader(canvas,p,pageWidth,cfg,b):drawPdfHeader(canvas,p,logo,pageWidth,cfg,b,taxInvoice,b.optString("placeOfSupply",cfg==null?"":cfg.optString("businessState","")));
            y=(int)nextHeaderBottom+14;
        }
        p.setTypeface(Typeface.DEFAULT);
        setPdfTextSize(p, 9, cfg);
        // Put the compact GST rate table in the unused left side of the totals
        // area. Its right edge is x=390, using the blank space up to the Rate column above;
        // subtotal/tax totals remain in a clean right-aligned column.
        int summaryTop=y+6;
        String overallComment=b.optString("overallComment","").trim();
        int leftX=35, leftRight=a6Paper?285:325, rightX=a6Paper?295:335, rightRight=560;
        // Left panel: overall comment and compact GST summary.
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.8f); p.setColor(android.graphics.Color.BLACK);
        int leftPanelTop=summaryTop;
        int commentY=summaryTop+13;
        if(b.optBoolean("includeOverallComment",false)&&!overallComment.isEmpty()){
            p.setTypeface(Typeface.DEFAULT_BOLD);setPdfTextSize(p, 8.5f, cfg);p.setTextAlign(Paint.Align.LEFT);
            drawText(canvas,p,"Overall Comment:",leftX+5,commentY);commentY+=12;
            p.setTypeface(Typeface.DEFAULT);setPdfTextSize(p, 8.0f, cfg);
            for(String line:wrapText(overallComment,p,leftRight-leftX-12)){drawText(canvas,p,line,leftX+5,commentY);commentY+=10;}
        }
        int termsTop=commentY+2;
        String pdfTerms=cfg==null?"":cfg.optString("termsConditions","").trim();
        boolean showPdfTerms=cfg!=null&&cfg.optBoolean("printTermsConditions",false)&&!pdfTerms.isEmpty();
        if(showPdfTerms){
            p.setTypeface(Typeface.DEFAULT_BOLD);setPdfTextSize(p, 7.6f, cfg);
            drawText(canvas,p,"Terms & Conditions:",leftX+5,termsTop+9);
            p.setTypeface(Typeface.DEFAULT);setPdfTextSize(p, 7.2f, cfg);
            java.util.List<String> termLines=wrapText(pdfTerms,p,leftRight-leftX-12);
            int termLineY=termsTop+19;
            for(String termLine:termLines){drawText(canvas,p,termLine,leftX+5,termLineY);termLineY+=10;}
            termsTop+=10+termLines.size()*10;
        }
        int gstTop=Math.max(termsTop+4,summaryTop+8);
        int leftPanelBottom=gstTop;
        if(taxInvoice){
            JSONArray gstGroups=tax.optJSONArray("groups");
            int groupCount=gstGroups==null?0:gstGroups.length();
            // Rate-wise summary: one row per GST rate, avoiding repetition of totals already shown at right.
            int gstWidth=leftRight-leftX; int titleH=16, headerH=19, rowH=16;
            int rows=Math.max(1,groupCount);
            float[] gc=a6Paper?new float[]{leftX,leftX+35,leftX+85,leftX+125,leftX+165,leftX+205,leftRight}:new float[]{leftX,leftX+48,leftX+111,leftX+154,leftX+197,leftX+240,leftRight};
            p.setTypeface(Typeface.DEFAULT_BOLD);setPdfTextSize(p, 7.4f, cfg);p.setTextAlign(Paint.Align.LEFT);
            p.setStyle(Paint.Style.FILL);p.setColor(invoiceHeaderFill);canvas.drawRect(leftX,gstTop,leftRight,gstTop+titleH,p);
            p.setStyle(Paint.Style.STROKE);p.setColor(invoiceGrid);drawOutlineRect(canvas,p,leftX,gstTop,leftRight,gstTop+titleH);p.setStyle(Paint.Style.FILL);p.setColor(android.graphics.Color.BLACK);
            drawText(canvas,p,"GST Rate Summary",leftX+5,gstTop+11);p.setTextAlign(Paint.Align.CENTER);
            int htop=gstTop+titleH;p.setStyle(Paint.Style.FILL);p.setColor(invoiceHeaderFill);canvas.drawRect(leftX,htop,leftRight,htop+headerH,p);p.setStyle(Paint.Style.STROKE);p.setColor(invoiceGrid);drawOutlineRect(canvas,p,leftX,htop,leftRight,htop+headerH);p.setStyle(Paint.Style.FILL);p.setColor(android.graphics.Color.BLACK);
            for(int k=1;k<gc.length-1;k++)canvas.drawLine(gc[k],htop,gc[k],htop+headerH+rows*rowH,p);
            String[] gh={"Rate","Taxable","CGST","SGST","IGST","Total GST"};
            for(int k=0;k<gh.length;k++)drawText(canvas,p,gh[k],(gc[k]+gc[k+1])/2f,htop+12);
            p.setTypeface(Typeface.DEFAULT);setPdfTextSize(p, 7.2f, cfg);
            if(groupCount==0){
                p.setStyle(Paint.Style.STROKE);drawOutlineRect(canvas,p,leftX,htop+headerH,leftRight,htop+headerH+rowH);p.setStyle(Paint.Style.FILL);
                drawText(canvas,p,"—",(leftX+leftRight)/2f,htop+headerH+11);
                leftPanelBottom=htop+headerH+rowH;
            } else {
                for(int gi=0;gi<groupCount;gi++){
                    JSONObject g=gstGroups.optJSONObject(gi); if(g==null)continue;
                    int rt=htop+headerH+gi*rowH, rb=rt+rowH;p.setStyle(Paint.Style.STROKE);drawOutlineRect(canvas,p,leftX,rt,leftRight,rb);p.setStyle(Paint.Style.FILL);
                    double rate=g.optDouble("rate",0), taxableValue=g.optDouble("taxable",0), taxValue=g.optDouble("tax",0);
                    boolean inter=tax.optBoolean("inter",false);double cg=inter?0:taxValue/2.0, sg=inter?0:taxValue/2.0, ig=inter?taxValue:0;
                    String[] vals={String.format(Locale.US,"%.0f%%",rate),formatBillValue(taxableValue),formatBillValue(cg),formatBillValue(sg),formatBillValue(ig),formatBillValue(taxValue)};
                    for(int k=0;k<vals.length;k++)drawText(canvas,p,vals[k],(gc[k]+gc[k+1])/2f,rt+11);
                }
                leftPanelBottom=htop+headerH+groupCount*rowH;
            }
        } else leftPanelBottom=(b.optBoolean("includeOverallComment",false)&&!overallComment.isEmpty())?Math.max(gstTop,commentY+3):leftPanelTop;
        boolean leftPanelVisible=taxInvoice||(b.optBoolean("includeOverallComment",false)&&!overallComment.isEmpty());
        if(leftPanelVisible) { p.setStyle(Paint.Style.STROKE); drawOutlineRect(canvas,p,leftX,leftPanelTop,leftRight,leftPanelBottom); p.setStyle(Paint.Style.FILL); }

        // Right panel: consistent two-column, Excel-like totals table with every cell bordered.
        java.util.List<String> totalLabels=new java.util.ArrayList<>();
        java.util.List<String> totalValues=new java.util.ArrayList<>();
        totalLabels.add("Subtotal");totalValues.add(formatBillValue(subtotal));
        if(discount>0.000001){totalLabels.add("Discount");totalValues.add("-"+formatBillValue(discount));}
        if(taxInvoice){totalLabels.add("Taxable Amount");totalValues.add(formatBillValue(tax.optDouble("taxable",0)));if(tax.optBoolean("inter",false)){totalLabels.add("IGST");totalValues.add(formatBillValue(tax.optDouble("igst",0)));}else{totalLabels.add("CGST");totalValues.add(formatBillValue(tax.optDouble("cgst",0)));totalLabels.add("SGST");totalValues.add(formatBillValue(tax.optDouble("sgst",0)));}totalLabels.add("Total GST");totalValues.add(formatBillValue(tax.optDouble("tax",0)));}
        double billRoundOff=b.optDouble("roundOff",0);if(Math.abs(billRoundOff)>=0.005){totalLabels.add("Round Off");totalValues.add((billRoundOff>0?"+":"-")+formatBillValue(Math.abs(billRoundOff)));}
        totalLabels.add("Total Amount");totalValues.add(formatBillValue(finalTotal));
        String paymentModeForSummary=b.optString("paymentMode","").trim();boolean creditBillForSummary=paymentModeForSummary.toLowerCase(Locale.US).contains("credit");boolean hasRecordedPayment=b.has("partialPaymentAmount")||b.has("paidAmount")||b.has("amountPaid");double partialPayment=hasRecordedPayment?b.optDouble("partialPaymentAmount",b.optDouble("paidAmount",b.optDouble("amountPaid",0))):0;if(!creditBillForSummary&&partialPayment<=0.000001)partialPayment=finalTotal;
        double billBalance=Math.max(0,finalTotal-partialPayment);
        totalLabels.add("Paid");totalValues.add(formatBillValue(partialPayment));
        if(creditBillForSummary){totalLabels.add("Bill Balance");totalValues.add(formatBillValue(billBalance));double customerTotalBalance=b.optDouble("customerTotalBalance",billBalance);totalLabels.add("Total Balance");totalValues.add(formatBillValue(Math.max(0,customerTotalBalance)));}
        int rowH=a6Paper?15:16;int rightBottom=summaryTop+totalLabels.size()*rowH;
        float split=a6Paper?rightX+145:rightX+142;
        for(int ri=0;ri<totalLabels.size();ri++){
            int rt=summaryTop+ri*rowH, rb=rt+rowH;
            boolean prominent="Total Amount".equals(totalLabels.get(ri))||"Bill Balance".equals(totalLabels.get(ri));
            p.setStyle(Paint.Style.FILL);if("Total Amount".equals(totalLabels.get(ri)))p.setColor(invoiceAccentFill);else if("Bill Balance".equals(totalLabels.get(ri)))p.setColor(invoiceHeaderFill);else p.setColor(android.graphics.Color.WHITE);canvas.drawRect(rightX,rt,rightRight,rb,p);
            p.setStyle(Paint.Style.STROKE);p.setColor(invoiceGrid);drawOutlineRect(canvas,p,rightX,rt,rightRight,rb);canvas.drawLine(split,rt,split,rb,p); p.setStyle(Paint.Style.FILL);p.setColor(android.graphics.Color.BLACK);
            p.setTypeface(prominent?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);setPdfTextSize(p, prominent?9.0f:8.2f, cfg);p.setTextAlign(Paint.Align.RIGHT);drawText(canvas,p,totalLabels.get(ri),split-5,rt+(a6Paper?10:11));p.setTextAlign(Paint.Align.RIGHT);drawText(canvas,p,totalValues.get(ri),rightRight-5,rt+(a6Paper?10:11));
        }
        p.setTextAlign(Paint.Align.LEFT);p.setTypeface(Typeface.DEFAULT);
        int summaryBottom=Math.max(leftPanelBottom,rightBottom);

        // Full-width bordered transaction table below both summary panels.
        JSONArray recentTransactions=b.optBoolean("includeLast5Transactions",false)?b.optJSONArray("last5Transactions"):null;
        int transactionsBottom=summaryBottom+8;
        if(recentTransactions!=null && recentTransactions.length()>0){
            int ty=summaryBottom+14;int tableLeft=35,tableRight=560;int headBottom=ty+17;
            p.setTypeface(Typeface.DEFAULT_BOLD);setPdfTextSize(p, 8.0f, cfg);p.setTextAlign(Paint.Align.LEFT);
            p.setStyle(Paint.Style.FILL);p.setColor(invoiceHeaderFill);canvas.drawRect(tableLeft,ty,tableRight,headBottom,p);p.setStyle(Paint.Style.STROKE);p.setColor(invoiceGrid);drawOutlineRect(canvas,p,tableLeft,ty,tableRight,headBottom);p.setStyle(Paint.Style.FILL);p.setColor(android.graphics.Color.BLACK);drawText(canvas,p,"Last 5 Customer Transactions (Latest First)",tableLeft+5,ty+12);
            int colY=headBottom;int rowHeight=19;
            // Seven columns requested: Date, Type, Bill/Txn No, Bill Amt, Paid, Previous Balance, Total Balance.
            float[] tc={tableLeft,tableLeft+78,tableLeft+126,tableLeft+282,tableLeft+346,tableLeft+398,tableLeft+460,tableRight};
            p.setStyle(Paint.Style.FILL);p.setColor(invoiceHeaderFill);canvas.drawRect(tableLeft,colY,tableRight,colY+rowHeight,p);p.setStyle(Paint.Style.STROKE);p.setColor(invoiceGrid);drawOutlineRect(canvas,p,tableLeft,colY,tableRight,colY+rowHeight);p.setStyle(Paint.Style.FILL);p.setColor(android.graphics.Color.BLACK);for(int k=1;k<tc.length-1;k++)canvas.drawLine(tc[k],colY,tc[k],colY+rowHeight,p);
            String[] th={"DATE","TYPE","BILL/TXN NO","BILL AMT.","PAID","P.BAL.","TOTAL BALANCE"};
            for(int k=0;k<th.length;k++){setPdfTextSize(p, k==6?6.7f:7.1f, cfg);if(k<3){p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,th[k],tc[k]+3,colY+12);}else{p.setTextAlign(Paint.Align.CENTER);drawText(canvas,p,th[k],(tc[k]+tc[k+1])/2f,colY+12);}}
            int rowY=colY+rowHeight;p.setTypeface(Typeface.DEFAULT);setPdfTextSize(p, 7.0f, cfg);
            for(int ti=0;ti<recentTransactions.length()&&ti<5;ti++){
                JSONObject tr=recentTransactions.optJSONObject(ti);if(tr==null)continue;
                drawOutlineRect(canvas,p,tableLeft,rowY,tableRight,rowY+rowHeight);for(int k=1;k<tc.length-1;k++)canvas.drawLine(tc[k],rowY,tc[k],rowY+rowHeight,p);
                String rawDate=tr.optString("date","");String displayDate=formatDate(rawDate);
                String type=tr.optString("type","").replace("Credit sale","Credit").replace("Payment received","Payment");String ref=tr.optString("reference","");
                double bal=tr.optDouble("balance",tr.optDouble("balanceDue",0));
                double prev=tr.has("previousBalance")?tr.optDouble("previousBalance",0):bal-tr.optDouble("debit",0)+tr.optDouble("credit",0);
                String txnTypeLower=type.toLowerCase(Locale.US);
                boolean paymentTxn=txnTypeLower.contains("payment")||txnTypeLower.contains("receipt")||txnTypeLower.equals("pay");
                boolean creditTxn=txnTypeLower.contains("credit");
                boolean saleTxn=!paymentTxn&&(creditTxn||txnTypeLower.contains("cash")||txnTypeLower.contains("sale")||txnTypeLower.contains("bill"));
                double billAmt=saleTxn?tr.optDouble("billTotal",tr.optDouble("total",tr.optDouble("amount",0))):0;
                double paid=creditTxn?tr.optDouble("paymentAmount",tr.optDouble("paidAmount",tr.optDouble("paid",0))):(saleTxn?billAmt:tr.optDouble("paymentAmount",tr.optDouble("paidAmount",tr.optDouble("amount",0))));
                p.setTextAlign(Paint.Align.LEFT);drawText(canvas,p,trimText(displayDate,13),tc[0]+3,rowY+12);drawText(canvas,p,trimText(type,8),tc[1]+3,rowY+12);drawText(canvas,p,trimText(ref,24),tc[2]+3,rowY+12);
                p.setTextAlign(Paint.Align.RIGHT);drawText(canvas,p,formatBillValue(billAmt),tc[4]-4,rowY+12);drawText(canvas,p,formatBillValue(paid),tc[5]-4,rowY+12);drawText(canvas,p,formatBillValue(prev),tc[6]-4,rowY+12);drawText(canvas,p,formatBillValue(bal),tc[7]-4,rowY+12);rowY+=rowHeight;
            }
            p.setTextAlign(Paint.Align.LEFT);transactionsBottom=rowY+3;
        }
        p.setTypeface(Typeface.DEFAULT);
        setPdfTextSize(p, 10, cfg);
        int footerY=Math.max(summaryBottom+20,transactionsBottom+20);
        int customFooterIndex=0;if(cfg!=null&&customFields!=null){String[] keys={"field1","field2","field3"};String[] labelKeys={"customBillField1Label","customBillField2Label","customBillField3Label"};String[] posKeys={"customBillField1Position","customBillField2Position","customBillField3Position"};for(int i=0;i<keys.length;i++){String label=cfg.optString(labelKeys[i],"").trim(),value=customFields.optString(keys[i],"").trim(),pos=cfg.optString(posKeys[i],i==2?"footer":"header").trim().toLowerCase(Locale.US);if(label.toLowerCase(Locale.US).contains("warranty")&&!value.isEmpty())value=formatDate(value);if(!label.isEmpty()&&!value.isEmpty()&&"footer".equals(pos)){if(label.toLowerCase(Locale.US).contains("warranty"))value=formatDate(value);drawText(canvas,p,label+": "+value,35,footerY);footerY+=14;customFooterIndex++;}}}
        // Single thank-you line, followed by QR and a centered creator/contact footer.
        p.setTypeface(Typeface.DEFAULT_BOLD);setPdfTextSize(p, 10, cfg);p.setTextAlign(Paint.Align.CENTER);
        drawText(canvas,p,"Thank you for shopping with us!",pageWidth/2f,footerY+10);footerY+=22;
        String footerMsg = cfg == null ? "" : cfg.optString("footer","").trim();
        if(!footerMsg.isEmpty() && !"Thank you for shopping with us!".equalsIgnoreCase(footerMsg)){
            p.setTypeface(Typeface.DEFAULT);setPdfTextSize(p, 8.5f, cfg);
            for(String line:wrapText(footerMsg,p,500)){drawText(canvas,p,line,pageWidth/2f,footerY);footerY+=12;}
        }
        if(cfg!=null&&cfg.optBoolean("upiQrEnabled",false)){
            // drawCenteredBillQr also draws the "Scan & Pay" caption below the QR.
            // Reserve the full image + caption + spacing so the credit footer cannot overlap it.
            int qrSize=72;
            drawCenteredBillQr(canvas,p,b,cfg,(int)(pageWidth/2f),footerY+4,qrSize);
            footerY+=qrSize+42;
        }
        // Terms & Conditions are rendered once in the summary panel; never repeat them in the footer.
        String signature = cfg == null ? "" : cfg.optString("signature","").trim();
        if(!signature.isEmpty()){
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextAlign(Paint.Align.RIGHT);drawText(canvas,p,signature,555,footerY);
            p.setTypeface(Typeface.DEFAULT);drawText(canvas,p,"Authorized Signatory",555,footerY+12);footerY+=14;
        }
        p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.ITALIC));setPdfTextSize(p, 7.5f, cfg);p.setTextAlign(Paint.Align.CENTER);
        String creditFooter=cfg == null ? "Bill created by SiddhiBill • Contact 8087794271 for more details" : cfg.optString("creditFooter","Bill created by SiddhiBill • Contact 8087794271 for more details").trim();
        if(!creditFooter.isEmpty()){
            // Never clamp the footer to a fixed Y coordinate: that caused overlap when the QR was enabled.
            drawText(canvas,p,creditFooter,pageWidth/2f,footerY+10);
        }
        p.setTypeface(Typeface.DEFAULT);p.setTextAlign(Paint.Align.LEFT);

        doc.finishPage(page);
        ByteArrayOutputStream bos=new ByteArrayOutputStream();
        doc.writeTo(bos); doc.close();
        String filename="Bill_"+b.optString("billNo","Bill").replaceAll("[^A-Za-z0-9_-]","_")+".pdf";
        return saveForSharing(bos.toByteArray(),filename,"application/pdf");
    }

    private String trimText(String s,int max){ if(s==null)return ""; return s.length()>max?s.substring(0,max-1)+"…":s; }
    private String formatDate(String d) {
        if (d == null) return "";
        String v = d.trim();
        if (v.isEmpty()) return "";
        String[] months = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
        try {
            // ISO: yyyy-MM-dd or yyyy-MM-ddTHH:mm:ss
            if (v.length() >= 10 && v.charAt(4) == '-' && v.charAt(7) == '-') {
                int year = Integer.parseInt(v.substring(0, 4));
                int month = Integer.parseInt(v.substring(5, 7));
                int day = Integer.parseInt(v.substring(8, 10));
                if (month >= 1 && month <= 12 && day >= 1 && day <= 31)
                    return String.format(Locale.US, "%02d/%s/%04d", day, months[month - 1], year);
            }
            // Existing UI/storage date: dd/MM/yyyy
            if (v.length() >= 10 && v.charAt(2) == '/' && v.charAt(5) == '/') {
                int day = Integer.parseInt(v.substring(0, 2));
                int month = Integer.parseInt(v.substring(3, 5));
                int year = Integer.parseInt(v.substring(6, 10));
                if (month >= 1 && month <= 12 && day >= 1 && day <= 31)
                    return String.format(Locale.US, "%02d/%s/%04d", day, months[month - 1], year);
            }
            // Existing UI/storage date: dd-MMM-yyyy; leave already-readable dates unchanged.
            return v;
        } catch (RuntimeException ignored) {
            return v;
        }
    }
    private String monthShort(String m) {
        String[] months={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
        if (m == null || m.trim().isEmpty()) return "";
        try { int n=Integer.parseInt(m.trim()); return n>=1&&n<=12?months[n-1]:m; }
        catch(Exception e) { return m; }
    }

    private double quantityValue(String q, String defaultUnit){
        if(q==null)return 0;
        String s=q.trim().toLowerCase().replace(",","");
        try{
            java.util.regex.Matcher m=java.util.regex.Pattern.compile(
                    "(\\d+(?:\\.\\d+)?)\\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pack|packs|box|boxes|bottle|bottles|dozen)?",
                    java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s);
            if(!m.find()) return 0;
            double n=Double.parseDouble(m.group(1));
            String u=m.group(2); if(u==null)u=defaultUnit==null?"piece":defaultUnit;
            u=u.toLowerCase();
            if(u.equals("mg")||u.startsWith("milligram"))return n/1000000.0;
            if(u.equals("g")||u.equals("gm")||u.startsWith("gram"))return n/1000.0;
            if(u.equals("ml")||u.startsWith("milliliter")||u.startsWith("millilitre"))return n/1000.0;
            if(u.equals("l")||u.equals("ltr")||u.equals("lt")||u.equals("liter")||u.equals("litre")||u.equals("liters")||u.equals("litres"))return n;
            if(u.equals("dozen")||u.equals("dz"))return n*12.0;
            return n;
        }catch(Exception e){return 0;}
    }

    private File copyToPurchaseStorage(Uri uri, String originalName) throws Exception {
        String safe=UUID.randomUUID().toString()+"_"+(originalName==null?"document":originalName).replaceAll("[^A-Za-z0-9._-]","_");
        File outFile=new File(purchaseDocsDir,safe);
        try(InputStream in=getContentResolver().openInputStream(uri); OutputStream out=new FileOutputStream(outFile)){
            if(in==null)throw new Exception("Could not read selected document");
            byte[] buf=new byte[8192]; int n;
            while((n=in.read(buf))>0)out.write(buf,0,n);
        }
        return outFile;
    }

    private void sendPurchaseProgress(String message){
        try{
            String encoded=android.util.Base64.encodeToString(message.getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
            runOnUiThread(()->webView.evaluateJavascript("window.onPurchaseImportProgress && window.onPurchaseImportProgress(atob('"+encoded+"'))",null));
        }catch(Exception ignored){}
    }

    private void sendPurchaseError(String message){
        try{
            String encoded=android.util.Base64.encodeToString((message==null?"Unknown error":message).getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
            runOnUiThread(()->webView.evaluateJavascript("window.onPurchaseImportError && window.onPurchaseImportError(atob('"+encoded+"'))",null));
        }catch(Exception ignored){}
    }

    private void sendPurchaseResult(String attachmentId,String fileName,String mime,String text){
        try{
            JSONObject o=new JSONObject();
            o.put("attachmentId",attachmentId);
            o.put("fileName",fileName==null?"":fileName);
            o.put("mime",mime==null?"":mime);
            o.put("text",text==null?"":text);
            String encoded=android.util.Base64.encodeToString(o.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
            runOnUiThread(()->webView.evaluateJavascript("window.onPurchaseImportResultBase64 && window.onPurchaseImportResultBase64('"+encoded+"')",null));
        }catch(Exception e){sendPurchaseError(e.getMessage());}
    }

    private void ocrImage(Uri uri, File stored, String fileName, String mime){
        sendPurchaseProgress("Reading invoice photo...");
        try{
            Bitmap bitmap=BitmapFactory.decodeFile(stored.getAbsolutePath());
            if(bitmap==null)throw new Exception("Could not decode the selected image");
            // Normalize phone-camera EXIF orientation before ML Kit so rotated camera photos
            // are recognized consistently with gallery uploads.
            try{
                androidx.exifinterface.media.ExifInterface exif=new androidx.exifinterface.media.ExifInterface(stored.getAbsolutePath());
                int orientation=exif.getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL);
                android.graphics.Matrix matrix=new android.graphics.Matrix();
                if(orientation==androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_90)matrix.postRotate(90f);
                else if(orientation==androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_180)matrix.postRotate(180f);
                else if(orientation==androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_270)matrix.postRotate(270f);
                else if(orientation==androidx.exifinterface.media.ExifInterface.ORIENTATION_FLIP_HORIZONTAL)matrix.preScale(-1f,1f);
                else if(orientation==androidx.exifinterface.media.ExifInterface.ORIENTATION_FLIP_VERTICAL)matrix.preScale(1f,-1f);
                if(!matrix.isIdentity()){
                    Bitmap rotated=Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
                    if(rotated!=bitmap){bitmap.recycle();bitmap=rotated;}
                }
            }catch(Exception ignored){}
            final Bitmap bitmapForOcr=bitmap;
            InputImage image=InputImage.fromBitmap(bitmapForOcr,0);
            TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            recognizer.process(image)
                .addOnSuccessListener(result->{
                    recognizer.close();
                    bitmapForOcr.recycle();
                    sendPurchaseProgress("Invoice photo read. Preparing purchase details...");
                    sendPurchaseResult(stored.getName(),fileName,mime,result.getText());
                })
                .addOnFailureListener(e->{recognizer.close();bitmapForOcr.recycle();sendPurchaseError("OCR failed: "+e.getMessage());});
        }catch(Exception e){sendPurchaseError("Could not read photo: "+e.getMessage());}
    }

    private String extractPdfText(File stored) throws Exception {
        try (PDDocument document = PDDocument.load(stored)) {
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
            String text = stripper.getText(document);
            return text == null ? "" : text;
        }
    }

    private void ocrPdf(Uri uri, File stored, String fileName, String mime){
        sendPurchaseProgress("Opening PDF invoice...");
        final ExecutorService executor=Executors.newSingleThreadExecutor();
        executor.execute(()->{
            try{
                // First try the PDF's native text layer. Most vendor invoices are
                // generated PDFs and this is considerably more accurate than OCR.
                sendPurchaseProgress("Checking the PDF text layer...");
                String directText=extractPdfText(stored);
                if(directText!=null && directText.trim().length()>50){
                    sendPurchaseProgress("PDF text found. Extracted " + directText.trim().length() + " characters.");
                    sendPurchaseResult(stored.getName(),fileName,mime,directText);
                    executor.shutdown();
                    return;
                }

                // Scanned/image-only PDF: fall back to page rendering + ML Kit OCR.
                sendPurchaseProgress("No usable PDF text layer found. Starting OCR...");
                ParcelFileDescriptor pfd=null;
                PdfRenderer renderer=null;
                try{
                    pfd=ParcelFileDescriptor.open(stored,ParcelFileDescriptor.MODE_READ_ONLY);
                    renderer=new PdfRenderer(pfd);
                    int pages=renderer.getPageCount();
                    StringBuilder all=new StringBuilder();
                    sendPurchaseProgress("PDF opened. " + pages + " page(s) found.");
                    TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                    try{
                        for(int index=0; index<pages; index++){
                            sendPurchaseProgress("Reading PDF page " + (index+1) + " of " + pages + "...");
                            PdfRenderer.Page page=renderer.openPage(index);
                            try{
                                float scale=3.0f;
                                int w=Math.max(1600,Math.round(page.getWidth()*scale));
                                int h=Math.max(2200,Math.round(page.getHeight()*scale));
                                float ratio=(float)page.getWidth()/(float)page.getHeight();
                                if((float)w/(float)h > ratio) w=Math.round(h*ratio); else h=Math.round(w/ratio);
                                Bitmap bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
                                Canvas canvas=new Canvas(bmp);
                                canvas.drawColor(android.graphics.Color.WHITE);
                                page.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT);
                                InputImage image=InputImage.fromBitmap(bmp,0);
                                try{
                                    com.google.mlkit.vision.text.Text result=Tasks.await(recognizer.process(image));
                                    String pageText=result==null?"":result.getText();
                                    if(pageText!=null && !pageText.trim().isEmpty()){
                                        all.append("\n").append(pageText);
                                        sendPurchaseProgress("Page " + (index+1) + " read. " + pageText.length() + " characters found...");
                                    }else{
                                        sendPurchaseProgress("Page " + (index+1) + " read, but no text was detected.");
                                    }
                                } finally { bmp.recycle(); }
                            } finally { page.close(); }
                        }
                    } finally { recognizer.close(); }
                    String finalText=all.toString();
                    sendPurchaseProgress("OCR complete. " + finalText.trim().length() + " characters extracted.");
                    sendPurchaseResult(stored.getName(),fileName,mime,finalText);
                } finally {
                    try{if(renderer!=null)renderer.close();}catch(Exception ignored){}
                    try{if(pfd!=null)pfd.close();}catch(Exception ignored){}
                }
            }catch(Exception e){
                sendPurchaseError("Could not read PDF: " + (e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));
            }finally{
                executor.shutdown();
            }
        });
    }

    private void importPurchaseUri(Uri uri){
        try{
            String original=uri.getLastPathSegment();
            if(original==null||original.trim().isEmpty()) original="vendor_bill_"+System.currentTimeMillis();
            String mime=getContentResolver().getType(uri);
            if(mime==null||mime.trim().isEmpty()) mime=original.toLowerCase().endsWith(".pdf")?"application/pdf":"image/jpeg";
            sendPurchaseProgress("Saving the original vendor bill...");
            File stored=copyToPurchaseStorage(uri,original);
            String lower=original.toLowerCase();
            if(mime.equalsIgnoreCase("application/pdf")||lower.endsWith(".pdf")) ocrPdf(uri,stored,original,mime);
            else ocrImage(uri,stored,original,mime);
        }catch(Exception e){sendPurchaseError("Could not import purchase bill: "+e.getMessage());}
    }

    private void openPurchaseAttachment(String id,String mime){
        try{
            File file=new File(purchaseDocsDir,id);
            if(!file.exists())throw new Exception("Attachment not found");
            byte[] data=readAll(file);
            Uri uri=saveToCacheProvider(data,file.getName());
            Intent view=new Intent(Intent.ACTION_VIEW);
            view.setDataAndType(uri,mime==null?"application/octet-stream":mime);
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            view.setClipData(ClipData.newRawUri(file.getName(),uri));
            startActivity(Intent.createChooser(view,"Open Purchase Bill"));
        }catch(Exception e){Toast.makeText(this,"Could not open attachment: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private byte[] readAll(File f)throws Exception{
        try(InputStream in=new FileInputStream(f);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);return out.toByteArray();
        }
    }

    private String loadAppState() {
        try { return localDb.loadState(); } catch (Exception e) { return "{}"; }
    }

    private void saveAppState(String json) {
        try { localDb.saveState(json); } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "Could not save local data: " + e.getMessage(), Toast.LENGTH_LONG).show());
        }
    }

    private void addFileToZip(ZipOutputStream zos, File file, String entryName) throws Exception {
        ZipEntry entry = new ZipEntry(entryName);
        zos.putNextEntry(entry);
        try (InputStream in = new FileInputStream(file)) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
        }
        zos.closeEntry();
    }

    private static byte[] hexToBytes(String hex) {
        byte[] out = new byte[hex.length()/2];
        for (int i=0;i<out.length;i++) out[i]=(byte)Integer.parseInt(hex.substring(i*2,i*2+2),16);
        return out;
    }

    private static String hex(byte[] data) {
        StringBuilder sb=new StringBuilder(data.length*2);
        for(byte b:data) sb.append(String.format(Locale.US,"%02x",b & 0xff));
        return sb.toString();
    }

    private boolean verifyShopNamePasswordInternal(String password) {
        if (password == null) return false;
        try {
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[] salt=hexToBytes(SHOP_PASSWORD_SALT_HEX);
            byte[] h=md.digest(concat(salt, password.getBytes(StandardCharsets.UTF_8)));
            for(int i=0;i<SHOP_PASSWORD_ITERATIONS;i++) h=md.digest(concat(salt,h));
            return MessageDigest.isEqual(h, hexToBytes(SHOP_PASSWORD_DIGEST_HEX));
        } catch(Exception e){ return false; }
    }

    private static byte[] concat(byte[] a, byte[] b) {
        byte[] out=new byte[a.length+b.length];
        System.arraycopy(a,0,out,0,a.length); System.arraycopy(b,0,out,a.length,b.length); return out;
    }

    /** Create a compact integrity signature for the protected shop name.
     *  Restore never asks the user for a password. The signature lets the app detect
     *  casual/manual edits to the shop name inside a backup while keeping restore portable.
     */
    private String shopNameIntegrity(String shopName) throws Exception {
        if (shopName == null) shopName = "";
        byte[] key = hexToBytes(SHOP_PASSWORD_DIGEST_HEX);
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(key, "HmacSHA256"));
        return hex(mac.doFinal(shopName.getBytes(StandardCharsets.UTF_8)));
    }

    private boolean verifyShopNameIntegrity(String shopName, String signature) {
        try {
            if (signature == null || signature.trim().isEmpty()) return false;
            return MessageDigest.isEqual(shopNameIntegrity(shopName).getBytes(StandardCharsets.UTF_8), signature.trim().toLowerCase(Locale.US).getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) { return false; }
    }

    private void verifyBackupDatabase(File dbFile) throws Exception {
        android.database.sqlite.SQLiteDatabase check = android.database.sqlite.SQLiteDatabase.openDatabase(
                dbFile.getAbsolutePath(), null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY);
        try {
            try (android.database.Cursor c = check.rawQuery("PRAGMA integrity_check", null)) {
                if (!c.moveToFirst() || !"ok".equalsIgnoreCase(c.getString(0))) throw new Exception("SQLite integrity check failed; backup was not created.");
            }
            try (android.database.Cursor c = check.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null)) {
                java.util.Set<String> tables = new java.util.HashSet<>();
                while (c.moveToNext()) tables.add(c.getString(0));
                if (!tables.contains("app_state") || !tables.contains("meta")) throw new Exception("Database is missing expected tables; backup was not created.");
            }
        } finally { check.close(); }
    }

    private File createBackupZip() throws Exception {
        File backupDir = new File(getCacheDir(), "backups");
        if (!backupDir.exists() && !backupDir.mkdirs()) throw new Exception("Could not create backup workspace");
        String stamp = new java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new java.util.Date());
        File zip = new File(backupDir, "SiddhiBill_Backup_" + stamp + "_" + (System.currentTimeMillis()%100000) + ".zip");
        // The complete SQLite database contains every table (currently app_state and meta).
        // Checkpoint WAL and close the helper before copying the main DB so committed rows
        // are not left only in a sidecar file.
        String state = localDb.loadState();
        android.database.Cursor checkpoint = null;
        try {
            checkpoint = localDb.getWritableDatabase().rawQuery("PRAGMA wal_checkpoint(FULL)", null);
            if (checkpoint.moveToFirst() && checkpoint.getInt(0) != 0) throw new Exception("SQLite is busy; close other operations and retry backup.");
        } finally { if (checkpoint != null) checkpoint.close(); }
        localDb.close();
        File dbFile = getDatabasePath("dukaanbill.db");
        if (!dbFile.exists() || dbFile.length() == 0) throw new Exception("Local database is missing or empty. Please reopen the app and try again.");
        // Verify the DB is readable and has all expected tables before putting it in the ZIP.
        verifyBackupDatabase(dbFile);
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zip))) {
            addFileToZip(zos, dbFile, BACKUP_DB_ENTRY);
            ZipEntry manifest = new ZipEntry("database/manifest.json");
            zos.putNextEntry(manifest);
            JSONObject manifestJson = new JSONObject();
            manifestJson.put("app", "SiddhiBill");
            manifestJson.put("schemaVersion", 2);
            manifestJson.put("databaseEntry", BACKUP_DB_ENTRY);
            org.json.JSONArray tableNames = new org.json.JSONArray();
            android.database.sqlite.SQLiteDatabase tableDb = android.database.sqlite.SQLiteDatabase.openDatabase(dbFile.getAbsolutePath(), null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY);
            try (android.database.Cursor tableCursor = tableDb.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name", null)) {
                while (tableCursor.moveToNext()) tableNames.put(tableCursor.getString(0));
            } finally { tableDb.close(); }
            manifestJson.put("tables", tableNames);
            manifestJson.put("stateKeys", new JSONObject(state).length());
            // Build the complete key inventory before writing the manifest.
            JSONObject manifestStateJson = new JSONObject(state);
            org.json.JSONArray moduleKeyArray = new org.json.JSONArray();
            java.util.Iterator<String> manifestKeyIterator = manifestStateJson.keys();
            while (manifestKeyIterator.hasNext()) moduleKeyArray.put(manifestKeyIterator.next());
            manifestJson.put("snapshotEntry", "data/modules_snapshot.json");
            manifestJson.put("snapshotKeys", moduleKeyArray);
            zos.write(manifestJson.toString().getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();
            ZipEntry stateEntry = new ZipEntry(BACKUP_STATE_ENTRY);
            zos.putNextEntry(stateEntry);
            zos.write(state.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            zos.closeEntry();
            // Add a directly readable settings snapshot and module inventory alongside the full DB/state.
            JSONObject fullStateJson = new JSONObject(state);
            ZipEntry settingsEntry = new ZipEntry("settings/settings.json");
            zos.putNextEntry(settingsEntry);
            String settingsJson = fullStateJson.optString("dukaanBillSettings", "{}");
            try { settingsJson = new JSONObject(settingsJson).toString(2); } catch (Exception ignored) { settingsJson = "{}"; }
            zos.write(settingsJson.getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();
            // Snapshot every persisted app-state key. This prevents newly added modules
            // (for example expenses) from being silently omitted from the readable snapshot.
            JSONObject moduleSnapshot = new JSONObject();
            java.util.Iterator<String> stateKeyIterator = fullStateJson.keys();
            while (stateKeyIterator.hasNext()) {
                String key = stateKeyIterator.next();
                moduleSnapshot.put(key, fullStateJson.opt(key));
            }
            ZipEntry modulesEntry = new ZipEntry("data/modules_snapshot.json");
            zos.putNextEntry(modulesEntry);
            zos.write(moduleSnapshot.toString(2).getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();

            String shopName = "SIDDHIBILL";
            try { shopName = new JSONObject(state).optString("shopName", shopName); } catch (Exception ignored) {}
            ZipEntry identityEntry = new ZipEntry(BACKUP_IDENTITY_ENTRY);
            zos.putNextEntry(identityEntry);
            JSONObject identity = new JSONObject();
            identity.put("version", 1);
            identity.put("shopNameSignature", shopNameIntegrity(shopName));
            zos.write(identity.toString().getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();

            if (purchaseDocsDir.exists()) {
                File[] files = purchaseDocsDir.listFiles();
                if (files != null) {
                    for (File f : files) if (f.isFile()) addFileToZip(zos, f, "attachments/" + f.getName());
                }
            }
            ZipEntry ownerEntry = new ZipEntry(BACKUP_OWNER_ENTRY);
            zos.putNextEntry(ownerEntry);
            String ownerJson = pendingOwnerDashboardBackup == null ? "{}" : pendingOwnerDashboardBackup;
            zos.write(ownerJson.getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();

            ZipEntry info = new ZipEntry("backup_info.txt");
            zos.putNextEntry(info);
            String text = "SiddhiBill\nBackup created: " + new java.util.Date() + "\nIncludes complete local SQLite database and app state; settings; products and inventory movements; purchases and vendors; team members, attendance and payments; brokers, commissions and payments; estimates; GST compliance; sales bills, customers and payments; Owner Dashboard shop/device registry (excluding Owner private key); protected shop identity metadata; and purchase invoice attachments.\nRestore does not require a password.\n";
            zos.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            zos.closeEntry();
        }
        // Re-open the finished ZIP and verify the required entries before offering it to the user.
        try (java.util.zip.ZipFile checkZip = new java.util.zip.ZipFile(zip)) {
            String[] requiredEntries = {BACKUP_DB_ENTRY, BACKUP_STATE_ENTRY, "database/manifest.json", "data/modules_snapshot.json", "settings/settings.json"};
            for (String entryName : requiredEntries) if (checkZip.getEntry(entryName) == null) throw new Exception("Backup validation failed: missing " + entryName);
            if (checkZip.getEntry(BACKUP_DB_ENTRY).getSize() <= 0 || checkZip.getEntry(BACKUP_STATE_ENTRY).getSize() <= 0) throw new Exception("Backup validation failed: empty database or app state.");
            JSONObject snapshot = new JSONObject(new String(readZipEntry(checkZip, "data/modules_snapshot.json"), StandardCharsets.UTF_8));
            if (snapshot.length() != new JSONObject(state).length()) throw new Exception("Backup validation failed: not all app-state keys were captured.");
        }
        return zip;
    }

    private byte[] readZipEntry(java.util.zip.ZipFile zip, String name) throws Exception {
        java.util.zip.ZipEntry entry = zip.getEntry(name);
        if (entry == null) throw new Exception("Missing ZIP entry: " + name);
        try (InputStream in = zip.getInputStream(entry); java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
            return out.toByteArray();
        }
    }

    // Best-effort chained one-time work supports a user-configurable interval in hours.
    private void scheduleAutoBackup(){
        int hours=getSharedPreferences("siddhibill_auto_backup",MODE_PRIVATE).getInt("interval_hours",12);
        hours=Math.max(1,Math.min(720,hours));
        OneTimeWorkRequest request=new OneTimeWorkRequest.Builder(AutoBackupWorker.class)
            .setInitialDelay(hours,java.util.concurrent.TimeUnit.HOURS).build();
        WorkManager.getInstance(getApplicationContext()).enqueueUniqueWork("siddhibill-auto-backup-test-loop",ExistingWorkPolicy.REPLACE,request);
    }
    private void configureAutoBackup(String mode,String hoursText){
        int hours=12;try{hours=Integer.parseInt(hoursText==null?"12":hoursText.trim());}catch(Exception ignored){}
        if(hours<1||hours>720){Toast.makeText(this,"Enter a backup interval from 1 to 720 hours.",Toast.LENGTH_LONG).show();return;}
        getSharedPreferences("siddhibill_auto_backup",MODE_PRIVATE).edit().putInt("interval_hours",hours).apply();
        pendingAutoBackupMode=mode;
        try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,REQ_AUTO_BACKUP_FOLDER);}
        catch(Exception e){Toast.makeText(this,"Could not open folder picker: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void notifyAutoBackupStatus(){
        android.content.SharedPreferences p=getSharedPreferences("siddhibill_auto_backup",MODE_PRIVATE);String mode=p.getString("destination","");String last=p.getString("last_success","");int hours=p.getInt("interval_hours",12);String folder=p.getString("tree_uri","");String message=mode.isEmpty()?"Automatic backup is not configured.":"Destination: "+("drive".equals(mode)?"Google Drive folder":"selected device folder")+". Interval: every "+hours+" hour(s). Folder: "+(folder.isEmpty()?"not selected":folder)+". Last successful backup: "+(last.isEmpty()?"not yet completed":last)+".";
        if(webView!=null){String q=JSONObject.quote(message);runOnUiThread(()->webView.evaluateJavascript("window.setAutoBackupStatus && window.setAutoBackupStatus("+q+")",null));}
    }

    private void notifyArchiveZipSaved(boolean ok, String message){
        if(webView!=null){String q=JSONObject.quote(message==null?"":message);runOnUiThread(()->webView.evaluateJavascript("window.onArchiveZipSaved && window.onArchiveZipSaved("+ok+","+q+")",null));}
    }

    private void updateBackupStatus(String message, boolean finished) {
        if (webView != null) {
            final String quoted = JSONObject.quote(message == null ? "" : message);
            runOnUiThread(() -> webView.evaluateJavascript("window.setNativeBackupStatus && window.setNativeBackupStatus(" + quoted + "," + finished + ")", null));
        }
    }

    private void startBackup() {
        updateBackupStatus("Preparing backup file…", false);
        new Thread(() -> {
            try {
                File created = createBackupZip();
                if (created.length() < 100) throw new Exception("Backup ZIP is unexpectedly small; no backup was saved.");
                runOnUiThread(() -> {
                    pendingBackupZip = created;
                    try {
                        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("application/zip");
                        i.putExtra(Intent.EXTRA_TITLE, created.getName());
                        updateBackupStatus("Backup prepared. Choose a folder or cloud location to save the ZIP.", false);
                        startActivityForResult(i, REQ_BACKUP_CREATE);
                    } catch (Exception e) {
                        updateBackupStatus("Could not open the save dialog: " + e.getMessage(), true);
                        Toast.makeText(this, "Could not open backup save dialog: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                updateBackupStatus("Backup failed: " + e.getMessage(), true);
                runOnUiThread(() -> Toast.makeText(this, "Backup failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }, "siddhibill-backup").start();
    }

    private void copyFileToUri(File src, Uri dest) throws Exception {
        try (InputStream in = new FileInputStream(src); OutputStream out = getContentResolver().openOutputStream(dest)) {
            if (out == null) throw new Exception("Could not open backup destination");
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            out.flush();
        }
    }

    private void startRestore() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        startActivityForResult(i, REQ_BACKUP_RESTORE);
    }

    private boolean safeZipPath(String name) {
        if (name == null || name.length() == 0 || name.startsWith("/") || name.contains("\\")) return false;
        return !name.contains("../") && !name.equals("..") && !name.contains("/../");
    }

    private void restoreBackup(Uri uri) throws Exception {
        File restoreDir = new File(getCacheDir(), "restore_" + System.currentTimeMillis());
        if (!restoreDir.mkdirs()) throw new Exception("Could not create restore workspace");
        File zipFile = new File(restoreDir, "backup.zip");
        try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(zipFile)) {
            if (in == null) throw new Exception("Could not read backup file");
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) out.write(b,0,n);
        }
        File restoredDb = new File(restoreDir, "dukaanbill.db");
        File restoredState = new File(restoreDir, "app_state.json");
        File restoredAttachments = new File(restoreDir, "attachments");
        File restoredIdentity = new File(restoreDir, "shop_identity.sig");
        File restoredOwner = new File(restoreDir, "owner_dashboard.json");
        if (!restoredAttachments.mkdirs()) restoredAttachments.mkdirs();
        boolean dbFound=false;
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile))) {
            ZipEntry e;
            byte[] b = new byte[8192];
            while ((e = zis.getNextEntry()) != null) {
                if (e.isDirectory() || !safeZipPath(e.getName())) { zis.closeEntry(); continue; }
                File outFile;
                if (e.getName().equals(BACKUP_DB_ENTRY)) { outFile=restoredDb; dbFound=true; }
                else if (e.getName().equals(BACKUP_STATE_ENTRY)) outFile=restoredState;
                else if (e.getName().equals(BACKUP_IDENTITY_ENTRY)) outFile=restoredIdentity;
                else if (e.getName().equals(BACKUP_OWNER_ENTRY)) outFile=restoredOwner;
                else if (e.getName().startsWith("attachments/")) {
                    String fn=e.getName().substring("attachments/".length());
                    if (fn.contains("/") || fn.length()==0) { zis.closeEntry(); continue; }
                    outFile=new File(restoredAttachments, fn);
                } else { zis.closeEntry(); continue; }
                File parent=outFile.getParentFile(); if(parent!=null&&!parent.exists())parent.mkdirs();
                try(OutputStream out=new FileOutputStream(outFile)){int n;while((n=zis.read(b))>0)out.write(b,0,n);}
                zis.closeEntry();
            }
        }
        if(!dbFound || !restoredDb.exists() || restoredDb.length()==0) throw new Exception("This is not a valid SiddhiBill backup: database is missing or empty.");
        // Validate the incoming database before touching the live database.
        verifyBackupDatabase(restoredDb);
        if (restoredState.exists()) {
            try { new JSONObject(new String(readAll(restoredState), StandardCharsets.UTF_8)); }
            catch (Exception e) { throw new Exception("Backup settings are damaged; existing data was not changed."); }
        }
        // Restore is intentionally password-free. The protected shop-name metadata is used only
        // to detect casual/manual edits to app_state.json. Business data is still restored normally.
        // Older backups without this metadata remain backward-compatible.
        boolean settingsIntegrityValid = true;
        boolean hasIntegrityMetadata = restoredState.exists() && restoredIdentity.exists();
        String currentStateBeforeRestore = localDb.loadState();
        if (hasIntegrityMetadata) {
            try {
                JSONObject st = new JSONObject(new String(readAll(restoredState), StandardCharsets.UTF_8));
                JSONObject id = new JSONObject(new String(readAll(restoredIdentity), StandardCharsets.UTF_8));
                String restoredShopName = st.optString("shopName", "DUKAAN BILL");
                settingsIntegrityValid = verifyShopNameIntegrity(restoredShopName, id.optString("shopNameSignature", ""));
            } catch (Exception ignored) { settingsIntegrityValid = false; }
        }
        localDb.close();
        File currentDb=getDatabasePath("dukaanbill.db");
        File stagedDb=new File(currentDb.getParentFile(), "dukaanbill.restore.tmp");
        File rollbackDb=new File(currentDb.getParentFile(), "dukaanbill.pre_restore.bak");
        if(stagedDb.exists() && !stagedDb.delete()) throw new Exception("Could not prepare restore staging file.");
        try(InputStream in=new FileInputStream(restoredDb);OutputStream out=new FileOutputStream(stagedDb)){
            byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();
        }
        verifyBackupDatabase(stagedDb);
        if (rollbackDb.exists() && !rollbackDb.delete()) throw new Exception("Could not prepare restore rollback file.");
        File wal=new File(currentDb.getAbsolutePath()+"-wal"), shm=new File(currentDb.getAbsolutePath()+"-shm");
        if(wal.exists()) wal.delete(); if(shm.exists()) shm.delete();
        if(currentDb.exists() && !currentDb.renameTo(rollbackDb)) throw new Exception("Could not safely stage current database; existing data was not changed.");
        if(!stagedDb.renameTo(currentDb)) {
            if(rollbackDb.exists()) rollbackDb.renameTo(currentDb);
            throw new Exception("Could not install restored database; previous data was preserved.");
        }
        try {
            localDb=new LocalDatabase(this);
            verifyBackupDatabase(currentDb);
        } catch(Exception restoreOpenError) {
            try { localDb.close(); } catch(Exception ignored) {}
            if(currentDb.exists()) currentDb.delete();
            if(rollbackDb.exists()) rollbackDb.renameTo(currentDb);
            localDb=new LocalDatabase(this);
            throw new Exception("Restored database failed validation; previous data was rolled back. " + restoreOpenError.getMessage());
        }
        if(rollbackDb.exists()) rollbackDb.delete();
        if(hasIntegrityMetadata && !settingsIntegrityValid) {
            // Keep the restored business database, but reject only the tampered settings payload.
            // Do NOT write the complete pre-restore state here, because that would overwrite the
            // restored bills/customers/products as well. Only carry forward the receiving phone's
            // current settings object.
            try {
                JSONObject currentStateObj = new JSONObject(currentStateBeforeRestore);
                JSONObject settingsOnly = new JSONObject();
                if(currentStateObj.has("dukaanBillSettings")) {
                    settingsOnly.put("dukaanBillSettings", currentStateObj.optString("dukaanBillSettings", "{}"));
                }
                localDb.saveState(settingsOnly.toString());
            } catch(Exception ignored) {}
            runOnUiThread(() -> Toast.makeText(this, "Backup restored. Shop settings were kept because the backup settings integrity check failed.", Toast.LENGTH_LONG).show());
        }
        if(purchaseDocsDir.exists()){
            File[] old=purchaseDocsDir.listFiles(); if(old!=null)for(File f:old)if(f.isFile())f.delete();
        } else purchaseDocsDir.mkdirs();
        File[] atts=restoredAttachments.listFiles();
        if(atts!=null)for(File f:atts)if(f.isFile()){
            try(InputStream in=new FileInputStream(f);OutputStream out=new FileOutputStream(new File(purchaseDocsDir,f.getName()))){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}
        }
        if (restoredOwner.exists()) {
            try {
                String ownerJson = new String(readAll(restoredOwner), StandardCharsets.UTF_8);
                new JSONObject(ownerJson);
                pendingOwnerDashboardBackup = ownerJson;
            } catch (Exception ignored) { pendingOwnerDashboardBackup = "{}"; }
        } else pendingOwnerDashboardBackup = "{}";
        getSharedPreferences("app_prefs",MODE_PRIVATE).edit().putBoolean("restored",true).apply();
        runOnUiThread(() -> { Toast.makeText(this, "Backup restored successfully. Reloading app...", Toast.LENGTH_LONG).show(); webView.postDelayed(() -> { webView.reload(); webView.postDelayed(() -> applyPendingOwnerDashboardToWebView(), 900); }, 700); });
    }

    private void applyPendingOwnerDashboardToWebView() {
        if (pendingOwnerDashboardBackup == null || pendingOwnerDashboardBackup.trim().isEmpty() || "{}".equals(pendingOwnerDashboardBackup.trim())) return;
        try {
            final String jsonLiteral = JSONObject.quote(pendingOwnerDashboardBackup);
            webView.evaluateJavascript("window.restoreOwnerDashboard && window.restoreOwnerDashboard(" + jsonLiteral + ");", null);
            pendingOwnerDashboardBackup = "{}";
        } catch (Exception ignored) {}
    }

    private String formatQuickListOcr(com.google.mlkit.vision.text.Text result){
        if(result==null) return "";
        class OcrLine { String text; android.graphics.Rect box; OcrLine(String t, android.graphics.Rect b){text=t;box=b;} int cy(){return box==null?0:(box.top+box.bottom)/2;} int cx(){return box==null?0:box.centerX();} int height(){return box==null?24:Math.max(1,box.height());} }
        java.util.List<OcrLine> lines=new java.util.ArrayList<>();
        for(com.google.mlkit.vision.text.Text.TextBlock b:result.getTextBlocks()){
            for(com.google.mlkit.vision.text.Text.Line l:b.getLines()){
                String t=l.getText()==null?"":l.getText().trim(); if(!t.isEmpty()) lines.add(new OcrLine(t,l.getBoundingBox()));
            }
        }
        if(lines.isEmpty()) return result.getText()==null?"":result.getText();
        java.util.Collections.sort(lines,(a,b)->Integer.compare(a.cy(),b.cy()));
        // Group only lines that share a visual baseline. The old 14-42 px tolerance
        // merged adjacent handwritten rows into one Quick List entry on phone photos.
        java.util.List<java.util.List<OcrLine>> rows=new java.util.ArrayList<>();
        for(OcrLine line:lines){
            java.util.List<OcrLine> best=null; double bestScore=Double.MAX_VALUE;
            for(java.util.List<OcrLine> row:rows){
                int top=Integer.MAX_VALUE,bottom=Integer.MIN_VALUE,avg=0,minHeight=Integer.MAX_VALUE;
                for(OcrLine cell:row){top=Math.min(top,cell.box==null?cell.cy():cell.box.top);bottom=Math.max(bottom,cell.box==null?cell.cy():cell.box.bottom);avg+=cell.cy();minHeight=Math.min(minHeight,cell.height());}
                avg/=row.size();
                int distance=Math.abs(line.cy()-avg);
                int overlap=line.box==null?0:Math.max(0,Math.min(bottom,line.box.bottom)-Math.max(top,line.box.top));
                int smaller=Math.max(1,Math.min(minHeight,line.height()));
                // Do not merge rows just because tall handwriting boxes overlap vertically.
                // Require close baselines; overlap is supporting evidence, not sufficient by itself.
                double overlapRatio=overlap/(double)smaller;
                int tightBaseline=Math.max(3,Math.min(9,(int)Math.round(smaller*0.28)));
                boolean sameBaseline=distance<=tightBaseline || (distance<=Math.max(4,(int)Math.round(smaller*0.42)) && overlapRatio>=0.62);
                double score=distance/(double)Math.max(1,smaller);
                if(sameBaseline && score<bestScore){best=row;bestScore=score;}
            }
            if(best==null){best=new java.util.ArrayList<>();rows.add(best);} best.add(line);
        }
        StringBuilder out=new StringBuilder();
        for(java.util.List<OcrLine> row:rows){
            java.util.Collections.sort(row,(a,b)->Integer.compare(a.cx(),b.cx()));
            StringBuilder line=new StringBuilder();
            for(OcrLine cell:row){if(line.length()>0)line.append(' ');line.append(cell.text);}
            String value=line.toString().trim(); if(value.isEmpty())continue;
            if(out.length()>0)out.append('\n'); out.append(value);
        }
        return out.toString();
    }

    private void sendQuickListOcr(String text){
        String normalized=text==null?"":text.trim();
        webView.post(() -> webView.evaluateJavascript("window.receiveQuickListOCR && window.receiveQuickListOCR("+JSONObject.quote(normalized)+");",null));
    }

    // All Quick List image sources pass through the same orientation, sizing and contrast pipeline.
    // No product-name substitutions or sample-specific OCR corrections are applied here.
    private Bitmap prepareQuickListBitmap(Bitmap source){
        if(source==null)return null;
        Bitmap oriented=source;
        int maxSide=Math.max(source.getWidth(),source.getHeight());
        if(maxSide>2600 || maxSide<1200){
            float scale=maxSide>2600?2600f/maxSide:Math.min(2.0f,1200f/Math.max(1,maxSide));
            Bitmap scaled=Bitmap.createScaledBitmap(source,Math.max(1,Math.round(source.getWidth()*scale)),Math.max(1,Math.round(source.getHeight()*scale)),true);
            if(scaled!=source && !source.isRecycled())source.recycle(); oriented=scaled;
        }
        Bitmap enhanced=Bitmap.createBitmap(oriented.getWidth(),oriented.getHeight(),Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(enhanced); Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        ColorMatrix cm=new ColorMatrix(); cm.setSaturation(0f);
        float contrast=1.18f, offset=-(0.5f*contrast-0.5f)*255f;
        ColorMatrix adjust=new ColorMatrix(new float[]{contrast,0,0,0,offset,0,contrast,0,0,offset,0,0,contrast,0,offset,0,0,0,1,0});
        cm.postConcat(adjust); paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(oriented,0,0,paint); if(oriented!=enhanced&&!oriented.isRecycled())oriented.recycle();
        return enhanced;
    }

    private Bitmap decodeQuickListUri(Uri uri) throws Exception {
        Bitmap decoded;
        try(InputStream in=getContentResolver().openInputStream(uri)){ decoded=BitmapFactory.decodeStream(in); }
        if(decoded==null)throw new Exception("Unsupported or unreadable image");
        int orientation=ExifInterface.ORIENTATION_UNDEFINED;
        try(InputStream exifStream=getContentResolver().openInputStream(uri)){ if(exifStream!=null)orientation=new ExifInterface(exifStream).getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL); }catch(Exception ignored){}
        Matrix matrix=new Matrix();
        switch(orientation){case ExifInterface.ORIENTATION_ROTATE_90:matrix.postRotate(90);break;case ExifInterface.ORIENTATION_ROTATE_180:matrix.postRotate(180);break;case ExifInterface.ORIENTATION_ROTATE_270:matrix.postRotate(270);break;case ExifInterface.ORIENTATION_FLIP_HORIZONTAL:matrix.preScale(-1,1);break;case ExifInterface.ORIENTATION_FLIP_VERTICAL:matrix.preScale(1,-1);break;}
        Bitmap oriented=decoded;
        if(!matrix.isIdentity()){oriented=Bitmap.createBitmap(decoded,0,0,decoded.getWidth(),decoded.getHeight(),matrix,true);if(oriented!=decoded)decoded.recycle();}
        return oriented;
    }

    // Keep a color-preserving candidate as well as the grayscale/contrast-enhanced candidate.
    // Always forcing grayscale/contrast can erase faint pencil strokes or merge nearby strokes.
    private Bitmap prepareQuickListColorBitmap(Bitmap source){
        if(source==null)return null;
        int maxSide=Math.max(source.getWidth(),source.getHeight());
        float scale=1f;
        if(maxSide>2600)scale=2600f/maxSide;
        else if(maxSide<1200)scale=Math.min(2.0f,1200f/Math.max(1,maxSide));
        if(Math.abs(scale-1f)>0.001f){
            Bitmap scaled=Bitmap.createScaledBitmap(source,Math.max(1,Math.round(source.getWidth()*scale)),Math.max(1,Math.round(source.getHeight()*scale)),true);
            if(scaled!=source&&!source.isRecycled())source.recycle();
            return scaled;
        }
        return source;
    }

    private int quickListOcrQuality(String text){
        if(text==null||text.trim().isEmpty())return 0;
        int score=0,lines=0;
        for(String line:text.split("\\r?\\n")){
            String t=line.trim();if(t.isEmpty())continue;lines++;
            score+=Math.min(45,t.length());
            // Reward rows that appear to contain both a unit and a trailing numeric amount.
            if(t.matches("(?i).*\\b(kg|kgs|gm|gram|g|ml|litre|liter|piece|pcs|pair|pack|packet|bottle|box|set)\\b.*\\d+(?:\\.\\d+)?\\s*$"))score+=30;
            if(t.matches(".*\\d.*"))score+=5;
        }
        return score+Math.min(lines,20)*12;
    }

    private void processQuickListBitmap(Bitmap raw){
        if(raw==null){Toast.makeText(this,"Could not open the image.",Toast.LENGTH_LONG).show();return;}
        Bitmap color=prepareQuickListColorBitmap(Bitmap.createBitmap(raw));
        Bitmap enhanced=prepareQuickListBitmap(Bitmap.createBitmap(raw));
        if(!raw.isRecycled())raw.recycle();
        TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(InputImage.fromBitmap(color,0)).addOnSuccessListener(colorResult->{
            String colorText=formatQuickListOcr(colorResult);
            recognizer.process(InputImage.fromBitmap(enhanced,0)).addOnSuccessListener(enhancedResult->{
                String enhancedText=formatQuickListOcr(enhancedResult);
                String selected=quickListOcrQuality(enhancedText)>quickListOcrQuality(colorText)?enhancedText:colorText;
                sendQuickListOcr(selected);
                recognizer.close();if(!color.isRecycled())color.recycle();if(!enhanced.isRecycled())enhanced.recycle();
            }).addOnFailureListener(err->{sendQuickListOcr(colorText);recognizer.close();if(!color.isRecycled())color.recycle();if(!enhanced.isRecycled())enhanced.recycle();});
        }).addOnFailureListener(err->{
            recognizer.process(InputImage.fromBitmap(enhanced,0)).addOnSuccessListener(result->{sendQuickListOcr(formatQuickListOcr(result));recognizer.close();if(!color.isRecycled())color.recycle();if(!enhanced.isRecycled())enhanced.recycle();})
                .addOnFailureListener(err2->{recognizer.close();if(!color.isRecycled())color.recycle();if(!enhanced.isRecycled())enhanced.recycle();runOnUiThread(()->Toast.makeText(this,"Could not read image text. Try a clearer photo.",Toast.LENGTH_LONG).show());});
        });
    }
    private void recognizeQuickListBitmap(Bitmap bmp){ processQuickListBitmap(bmp); }

    private void recognizeQuickListUri(Uri uri){
        try {
            String type=getContentResolver().getType(uri);
            if((type!=null&&type.toLowerCase().contains("pdf"))||String.valueOf(uri).toLowerCase().endsWith(".pdf")){
                recognizeQuickListPdf(uri); return;
            }
            if((type!=null&&type.toLowerCase().startsWith("text/"))||String.valueOf(uri).toLowerCase().endsWith(".txt")){
                StringBuilder content=new StringBuilder();
                try(InputStream in=getContentResolver().openInputStream(uri); java.io.BufferedReader reader=new java.io.BufferedReader(new java.io.InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=reader.readLine())!=null){if(content.length()>0)content.append('\n');content.append(line);}}
                sendQuickListOcr(content.toString()); return;
            }
            Bitmap bitmap=decodeQuickListUri(uri);
            // The camera image is now decoded into memory; remove only our temporary capture.
            String cameraName=uri.getLastPathSegment();
            if(cameraName!=null && cameraName.startsWith("quicklist_capture_")){
                try{new File(new File(getCacheDir(),"share"),cameraName).delete();}catch(Exception ignored){}
            }
            processQuickListBitmap(bitmap);
        } catch(Exception e){ Toast.makeText(this,"Could not open file: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private void recognizeQuickListPdf(Uri uri){
        new Thread(()->{
            ParcelFileDescriptor pfd=null; PdfRenderer renderer=null; TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            try{
                pfd=getContentResolver().openFileDescriptor(uri,"r"); if(pfd==null)throw new Exception("Could not open PDF");
                renderer=new PdfRenderer(pfd); StringBuilder all=new StringBuilder(); int pages=Math.min(renderer.getPageCount(),5);
                for(int i=0;i<pages;i++){
                    PdfRenderer.Page page=renderer.openPage(i); Bitmap bmp=null;
                    try{
                        float scale=Math.min(3f,1800f/Math.max(page.getWidth(),page.getHeight()));
                        bmp=Bitmap.createBitmap(Math.max(1,(int)(page.getWidth()*scale)),Math.max(1,(int)(page.getHeight()*scale)),Bitmap.Config.ARGB_8888);
                        Canvas canvas=new Canvas(bmp);canvas.drawColor(android.graphics.Color.WHITE);page.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT);
                        com.google.mlkit.vision.text.Text result=Tasks.await(recognizer.process(InputImage.fromBitmap(bmp,0)));
                        String text=formatQuickListOcr(result); if(!text.trim().isEmpty()){if(all.length()>0)all.append('\n');all.append(text);}
                    }finally{if(bmp!=null&&!bmp.isRecycled())bmp.recycle();page.close();}
                }
                sendQuickListOcr(all.toString());
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Could not read PDF. Try a clear image or a shorter PDF.",Toast.LENGTH_LONG).show());}
            finally{recognizer.close();try{if(renderer!=null)renderer.close();}catch(Exception ignored){}try{if(pfd!=null)pfd.close();}catch(Exception ignored){}}
        }).start();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == REQ_WEB_FILE_CHOOSER) {
            if (webFileCallback != null) {
                Uri[] results = (resultCode == RESULT_OK && data != null) ? new Uri[]{data.getData()} : null;
                webFileCallback.onReceiveValue(results);
                webFileCallback = null;
            }
            return;
        }
        if(requestCode==REQ_SCAN_QR){
            if(resultCode==RESULT_OK && data!=null){
                IntentResult scanResult = IntentIntegrator.parseActivityResult(resultCode, data);
                if(scanResult != null && scanResult.getContents() != null){
                    String scanned = scanResult.getContents();
                    webView.post(() -> webView.evaluateJavascript("window.onActivationQrScanned && window.onActivationQrScanned(" +
                            JSONObject.quote(scanned) + ");", null));
                }
            }
            return;
        }
        if(requestCode==REQ_QUICKLIST_IMAGE || requestCode==REQ_QUICKLIST_PDF){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null){
                Uri picked=data.getData();
                try{getContentResolver().takePersistableUriPermission(picked,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
                recognizeQuickListUri(picked);
            }
            return;
        }
        if(requestCode==REQ_PURCHASE_CAMERA){
            if(resultCode==RESULT_OK && purchaseCameraUri!=null){
                importPurchaseUri(purchaseCameraUri);
            } else if(purchaseCameraUri!=null){
                try{getContentResolver().delete(purchaseCameraUri,null,null);}catch(Exception ignored){}
            }
            purchaseCameraUri=null;
            return;
        }
        if(requestCode==REQ_QUICKLIST_CAMERA){
            if(resultCode==RESULT_OK){
                if(quickListCameraUri!=null) recognizeQuickListUri(quickListCameraUri);
                else if(data!=null && data.getExtras()!=null && data.getExtras().get("data") instanceof Bitmap) recognizeQuickListBitmap((Bitmap)data.getExtras().get("data"));
                else Toast.makeText(this,"Camera did not return an image. Please try Upload Image.",Toast.LENGTH_LONG).show();
            } else if(quickListCameraUri!=null){try{getContentResolver().delete(quickListCameraUri,null,null);}catch(Exception ignored){}}
            quickListCameraUri=null;
            return;
        }
        if (requestCode == REQ_EXPORT_FILE_CREATE && (resultCode != RESULT_OK || data == null || data.getData() == null)) {
            pendingExportBytes=null; pendingExportFilename=null;
            Toast.makeText(this,"Export save cancelled.",Toast.LENGTH_SHORT).show();
            return;
        }
        if (requestCode == REQ_SYNC_DOWNLOAD && (resultCode != RESULT_OK || data == null || data.getData() == null)) {
            pendingSyncDownloadBytes = null;
            Toast.makeText(this, "Sync file download cancelled.", Toast.LENGTH_SHORT).show();
            return;
        }
        if(requestCode==REQ_AUTO_BACKUP_FOLDER && (resultCode!=RESULT_OK || data==null || data.getData()==null)){Toast.makeText(this,"Automatic backup folder was not configured.",Toast.LENGTH_SHORT).show();return;}
        if (requestCode == REQ_ARCHIVE_IMPORT && (resultCode != RESULT_OK || data == null || data.getData() == null)) {
            Toast.makeText(this, "Archive import cancelled.", Toast.LENGTH_SHORT).show();
            return;
        }
        if ((requestCode == REQ_ARCHIVE_CREATE || requestCode == REQ_ARCHIVE_PDF_CREATE) && (resultCode != RESULT_OK || data == null || data.getData() == null)) {
            pendingArchiveZip = null; pendingArchivePdf = null;
            notifyArchiveZipSaved(false, requestCode == REQ_ARCHIVE_PDF_CREATE ? "Summary PDF save cancelled. No bills were removed; the saved ZIP can be kept or discarded." : "Archive ZIP save cancelled. No bills were removed.");
            return;
        }
        if (requestCode == REQ_BACKUP_CREATE && (resultCode != RESULT_OK || data == null || data.getData() == null)) {
            updateBackupStatus("Backup save cancelled. No file was saved.", true);
            pendingBackupZip = null;
            return;
        }
        if(resultCode!=RESULT_OK || data==null) return;
        if(requestCode==REQ_EXPORT_FILE_CREATE && data.getData()!=null){
            try {
                if(pendingExportBytes==null || pendingExportBytes.length==0) throw new Exception("Export data is empty");
                try(OutputStream out=getContentResolver().openOutputStream(data.getData(),"w")){
                    if(out==null) throw new Exception("Could not open the selected save location");
                    out.write(pendingExportBytes); out.flush();
                }
                Toast.makeText(this,"Saved "+(pendingExportFilename==null?"export file":pendingExportFilename),Toast.LENGTH_LONG).show();
                if(webView!=null) webView.evaluateJavascript("window.onGstExportSaved && window.onGstExportSaved(true,"+JSONObject.quote(pendingExportFilename==null?"Export":pendingExportFilename)+")",null);
            } catch(Exception e){
                Toast.makeText(this,"Could not save export file: "+e.getMessage(),Toast.LENGTH_LONG).show();
                if(webView!=null) webView.evaluateJavascript("window.onGstExportSaved && window.onGstExportSaved(false,"+JSONObject.quote(e.getMessage())+")",null);
            } finally {pendingExportBytes=null;pendingExportFilename=null;}
        } else if(requestCode==REQ_SYNC_DOWNLOAD && data.getData()!=null){
            try {
                if (pendingSyncDownloadBytes == null || pendingSyncDownloadBytes.length == 0) throw new Exception("Sync data is empty");
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "w")) {
                    if (out == null) throw new Exception("Could not open the selected download location");
                    out.write(pendingSyncDownloadBytes);
                    out.flush();
                }
                Toast.makeText(this, "Sync file downloaded successfully.", Toast.LENGTH_LONG).show();
            } catch(Exception e) {
                Toast.makeText(this, "Could not download sync file: " + e.getMessage(), Toast.LENGTH_LONG).show();
            } finally { pendingSyncDownloadBytes = null; }
        } else if(requestCode==REQ_PURCHASE_DOCUMENT && data.getData()!=null){
            Uri uri=data.getData();
            try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            importPurchaseUri(uri);
        } else if(requestCode==REQ_AUTO_BACKUP_FOLDER){
            try{Uri tree=data.getData();int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);getContentResolver().takePersistableUriPermission(tree,flags);String mode="drive".equals(pendingAutoBackupMode)?"drive":"device";getSharedPreferences("siddhibill_auto_backup",MODE_PRIVATE).edit().putString("destination",mode).putString("tree_uri",tree.toString()).apply();scheduleAutoBackup();Toast.makeText(this,"Automatic backup configured for the selected "+("drive".equals(mode)?"Google Drive":"device")+" folder.",Toast.LENGTH_LONG).show();notifyAutoBackupStatus();}catch(Exception e){Toast.makeText(this,"Could not save backup folder: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        } else if(requestCode==REQ_ARCHIVE_IMPORT){
            try {
                String archiveJson=null;
                try(InputStream in=getContentResolver().openInputStream(data.getData()); ZipInputStream zis=new ZipInputStream(in)){
                    ZipEntry entry; while((entry=zis.getNextEntry())!=null){
                        if("archive/transactions.json".equals(entry.getName())){ByteArrayOutputStream bout=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=zis.read(buf))>0){bout.write(buf,0,n);if(bout.size()>50*1024*1024)throw new Exception("Archive is too large");}archiveJson=new String(bout.toByteArray(),StandardCharsets.UTF_8);break;}
                    }
                }
                if(archiveJson==null)throw new Exception("This ZIP does not contain a SiddhiBill archive");
                JSONObject parsed=new JSONObject(archiveJson);
                if(!"SiddhiBillArchive".equals(parsed.optString("format")))throw new Exception("Unsupported archive format");
                String q=JSONObject.quote(parsed.toString());webView.evaluateJavascript("window.onArchiveImportData && window.onArchiveImportData("+q+")",null);
            }catch(Exception e){Toast.makeText(this,"Archive import failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        } else if(requestCode==REQ_ARCHIVE_CREATE){
            try {
                if(pendingArchiveZip==null || !pendingArchiveZip.exists() || pendingArchiveZip.length()<50) throw new Exception("Archive ZIP is missing or empty");
                copyFileToUri(pendingArchiveZip,data.getData());
                Intent pdfIntent=new Intent(Intent.ACTION_CREATE_DOCUMENT);pdfIntent.addCategory(Intent.CATEGORY_OPENABLE);pdfIntent.setType("application/pdf");pdfIntent.putExtra(Intent.EXTRA_TITLE,pendingArchivePdf==null?"SiddhiBill_Archive_Summary.pdf":pendingArchivePdf.getName());
                startActivityForResult(pdfIntent,REQ_ARCHIVE_PDF_CREATE);
            } catch(Exception e){ notifyArchiveZipSaved(false,"Could not save archive ZIP or prepare PDF save: "+e.getMessage()+". No bills were removed.");pendingArchiveZip=null;pendingArchivePdf=null; }
        } else if(requestCode==REQ_ARCHIVE_PDF_CREATE){
            try {
                if(pendingArchivePdf==null || !pendingArchivePdf.exists() || pendingArchivePdf.length()<100) throw new Exception("Archive summary PDF is missing or empty");
                copyFileToUri(pendingArchivePdf,data.getData());
                notifyArchiveZipSaved(true,"Both archive files were saved: structured ZIP and tabular summary PDF.");
                Toast.makeText(this,"Archive ZIP and summary PDF saved successfully.",Toast.LENGTH_LONG).show();
            } catch(Exception e){notifyArchiveZipSaved(false,"Could not save summary PDF: "+e.getMessage()+". No bills were removed.");}
            finally{pendingArchiveZip=null;pendingArchivePdf=null;}
        } else if(requestCode==REQ_BACKUP_CREATE){
            if(data!=null && data.getData()!=null){
                try{
                    if(pendingBackupZip==null||!pendingBackupZip.exists())throw new Exception("Backup file is missing");
                    copyFileToUri(pendingBackupZip,data.getData());
                    updateBackupStatus("Backup saved successfully. Keep this ZIP safely in your cloud or another device.", true);
                    Toast.makeText(this,"Backup saved successfully. Keep this ZIP safely in your cloud.",Toast.LENGTH_LONG).show();
                }catch(Exception e){
                    updateBackupStatus("Could not save backup: "+e.getMessage(),true);
                    Toast.makeText(this,"Could not save backup: "+e.getMessage(),Toast.LENGTH_LONG).show();
                }
            } else {
                updateBackupStatus("Backup save cancelled. No file was saved.", true);
            }
            pendingBackupZip=null;
        } else if(requestCode==REQ_BACKUP_RESTORE && data.getData()!=null){
            new Thread(() -> {
                try { restoreBackup(data.getData()); }
                catch(Exception e){runOnUiThread(() -> Toast.makeText(this,"Restore failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}
            }).start();
        }
    }

    private Uri createPurchasePdfForSharing(String json) throws Exception {
        JSONObject purchase = new JSONObject(json);
        byte[] bytes = createPurchasePdfBytes(purchase);
        String invoice = purchase.optString("invoiceNo", "Purchase").replaceAll("[^A-Za-z0-9_-]", "_");
        return saveForSharing(bytes, "SiddhiBill_Purchase_" + invoice + ".pdf", "application/pdf");
    }

    private byte[] createPurchasePdfBytes(JSONObject purchase) throws Exception {
        final int width = 842, height = 595;
        PdfDocument doc = new PdfDocument();
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(android.graphics.Color.BLACK);
        paint.setTextSize(9);
        JSONObject settings = purchase.optJSONObject("settings");
        JSONObject vendor = purchase.optJSONObject("vendorSnapshot");
        if (vendor == null) vendor = new JSONObject();
        JSONArray items = purchase.optJSONArray("items");
        final boolean taxableBill = purchase.optBoolean("taxableBill", true);
        int pageNo = 1;
        PdfDocument.Page page = doc.startPage(new PdfDocument.PageInfo.Builder(width, height, pageNo).create());
        Canvas c = page.getCanvas();
        float y = 38;
        // Purchase PDFs identify the shop as BUYER and the supplier as SELLER.
        // Deliberately do not print the shopkeeper's logo on a supplier purchase bill.
        paint.setColor(android.graphics.Color.rgb(36,70,111));
        paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(20);
        drawText(c, paint, "PURCHASE BILL", 36, y);
        paint.setColor(android.graphics.Color.BLACK); paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(9); y += 22;
        drawText(c, paint, "Invoice No: " + purchase.optString("invoiceNo", "-"), 36, y);
        drawText(c, paint, "Date: " + purchase.optString("date", "-"), 330, y); y += 15;
        drawText(c, paint, "PO No: " + purchase.optString("poNumber", "-"), 36, y);
        drawText(c, paint, "Payment Terms: " + purchase.optString("paymentTerms", "-"), 330, y); y += 22;

        // Buyer = this shop, taken from Settings.
        paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(10);
        drawText(c, paint, "BUYER (YOUR SHOP)", 36, y);
        // Seller = supplier/vendor from the saved purchase snapshot.
        drawText(c, paint, "SELLER (VENDOR)", 430, y); y += 15;
        paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(8);
        String buyerName = settings == null ? "" : settings.optString("shopName", "");
        String buyerAddress = settings == null ? "" : settings.optString("address", "");
        String buyerGstin = settings == null ? "" : settings.optString("gstin", "");
        String buyerState = settings == null ? "" : settings.optString("businessState", "");
        String buyerMobile = settings == null ? "" : settings.optString("shopMobile", "");
        drawText(c, paint, trimText(buyerName, 55), 36, y); drawText(c, paint, trimText(vendor.optString("name", purchase.optString("vendorName", "Vendor")), 55), 430, y); y += 13;
        drawText(c, paint, trimText(buyerAddress, 58), 36, y); drawText(c, paint, trimText(vendor.optString("address", ""), 58), 430, y); y += 13;
        drawText(c, paint, "GSTIN: " + (buyerGstin.isEmpty() ? "-" : buyerGstin), 36, y); drawText(c, paint, "GSTIN: " + vendor.optString("gstin", "-"), 430, y); y += 13;
        drawText(c, paint, "State: " + (buyerState.isEmpty() ? "-" : buyerState), 36, y); drawText(c, paint, "PAN: " + vendor.optString("pan", "-"), 430, y); y += 13;
        drawText(c, paint, "Phone: " + (buyerMobile.isEmpty() ? "-" : buyerMobile), 36, y); drawText(c, paint, "State: " + vendor.optString("state", purchase.optString("supplierState", "-")), 430, y); y += 13;
        if (taxableBill) {
            String buyerFssai = settings == null ? "" : settings.optString("fssai", "").trim();
            JSONObject vendorSnapshot = purchase.optJSONObject("vendorSnapshot");
            String vendorFssai = vendor.optString("fssai", vendorSnapshot == null ? "" : vendorSnapshot.optString("fssai", "")).trim();
            if (!buyerFssai.isEmpty()) drawText(c, paint, "FSSAI: " + buyerFssai, 36, y);
            if (!vendorFssai.isEmpty()) drawText(c, paint, "FSSAI: " + vendorFssai, 430, y);
            if (!buyerFssai.isEmpty() || !vendorFssai.isEmpty()) y += 13;
        }
        y += 5;
        c.drawLine(36, y, width - 36, y, paint); y += 18;

        // Compact, aligned item table. Each data field has its own column.
        paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(7);
        paint.setColor(android.graphics.Color.rgb(235,240,246)); paint.setStyle(Paint.Style.FILL);
        drawOutlineRect(c,paint,32, y, width - 32, y + 28);
        paint.setColor(android.graphics.Color.BLACK); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(0.7f);
        drawOutlineRect(c,paint,32, y, width - 32, y + 28);
        float[] tableX = new float[]{32,48,320,360,410,480,550,600,660,720,780,810};
        for (float vx : tableX) c.drawLine(vx, y, vx, y + 28, paint);
        paint.setStyle(Paint.Style.FILL); paint.setColor(android.graphics.Color.BLACK);
        paint.setColor(android.graphics.Color.WHITE);
        drawText(c, paint, "#", 36, y + 17);
        drawText(c, paint, "Item", 50, y + 12);
        drawText(c, paint, "HSN/SAC", 50, y + 23);
        drawText(c, paint, "Qty", 330, y + 17);
        drawText(c, paint, "Unit", 365, y + 17);
        drawText(c, paint, "Buy Rate", 420, y + 17);
        drawText(c, paint, "Taxable", 490, y + 17);
        drawText(c, paint, "Tax%", 560, y + 17);
        drawText(c, paint, "CGST", 610, y + 17);
        drawText(c, paint, "SGST", 670, y + 17);
        drawText(c, paint, "IGST", 730, y + 17);
        drawText(c, paint, "Total", 785, y + 17);
        paint.setColor(android.graphics.Color.BLACK); paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(7);
        y += 40;
        double sumTaxable = 0, sumTax = 0, sumGross = 0, sumCgst = 0, sumSgst = 0, sumIgst = 0;
        java.util.Map<String, double[]> taxSummary = new java.util.TreeMap<>();
        if (items != null) {
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i); if (item == null) continue;
                if (y > 485) {
                    doc.finishPage(page); pageNo++;
                    page = doc.startPage(new PdfDocument.PageInfo.Builder(width, height, pageNo).create()); c = page.getCanvas();
                    paint.setColor(android.graphics.Color.BLACK); paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(12);
                    drawText(c, paint, "PURCHASE BILL (continued)", 36, 38);
                    paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(7); y = 62;
                }
                String name = item.optString("name", item.optString("description", "Item")); if(settings!=null && settings.optBoolean("printItemCode",false)){String code=item.optString("itemCode","").trim();if(!code.isEmpty())name=code+" - "+name;}
                String hsn = item.optString("hsn", item.optString("hsnCode", ""));
                double qty = item.optDouble("qty", 0);
                double taxable = item.has("taxableAmount") ? item.optDouble("taxableAmount", 0) : item.optDouble("invoiceTaxableAmount", 0);
                double cgst = item.optDouble("cgstAmount", 0), sgst = item.optDouble("sgstAmount", 0), igst = item.optDouble("igstAmount", 0);
                double gst = item.has("totalTaxAmount") ? item.optDouble("totalTaxAmount", cgst + sgst + igst) : cgst + sgst + igst;
                double gross = item.has("lineTotalInclusive") ? item.optDouble("lineTotalInclusive", 0) : item.optDouble("lineTotal", taxable + gst);
                double taxRate = taxableBill ? item.optDouble("taxRate", item.optDouble("gstRate", item.optDouble("cgstRate", 0) + item.optDouble("sgstRate", 0) + item.optDouble("igstRate", 0))) : 0;
                if (!taxableBill) { cgst = 0; sgst = 0; igst = 0; gst = 0; }
                double buyRate = qty > 0 ? taxable / qty : item.optDouble("rate", 0);
                drawText(c, paint, String.valueOf(i + 1), 36, y + 4);
                drawText(c, paint, trimText(name, 48), 50, y + 4);
                drawText(c, paint, trimText(hsn, 18), 50, y + 14);
                drawTextRight(c, paint, String.format(Locale.US, "%.3g", qty), 352, y + 4);
                drawText(c, paint, trimText(item.optString("unit", ""), 10), 365, y + 4);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", buyRate), 470, y + 4);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", taxable), 540, y + 4);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", taxRate), 590, y + 4);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", cgst), 650, y + 4);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", sgst), 710, y + 4);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", igst), 770, y + 4);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", gross), width - 36, y + 4);
                paint.setColor(android.graphics.Color.BLACK); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(0.5f);
                drawOutlineRect(c,paint,32, y - 8, width - 32, y + 11);
                for (float vx : tableX) c.drawLine(vx, y - 8, vx, y + 11, paint);
                c.drawLine(32, y + 11, width - 32, y + 11, paint);
                paint.setStyle(Paint.Style.FILL); y += 23;
                sumTaxable += taxable; sumTax += gst; sumGross += gross;
                sumCgst += cgst; sumSgst += sgst; sumIgst += igst;
                String taxKey = String.format(Locale.US, "%.2f", taxRate);
                double[] sums = taxSummary.get(taxKey); if (sums == null) { sums = new double[5]; taxSummary.put(taxKey, sums); }
                sums[0] += taxable; sums[1] += cgst; sums[2] += sgst; sums[3] += igst; sums[4] += gst;
            }
        }
        if (y > 460) { doc.finishPage(page); pageNo++; page = doc.startPage(new PdfDocument.PageInfo.Builder(width, height, pageNo).create()); c = page.getCanvas(); y = 50; }
        paint.setTextSize(9); paint.setTypeface(Typeface.DEFAULT);
        double declaredTaxable = purchase.has("subtotal") ? purchase.optDouble("subtotal", sumTaxable) : sumTaxable;
        double declaredTax = purchase.optDouble("taxAmount", sumTax);
        double charges = purchase.optDouble("otherCharges", 0), discount = purchase.optDouble("invoiceDiscount", 0), tcs = purchase.optDouble("tcsAmount", 0), roundOff = purchase.optDouble("roundOff", 0);
        double total = purchase.optDouble("total", declaredTaxable + declaredTax + charges - discount + tcs + roundOff);
        double paid = purchase.optDouble("paid", 0), pending = Math.max(0, total - paid);
        paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(8);
        if (!taxableBill) {
            drawText(c, paint, "NON-TAXABLE PURCHASE - GST NOT APPLIED", 36, y + 8); y += 24;
        } else {
            drawText(c, paint, "GST BREAKDOWN BY RATE", 36, y + 8); y += 17;
            paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(7);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(0.6f); drawOutlineRect(c,paint,32, y, 806, y + 17);
            float[] gstX = new float[]{32,120,270,390,510,630,806}; for (float vx : gstX) c.drawLine(vx, y, vx, y + 17, paint);
            paint.setStyle(Paint.Style.FILL);
            drawText(c, paint, "Rate", 36, y + 11); drawText(c, paint, "Taxable", 145, y + 11);
            drawText(c, paint, "CGST", 290, y + 11); drawText(c, paint, "SGST", 400, y + 11);
            drawText(c, paint, "IGST", 510, y + 11); drawText(c, paint, "Total GST", 640, y + 11); y += 17;
            for (java.util.Map.Entry<String, double[]> entry : taxSummary.entrySet()) {
                double[] values = entry.getValue();
                drawText(c, paint, entry.getKey() + "%", 36, y + 8);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", values[0]), 260, y + 8);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", values[1]), 370, y + 8);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", values[2]), 480, y + 8);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", values[3]), 590, y + 8);
                drawTextRight(c, paint, String.format(Locale.US, "%.2f", values[4]), 790, y + 8);
                paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(0.5f); drawOutlineRect(c,paint,32, y - 3, 806, y + 11); for (float vx : gstX) c.drawLine(vx, y - 3, vx, y + 11, paint); paint.setStyle(Paint.Style.FILL); y += 14;
            }
            paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setStyle(Paint.Style.STROKE); drawOutlineRect(c,paint,32, y, 806, y + 17); for (float vx : gstX) c.drawLine(vx, y, vx, y + 17, paint); paint.setStyle(Paint.Style.FILL);
            drawText(c, paint, "TOTAL", 36, y + 11); drawTextRight(c, paint, String.format(Locale.US, "%.2f", sumTaxable), 260, y + 11);
            drawTextRight(c, paint, String.format(Locale.US, "%.2f", sumCgst), 370, y + 11); drawTextRight(c, paint, String.format(Locale.US, "%.2f", sumSgst), 490, y + 11);
            drawTextRight(c, paint, String.format(Locale.US, "%.2f", sumIgst), 610, y + 11); drawTextRight(c, paint, String.format(Locale.US, "%.2f", sumTax), 790, y + 11); y += 24;
        }
        if (y > 390) { doc.finishPage(page); pageNo++; page = doc.startPage(new PdfDocument.PageInfo.Builder(width, height, pageNo).create()); c = page.getCanvas(); y = 50; paint.setColor(android.graphics.Color.BLACK); }
        String[][] totalsRows = new String[][]{{"Items total (tax-inclusive)", String.format(Locale.US, "%.2f", sumGross)}, {"Taxable amount", String.format(Locale.US, "%.2f", declaredTaxable)}, {taxableBill ? "GST included" : "GST (not applicable)", String.format(Locale.US, "%.2f", taxableBill ? declaredTax : 0)}, {"Other charges", String.format(Locale.US, "%.2f", charges)}, {"Discount", String.format(Locale.US, "-%.2f", discount)}, {"TCS", String.format(Locale.US, "%.2f", tcs)}, {"Round off", String.format(Locale.US, "%.2f", roundOff)}};
        paint.setTextSize(8); paint.setTypeface(Typeface.DEFAULT); paint.setStyle(Paint.Style.STROKE);
        for (String[] row : totalsRows) { drawOutlineRect(c,paint,500, y, 806, y + 16); c.drawLine(690, y, 690, y + 16, paint); paint.setStyle(Paint.Style.FILL); drawText(c, paint, row[0], 505, y + 11); drawTextRight(c, paint, row[1], 800, y + 11); y += 16; paint.setStyle(Paint.Style.STROKE); }
        paint.setStyle(Paint.Style.FILL); y += 4;
        paint.setTypeface(Typeface.DEFAULT_BOLD); paint.setTextSize(13); paint.setStyle(Paint.Style.STROKE); drawOutlineRect(c,paint,500, y - 5, 806, y + 15); c.drawLine(690, y - 5, 690, y + 15, paint); paint.setStyle(Paint.Style.FILL);
        drawText(c, paint, "INVOICE TOTAL", 505, y + 8); drawTextRight(c, paint, String.format(Locale.US, "%.2f", total), 800, y + 8); y += 20;
        paint.setTypeface(Typeface.DEFAULT); paint.setTextSize(10);
        drawTextRight(c, paint, "Paid: Rs. " + String.format(Locale.US, "%.2f", paid), width - 36, y); y += 17;
        drawTextRight(c, paint, "Balance pending: Rs. " + String.format(Locale.US, "%.2f", pending), width - 36, y);
        doc.finishPage(page);
        ByteArrayOutputStream out = new ByteArrayOutputStream(); doc.writeTo(out); doc.close(); return out.toByteArray();
    }

    private Uri createBillPdfForSharing(String json) throws Exception {
        JSONObject b = new JSONObject(json);
        JSONObject cfg = b.optJSONObject("settings");
        String paper = cfg == null ? "A4" : cfg.optString("paperSize", "A4");
        if ("58mm".equalsIgnoreCase(paper) || "80mm".equalsIgnoreCase(paper)) {
            byte[] bytes = createThermalPdfBytes(json);
            String filename = "Bill_" + b.optString("billNo", "Bill").replaceAll("[^A-Za-z0-9_-]", "_") + "_" + paper + ".pdf";
            return saveForSharing(bytes, filename, "application/pdf");
        }
        Uri pdf = createPdf(json);
        return pdf;
    }

    private class AndroidBridge {
        @JavascriptInterface public void shareBillImage(String base64Png,String billName,String phone){
            try{byte[] data=Base64.decode(base64Png,Base64.DEFAULT);String safe=(billName==null||billName.trim().isEmpty())?"DukaanBill":billName;shareFile(data,safe+".png","image/png","WhatsApp Bill");}
            catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not share bill image: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void printEstimateHtmlDocument(String html,String documentName,String paperSize){
            final String content=html==null?"":html;
            final String title=(documentName==null||documentName.trim().isEmpty()?"Estimate":documentName).replaceAll("[^A-Za-z0-9_-]","_");
            final String paper=paperSize==null?"A4":paperSize.trim().toUpperCase(Locale.ROOT);
            runOnUiThread(()->{
                try{
                    WebView reportView=new WebView(MainActivity.this);
                    reportView.getSettings().setJavaScriptEnabled(true);
                    reportView.setWebViewClient(new android.webkit.WebViewClient(){
                        @Override public void onPageFinished(WebView view,String url){
                            try{
                                PrintAttributes.MediaSize media;
                                if("58MM".equals(paper))media=new PrintAttributes.MediaSize("SIDDHI_58MM","58 mm",2283,20000);
                                else if("80MM".equals(paper))media=new PrintAttributes.MediaSize("SIDDHI_80MM","80 mm",3150,20000);
                                else if("A6".equals(paper))media=new PrintAttributes.MediaSize("SIDDHI_A6","A6",4134,5830);
                                else media=new PrintAttributes.MediaSize("SIDDHI_A4","A4",8270,11690);
                                PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                                PrintDocumentAdapter adapter=view.createPrintDocumentAdapter(title);
                                pm.print(title,adapter,new PrintAttributes.Builder().setMediaSize(media).setResolution(new PrintAttributes.Resolution("estimate_print","Estimate",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).setColorMode(PrintAttributes.COLOR_MODE_COLOR).build());
                            }catch(Exception ex){Toast.makeText(MainActivity.this,"Could not open estimate PDF/Print dialog: "+ex.getMessage(),Toast.LENGTH_LONG).show();}
                        }
                    });
                    reportView.loadDataWithBaseURL("file:///android_asset/www/",content,"text/html","UTF-8",null);
                }catch(Exception ex){Toast.makeText(MainActivity.this,"Could not prepare estimate for printing: "+ex.getMessage(),Toast.LENGTH_LONG).show();}
            });
        }

        @JavascriptInterface public void printHtmlDocument(String html,String documentName){
            final String content=html==null?"":html;
            final String title=(documentName==null||documentName.trim().isEmpty()?"SiddhiBill_Report":documentName).replaceAll("[^A-Za-z0-9_-]","_");
            runOnUiThread(()->{
                if(content.trim().isEmpty()){
                    Toast.makeText(MainActivity.this,"Cannot create PDF: report content is empty.",Toast.LENGTH_LONG).show();
                    return;
                }
                Toast.makeText(MainActivity.this,"Preparing PDF report…",Toast.LENGTH_SHORT).show();
                saveHtmlReportAsPdf(content,title);
            });
        }
        private void saveHtmlReportAsPdf(String html,String title){
            // Render report HTML directly into an A4 PDF using PdfDocument.
            // This avoids screen snapshots and the Android print-app chooser.
            final WebView reportView;
            try{
                String printableHtml=html==null?"":html;
                printableHtml=printableHtml.replaceAll("(?is)<script\\b[^>]*>.*?</script\\s*>","");
                final int pageWidthCss=794; // A4 portrait CSS width at 96 dpi
                String printCss="<meta name=\"viewport\" content=\"width=794, initial-scale=1\">"
                    +"<style id=\"siddhibill-native-print\">"
                    +"@page{size:A4 portrait;margin:10mm}"
                    +"html,body{width:794px!important;min-width:0!important;max-width:794px!important;margin:0!important;padding:0!important;background:#fff!important;overflow:visible!important}"
                    +"body{font-family:Arial,sans-serif!important;font-size:10px!important;color:#222!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}"
                    +"*,*:before,*:after{box-sizing:border-box!important;max-width:100%!important}"
                    +"button,.ledger-toolbar,.no-print,.print-actions,.report-actions,.screen-only,.back-button{display:none!important}"
                    +"table{width:100%!important;max-width:100%!important;table-layout:fixed!important;border-collapse:collapse!important;font-size:9px!important}"
                    +"thead{display:table-header-group!important}tfoot{display:table-footer-group!important}"
                    +"tr{break-inside:avoid!important;page-break-inside:avoid!important}"
                    +"th,td{white-space:normal!important;overflow-wrap:anywhere!important;word-wrap:break-word!important;word-break:break-word!important;vertical-align:top!important;padding:4px!important}"
                    +"img,svg{max-width:100%!important;height:auto!important}"
                    +"pre{white-space:pre-wrap!important;overflow-wrap:anywhere!important}"
                    +"</style>";
                if(printableHtml.matches("(?is).*<head\\b[^>]*>.*")){
                    printableHtml=printableHtml.replaceFirst("(?is)(<head\\b[^>]*>)","$1"+java.util.regex.Matcher.quoteReplacement(printCss));
                }else{
                    printableHtml="<!doctype html><html><head>"+printCss+"</head><body>"+printableHtml+"</body></html>";
                }

                reportView=new WebView(MainActivity.this);
                reportView.setBackgroundColor(Color.WHITE);
                reportView.getSettings().setJavaScriptEnabled(true);
                reportView.getSettings().setDomStorageEnabled(true);
                reportView.getSettings().setLoadsImagesAutomatically(true);
                reportView.setLayerType(View.LAYER_TYPE_SOFTWARE,null);
                final android.view.ViewGroup host=(android.view.ViewGroup)getWindow().getDecorView();
                final float density=getResources().getDisplayMetrics().density;
                final int viewWidth=Math.round(pageWidthCss*density);
                android.widget.FrameLayout.LayoutParams params=new android.widget.FrameLayout.LayoutParams(viewWidth,1);
                host.addView(reportView,0,params);
                reportView.setAlpha(0.01f);
                reportView.setVisibility(View.VISIBLE);
                reportView.setWebViewClient(new android.webkit.WebViewClient(){
                    private boolean finished=false;
                    private void cleanup(){
                        try{if(reportView.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)reportView.getParent()).removeView(reportView);}catch(Exception ignored){}
                        try{reportView.stopLoading();reportView.destroy();}catch(Exception ignored){}
                    }
                    @Override public void onReceivedError(WebView view,android.webkit.WebResourceRequest request,android.webkit.WebResourceError error){
                        if(request!=null&&request.isForMainFrame()&&!finished){
                            finished=true;
                            runOnUiThread(()->{Toast.makeText(MainActivity.this,"Could not load report for PDF: "+(error==null?"unknown WebView error":error.getDescription()),Toast.LENGTH_LONG).show();cleanup();});
                        }
                    }
                    @Override public void onPageFinished(WebView view,String url){
                        if(finished)return;
                        finished=true;
                        view.postDelayed(()->{
                            android.graphics.pdf.PdfDocument document=null;
                            try{
                                // Wait for the report WebView's final layout after onPageFinished.
                                // getContentHeight is the WebView's full document height in CSS px.
                                // Lay out the WebView at the document's full height before
                                // capturing it. A 1px-height attached WebView otherwise captures
                                // only its first viewport.
                                int cssContentHeight=Math.max(1,reportView.getContentHeight());
                                float webScale=reportView.getScale();
                                if(webScale<=0f)webScale=1f;
                                int measuredDocumentHeight=Math.max(1,Math.round(cssContentHeight*webScale*density));
                                reportView.measure(View.MeasureSpec.makeMeasureSpec(viewWidth,View.MeasureSpec.EXACTLY),
                                    View.MeasureSpec.makeMeasureSpec(measuredDocumentHeight,View.MeasureSpec.EXACTLY));
                                reportView.layout(0,0,viewWidth,measuredDocumentHeight);
                                // Capture the entire laid-out HTML document once. Scrolling a
                                // height-constrained WebView before draw() is not reliable on all
                                // Android WebView versions: it can redraw the first viewport on
                                // every page. A Picture is a stable full-document snapshot.
                                android.graphics.Picture fullPagePicture=reportView.capturePicture();
                                int pictureWidth=Math.max(1,fullPagePicture.getWidth());
                                float pictureScale=(float)viewWidth/(float)pictureWidth;
                                int fullContentHeight=Math.max(1,Math.round(fullPagePicture.getHeight()*pictureScale));
                                // A4 portrait in PDF points (72 points per inch), with 10 mm margins.
                                final int pdfWidth=595,pdfHeight=842,margin=28;
                                final int contentWidth=pdfWidth-(margin*2),contentHeight=pdfHeight-(margin*2);
                                final float drawScale=(float)contentWidth/(float)viewWidth;
                                final int pageSlicePx=Math.max(1,(int)Math.floor(contentHeight/drawScale));
                                int pageCount=Math.max(1,(int)Math.ceil((double)fullContentHeight/pageSlicePx));
                                document=new android.graphics.pdf.PdfDocument();
                                int writtenPageCount=0;
                                for(int pageIndex=0;pageIndex<pageCount;pageIndex++){
                                    // Draw a different vertical slice of the full document picture.
                                    Bitmap pageBitmap=Bitmap.createBitmap(viewWidth,pageSlicePx,Bitmap.Config.ARGB_8888);
                                    android.graphics.Canvas pageCanvas=new android.graphics.Canvas(pageBitmap);
                                    pageCanvas.drawColor(Color.WHITE);
                                    pageCanvas.save();
                                    pageCanvas.scale(pictureScale,pictureScale);
                                    pageCanvas.translate(0,-pageIndex*pageSlicePx/pictureScale);
                                    fullPagePicture.draw(pageCanvas);
                                    pageCanvas.restore();
                                    boolean hasReportContent=false;
                                    int scanRight=Math.max(1,(int)(viewWidth*0.94f));
                                    int scanBottom=Math.max(1,(int)(pageSlicePx*0.97f));
                                    for(int y=(int)(pageSlicePx*0.03f);y<scanBottom&&!hasReportContent;y+=6){
                                        for(int x=(int)(viewWidth*0.03f);x<scanRight;x+=6){
                                            int pixel=pageBitmap.getPixel(x,y);
                                            int red=Color.red(pixel),green=Color.green(pixel),blue=Color.blue(pixel);
                                            if(red<232||green<232||blue<232){hasReportContent=true;break;}
                                        }
                                    }
                                    if(hasReportContent){
                                        android.graphics.pdf.PdfDocument.PageInfo pageInfo=new android.graphics.pdf.PdfDocument.PageInfo.Builder(pdfWidth,pdfHeight,writtenPageCount+1).create();
                                        android.graphics.pdf.PdfDocument.Page page=document.startPage(pageInfo);
                                        android.graphics.Canvas canvas=page.getCanvas();
                                        canvas.drawColor(Color.WHITE);
                                        canvas.save();
                                        canvas.translate(margin,margin);
                                        canvas.clipRect(0,0,contentWidth,contentHeight);
                                        canvas.scale(drawScale,drawScale);
                                        canvas.drawBitmap(pageBitmap,0,0,null);
                                        canvas.restore();
                                        document.finishPage(page);
                                        writtenPageCount++;
                                    }
                                    pageBitmap.recycle();
                                }
                                reportView.scrollTo(0,0);
                                ByteArrayOutputStream output=new ByteArrayOutputStream();
                                document.writeTo(output);
                                byte[] pdfBytes=output.toByteArray();
                                if(pdfBytes.length<500||pdfBytes[0]!='%'||pdfBytes[1]!='P')throw new Exception("PDF renderer returned an invalid document");
                                String filename=title==null?"SiddhiBill_Report.pdf":title;
                                if(!filename.toLowerCase(Locale.ROOT).endsWith(".pdf"))filename += ".pdf";
                                savePdfBytesWithDuplicateCheck(pdfBytes,filename);
                            }catch(Exception ex){
                                Toast.makeText(MainActivity.this,"Could not generate A4 PDF: "+ex.getMessage(),Toast.LENGTH_LONG).show();
                            }finally{
                                if(document!=null)try{document.close();}catch(Exception ignored){}
                                cleanup();
                            }
                        },700);
                    }
                });
                reportView.loadDataWithBaseURL("file:///android_asset/www/",printableHtml,"text/html","UTF-8",null);
            }catch(Exception ex){
                Toast.makeText(MainActivity.this,"Could not prepare report PDF: "+ex.getMessage(),Toast.LENGTH_LONG).show();
            }
        }
        private void savePdfBytesWithDuplicateCheck(byte[] bytes,String filename){
            String folder=siddhiBillFolderFor(filename); String relative=Environment.DIRECTORY_DOWNLOADS+"/SiddhiBill/"+folder;
            if(Build.VERSION.SDK_INT>=29){
                Uri existing=null;
                try(android.database.Cursor c=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,new String[]{MediaStore.MediaColumns._ID},MediaStore.MediaColumns.DISPLAY_NAME+"=? AND "+MediaStore.MediaColumns.RELATIVE_PATH+"=?",new String[]{filename,relative+"/"},null)){
                    if(c!=null&&c.moveToFirst())existing=ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI,c.getLong(0));
                }catch(Exception e){Toast.makeText(MainActivity.this,"Could not check duplicate PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();return;}
                Uri old=existing;
                if(old!=null){new android.app.AlertDialog.Builder(MainActivity.this).setTitle("PDF already exists").setMessage(filename+" already exists in Downloads/SiddhiBill/"+folder+". Replace it and open the latest PDF?").setNegativeButton("Cancel",(d,w)->{}).setPositiveButton("Replace",(d,w)->writePdfAndOpen(bytes,filename,folder,relative,old)).show();}
                else writePdfAndOpen(bytes,filename,folder,relative,null);
            }else{
                File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"SiddhiBill/"+folder);if(!dir.exists())dir.mkdirs();File file=new File(dir,filename);
                if(file.exists()){new android.app.AlertDialog.Builder(MainActivity.this).setTitle("PDF already exists").setMessage(filename+" already exists. Replace and open the latest PDF?").setNegativeButton("Cancel",(d,w)->{}).setPositiveButton("Replace",(d,w)->{file.delete();try(FileOutputStream f=new FileOutputStream(file)){f.write(bytes);}catch(Exception e){Toast.makeText(MainActivity.this,"Could not save PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();return;}openSavedPdf(Uri.fromFile(file));}).show();}
                else try(FileOutputStream f=new FileOutputStream(file)){f.write(bytes);openSavedPdf(Uri.fromFile(file));}catch(Exception e){Toast.makeText(MainActivity.this,"Could not save PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();}
            }
        }
        private void writePdfAndOpen(byte[] bytes,String filename,String folder,String relative,Uri existing){
            try{
                if(existing!=null)getContentResolver().delete(existing,null,null);
                ContentValues v=new ContentValues();v.put(MediaStore.MediaColumns.DISPLAY_NAME,filename);v.put(MediaStore.MediaColumns.MIME_TYPE,"application/pdf");v.put(MediaStore.MediaColumns.RELATIVE_PATH,relative+"/");v.put(MediaStore.MediaColumns.IS_PENDING,1);
                Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(uri==null)throw new Exception("Android could not create the PDF");
                try(OutputStream o=getContentResolver().openOutputStream(uri)){if(o==null)throw new Exception("Could not write PDF");o.write(bytes);o.flush();}
                ContentValues done=new ContentValues();done.put(MediaStore.MediaColumns.IS_PENDING,0);getContentResolver().update(uri,done,null,null);
                Toast.makeText(MainActivity.this,"Saved to Downloads/SiddhiBill/"+folder+"/"+filename,Toast.LENGTH_LONG).show();openSavedPdf(uri);
            }catch(Exception e){Toast.makeText(MainActivity.this,"Could not save/open PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
        private void openSavedPdf(Uri uri){
            try{Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(uri,"application/pdf");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);i.setClipData(ClipData.newRawUri("SiddhiBill PDF",uri));startActivity(Intent.createChooser(i,"Open PDF with"));}
            catch(Exception e){Toast.makeText(MainActivity.this,"PDF saved, but no compatible PDF app was found: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
        @JavascriptInterface public void printBill(String json){ try{ MainActivity.this.printBill(json); }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not print bill: "+e.getMessage(),Toast.LENGTH_LONG).show());} }
        @JavascriptInterface public void directThermalPrint80(String json){ try{ MainActivity.this.directThermalPrint80(json); }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Direct print failed: "+e.getMessage(),Toast.LENGTH_LONG).show());} }
        @JavascriptInterface public void openPurchasePdf(String json){
            try{
                Uri uri=createPurchasePdfForSharing(json);
                Intent view=new Intent(Intent.ACTION_VIEW); view.setDataAndType(uri,"application/pdf");
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                view.setClipData(ClipData.newRawUri("SiddhiBill Purchase PDF",uri));
                try { startActivity(view); }
                catch(Exception noViewer){ Intent chooser=Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("application/pdf").putExtra(Intent.EXTRA_STREAM,uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),"Open purchase PDF"); chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(chooser); }
            }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not create purchase PDF: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void openBillPdf(String json){
            try{
                JSONObject b=new JSONObject(json);JSONObject cfg=b.optJSONObject("settings");String paper=cfg==null?"A4":cfg.optString("paperSize","A4");
                String filename=("58mm".equalsIgnoreCase(paper)||"80mm".equalsIgnoreCase(paper))?"Bill_"+b.optString("billNo","Bill").replaceAll("[^A-Za-z0-9_-]","_")+"_"+paper+".pdf":"Bill_"+b.optString("billNo","Bill").replaceAll("[^A-Za-z0-9_-]","_")+".pdf";
                String folder=siddhiBillFolderFor(filename);Uri existing=null;
                if(Build.VERSION.SDK_INT>=29){String rel=Environment.DIRECTORY_DOWNLOADS+"/SiddhiBill/"+folder+"/";try(android.database.Cursor c=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,new String[]{MediaStore.MediaColumns._ID},MediaStore.MediaColumns.DISPLAY_NAME+"=? AND "+MediaStore.MediaColumns.RELATIVE_PATH+"=?",new String[]{filename,rel},null)){if(c!=null&&c.moveToFirst())existing=ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI,c.getLong(0));}}
                else {File f=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"SiddhiBill/"+folder+"/"+filename);if(f.exists())existing=Uri.fromFile(f);}
                if(existing!=null){final Uri old=existing;new android.app.AlertDialog.Builder(MainActivity.this).setTitle("Bill PDF already exists").setMessage(filename+" already exists in Downloads/SiddhiBill/Bills. Replace it with the latest bill PDF and open it?").setNegativeButton("Cancel",(d,w)->{}).setPositiveButton("Replace",(d,w)->{try{if(Build.VERSION.SDK_INT>=29)getContentResolver().delete(old,null,null);else new File(old.getPath()).delete();openBillPdfNow(json);}catch(Exception e){Toast.makeText(MainActivity.this,"Could not replace existing bill PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();}}).show();return;}
                openBillPdfNow(json);
            }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not create/open PDF: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        private void openBillPdfNow(String json){
            try{
                Uri uri=createBillPdfForSharing(json);Intent view=new Intent(Intent.ACTION_VIEW);view.setDataAndType(uri,"application/pdf");view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);view.setClipData(ClipData.newRawUri("SiddhiBill PDF",uri));
                try{startActivity(Intent.createChooser(view,"Open PDF with"));}catch(Exception noViewer){Toast.makeText(MainActivity.this,"Bill PDF saved, but no compatible PDF app was found.",Toast.LENGTH_LONG).show();}
            }catch(Exception e){Toast.makeText(MainActivity.this,"Could not create/open PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
        @JavascriptInterface public void shareDukaanBillToWhatsApp(String json){
            try{
                byte[] data=json.getBytes(StandardCharsets.UTF_8);
                Uri uri=saveToCacheProvider(data,"DukaanBill_"+new JSONObject(json).optString("billNo","Bill").replaceAll("[^A-Za-z0-9_-]","_")+".dukaanbill");
                Intent send=new Intent(Intent.ACTION_SEND);
                send.setType("application/vnd.dukaanbill");
                send.putExtra(Intent.EXTRA_STREAM,uri);
                send.putExtra(Intent.EXTRA_TEXT,"Dukaan Bill - Thermal Print");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                send.setClipData(ClipData.newRawUri("Dukaan Bill",uri));
                Intent chooser=Intent.createChooser(send,"Send Dukaan Bill");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(chooser);
            }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not share Dukaan Bill: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public boolean isAppActivated(){ return isActivated(); }
        @JavascriptInterface public String startSevenDayTrial(){ return MainActivity.this.startTrial(); }
        @JavascriptInterface public String approveTrialActivation(String request){try{return MainActivity.this.approveActivation(request,"TRIAL");}catch(Exception e){return "ERROR:"+e.getMessage();}}
        @JavascriptInterface public long trialExpiry(){ return getSharedPreferences("activation",MODE_PRIVATE).getLong("trial_expiry",0L); }
        @JavascriptInterface public String ownerContactNumber(){ return "8087794271"; }
        @JavascriptInterface public void shareActivationFile(String token){ MainActivity.this.shareActivationFile(token); }
        @JavascriptInterface public String createActivationRequest(){ try{return MainActivity.this.createActivationRequest("SHOP");}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public String createShopSetupInvite(String shopName,String shopMobile,String managerName,String address,String gstin,String state){ try{return MainActivity.this.createShopSetupInvite(shopName,shopMobile,managerName,address,gstin,state);}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public boolean unlockOwner(String pin){ return MainActivity.this.unlockOwnerSession(pin); }
        @JavascriptInterface public boolean ownerSessionUnlocked(){ return sessionOwnerPrivateKey != null; }
        @JavascriptInterface public boolean isOwnerDevice(){ return ownerConfigured(); }
        @JavascriptInterface public void updateOwnerShopSettings(String shopName,String shopMobile,String managerName,String address,String gstin,String state){
            try{
                JSONObject root=new JSONObject(MainActivity.this.loadAppState());
                JSONObject settings=root.optJSONObject("dukaanBillSettings");
                if(settings==null) settings=new JSONObject();
                if(shopName!=null && !shopName.trim().isEmpty()) settings.put("shopName",shopName.trim());
                if(shopMobile!=null) { settings.put("shopMobile",shopMobile.trim()); JSONArray a=new JSONArray(); if(!shopMobile.trim().isEmpty()) a.put(shopMobile.trim()); settings.put("shopMobiles",a); }
                if(address!=null) settings.put("address",address.trim());
                if(gstin!=null) settings.put("gstin",gstin.trim());
                if(state!=null) settings.put("businessState",state.trim());
                root.put("dukaanBillSettings",settings);
                MainActivity.this.saveAppState(root.toString());
            }catch(Exception ignored){}
        }
        @JavascriptInterface public String acceptShopSetupInvite(String invite){ try{ JSONObject p=MainActivity.this.verifyShopSetupInvite(invite); getSharedPreferences("activation",MODE_PRIVATE).edit().putString("pending_shop_setup",invite).putString("shop_setup_id",p.optString("setupId")).putString("shop_name",p.optString("shopName")).putString("shop_mobile",p.optString("shopMobile")).putString("shop_manager",p.optString("managerName")).putString("shop_address",p.optString("address")).putString("shop_gstin",p.optString("gstin")).putString("shop_state",p.optString("state")).apply(); return p.toString(); }catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public String pendingShopSetup(){ return getSharedPreferences("activation",MODE_PRIVATE).getString("pending_shop_setup",null); }
        @JavascriptInterface public String getActivatedShopSetup(){ try{ android.content.SharedPreferences p=getSharedPreferences("activation",MODE_PRIVATE); JSONObject o=new JSONObject(); o.put("shopName",p.getString("shop_name","")); o.put("shopMobile",p.getString("shop_mobile","")); o.put("managerName",p.getString("shop_manager","")); o.put("address",p.getString("shop_address","")); o.put("gstin",p.getString("shop_gstin","")); o.put("state",p.getString("shop_state","")); return o.toString(); }catch(Exception e){return "{}";} }
        @JavascriptInterface public void clearPendingShopSetup(){ getSharedPreferences("activation",MODE_PRIVATE).edit().remove("pending_shop_setup").remove("shop_setup_id").apply(); }

        @JavascriptInterface public String createOwnerActivationRequest(){ try{return MainActivity.this.createActivationRequest("OWNER");}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public String finalizeOwnerActivation(String pin){ try{MainActivity.this.finalizeOwnerActivation(pin);return "OK";}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public boolean pendingOwnerActivation(){ return getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).contains("pending_owner_key"); }
        @JavascriptInterface public String generateQr(String text){ try{return qrDataUrl(text);}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public void shareActivationRequest(String text){
            try { Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/918087794271?text="+Uri.encode("SiddhiBill activation request\n\n"+(text==null?"":text)))); startActivity(i); }
            catch(Exception e){shareText("SiddhiBill Activation Request",text);}
        }
        @JavascriptInterface public void shareActivationToken(String text){shareText("SiddhiBill Activation Approval",text);}
        @JavascriptInterface public void openOwnerWhatsApp(){ try { Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/918087794271?text="+Uri.encode("Hello, I need SiddhiBill support/activation."))); startActivity(i); } catch(Exception e){Toast.makeText(MainActivity.this,"Could not open WhatsApp: "+e.getMessage(),Toast.LENGTH_LONG).show();} }
        @JavascriptInterface public void scanActivationQr(){scanQr();}
        @JavascriptInterface public boolean ownerConfigured(){return getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).contains(OWNER_PRIVATE_PREF);}
        @JavascriptInterface public String configureOwner(String privateKeyB64,String pin){try{if(pin==null||pin.length()<6)return "ERROR:Owner PIN must be at least 6 digits/characters";saveOwnerPrivate(privateKeyB64,pin);sessionOwnerPrivateKey=loadOwnerPrivate(pin);setActivated(true);return "OK";}catch(Exception e){return "ERROR:"+e.getMessage();}}
        @JavascriptInterface public String approveActivation(String request){try{return MainActivity.this.approveActivation(request);}catch(Exception e){return "ERROR:"+e.getMessage();}}
        @JavascriptInterface public boolean closeOwnerToBilling(){ if(!isActivated() || !ownerConfigured() || sessionOwnerPrivateKey==null) return false; runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.loadUrl("file:///android_asset/www/index.html"); }); return true; }
        @JavascriptInterface public boolean openOwnerSetupBilling(){ if(!ownerConfigured() || sessionOwnerPrivateKey==null) return false; runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.loadUrl("file:///android_asset/www/index.html"); }); return true; }
        @JavascriptInterface public String applyActivation(String token){try{MainActivity.this.applyActivation(token);return "OK";}catch(Exception e){return "ERROR:"+e.getMessage();}}
        @JavascriptInterface public void openActivatedApp(){ if(isActivated() || (ownerConfigured() && sessionOwnerPrivateKey!=null)){ runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.post(() -> webView.loadUrl("file:///android_asset/www/index.html")); }); } }
        @JavascriptInterface public void openBilling(){ runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.post(() -> webView.loadUrl(isActivated() ? "file:///android_asset/www/index.html" : "file:///android_asset/www/activation.html")); }); }
        @JavascriptInterface public void openOwnerDevice(){
            if(!isActivated() || !ownerConfigured() || sessionOwnerPrivateKey==null){ showActivationPage("Owner access is locked. Verify activation and unlock the Owner PIN first."); return; }
            runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.loadUrl("file:///android_asset/www/index.html"); });
        }
        @JavascriptInterface public void openOwnerMode(){
            // Do not expose the Owner dashboard route from ordinary shop devices.
            if(!isActivated() || !ownerConfigured()) { runOnUiThread(() -> Toast.makeText(MainActivity.this,"Owner Dashboard is available only on a configured Owner device.",Toast.LENGTH_LONG).show()); return; }
            runOnUiThread(() -> { webView.stopLoading(); webView.clearHistory(); webView.loadUrl("file:///android_asset/www/activation.html?owner=1"); });
        }
        @JavascriptInterface public void sendBillMessage(String phone,String message){
            Log.i("SiddhiBillShareDiag", "sendBillMessage entered; phonePresent=" + (phone!=null && !phone.trim().isEmpty()) + "; messageLength=" + (message==null?0:message.length()));
            try{
                String digits=phone==null?"":phone.replaceAll("\\D","");
                if(digits.startsWith("91")&&digits.length()==12) digits=digits.substring(2);
                if(digits.length()!=10) throw new Exception("Invalid 10 digit mobile number");
                Intent sms=new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"+digits));
                sms.putExtra("sms_body", message==null?"":message);
                sms.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(sms);
            }catch(Exception e){Log.e("SiddhiBillShareDiag", "sendBillMessage failed", e); runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not open mobile message: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void shareEstimatePdfToWhatsApp(String html,String estimateNo,String phone,String message,String paperSize){
            try{
                final String safeName=(estimateNo==null||estimateNo.trim().isEmpty()?"Estimate":estimateNo).replaceAll("[^A-Za-z0-9_-]","_");
                final String content=html==null?"":html;
                final String paper=(paperSize==null?"A4":paperSize).trim().toUpperCase(Locale.ROOT);
                runOnUiThread(()->{
                    WebView pdfView=null;
                    try{
                        pdfView=new WebView(MainActivity.this);
                        final WebView view=pdfView;
                        view.getSettings().setJavaScriptEnabled(false);
                        view.setWebViewClient(new android.webkit.WebViewClient(){
                            @Override public void onPageFinished(WebView v,String url){
                                try{
                                    PrintAttributes.MediaSize media;
                                    if("58MM".equals(paper))media=new PrintAttributes.MediaSize("SIDDHI_58MM","58 mm",2283,20000);
                                    else if("80MM".equals(paper))media=new PrintAttributes.MediaSize("SIDDHI_80MM","80 mm",3150,20000);
                                    else if("A6".equals(paper))media=PrintAttributes.MediaSize.ISO_A6;
                                    else media=PrintAttributes.MediaSize.ISO_A4;
                                    PrintAttributes attrs=new PrintAttributes.Builder().setMediaSize(media).setResolution(new PrintAttributes.Resolution("estimate_pdf","Estimate PDF",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).setColorMode(PrintAttributes.COLOR_MODE_COLOR).build();
                                    PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                                    if(pm==null)throw new Exception("Android print service is unavailable");
                                    pm.print("Estimate_"+safeName,view.createPrintDocumentAdapter("Estimate_"+safeName),attrs);
                                }catch(Exception ex){
                                    Log.e("SiddhiBillEstimateShare","Could not open estimate print dialog",ex);
                                    Toast.makeText(MainActivity.this,"Could not print estimate: "+ex.getMessage(),Toast.LENGTH_LONG).show();
                                    view.destroy();
                                }
                            }
                        });
                        view.loadDataWithBaseURL("file:///android_asset/www/",content,"text/html","UTF-8",null);
                        Toast.makeText(MainActivity.this,"Choose Save as PDF in the print dialog, then share the saved PDF in WhatsApp.",Toast.LENGTH_LONG).show();
                    }catch(Exception ex){
                        if(pdfView!=null)pdfView.destroy();
                        Toast.makeText(MainActivity.this,"Could not prepare estimate PDF: "+ex.getMessage(),Toast.LENGTH_LONG).show();
                    }
                });
            }catch(Exception e){
                Log.e("SiddhiBillEstimateShare","shareEstimatePdfToWhatsApp failed",e);
                runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not prepare estimate PDF: "+e.getMessage(),Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void shareBillPdfToWhatsApp(String json,String phone){
            Log.i("SiddhiBillShareDiag", "shareBillPdfToWhatsApp entered; jsonLength=" + (json==null?0:json.length()) + "; phonePresent=" + (phone!=null && !phone.trim().isEmpty()));
            try{
                String digits=phone==null?"":phone.replaceAll("\\D","");
                if(digits.startsWith("91")&&digits.length()==12) digits=digits.substring(2);
                if(digits.length()!=10) throw new Exception("Invalid 10 digit mobile number");
                Uri uri=createBillPdfForSharing(json);
                Intent send=new Intent(Intent.ACTION_SEND); send.setType("application/pdf");
                send.putExtra(Intent.EXTRA_STREAM,uri); send.putExtra(Intent.EXTRA_TEXT,"SiddhiBill - Bill");
                send.putExtra("jid","91"+digits+"@s.whatsapp.net"); send.setPackage("com.whatsapp");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                send.setClipData(ClipData.newRawUri("SiddhiBill PDF",uri));
                try{startActivity(send);}catch(Exception noDirect){
                    Intent chat=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/91"+digits+"?text=SiddhiBill%20-%20Bill"));
                    chat.setPackage("com.whatsapp"); startActivity(chat);
                    Toast.makeText(MainActivity.this,"WhatsApp chat opened. Attach the PDF if direct attachment is not supported by your WhatsApp version.",Toast.LENGTH_LONG).show();
                }
            }catch(Exception e){Log.e("SiddhiBillShareDiag", "shareBillPdfToWhatsApp failed", e); runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not open WhatsApp: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public String loadAppState(){ return MainActivity.this.loadAppState(); }
        @JavascriptInterface public void saveAppState(String json){ MainActivity.this.saveAppState(json); }
        @JavascriptInterface public void setOwnerDashboardBackup(String json){
            try { new JSONObject(json == null || json.trim().isEmpty() ? "{}" : json); pendingOwnerDashboardBackup = json == null ? "{}" : json; }
            catch(Exception e){ pendingOwnerDashboardBackup = "{}"; }
        }
        @JavascriptInterface public String getPairedBluetoothPrinters(){ return MainActivity.this.pairedBluetoothPrintersJson(); }
        @JavascriptInterface public void configureAutoBackup(String mode,String hours){runOnUiThread(()->MainActivity.this.configureAutoBackup(mode,hours));}
        @JavascriptInterface public void refreshAutoBackupStatus(){MainActivity.this.notifyAutoBackupStatus();}
        @JavascriptInterface public void chooseArchiveImport(){runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/zip","application/octet-stream"});startActivityForResult(i,REQ_ARCHIVE_IMPORT);}catch(Exception e){Toast.makeText(MainActivity.this,"Could not open archive picker: "+e.getMessage(),Toast.LENGTH_LONG).show();}});}
    private File createArchiveSummaryPdf(JSONObject archive,File target) throws Exception {
        PdfDocument pdf=new PdfDocument(); Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG); paint.setColor(Color.BLACK); paint.setTextSize(7f);
        JSONArray customers=archive.optJSONObject("records")==null?new JSONArray():archive.optJSONObject("records").optJSONArray("customerBills");
        JSONArray purchases=archive.optJSONObject("records")==null?new JSONArray():archive.optJSONObject("records").optJSONArray("purchaseBills");
        if(customers==null)customers=new JSONArray();if(purchases==null)purchases=new JSONArray();
        int pageNo=0; PdfDocument.Page page=null; Canvas canvas=null; int y=0;
        String[] headers={"Date","Bill No.","Customer/Vendor","Type","Taxable","CGST","SGST","IGST","Total","Paid","Balance","Status"};
        float[] x={20,72,132,235,286,330,366,402,438,485,530,576};
        java.util.ArrayList<JSONObject> rows=new java.util.ArrayList<>();
        for(int i=0;i<customers.length();i++){JSONObject b=customers.optJSONObject(i);if(b!=null){JSONObject r=new JSONObject();r.put("date",b.optString("date",""));r.put("no",b.optString("billNo",""));r.put("party",b.optString("customer",""));r.put("type","Customer");r.put("taxable",b.optDouble("taxableValue",b.optDouble("subtotal",0)));r.put("cgst",b.optDouble("cgst",0));r.put("sgst",b.optDouble("sgst",0));r.put("igst",b.optDouble("igst",0));double total=b.optDouble("total",0),paid="Credit".equalsIgnoreCase(b.optString("paymentMode","Cash"))?b.optDouble("partialPaymentAmount",0):total;r.put("total",total);r.put("paid",paid);r.put("balance",Math.max(0,total-paid));r.put("status",Math.max(0,total-paid)>0?"Outstanding":"Paid");rows.add(r);}}
        for(int i=0;i<purchases.length();i++){JSONObject b=purchases.optJSONObject(i);if(b!=null){JSONObject r=new JSONObject();r.put("date",b.optString("date",b.optString("invoiceDate","")));r.put("no",b.optString("invoiceNo",b.optString("billNo","")));r.put("party",b.optString("vendorName",b.optString("vendor","")));r.put("type","Purchase");r.put("taxable",b.optDouble("taxableValue",b.optDouble("subtotal",0)));r.put("cgst",b.optDouble("cgst",0));r.put("sgst",b.optDouble("sgst",0));r.put("igst",b.optDouble("igst",0));double total=b.optDouble("total",b.optDouble("grandTotal",0)),paid=b.optDouble("paidAmount",b.optDouble("paid",0)),balance=b.optDouble("balance",b.optDouble("balancePending",Math.max(0,total-paid)));r.put("total",total);r.put("paid",paid);r.put("balance",balance);r.put("status",balance<=0?"Paid":"Outstanding");rows.add(r);}}
        java.util.Collections.sort(rows,(a,b)->a.optString("date","").compareTo(b.optString("date","")));
        try {
            int idx=0; while(idx<rows.size()||pageNo==0){
                pageNo++;PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(842,595,pageNo).create();page=pdf.startPage(info);canvas=page.getCanvas();y=24;
                paint.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));paint.setTextSize(13f);canvas.drawText((archive.optString("shopName","SiddhiBill")+" - Archive Summary"),20,y,paint);y+=15;
                paint.setTextSize(8f);paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));canvas.drawText("Period: "+archive.optJSONObject("dateRange").optString("from","All dates")+" to "+archive.optJSONObject("dateRange").optString("to","All dates")+" | Generated: "+new java.util.Date()+" | Customer bills: "+customers.length()+" | Purchase bills: "+purchases.length(),20,y,paint);y+=18;
                paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));paint.setTextSize(6.5f);for(int h=0;h<headers.length;h++)canvas.drawText(headers[h],x[h],y,paint);y+=7;canvas.drawLine(20,y,820,y,paint);y+=10;paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));paint.setTextSize(6.5f);
                int bottom=555;while(idx<rows.size()&&y<bottom){JSONObject r=rows.get(idx++);String[] vals={r.optString("date",""),r.optString("no",""),r.optString("party",""),r.optString("type",""),String.format(Locale.US,"%.2f",r.optDouble("taxable",0)),String.format(Locale.US,"%.2f",r.optDouble("cgst",0)),String.format(Locale.US,"%.2f",r.optDouble("sgst",0)),String.format(Locale.US,"%.2f",r.optDouble("igst",0)),String.format(Locale.US,"%.2f",r.optDouble("total",0)),String.format(Locale.US,"%.2f",r.optDouble("paid",0)),String.format(Locale.US,"%.2f",r.optDouble("balance",0)),r.optString("status","")};for(int h=0;h<vals.length;h++){String v=vals[h];float colRight=(h+1< x.length?x[h+1]-3:820);float colWidth=Math.max(8,colRight-x[h]);if(h==1){float measured=paint.measureText(v);if(measured>colWidth){canvas.save();canvas.translate(x[h],y);canvas.scale(colWidth/measured,1f);canvas.drawText(v,0,0,paint);canvas.restore();}else{canvas.drawText(v,x[h],y,paint);}}else{float max=h==2?16:(h==0?10:9);if(v.length()>max)v=v.substring(0,(int)max);canvas.drawText(v,x[h],y,paint);}}y+=12;}
                if(idx>=rows.size()){y=Math.min(575,y+4);paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.ITALIC));paint.setTextSize(7);canvas.drawText("Structured transaction summary only. Item details and original attachments are not included.",20,y,paint);}
                pdf.finishPage(page);if(idx>=rows.size())break;
            }
            try(FileOutputStream out=new FileOutputStream(target)){pdf.writeTo(out);out.flush();}
        } finally {pdf.close();}
        if(!target.exists()||target.length()<100)throw new Exception("Could not generate archive summary PDF");return target;
    }

        @JavascriptInterface public void createArchiveZip(String archiveJson){
            runOnUiThread(() -> {
                try {
                    JSONObject archive = new JSONObject(archiveJson == null ? "{}" : archiveJson);
                    if(!"SiddhiBillArchive".equals(archive.optString("format"))) throw new Exception("Invalid archive format");
                    File outDir = new File(getCacheDir(), "archives"); if(!outDir.exists()&&!outDir.mkdirs())throw new Exception("Could not create temporary archive folder");
                    String stamp=new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new java.util.Date());
                    File zip = new File(outDir, "SiddhiBill_Archive_" + stamp + ".zip");
                    try(ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zip))){
                        ZipEntry dataEntry = new ZipEntry("archive/transactions.json"); zos.putNextEntry(dataEntry);
                        zos.write(archive.toString().getBytes(StandardCharsets.UTF_8)); zos.closeEntry();
                    }
                    if(zip.length()<50) throw new Exception("Generated archive is unexpectedly small");
                    pendingArchiveZip=zip; pendingArchivePdf=createArchiveSummaryPdf(archive,new File(outDir,"SiddhiBill_Archive_Summary_"+stamp+".pdf"));
                    Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/zip"); i.putExtra(Intent.EXTRA_TITLE,zip.getName());
                    startActivityForResult(i,REQ_ARCHIVE_CREATE);
                } catch(Exception e){ notifyArchiveZipSaved(false,"Could not prepare archive files: "+e.getMessage()+". No bills were removed."); }
            });
        }
        @JavascriptInterface public void backupData(){ runOnUiThread(MainActivity.this::startBackup); }
        @JavascriptInterface public void backupData(String ownerJson){
            try { new JSONObject(ownerJson == null || ownerJson.trim().isEmpty() ? "{}" : ownerJson); pendingOwnerDashboardBackup = ownerJson == null ? "{}" : ownerJson; }
            catch(Exception e){ pendingOwnerDashboardBackup = "{}"; }
            runOnUiThread(MainActivity.this::startBackup);
        }
        @JavascriptInterface public boolean verifyShopNamePassword(String password){ return MainActivity.this.verifyShopNamePasswordInternal(password); }
        @JavascriptInterface public void restoreData(){ runOnUiThread(MainActivity.this::startRestore); }
        @JavascriptInterface public void shareTextFile(String base64,String filename,String mime){
            try{byte[] bytes=Base64.decode(base64,Base64.DEFAULT);shareFile(bytes,filename==null?"SiddhiBill.csv":filename,mime==null?"text/csv":mime,"Export SiddhiBill CSV");}
            catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not export CSV: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void saveExportFile(String base64,String filename){
            try {
                byte[] bytes=Base64.decode(base64,Base64.DEFAULT);
                if(bytes.length==0) throw new Exception("Export file is empty");
                String safeName=(filename==null||filename.trim().isEmpty())?"SiddhiBill_Export.csv":filename.replaceAll("[^A-Za-z0-9._-]","_");
                runOnUiThread(() -> saveExportFileWithDuplicateCheck(bytes, safeName));
            } catch(Exception e) {
                runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not save export file: "+e.getMessage(),Toast.LENGTH_LONG).show());
                if(webView!=null) webView.post(()->webView.evaluateJavascript("window.onGstExportSaved && window.onGstExportSaved(false,"+JSONObject.quote(e.getMessage())+")",null));
            }
        }
        private void saveExportFileWithDuplicateCheck(byte[] bytes, String safeName) {
            String folder=siddhiBillFolderFor(safeName);
            if(Build.VERSION.SDK_INT>=29){
                String relativePath=Environment.DIRECTORY_DOWNLOADS+"/SiddhiBill/"+folder;
                Uri existingUri=null;
                try {
                    String[] projection={MediaStore.MediaColumns._ID};
                    String selection=MediaStore.MediaColumns.DISPLAY_NAME+"=? AND "+MediaStore.MediaColumns.RELATIVE_PATH+"=?";
                    try (android.database.Cursor cursor=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,projection,selection,new String[]{safeName,relativePath+"/"},null)) {
                        if(cursor!=null && cursor.moveToFirst()) {
                            long id=cursor.getLong(0);
                            existingUri=ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI,id);
                        }
                    }
                } catch(Exception e) {
                    Toast.makeText(MainActivity.this,"Could not check for an existing file: "+e.getMessage(),Toast.LENGTH_LONG).show();
                    if(webView!=null) webView.evaluateJavascript("window.onGstExportSaved && window.onGstExportSaved(false,'Could not check for duplicate file')",null);
                    return;
                }
                if(existingUri!=null){
                    final Uri oldFileUri=existingUri;
                    new android.app.AlertDialog.Builder(MainActivity.this)
                        .setTitle("File already exists")
                        .setMessage("\""+safeName+"\" already exists in Downloads/SiddhiBill/"+folder+". Replace the existing file? Choosing Replace avoids creating a duplicate.")
                        .setNegativeButton("Cancel",(dialog,which)->{
                            if(webView!=null) webView.evaluateJavascript("window.onGstExportSaved && window.onGstExportSaved(false,'Download cancelled: file already exists')",null);
                        })
                        .setPositiveButton("Replace",(dialog,which)->writeExportFile(bytes,safeName,folder,relativePath,oldFileUri))
                        .show();
                    return;
                }
                writeExportFile(bytes,safeName,folder,relativePath,null);
            } else {
                File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"SiddhiBill/"+folder);
                if(!dir.exists()&&!dir.mkdirs()){
                    Toast.makeText(MainActivity.this,"Could not create SiddhiBill export folder",Toast.LENGTH_LONG).show();
                    return;
                }
                File outFile=new File(dir,safeName);
                if(outFile.exists()){
                    new android.app.AlertDialog.Builder(MainActivity.this).setTitle("File already exists")
                        .setMessage("\""+safeName+"\" already exists. Replace the existing file?")
                        .setNegativeButton("Cancel",(dialog,which)->{})
                        .setPositiveButton("Replace",(dialog,which)->writeLegacyExport(bytes,outFile))
                        .show();
                } else writeLegacyExport(bytes,outFile);
            }
        }
        private void writeExportFile(byte[] bytes,String safeName,String folder,String relativePath,Uri existingUri){
            try {
                if(existingUri!=null && getContentResolver().delete(existingUri,null,null)==0) throw new Exception("Could not replace the existing file");
                ContentValues values=new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME,safeName);
                values.put(MediaStore.MediaColumns.MIME_TYPE,safeName.toLowerCase(Locale.ROOT).endsWith(".csv")?"text/csv":(safeName.toLowerCase(Locale.ROOT).endsWith(".pdf")?"application/pdf":"application/octet-stream"));
                values.put(MediaStore.MediaColumns.RELATIVE_PATH,relativePath);
                values.put(MediaStore.MediaColumns.IS_PENDING,1);
                Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
                if(uri==null) throw new Exception("Android could not create the SiddhiBill export file");
                try(OutputStream out=getContentResolver().openOutputStream(uri)){
                    if(out==null) throw new Exception("Could not open the SiddhiBill export file");
                    out.write(bytes);out.flush();
                }
                ContentValues done=new ContentValues();done.put(MediaStore.MediaColumns.IS_PENDING,0);getContentResolver().update(uri,done,null,null);
                Toast.makeText(MainActivity.this,"Saved to Downloads/SiddhiBill/"+folder+"/"+safeName,Toast.LENGTH_LONG).show();
                if(webView!=null) webView.evaluateJavascript("window.onGstExportSaved && window.onGstExportSaved(true,"+JSONObject.quote(safeName)+")",null);
            } catch(Exception e){
                Toast.makeText(MainActivity.this,"Could not save export file: "+e.getMessage(),Toast.LENGTH_LONG).show();
                if(webView!=null) webView.evaluateJavascript("window.onGstExportSaved && window.onGstExportSaved(false,"+JSONObject.quote(e.getMessage())+")",null);
            }
        }
        private void writeLegacyExport(byte[] bytes,File outFile){
            try(FileOutputStream out=new FileOutputStream(outFile)){out.write(bytes);out.flush();
                Toast.makeText(MainActivity.this,"Saved to "+outFile.getAbsolutePath(),Toast.LENGTH_LONG).show();
            }catch(Exception e){Toast.makeText(MainActivity.this,"Could not save export file: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
        @JavascriptInterface public void shareSyncFile(String base64){
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                if (bytes.length == 0) throw new Exception("Sync data is empty");
                // Include purchase invoice attachments in the same portable sync payload.
                JSONObject syncRoot = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
                JSONObject syncData = syncRoot.optJSONObject("data");
                if (syncData != null) {
                    JSONArray attachments = new JSONArray();
                    File docs = purchaseDocsDir;
                    File[] files = docs == null ? null : docs.listFiles();
                    if (files != null) for (File file : files) if (file.isFile()) {
                        try (InputStream in = new FileInputStream(file); java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream()) {
                            byte[] chunk = new byte[8192]; int count; while ((count = in.read(chunk)) > 0) buffer.write(chunk, 0, count);
                            JSONObject item = new JSONObject(); item.put("name", file.getName());
                            item.put("base64", Base64.encodeToString(buffer.toByteArray(), Base64.NO_WRAP)); attachments.put(item);
                        }
                    }
                    syncData.put("purchaseAttachments", attachments);
                    bytes = syncRoot.toString().getBytes(StandardCharsets.UTF_8);
                }
                final byte[] syncBytes = bytes;
                runOnUiThread(() -> {
                    android.widget.LinearLayout options = new android.widget.LinearLayout(MainActivity.this);
                    options.setOrientation(android.widget.LinearLayout.VERTICAL);
                    int pad = (int) (20 * getResources().getDisplayMetrics().density);
                    options.setPadding(pad, pad / 2, pad, pad / 2);
                    android.widget.TextView description = new android.widget.TextView(MainActivity.this);
                    description.setText("Choose how to share or save the sync file.");
                    description.setTextColor(0xFF172B4D);
                    description.setTextSize(16);
                    description.setPadding(0, 0, 0, pad / 2);
                    options.addView(description, new android.widget.LinearLayout.LayoutParams(-1, -2));
                    android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(MainActivity.this)
                        .setTitle("Create Sync File")
                        .setView(options)
                        .setNegativeButton("Cancel", null)
                        .create();
                    String[] labels = new String[]{"WhatsApp", "Share with another app (Drive / Nearby Share)", "Save sync file to this phone"};
                    for (int i = 0; i < labels.length; i++) {
                        final int action = i;
                        android.widget.Button button = new android.widget.Button(MainActivity.this);
                        button.setText(labels[i]);
                        button.setTextColor(0xFF172B4D);
                        button.setAllCaps(false);
                        android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(-1, -2);
                        lp.bottomMargin = Math.max(4, pad / 4);
                        options.addView(button, lp);
                        button.setOnClickListener(v -> {
                            dialog.dismiss();
                            if (action == 0) shareSyncFileToWhatsApp(syncBytes);
                            else if (action == 1) shareSyncFileToOtherApps(syncBytes);
                            else saveSyncFileWithPicker(syncBytes);
                        });
                    }
                    dialog.show();
                });
            } catch(Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Could not create sync file: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
        private void shareSyncFileToWhatsApp(byte[] bytes) {
            try {
                Uri uri = saveToCacheProvider(bytes, "SiddhiBill_Shop_Sync.siddhisync");
                Intent send = new Intent(Intent.ACTION_SEND);
                // Do not use the app-specific vendor MIME type here: WhatsApp rejects it on some versions.
                send.setType("application/octet-stream");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_SUBJECT, "SiddhiBill Shop Sync File");
                send.putExtra(Intent.EXTRA_TEXT, "SiddhiBill shop sync file. Import this file in SiddhiBill on the other phone.");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                send.setClipData(ClipData.newUri(getContentResolver(), "SiddhiBill Shop Sync File", uri));
                send.setPackage("com.whatsapp");
                try {
                    startActivity(send);
                } catch (Exception whatsappUnavailable) {
                    send.setPackage("com.whatsapp.w4b");
                    try { startActivity(send); }
                    catch (Exception businessUnavailable) {
                        send.setPackage(null);
                        startActivity(Intent.createChooser(send, "Share SiddhiBill Sync File"));
                        Toast.makeText(MainActivity.this, "WhatsApp was not available. Choose a file-sharing app.", Toast.LENGTH_LONG).show();
                    }
                }
            } catch(Exception e) {
                Toast.makeText(MainActivity.this, "Could not share sync file: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        private void shareSyncFileToOtherApps(byte[] bytes) {
            try {
                Uri uri = saveToCacheProvider(bytes, "SiddhiBill_Shop_Sync.siddhisync");
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("application/octet-stream");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_SUBJECT, "SiddhiBill Shop Sync File");
                send.putExtra(Intent.EXTRA_TEXT, "SiddhiBill shop sync file. On the other phone, download the file and import it in SiddhiBill.");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                send.setClipData(ClipData.newUri(getContentResolver(), "SiddhiBill Shop Sync File", uri));
                startActivity(Intent.createChooser(send, "Share SiddhiBill Sync File"));
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Could not share sync file: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }

        private void saveSyncFileWithPicker(byte[] bytes) {
            try {
                pendingSyncDownloadBytes = bytes;
                Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                create.addCategory(Intent.CATEGORY_OPENABLE);
                create.setType("application/octet-stream");
                create.putExtra(Intent.EXTRA_TITLE, "SiddhiBill_Shop_Sync.siddhisync");
                create.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                startActivityForResult(create, REQ_SYNC_DOWNLOAD);
            } catch(Exception e) {
                pendingSyncDownloadBytes = null;
                Toast.makeText(MainActivity.this, "Could not open download location: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        @JavascriptInterface public void restoreSyncAttachments(String attachmentsJson) {
            try {
                JSONArray attachments = new JSONArray(attachmentsJson == null ? "[]" : attachmentsJson);
                if (purchaseDocsDir == null && !purchaseDocsDir.mkdirs()) throw new Exception("Could not create purchase attachment folder");
                for (int i = 0; i < attachments.length(); i++) {
                    JSONObject item = attachments.optJSONObject(i); if (item == null) continue;
                    String name = item.optString("name", "").replaceAll("[^A-Za-z0-9._-]", "_");
                    String encoded = item.optString("base64", "");
                    if (name.isEmpty() || encoded.isEmpty()) continue;
                    byte[] content = Base64.decode(encoded, Base64.DEFAULT);
                    if (content.length == 0) continue;
                    File target = new File(purchaseDocsDir, name);
                    try (OutputStream out = new FileOutputStream(target)) { out.write(content); out.flush(); }
                }
            } catch (Exception e) {
                android.util.Log.e("SiddhiBill", "Could not restore sync attachments", e);
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Some purchase attachments could not be synced: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void chooseQuickListSource(){
            runOnUiThread(() -> new android.app.AlertDialog.Builder(MainActivity.this)
                .setTitle("Add list to Quick List")
                .setItems(new String[]{"Camera", "Choose Image, PDF or TXT"}, (dialog, which) -> {
                    if(which==0) takeQuickListPhoto(); else pickQuickListFile();
                }).setNegativeButton("Cancel", null).show());
        }
        @JavascriptInterface public void pickQuickListFile(){
            try{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","application/pdf","text/plain"});
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i,REQ_QUICKLIST_IMAGE);
            }catch(Exception e){Toast.makeText(MainActivity.this,"Could not open files: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
        @JavascriptInterface public void takeQuickListPhoto(){
            // Ask for camera permission explicitly, then launch the external camera on the UI thread.
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    pendingQuickListCameraLaunch = true;
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_QUICKLIST_CAMERA_PERMISSION);
                    return;
                }
                launchQuickListCamera();
            });
        }
        @JavascriptInterface public void pickQuickListImage(){ pickQuickListFile(); }
        @JavascriptInterface public void pickQuickListPdf(){ pickQuickListFile(); }
        @JavascriptInterface public void recognizeQuickListImage(String base64){
            try{byte[] bytes=Base64.decode(base64,Base64.DEFAULT);Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);if(bmp==null)throw new Exception("Invalid image");InputImage image=InputImage.fromBitmap(bmp,0);TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);recognizer.process(image).addOnSuccessListener(result->{String text=formatQuickListOcr(result);webView.post(()->webView.evaluateJavascript("window.receiveQuickListOCR && window.receiveQuickListOCR("+JSONObject.quote(text)+");",null));recognizer.close();bmp.recycle();}).addOnFailureListener(err->{recognizer.close();bmp.recycle();runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not read image text. Try a clearer photo.",Toast.LENGTH_LONG).show());});}
            catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not read image: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void pickPurchaseDocument(){
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","image/jpeg","image/png","image/webp"});startActivityForResult(i,REQ_PURCHASE_DOCUMENT);
        }
        @JavascriptInterface public void capturePurchaseBill(){
            runOnUiThread(()->{
                if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
                    pendingPurchaseCameraLaunch=true;
                    requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_PURCHASE_CAMERA_PERMISSION);
                    return;
                }
                launchPurchaseBillCamera();
            });
        }
        @JavascriptInterface public void openPurchaseAttachment(String id,String mime){openPurchaseAttachment(id,mime);}
    }

    private void launchPurchaseBillCamera(){
        pendingPurchaseCameraLaunch=false;
        try{
            File shareDir=new File(getCacheDir(),"share");
            if(!shareDir.exists()&&!shareDir.mkdirs())throw new Exception("Could not prepare camera storage");
            File capture=new File(shareDir,"purchase_capture_"+System.currentTimeMillis()+".jpg");
            if(!capture.createNewFile())throw new Exception("Could not create camera image");
            purchaseCameraUri=Uri.parse("content://com.siddhibill.app.share/"+capture.getName());
            Intent i=new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT,purchaseCameraUri);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            i.setClipData(android.content.ClipData.newRawUri("Vendor bill camera output",purchaseCameraUri));
            startActivityForResult(i,REQ_PURCHASE_CAMERA);
        }catch(android.content.ActivityNotFoundException e){purchaseCameraUri=null;Toast.makeText(MainActivity.this,"No Camera app is installed. Please choose Upload Photo / PDF instead.",Toast.LENGTH_LONG).show();}
        catch(Exception e){purchaseCameraUri=null;Toast.makeText(MainActivity.this,"Could not open vendor bill camera: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    private void launchQuickListCamera(){
        pendingQuickListCameraLaunch = false;
        try {
            // Ask the camera app to write the full-resolution image to app-private cache.
            // Without EXTRA_OUTPUT Android camera apps commonly return only a tiny thumbnail.
            File shareDir=new File(getCacheDir(),"share");
            if(!shareDir.exists() && !shareDir.mkdirs()) throw new Exception("Could not prepare camera storage");
            File capture=new File(shareDir,"quicklist_capture_"+System.currentTimeMillis()+".jpg");
            if(capture.exists() && !capture.delete()) throw new Exception("Could not prepare camera image");
            if(!capture.createNewFile()) throw new Exception("Could not create camera image");
            quickListCameraUri=Uri.parse("content://com.siddhibill.app.share/"+capture.getName());
            Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT,quickListCameraUri);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            i.setClipData(android.content.ClipData.newRawUri("Quick List camera output",quickListCameraUri));
            startActivityForResult(i, REQ_QUICKLIST_CAMERA);
        } catch (android.content.ActivityNotFoundException e) {
            quickListCameraUri=null;
            Toast.makeText(MainActivity.this, "No Camera app is installed. Please install or enable your phone's Camera app.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            quickListCameraUri=null;
            Toast.makeText(MainActivity.this, "Could not open Camera: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==REQ_QUICKLIST_CAMERA_PERMISSION){
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED && pendingQuickListCameraLaunch){
                launchQuickListCamera();
            } else {
                pendingQuickListCameraLaunch = false;
                Toast.makeText(MainActivity.this, "Camera permission is needed to capture a Quick List photo. You can allow it in Android Settings or choose an existing image.", Toast.LENGTH_LONG).show();
            }
            return;
        }
        if(requestCode==REQ_PURCHASE_CAMERA_PERMISSION){
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED && pendingPurchaseCameraLaunch){launchPurchaseBillCamera();}
            else {pendingPurchaseCameraLaunch=false;Toast.makeText(MainActivity.this,"Camera permission is needed to capture a vendor bill. You can upload a photo/PDF instead.",Toast.LENGTH_LONG).show();}
            return;
        }
        if(requestCode==REQ_BT_PRINT){
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED && pendingDirectPrintJson!=null && !pendingDirectPrintJson.isEmpty()){
                String payload=pendingDirectPrintJson; pendingDirectPrintJson=null;
                new Thread(() -> { try{ directThermalPrint80(payload); } catch(Exception e){ runOnUiThread(() -> Toast.makeText(MainActivity.this,"Direct print failed: "+e.getMessage(),Toast.LENGTH_LONG).show()); } }).start();
            } else { pendingDirectPrintJson=null; Toast.makeText(MainActivity.this,"Bluetooth permission is required for direct printing.",Toast.LENGTH_LONG).show(); }
        }
    }

    @Override public void onBackPressed(){
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("window.handleAndroidBack ? window.handleAndroidBack() : false", value -> {
            if (value == null || "false".equals(value.trim()) || "null".equals(value.trim())) super.onBackPressed();
        });
    }
}

