package com.dukaanbill.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONObject;
import org.json.JSONArray;

import java.util.Iterator;

public class LocalDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "dukaanbill.db";
    private static final int DB_VERSION = 1;

    public LocalDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS app_state (state_key TEXT PRIMARY KEY, state_value TEXT NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS meta (meta_key TEXT PRIMARY KEY, meta_value TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    public synchronized String loadState() {
        JSONObject out = new JSONObject();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT state_key,state_value FROM app_state", null)) {
            while (c.moveToNext()) {
                out.put(c.getString(0), c.getString(1));
            }
        } catch (Exception ignored) {}
        return out.toString();
    }

    // Read large WebView state in bounded pieces instead of returning one multi-megabyte bridge value.
    public synchronized String loadStateKeys() throws Exception {
        JSONArray keys = new JSONArray();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT state_key FROM app_state ORDER BY state_key", null)) {
            while (c.moveToNext()) keys.put(c.getString(0));
        }
        return keys.toString();
    }

    public synchronized String loadStateValueChunk(String key, int offset, int maxLength) throws Exception {
        if (key == null || offset < 0 || maxLength < 1 || maxLength > 262144) throw new IllegalArgumentException("Invalid state chunk request");
        // IMPORTANT: slice inside SQLite. Calling getString() on state_value here
        // would materialize the complete multi-megabyte JSON value for every chunk.
        // offset/maxLength are Unicode code-point positions (not UTF-16 code units).
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT substr(state_value, ?, ?) FROM app_state WHERE state_key=?";
        try (Cursor c = db.rawQuery(sql, new String[]{String.valueOf(offset + 1), String.valueOf(maxLength), key})) {
            if (!c.moveToFirst()) return "";
            String chunk = c.getString(0);
            return chunk == null ? "" : chunk;
        }
    }

    // Persist one state key without serializing or rewriting unrelated large transaction arrays.
    // Read compact vendor balances directly from the JSON transaction store.
    // JSON1 is available on supported Android SQLite builds; callers fall back safely
    // to the existing full-state path if this query is unavailable.
    public synchronized String loadVendorSummaryJson() throws Exception {
        SQLiteDatabase db = getReadableDatabase();
        JSONObject out = new JSONObject();
        JSONArray rows = new JSONArray();
        try (Cursor c = db.rawQuery(
                "SELECT json_extract(e.value,'$.vendorId'), " +
                "SUM(COALESCE(CAST(json_extract(e.value,'$.total') AS REAL),0)), " +
                "SUM(COALESCE(CAST(json_extract(e.value,'$.paid') AS REAL),0)), COUNT(*) " +
                "FROM app_state s, json_each(s.state_value) e WHERE s.state_key='pksPurchases' " +
                "GROUP BY json_extract(e.value,'$.vendorId')", null)) {
            while (c.moveToNext()) {
                JSONObject row = new JSONObject();
                row.put("vendorId", c.isNull(0) ? "" : c.getString(0));
                row.put("purchases", c.getDouble(1));
                row.put("purchasePaid", c.getDouble(2));
                row.put("billCount", c.getInt(3));
                rows.put(row);
            }
        }
        JSONArray paymentRows = new JSONArray();
        double paymentTotal = 0;
        try (Cursor c = db.rawQuery(
                "SELECT json_extract(e.value,'$.vendorId'), COALESCE(SUM(CAST(json_extract(e.value,'$.amount') AS REAL)),0) " +
                "FROM app_state s, json_each(s.state_value) e WHERE s.state_key='pksVendorPayments' " +
                "GROUP BY json_extract(e.value,'$.vendorId')", null)) {
            while (c.moveToNext()) { JSONObject row = new JSONObject(); row.put("vendorId", c.isNull(0) ? "" : c.getString(0)); row.put("paid", c.getDouble(1)); paymentTotal += c.getDouble(1); paymentRows.put(row); }
        }
        out.put("supported", true);
        out.put("vendors", rows);
        out.put("paymentsByVendor", paymentRows);
        out.put("vendorPaymentTotal", paymentTotal);
        return out.toString();
    }

    // Return only one purchase-history page. Search includes invoice/vendor metadata
    // and common item identifiers without transferring the full purchase JSON blob.
    public synchronized String loadPurchasePageJson(int offset, int limit, String search) throws Exception {
        if (offset < 0 || limit < 1 || limit > 200) throw new IllegalArgumentException("Invalid purchase page");
        SQLiteDatabase db = getReadableDatabase();
        String q = search == null ? "" : search.trim().toLowerCase();
        String where = "s.state_key='pksPurchases'";
        java.util.ArrayList<String> args = new java.util.ArrayList<>();
        if (!q.isEmpty()) {
            where += " AND (lower(COALESCE(json_extract(e.value,'$.invoiceNo'),'')) LIKE ? " +
                    "OR lower(COALESCE(json_extract(e.value,'$.vendorName'),'')) LIKE ? " +
                    "OR lower(COALESCE(json_extract(e.value,'$.date'),'')) LIKE ? " +
                    "OR lower(COALESCE(json_extract(e.value,'$.id'),'')) LIKE ? " +
                    "OR EXISTS (SELECT 1 FROM json_each(json_extract(e.value,'$.items')) i WHERE " +
                    "lower(COALESCE(json_extract(i.value,'$.name'),'')) LIKE ? OR " +
                    "lower(COALESCE(json_extract(i.value,'$.hsn'),'')) LIKE ? OR " +
                    "lower(COALESCE(json_extract(i.value,'$.barcode'),'')) LIKE ?))";
            String like = "%" + q + "%";
            for (int i=0;i<7;i++) args.add(like);
        }
        String[] bind = args.toArray(new String[0]);
        int count = 0;
        try (Cursor c = db.rawQuery("SELECT COUNT(*) FROM app_state s, json_each(s.state_value) e WHERE " + where, bind)) {
            if (c.moveToFirst()) count = c.getInt(0);
        }
        JSONArray records = new JSONArray();
        java.util.ArrayList<String> pageArgs = new java.util.ArrayList<>(args);
        pageArgs.add(String.valueOf(limit)); pageArgs.add(String.valueOf(offset));
        try (Cursor c = db.rawQuery("SELECT e.value FROM app_state s, json_each(s.state_value) e WHERE " + where +
                " ORDER BY COALESCE(json_extract(e.value,'$.date'),'') DESC, e.key DESC LIMIT ? OFFSET ?", pageArgs.toArray(new String[0]))) {
            while (c.moveToNext()) records.put(new JSONObject(c.getString(0)));
        }
        JSONObject out = new JSONObject(); out.put("supported", true); out.put("total", count); out.put("records", records);
        return out.toString();
    }

    public synchronized void saveStateValue(String key, String value) throws Exception {
        if (key == null || key.trim().isEmpty()) throw new IllegalArgumentException("Invalid state key");
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("state_key", key);
        cv.put("state_value", value == null ? "" : value);
        db.insertWithOnConflict("app_state", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public synchronized void saveState(String json) throws Exception {
        JSONObject obj = new JSONObject(json == null ? "{}" : json);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                ContentValues cv = new ContentValues();
                cv.put("state_key", key);
                cv.put("state_value", obj.optString(key, ""));
                db.insertWithOnConflict("app_state", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }
}
