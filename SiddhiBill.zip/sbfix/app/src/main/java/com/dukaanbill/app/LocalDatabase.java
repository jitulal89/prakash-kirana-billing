package com.dukaanbill.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONObject;
import org.json.JSONArray;

import java.util.Iterator;

public class LocalDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "dukaanbill.db";
    private static final int DB_VERSION = 1;

    public LocalDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS app_state (state_key TEXT PRIMARY KEY, state_value TEXT NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS meta (meta_key TEXT PRIMARY KEY, meta_value TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    public synchronized String loadState() {
        JSONObject out = new JSONObject();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT state_key,state_value FROM app_state", null)) {
            while (c.moveToNext()) {
                out.put(c.getString(0), c.getString(1));
            }
        } catch (Exception ignored) {}
        return out.toString();
    }

    // Read large WebView state in bounded pieces instead of returning one multi-megabyte bridge value.
    public synchronized String loadStateKeys() throws Exception {
        JSONArray keys = new JSONArray();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT state_key FROM app_state ORDER BY state_key", null)) {
            while (c.moveToNext()) keys.put(c.getString(0));
        }
        return keys.toString();
    }

    public synchronized String loadStateValueChunk(String key, int offset, int maxLength) throws Exception {
        if (key == null || offset < 0 || maxLength < 1 || maxLength > 262144) throw new IllegalArgumentException("Invalid state chunk request");
        // IMPORTANT: slice inside SQLite. Calling getString() on state_value here
        // would materialize the complete multi-megabyte JSON value for every chunk.
        // offset/maxLength are Unicode code-point positions (not UTF-16 code units).
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT substr(state_value, ?, ?) FROM app_state WHERE state_key=?";
        try (Cursor c = db.rawQuery(sql, new String[]{String.valueOf(offset + 1), String.valueOf(maxLength), key})) {
            if (!c.moveToFirst()) return "";
            String chunk = c.getString(0);
            return chunk == null ? "" : chunk;
        }
    }

    // Persist one state key without serializing or rewriting unrelated large transaction arrays.
    public synchronized void saveStateValue(String key, String value) throws Exception {
        if (key == null || key.trim().isEmpty()) throw new IllegalArgumentException("Invalid state key");
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("state_key", key);
        cv.put("state_value", value == null ? "" : value);
        db.insertWithOnConflict("app_state", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public synchronized void saveState(String json) throws Exception {
        JSONObject obj = new JSONObject(json == null ? "{}" : json);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                ContentValues cv = new ContentValues();
                cv.put("state_key", key);
                cv.put("state_value", obj.optString(key, ""));
                db.insertWithOnConflict("app_state", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }
}
