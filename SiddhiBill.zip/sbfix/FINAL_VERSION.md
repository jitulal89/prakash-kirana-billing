SiddhiBill v3.60.77
Billing round-off: nearest-rupee calculation; show and apply only when the payable amount changes; include in bill UI, HTML preview, image export, A4/A6 PDF, 58/80mm PDF, and direct 80mm thermal output.
Sync file: WhatsApp and Download options; generic MIME type for Android sharing compatibility.
