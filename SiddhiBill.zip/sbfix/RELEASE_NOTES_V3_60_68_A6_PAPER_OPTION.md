# SiddhiBill v3.60.68 — A6 paper option

- Added **A6 (Quarter A4)** to the saved POS/PDF paper-size setting and the per-bill Print/PDF paper selector.
- A6 produces a portrait PDF page approximately 105 × 148 mm (quarter the area of A4), while retaining the existing bill layout scaled to the selected page.
- A6 selections open the generated PDF flow; 58 mm and 80 mm thermal paths remain unchanged.
- Existing A4 and thermal options are retained.

Validation: JavaScript syntax check, paper-option routing assertions, prior v3.60.67 regression checks, and ZIP integrity check. An Android APK build and visual/physical printer validation are not claimed by these source checks.
