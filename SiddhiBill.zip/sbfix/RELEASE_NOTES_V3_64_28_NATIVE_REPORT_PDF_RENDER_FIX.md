# SiddhiBill v3.64.28 – Native report PDF rendering fix

- Replaced direct WebView-to-Canvas drawing for HTML reports with Android WebView's native `PrintDocumentAdapter` PDF rendering pipeline.
- Kept the original report HTML and JavaScript intact so reports that populate content dynamically can finish rendering before PDF generation.
- Added a short post-load render wait, native A4 PDF layout/write callbacks, temporary-file validation, and explicit render/save error feedback.
- Preserved the existing categorized Downloads/SiddhiBill save flow, duplicate-file confirmation, and Android PDF app chooser.
- Applies to report types that call the shared `printHtmlDocument` bridge, including Customer Ledger, Team Management, Broker, Profit & Loss, and Daily Transactions.

Validation: `node --check app/src/main/assets/www/app.js` passed; `node test_v36416_customer_ledger_item_comments.js` passed; `node test_v36417_profit_loss_report.js` passed; `node test_v36053_owner_terms_reports_printer.js` passed; ZIP integrity checked. Android Gradle build/device PDF rendering were not run because this project snapshot has no Gradle wrapper and no Gradle executable/Android SDK build environment available here.
