# SiddhiBill v3.60.56 — Backup/Restore Picker Fix

## Root cause
Android activity-result request codes collided: backup creation used `9012`, the same as the Quick List image picker; restore used `9013`, the same as the Quick List camera. Android therefore routed backup/restore picker results into image/camera handlers, producing errors such as “Unsupported or unreadable image” and “Camera did not return an image.”

## Fix
- Assigned distinct request codes `9112` (backup save) and `9113` (backup restore).
- Kept Quick List and camera request codes unchanged.
- Bumped app version to 3.60.56 / versionCode 109.

## Validation
JavaScript regression tests and source ZIP integrity checks are run separately. Physical Android backup-save and restore round-trip tests are still required before release.
