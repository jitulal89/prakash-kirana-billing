# SiddhiBill v3.64.44 — Transaction History View Bill Modal Fix

- Fixed the Customer Transaction History **View Bill** action so it dismisses the transaction-history modal before navigating to the existing bill preview page.
- The selected bill continues to open in read-only preview mode; no bill edit mode is entered.
- No transaction, bill, or ledger data is changed by this navigation action.
