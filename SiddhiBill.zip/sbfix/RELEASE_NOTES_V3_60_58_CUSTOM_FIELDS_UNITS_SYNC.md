# SiddhiBill v3.60.58 — Custom Bill Fields and Unit Sync

- PDF bill header layout now reserves space for all configured custom header fields so the item table does not overlap them.
- PDF header/footer position matching is case-insensitive.
- Unit sync payload now includes both `unitCatalog` and legacy `customUnits` arrays for compatibility.
- Sync import accepts either field and merges unit aliases rather than replacing locally configured aliases.
- Version code 111, version name 3.60.58.

Validation: JavaScript syntax and source-level regression tests only. Android build, PDF rendering and physical thermal-printer output still require device verification.
