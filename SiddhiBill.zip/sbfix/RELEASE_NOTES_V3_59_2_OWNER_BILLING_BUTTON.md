# SiddhiBill v3.59.2 — Owner Setup Billing and Activation Button Feedback

- Added a visible “Open Billing & Set Up This Shop” path for a configured Owner device before the shop licence exists.
- Native bridge allows this path only when Owner configuration exists and the Owner PIN is unlocked.
- The Owner Dashboard return button now supports both pre-shop-activation setup and normal activated billing return.
- Activation button selection now uses orange filled feedback instead of only an orange outline; trial/permanent approval options share a consistent unselected style and highlight the chosen option.
- Kept ordinary shop-device access checks and existing data stores unchanged.
- Updated app version to 3.59.2 (versionCode 79).

Validation performed: JavaScript syntax, XML parsing, source archive integrity. Full Gradle build and physical-device tests were not run in this environment.
