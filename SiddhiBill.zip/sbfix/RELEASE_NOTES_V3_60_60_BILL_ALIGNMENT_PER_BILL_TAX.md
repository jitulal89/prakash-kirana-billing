SiddhiBill v3.60.60 — Billing layout and per-bill tax toggle

Changes:
- Added a billing-page checkbox to mark each new/edit bill as tax or non-tax. Existing shop Taxation setting supplies the default for a new bill; the saved bill's taxationEnabled flag controls invoice rendering.
- Tax input visibility follows the billing checkbox; tax fields are hidden for non-tax bills and visible for tax bills.
- Responsive item details use a three-column mobile grid to prevent Rate, Tax, HSN, Amount and Remove controls from overflowing the phone viewport. Amount and remove controls have dedicated grid placement.
- Existing 80mm receipt/PDF render paths consume the saved bill taxationEnabled value and settings payload for GST and custom fields.

Validation:
- app.js passes node --check.
- Android APK build and physical 80mm printer/PDF output have not been run in this environment.
