SiddhiBill v3.60.66 — Tax invoice print regression fixes

Changes
- Added dedicated Address fields to Add Customer and Edit Customer; customer address, GSTIN and state are snapshotted onto generated bills and passed to PDF/thermal print payloads.
- A4 native PDF shop header now respects Print Shop Name/Address/Mobile/Logo settings and includes configured shop GSTIN, FSSAI and Place of Supply for tax invoices.
- 80mm PDF and direct ESC/POS thermal output include configured shop GSTIN, FSSAI and Place of Supply in the shop header, with customer address/GSTIN/state below customer information.
- 80mm PDF item rows now print HSN/SAC below item names, matching direct ESC/POS behavior.
- A4 native PDF adds a GST-rate breakdown table with taxable value and CGST/SGST/IGST by rate; 80mm PDF and direct thermal receipt print taxable/tax breakdown per GST rate.
- Native thermal PDF height allowance increased for HSN, customer fields and tax breakdown.
- Updated Android version metadata to 3.60.66 / versionCode 112.

Validation
- JavaScript syntax check passed.
- Targeted regression checks passed: v3.60.66 tax/print, v3.60.60 billing tax/layout, FSSAI output, custom billing fields, Quick List HSN, units/custom-fields sync, and backup/printer selection.
- ZIP integrity check will be performed after packaging.
- Android Gradle/APK build and device-level PDF/physical printer tests were not run in this environment.
