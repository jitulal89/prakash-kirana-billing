# SiddhiBill v3.60.83 — One-tap incoming sync import

- Registered `.siddhisync` files for Android VIEW intents when shared/opened from WhatsApp or a file manager.
- When a valid sync file is opened, SiddhiBill reads it and asks the user to confirm Import or Cancel.
- Import confirmation calls the existing merge logic directly; users no longer need to navigate to More → Backup & Restore → Import Sync File.
- Kept same-shop validation and preservation of device-local logo, printer and activation settings.
- Increased incoming file limit to 30 MB for larger sync payloads.
- Version 3.60.83 (versionCode 124).
