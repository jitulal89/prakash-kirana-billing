# SiddhiBill v3.60.74 — GST table side-by-side layout and 80mm spacing

- A4 HTML bill preview now places the GST-rate table in the left-side whitespace beside the subtotal/totals column.
- GST table is left-aligned and constrained to the left 58% of the available summary width; subtotal, tax totals and total amount remain right aligned in the right column.
- 80mm PDF GST detail labels have clearer spacing between GST rate, taxable amount and GST amount.
- Direct ESC/POS thermal print separates GST detail labels with clearer spacing and an additional line gap between tax-rate groups.
- Preserved the existing native A4 GST table layout, customer details and printing behavior.

Validation: JavaScript syntax and source-level regression checks; Android APK build and physical printer tests not run locally.
