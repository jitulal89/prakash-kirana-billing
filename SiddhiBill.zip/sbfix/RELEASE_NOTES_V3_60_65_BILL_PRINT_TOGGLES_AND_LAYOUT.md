SiddhiBill v3.60.65

- Added per-field print toggles for shop name, address, mobile number and logo. Defaults preserve existing printing.
- Bill edit conversion now replaces the previous bill record and assigns a bill number from the correct tax/non-tax sequence when switching bill type.
- Reworked mobile item-entry CSS with explicit grid areas so non-tax rows retain a stable Qty / Unit / Rate / Amount / Delete layout and tax/HSN appear below only for tax bills.

Validation: JavaScript syntax check and ZIP integrity check. Device/PDF/printer end-to-end testing still required.
