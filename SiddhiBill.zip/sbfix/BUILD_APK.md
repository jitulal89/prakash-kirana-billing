SiddhiBill v3.60.77
Build workflow: .github/workflows/build-apk.yml
The APK was not locally compiled because Gradle and the Android SDK are unavailable in this workspace. Commit/push this source package to the GitHub repository and run the Build APK workflow. Install the resulting APK and validate: round-off calculation/display in billing; PDF and thermal output for exact, round-down and round-up totals; WhatsApp sync sharing, Download/Save As, and import on a second phone.
