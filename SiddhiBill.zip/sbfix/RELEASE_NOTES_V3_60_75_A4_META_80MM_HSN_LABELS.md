# SiddhiBill v3.60.75 — A4 Customer Spacing and 80mm HSN Labels

- A4 GST rate table uses the left-side whitespace beside totals without pushing the totals column beyond the printable width.
- Native A4 PDF places customer mobile on the right side of the same row as customer name, directly below invoice date.
- Customer GSTIN, FSSAI, address, and state now begin below the customer/mobile row; address wrapping uses consistent vertical spacing to prevent overlap.
- Image-based A4 bill output also aligns customer mobile with the customer-name row and wraps long customer detail lines.
- 80mm tax PDF and direct thermal output show the heading `Item name - HSN/SAC` once; item rows show `Chana - 12345677` without repeating `HSN/SAC:`.
- 80mm tax totals label reads `Total GST`.
- Version: 3.60.75 (versionCode 116).

## Validation

- `node --check app/src/main/assets/www/app.js`: passed.
- Targeted regression tests for A4 GST layout, 80mm item/HSN formatting, customer-address tax-only behavior, tax-print output, and custom fields/navigation: passed.
- ZIP integrity: checked after packaging.
- Android Gradle build and physical printer test: not run in this environment.
