const fs = require('fs');
const s = fs.readFileSync('app/src/main/assets/www/app.js', 'utf8');
const start = s.indexOf('list.querySelectorAll(".view-transaction-bill")');
if (start < 0) throw new Error('View Bill handler not found');
const end = s.indexOf('list.querySelectorAll(".edit-customer-payment")', start);
const handler = s.slice(start, end);
if (!handler.includes('transactionHistoryModal')) throw new Error('Transaction history modal is not dismissed');
if (!handler.includes('.classList.add("hidden")')) throw new Error('Modal hide action missing');
if (!handler.includes('renderBill(b);showPage("preview")')) throw new Error('Existing preview navigation changed');
console.log('PASS: View Bill dismisses transaction history modal before opening preview');

