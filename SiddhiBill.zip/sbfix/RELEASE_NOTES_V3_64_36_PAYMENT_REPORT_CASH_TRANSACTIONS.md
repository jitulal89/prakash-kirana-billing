# SiddhiBill v3.64.36 — Include Cash Transactions in Payment Transactions Report

- Added cash sales from `state.bills` as customer cash receipts (Credit column).
- Added cash-paid vendor purchase invoices from `state.purchases` as cash outflows (Debit column).
- Added cash expenses from `state.expenses` as cash outflows (Debit column).
- Existing customer payment receipts and vendor payment records remain included.
- Credit sales are not added as full cash receipts; their actual partial/subsequent receipts remain sourced from `customerPayments`, preventing double counting.
- Uses transaction dates and selected report date range.
- CSV and PDF exports use the same consolidated row source as the on-screen report.
- JavaScript syntax and existing report-related regression tests passed. Android build/device validation not run.
