# SiddhiBill v3.60.63 — Tax print and layout regression fix

- Reworked mobile taxable item-entry layout: Qty, Unit, Rate, Amount and Delete share the first row; Tax and HSN/SAC move to a second row. Non-tax layout remains unchanged.
- Tax invoice creation now requires a customer name (Walk-in Customer is rejected for a tax invoice).
- Snapshots customer address from a matched customer record onto the bill so print output can show it.
- Added a per-bill "Item rates are inclusive of GST" control. Existing bills default to inclusive to preserve legacy calculations. Exclusive mode adds calculated GST to bill total.
- Updated browser and native PDF tax summary calculations to honor the inclusive/exclusive flag.
- Native PDF reads HSN/SAC from either `hsn` or `hsnCode`; customer address and customer GSTIN are included when available.
- Product action buttons are kept horizontally aligned on mobile.

Validation: `node --check app/src/main/assets/www/app.js` and the v3.60.60 billing tax/layout regression test pass. APK build, generated A4/80mm PDF visual inspection, and physical printer validation remain outstanding.
