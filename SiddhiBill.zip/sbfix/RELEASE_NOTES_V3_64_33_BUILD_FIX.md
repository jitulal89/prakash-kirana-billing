# SiddhiBill v3.64.33 — Android build fix

- Fixed the unresolved `Context` symbol in the native A4 PDF print flow.
- Uses the fully qualified `android.content.Context.PRINT_SERVICE` constant through `MainActivity.this`.
- No report data, billing logic, database, or OCR behavior changed.
- Native Android print flow remains: report HTML -> Android PrintManager -> A4 PDF print screen -> Save as PDF.
- ZIP integrity checked. Android Gradle build and on-device PDF output still require GitHub Actions/device validation.
