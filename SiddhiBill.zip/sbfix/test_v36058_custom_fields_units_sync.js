const fs=require('fs');const path=require('path');const root=__dirname;const js=fs.readFileSync(path.join(root,'app/src/main/assets/www/app.js'),'utf8');const java=fs.readFileSync(path.join(root,'app/src/main/java/com/dukaanbill/app/MainActivity.java'),'utf8');
function ok(v,m){if(!v)throw new Error(m)}
ok(js.includes('unitCatalog:units,customUnits:units'),'sync bundle must include unitCatalog and legacy customUnits');
ok(js.includes("(Array.isArray(b.data.unitCatalog)&&b.data.unitCatalog.length)?b.data.unitCatalog:(Array.isArray(b.data.customUnits)?b.data.customUnits:[])"),'sync import must prefer non-empty current units and fall back to legacy unit arrays');
ok(js.includes('prior.aliases=[...new Set([...prior.aliases,...aliases])]'),'sync import must merge aliases without losing local aliases');
ok(java.includes('int customHeaderY=detailsBottom+16') && java.includes('int baseTableY = Math.max(detailsBottom+20,customHeaderY+8)'),'PDF reserves space for customer and custom header fields');
ok(java.includes('"header".equalsIgnoreCase(pos)'),'PDF header placement is case-insensitive');
ok(java.includes('pos=cfg.optString(posKeys[i],i==2?"footer":"header").trim().toLowerCase(Locale.US)') && java.includes('"footer".equals(pos)'),'PDF footer placement normalizes position case');
ok(java.includes('"footer".equals(pos)') && java.includes('wrapPlain(label+": "+value,48)'),'thermal receipt prints footer fields');
console.log('v3.60.58 custom fields and units sync checks passed');
