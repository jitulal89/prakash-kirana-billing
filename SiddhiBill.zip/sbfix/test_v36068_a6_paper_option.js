const fs=require('fs');
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const app=fs.readFileSync('app/src/main/assets/www/app.js','utf8');
const java=fs.readFileSync('app/src/main/java/com/dukaanbill/app/MainActivity.java','utf8');
const checks=[
 ['A6 option in settings',html.includes('<option value="A6">A6 (Quarter A4)</option>') && html.includes('id="setPaperSize"')],
 ['A6 option in print selector',html.includes('id="printPaperSize"') && (html.match(/<option value="A6">A6 \(Quarter A4\)<\/option>/g)||[]).length===2],
 ['saved A6 choice restored',app.includes('"a6":"A6"')],
 ['A6 routed to PDF output',app.includes('(paper==="a4" || paper==="a6") && window.Android?.openBillPdf')],
 ['A6 uses quarter-size PDF page',java.includes('boolean a6Paper = cfg != null && "A6".equalsIgnoreCase') && java.includes('int outputPageWidth = a6Paper ? 298 : pageWidth') && java.includes('int outputPageHeight = a6Paper ? 421 : pageHeight')],
 ['A6 canvas scaled on new pages',(java.match(/if \(a6Paper\) canvas\.scale\(0\.5f, 0\.5f\);/g)||[]).length===3],
 ['thermal routing unchanged',app.includes('paper==="80mm" && window.Android?.directThermalPrint80')]
]; let failed=0; for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${name}`); if(!ok)failed++;} if(failed)process.exit(1);
