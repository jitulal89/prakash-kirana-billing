const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, 'app');
const main = fs.readFileSync(path.join(root, 'src/main/java/com/dukaanbill/app/MainActivity.java'), 'utf8');
const provider = fs.readFileSync(path.join(root, 'src/main/java/com/dukaanbill/app/ShareFileProvider.java'), 'utf8');
const manifest = fs.readFileSync(path.join(root, 'src/main/AndroidManifest.xml'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'build.gradle'), 'utf8');
function ok(cond, msg) { if (!cond) throw new Error(msg); }
ok(main.includes('send.setType("application/octet-stream")'), 'sync share uses WhatsApp-compatible generic MIME');
ok(main.includes('new String[]{"WhatsApp", "Download"}'), 'sync share offers WhatsApp and Download choices');
ok(main.includes('incomingType.equals("application/vnd.siddhibill.sync")'), 'sync MIME accepted on incoming share');
ok(provider.includes('"siddhisync".equalsIgnoreCase(ext)) return "application/octet-stream"'), 'provider returns generic sync MIME');
ok((manifest.match(/application\/vnd\.siddhibill\.sync/g)||[]).length >= 2, 'manifest accepts sync MIME for incoming VIEW/SEND');
ok(gradle.includes("versionName '3.60.77'"), 'version bumped');
console.log('Current sync share MIME and WhatsApp/Download chooser regression checks passed');
