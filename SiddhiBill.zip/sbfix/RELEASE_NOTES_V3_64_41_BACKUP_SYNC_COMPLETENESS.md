# SiddhiBill v3.64.41 — Backup and Sync Completeness

## Manual Create Backup
- Module snapshot is generated dynamically from every persisted app-state key, not a manually maintained list.
- Manifest records actual SQLite table names and all saved state keys.
- The finished ZIP is reopened and checked for required database, state, settings, manifest and module snapshot entries.
- Snapshot key count is checked against the complete saved app state.
- The full SQLite database remains the authoritative source and includes all physical tables.

## Automatic Backup
- Module snapshot includes every saved app-state key, including expenses and GST compliance.
- Manifest records the complete state-key list and actual SQLite table names.
- Source SQLite database is checked with PRAGMA integrity_check before upload.
- Completed ZIP is checked for required entries before upload.
- Purchase invoice attachments continue to be included.

## Phone-to-phone Sync
- GST compliance period records are exported and merged.
- Expenses remain included in both export and import.
- Purchase invoice attachments are now embedded in the native Android sync file and restored into the receiving phone's purchase_docs folder.
- Sender settings are no longer merged into the receiving phone. Local shop identity, logo, printer configuration, activation and other local settings remain untouched.
- Unit catalog and OCR product aliases continue to merge.

## Validation
- JavaScript syntax and backup/sync regression tests pass.
- Android Gradle compilation and physical-device backup, restore and two-phone sync verification are still required.
