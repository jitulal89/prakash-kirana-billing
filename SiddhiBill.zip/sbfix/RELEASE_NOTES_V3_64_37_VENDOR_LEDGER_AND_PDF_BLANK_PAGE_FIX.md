# SiddhiBill v3.64.37 — Vendor Ledger and PDF Blank-Page Fix

## PDF rendering
- Added per-page rendered-content detection to the direct A4 PDF renderer.
- Empty trailing WebView pages are omitted rather than written into the PDF.
- Populated pages are numbered sequentially.
- Intended to address extra blank pages in Team Member, Attendance and Ledger reports while preserving populated pages.

## Vendor Ledger
- Added Vendor Ledger section to Business Reports.
- Vendor selector is populated from the saved vendor master.
- Date-range filtered purchase invoices, invoice items and separate vendor payment records.
- Shows purchase totals, invoice-paid amounts, pending invoice amounts, separate payments and vendor opening balance.
- Generates a portrait A4 PDF through the existing direct-download bridge and routes the file to Downloads/SiddhiBill/Vendor-Ledger.

## Validation
- JavaScript syntax and regression tests run locally.
- Android Gradle build and PDF output on device still require GitHub Actions/device verification.
