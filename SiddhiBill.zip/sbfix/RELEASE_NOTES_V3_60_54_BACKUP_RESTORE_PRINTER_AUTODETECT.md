# SiddhiBill v3.60.54 — Backup/Restore Safety and Generic Printer Selection

## Backup changes
- Backups continue to include the entire SQLite database file, not a hand-maintained subset of business tables. The current database schema contains `app_state` and `meta`; the ZIP now includes a manifest that enumerates actual non-internal SQLite tables dynamically.
- Run `PRAGMA wal_checkpoint(FULL)` and require a non-busy result before snapshotting the DB.
- Validate SQLite `integrity_check` and required tables before writing the database into the ZIP.
- Include app state, protected shop identity metadata, Owner Dashboard shop/device registry, and all saved purchase invoice attachment files.

## Restore changes
- Validate the extracted SQLite database and settings JSON before modifying the live database.
- Copy the restored database to a staging file and validate it before replacement.
- Rename the existing database to a rollback file before installing the restored DB. If installation or post-install validation fails, restore the previous database.
- Keep backward compatibility with earlier backup ZIPs that contain the expected database entry and omit the newer manifest.

## Printer changes
- Printer dropdowns in Settings and Owner shop setup are now populated from Android's paired Bluetooth device list instead of hard-coded printer models.
- Users can select any paired printer by its advertised Bluetooth name, or choose Auto Detect.
- Auto Detect chooses an available paired Bluetooth device instead of relying on a KPC-specific model check.
- This uses the existing Bluetooth Classic SPP / ESC-POS print pipeline. BLE-only printers and printers that do not accept ESC/POS over SPP may still require a different protocol/driver.

## Verification
- 26 JavaScript regression test files passed.
- `app.js` and the activation page inline JavaScript passed Node syntax checks.
- Source ZIP integrity passed.
- APK build/physical Android test not performed because no Gradle wrapper or system Gradle is available in this environment.
