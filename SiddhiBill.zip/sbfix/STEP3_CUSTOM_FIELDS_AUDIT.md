# Step 3 audit — configurable billing fields

## Implemented
- Two configurable text fields and one configurable date field.
- Configurable label per field.
- Per-field print placement: header, footer, or hidden.
- Per-bill values stored in `bill.customFields`.
- Values restored when an existing bill is edited.
- HTML preview, canvas bill image, native ESC/POS thermal output, and native PDF output render fields according to placement.
- Older bills without `customFields` remain valid.

## Test status
- Automated JavaScript test suite: passed.
- JS syntax: passed.
- ZIP integrity: passed.
- Android APK build/install and visual device checks: not performed.
