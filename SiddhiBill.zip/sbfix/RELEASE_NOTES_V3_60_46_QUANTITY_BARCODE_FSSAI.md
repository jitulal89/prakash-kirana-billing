# SiddhiBill v3.60.46 — Quantity Priority, Product Barcode and FSSAI

## Changes
- Purchase OCR now prefers an explicit Quantity/Qty column. It uses the row's numeric EA/UoM count only when the quantity is exactly `1 Case`/`1 Box`, or when no Quantity/Qty column exists. Removed the previous whole-bill numeric-UOM override from the invoice-specific parser.
- `EA`/`Each` normalize to `Piece` in generic purchase column parsing.
- Product setup now has a Barcode field; barcode is retained while editing, searchable in Product Master, accepted in Product CSV imports, and copied from purchase lines to Product Master when the product has no barcode yet.
- Shop settings and Vendor setup now include optional FSSAI number fields.
- Shop FSSAI prints on taxable sales bills/PDFs; shop and vendor FSSAI print on taxable purchase PDFs. Non-taxable bills omit FSSAI.
- Added regression coverage for Quantity vs EA/UoM, `1 Case` fallback, missing Quantity column, barcode field, and FSSAI output hooks.

## Validation
- `node --check app/src/main/assets/www/app.js` passed.
- 19 JavaScript test files passed, including the attached supplier invoice regression and updated quantity expectations.
- ZIP integrity checked after packaging.
- Android APK build/install and physical device PDF/thermal printing were not run in this environment.
