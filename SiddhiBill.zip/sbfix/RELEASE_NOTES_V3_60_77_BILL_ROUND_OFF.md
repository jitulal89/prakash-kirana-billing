# SiddhiBill v3.60.77 — Billing Round-Off

## Behaviour
- Billing calculates the pre-rounding payable amount after discount and, for exclusive-tax bills, applicable GST.
- Final payable amount is rounded to the nearest whole rupee using standard half-up rounding.
- Round-off is the signed difference between the calculated amount and rounded payable amount.
- Round-off is shown/applied only when the difference is at least ₹0.01; bills already at a whole-rupee total do not show a Round Off row.
- The saved bill stores `calculatedTotal`, `roundOff`, and rounded `total`, so sales reports and customer balances use the actual payable amount.

## Coverage
1. Billing totals UI (`getBillTotals` and `calc`) — shows conditional Round Off row and rounded Total Amount.
2. Saved bill payload — stores pre-rounding total, signed round-off and final payable total.
3. Bill preview / A4 and A6 HTML PDF — conditional Round Off row before Total Amount.
4. Canvas bill image export — conditional Round Off row and rounded total.
5. Native A4/A6 PDF (`MainActivity.createPdf`) — conditional Round Off row before Total Amount.
6. Native 80mm/58mm PDF (`createThermalPdfBytes`) — conditional Round Off row before TOTAL.
7. Direct 80mm ESC/POS thermal printing — conditional Round Off row before TOTAL.
8. Existing saved bills without a `roundOff` field are not retroactively recalculated; they retain their saved total until edited and saved again.

## Validation
- JavaScript syntax check passed.
- Round-off regression test passed for exact total, round down, round up and half-rupee cases.
- Relevant existing regression checks passed for FSSAI output, tax-only customer address and custom bill fields.
- A prior GST layout test contains stale version metadata and was updated to the current release metadata. One unrelated purchase full-cycle test could not run because its referenced sample PDF is absent from the package.
- Android APK compilation and physical printer/PDF viewer tests were not run in this environment.
