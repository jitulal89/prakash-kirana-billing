# SiddhiBill v3.60.79 — Customer/Vendor Transactions and Payment Reports

## Changes
- Customer payment entry captures a payment date (defaults to today).
- Customer and vendor cards have a Transactions action.
- Transaction history has date filters, 20-row pagination, references, debit/credit values and a running balance.
- Reports include customer receipts and vendor payments filtered by the Reports date range, with credit/debit/net totals.
- Export Excel downloads a CSV that opens in Excel and other spreadsheet apps.
- Export PDF opens a print-ready report with transaction rows and totals; use the print dialog's Save as PDF option.
- Print dialog includes an opt-in checkbox for the last five customer transactions. The chosen rows are passed to the PDF and direct thermal print renderers.

## Validation
- `node --check app/src/main/assets/www/app.js` passed.
- `node test_v36079_customer_vendor_payments_reports.js` passed.
- Updated the existing v3.60.78 regression test's expected app version to v3.60.79; that test passed.
- Android Gradle build was not run because Gradle/Gradle wrapper is unavailable in this environment. Please build the APK in GitHub Actions before production use.
