SiddhiBill v3.60.41 — Purchase amount tax mode

Added a bill-level "Item amounts entered" selector to Purchase Bill Entry:
- Inclusive of GST (default): entered Quick List/item amount is treated as the line total including GST; taxable amount is calculated by removing GST from that amount.
- Exclusive of GST: entered Quick List/item amount is treated as the taxable amount; GST is calculated from the selected tax rate and added to the line total.
- Mode applies to all item rows in the bill; it is not selected per item.
- Mode is saved with the purchase and restored when editing an existing purchase.
- Item editor labels and calculation summary reflect the selected mode.
- Switching mode invalidates preserved OCR taxable amount hints so calculations follow the selected mode.

Validation performed:
- JavaScript syntax check passed.
- Existing purchase/OCR regression tests passed, including all 13 rows from the sample invoice.
- New tax-mode tests passed: 236 inclusive at 18% => taxable 200 + GST 36; 200 exclusive at 18% => total 236; no-tax exclusive amounts unchanged.
- ZIP integrity check performed after packaging.

No APK was built or installed; validation is source-level only.
