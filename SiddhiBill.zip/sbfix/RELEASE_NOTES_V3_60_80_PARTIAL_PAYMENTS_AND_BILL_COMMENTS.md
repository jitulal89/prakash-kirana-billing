# SiddhiBill v3.60.80 — Partial Payments, Transaction History and Bill Comments

## Changes
- Moved the last-five-customer-transactions option to the Billing page and synchronize it with the print dialog. The selected customer transaction list is prepared before preview and output.
- Added a partial-payment amount for Credit bills. Validates that payment does not exceed the bill total and requires a named customer.
- Links partial payments to the bill in customer payment records, so customer balance/history/report calculations include the receipt. Editing a bill replaces its previous linked partial-payment record instead of duplicating it.
- Added an optional per-item comment field below item tax/HSN inputs. Added an overall bill comment below totals and independent checkboxes controlling whether item comments and overall comment print.
- Included comments and paid/balance-due lines in HTML bill preview, native receipt PDF, A4 PDF and direct thermal output.
- Version code 121, version name 3.60.80.

## Validation
- `node --check app/src/main/assets/www/app.js`: passed.
- `test_v36080_credit_partial_item_comments_last5.js`: passed.
- `test_v36079_customer_vendor_payments_reports.js`: passed.
- `test_v36078_pdf_payment_followup_report.js`: passed.
- Android Gradle build and physical printer validation were not performed in this environment.
