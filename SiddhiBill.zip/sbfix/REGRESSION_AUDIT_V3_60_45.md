# SiddhiBill v3.60.45 — Regression Audit Status

| Area | Status | Evidence / limitation |
|---|---|---|
| Quick List OCR parsing | PASS | Existing JavaScript tests plus shared alias test |
| Purchase OCR parsing | PASS (source tests) | Attached supplier PDF text extraction; 13 rows; invoice totals reconcile |
| Harpic Original 10th row | PASS (source regression) | ₹2,446.42 line total; 18% GST |
| Each/EA to Piece | PASS (source tests) | Quick List and Purchase OCR output |
| Confirmed alias with promotional suffix | PASS (new regression) | `HARPC ORG 500ML+20%EXTRA FR` corrected while suffix remains |
| Product Master unit/GST/HSN fallback | PASS (new regression) | Confirmed alias with missing fields recovers master metadata |
| Ambiguous near-tie | PASS (new regression) | Equal-confidence product variants are not selected |
| Purchase tax and totals | PASS | Inclusive/exclusive, taxable/non-taxable and total regressions |
| Vendor OCR review | PASS (source tests) | Editable review before vendor creation |
| Purchase item UI/PDF source structure | PASS (static/source tests only) | Existing source checks; not visually rendered on Android |
| Save retains purchase entry | PASS (source assertion only) | Save handler retains editor and provides explicit New Purchase action |
| Activation / owner access / trial | NOT RE-AUDITED in this release | Requires dedicated behavior regression pass |
| Backup / restore / two-device sync | NOT RE-AUDITED in this release | Requires data migration and two-device behavior tests |
| CSV imports | NOT RE-AUDITED in this release | Requires file-based import tests |
| WhatsApp / Bluetooth / thermal / A4 printing | NOT DEVICE-TESTED | Requires physical Android device and printers/share targets |
| Android APK build/install | NOT TESTED | No Gradle wrapper or system Gradle in this environment |

## Test execution

All 18 `test*.js` files in this source archive passed after the changes. `node --check app/src/main/assets/www/app.js` passed. ZIP integrity was checked after packaging.
