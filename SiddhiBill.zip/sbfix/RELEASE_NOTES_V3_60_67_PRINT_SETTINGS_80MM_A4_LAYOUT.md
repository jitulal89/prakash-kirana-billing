SiddhiBill v3.60.67 — Print Settings, 80mm and A4 Layout Fixes

- Clearly label the existing FSSAI Number / Licence Details field in Settings; persistence continues to use setFssai/state.settings.fssai.
- 80mm/native receipt: omit Place of Supply, keep item name and HSN/SAC on the same line, and print compact left-aligned rate-wise GST taxable/tax rows before Subtotal.
- A4/HTML bill: shop GSTIN, FSSAI and state are grouped in the header; customer GSTIN/address remain compact under customer information; rate-wise GST table is compact and precedes the thank-you message.
- Explicit right alignment for amount cells in item and totals tables.
- Print settings checkboxes and labels use a one-line flex layout on mobile.

Validation: source syntax and ZIP integrity checked. Android Gradle build and visual/physical printer validation are not claimed.
