const fs = require('fs');
const path = require('path');
const vm = require('vm');
const source = fs.readFileSync(path.join(__dirname, 'app/src/main/assets/www/app.js'), 'utf8');
const html = fs.readFileSync(path.join(__dirname, 'app/src/main/assets/www/index.html'), 'utf8');
function extract(name, nextName) {
  const start = source.indexOf(`function ${name}(`);
  const end = source.indexOf(`function ${nextName}(`, start + 1);
  if (start < 0 || end < 0) throw new Error(`Cannot extract ${name}`);
  return source.slice(start, end);
}
if (!html.includes('id="serviceDueReportCard"') || !html.includes('id="serviceDueReportList"') || !html.includes('id="serviceDueRefreshBtn"')) throw new Error('Service due report UI missing');
const rowsFn = extract('serviceDueReportRows', 'serviceDueWhatsAppUrl');
const urlFn = extract('serviceDueWhatsAppUrl', 'renderServiceDueReport');
const context = {
  state: {
    settings: { shopName: 'Siddhi Service Centre', customBillField1Label: 'Current Kilometres', customBillField2Label: 'Vehicle Number', customBillField3Label: 'Next Service Due Date' },
    customers: [{ name: 'Asha Patil', phone: '9876543210' }],
    bills: [
      { billNo: 'B100', customer: 'Asha Patil', customerPhone: '', customFields: { field1: '12500', field2: 'MH31AB1234', field3: '2026-10-20' } },
      { billNo: 'B101', customer: 'Asha Patil', customerPhone: '', customFields: { field3: '2026-10-25' } },
      { billNo: 'B102', customer: 'Asha Patil', customFields: { field3: '2026-10-18' } },
      { billNo: 'B103', customer: 'Walk-in Customer', customFields: { field3: '2026-10-20' } },
      { billNo: 'B104', customer: 'Asha Patil', customFields: { field3: '2026-11-01' } }
    ]
  },
  customBillFieldDefinitions() { return [
    { key: 'field1', label: 'Current Kilometres', position: 'header', type: 'text' },
    { key: 'field2', label: 'Vehicle Number', position: 'header', type: 'text' },
    { key: 'field3', label: 'Next Service Due Date', position: 'footer', type: 'date' }
  ]; },
  getCustomerRecords() { return context.state.customers; },
  normalizePhone(phone) { let p = String(phone || '').replace(/\D/g, ''); if (p.startsWith('0091') && p.length === 14) p = p.slice(4); else if (p.startsWith('91') && p.length === 12) p = p.slice(2); return p; },
  encodeURIComponent
};
vm.createContext(context);
vm.runInContext(rowsFn + '\n' + urlFn, context);
const rows = vm.runInContext('serviceDueReportRows(new Date(2026, 9, 17))', context);
if (rows.length !== 2) throw new Error(`Expected 2 upcoming named-customer service rows, got ${rows.length}`);
if (!rows.some(r => r.billNo === 'B100' && r.vehicle === '12500' && r.phone === '9876543210') || rows.some(r => r.billNo === 'B101')) throw new Error('Service row fields or customer phone fallback failed');
const url = vm.runInContext("serviceDueWhatsAppUrl(serviceDueReportRows(new Date(2026, 9, 17)).find(r => r.billNo === 'B100'))", context);
if (!url.startsWith('https://wa.me/919876543210?text=') || !decodeURIComponent(url).includes('Current Kilometres: 12500')) throw new Error('WhatsApp URL/message incorrect');
console.log('Service due report regression passed (7-day range, customer matching, mobile fallback, WhatsApp URL).');
