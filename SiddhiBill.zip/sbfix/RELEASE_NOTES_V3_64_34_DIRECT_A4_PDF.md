# SiddhiBill v3.64.34 — Direct A4 Portrait PDF Downloads

- All HTML report PDFs now render as A4 Portrait.
- Removed Android PrintManager/print-app chooser from report export.
- Generates a multi-page PDF in-app with Android PdfDocument by drawing the loaded report HTML at A4 page dimensions.
- Applies print CSS to hide report controls, fit tables to portrait width, wrap long cell values, and use compact table typography.
- Sends generated PDF bytes to the existing SiddhiBill save routine, preserving report-specific Downloads/SiddhiBill folders and duplicate replacement prompt.
- Android build and device output still require GitHub Actions and phone validation.
