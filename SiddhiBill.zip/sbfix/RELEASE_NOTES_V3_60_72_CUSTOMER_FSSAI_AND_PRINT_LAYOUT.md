# SiddhiBill v3.60.72 — Customer FSSAI and print-layout correction

## Implemented
- Added optional FSSAI Number / Licence Details fields to both Add Customer and Edit Customer. The value is retained on the customer record and snapshotted onto a saved bill. It is printed only on tax invoices.
- Removed the separate Place of Supply line from 80mm PDF and direct thermal receipt output; A4 tax invoices retain shop State / Place of Supply in the header.
- Combined item name and HSN/SAC on the same 80mm item line when it fits; longer labels wrap only when required by the printable width.
- Moved rate-wise GST taxable/tax details before Subtotal and left-aligned them in 80mm PDF and direct thermal output.
- Forced Settings checkbox labels to remain inline with their checkboxes.
- Tightened A4 customer metadata spacing by placing customer GSTIN/FSSAI/address/state rows immediately after mobile details.
- A4 item amount header and amount values are right-aligned at the same column edge.
- A4 GST rate table uses compact typography and right-aligned numeric columns; footer starts below the GST table and total to avoid overlap.
- Version metadata updated to 3.60.72 / versionCode 113.

## Validation
- JavaScript syntax check: expected to pass (`node --check`).
- Added source regression test `test_v36072_customer_fssai_and_print_layout.js`.
- Updated older print regression assertions to reflect the active output paths.
- Android APK build and physical A4/80mm thermal printer tests are not claimed by this source package.
