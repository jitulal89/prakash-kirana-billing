# SiddhiBill v3.64.40 — Quick List Quantity / Unit / Rate Parsing Fix

## Fixed
- Correctly parses `Plastic Glass 100 piece 5` as item `Plastic Glass`, quantity `100`, unit `piece`, rate per unit `5`.
- Prevents the final price from being consumed as a bare GST percentage.
- Retains support for the optional explicit GST suffix, e.g. `Plastic Glass 100 piece 5 18%`.
- The parser returns the structured values before the name-only fallback, allowing the existing Add List flow to calculate the line amount correctly.

## Validation
- Runtime parser regression checks passed for the exact user example and the optional GST format.
- Existing app regression tests should be rerun; Android Gradle build and device verification remain pending.
