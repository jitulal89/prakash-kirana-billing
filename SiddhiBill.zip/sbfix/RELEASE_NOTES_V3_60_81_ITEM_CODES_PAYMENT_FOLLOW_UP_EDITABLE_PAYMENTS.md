# SiddhiBill v3.60.81

- Added optional unique Item Code in Product Setup. Billing product search matches item name or item code; bill item description can print `ItemCode - ItemName` when enabled in Settings.
- Added Next Payment Follow-up Date to the bill print/PDF customer details dialog and stored it on the bill. A dedicated Next Payment Follow-up report combines qualifying bill follow-ups and dates saved on customer receipts.
- Added optional Next Follow-up Date to customer payment entry.
- Added Edit Payment action to customer transaction history; editing preserves the payment record ID and updates amount/date/follow-up date.

Validation: JavaScript syntax and ZIP integrity checks performed. Android APK build and physical printer testing remain to be run.
