# SiddhiBill v3.60.69 — Customer Address Tax-Only Print Fix

- Customer billing address is now printed only for tax bills (GST invoices).
- Fixed the image/canvas bill output path, which previously printed a saved customer address on non-tax bills.
- Fixed native A4 PDF output, which previously printed the customer address on non-tax bills.
- Preserved customer address storage and tax-invoice output.
- Added `test_customer_address_tax_only_regression.js` to guard HTML preview, image/PDF output, native thermal output, and A4 PDF behavior.

Validation: source-level regression checks passed. APK build and physical printer validation are not claimed by this source package.
