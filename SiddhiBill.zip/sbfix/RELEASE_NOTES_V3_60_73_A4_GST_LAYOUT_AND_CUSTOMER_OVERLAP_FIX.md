# SiddhiBill v3.60.73 — A4 GST Table Placement and Customer Detail Spacing

## Changes
- Fixed A4 customer metadata vertical flow: customer GSTIN/FSSAI/address/state now start below the mobile row instead of at a baseline that overlapped it.
- Customer address now wraps to multiple lines when needed and advances the following fields and items table accordingly.
- Moved the A4 rate-wise GST table to the left side of the totals section, with its right edge ending before the item Rate column alignment (x=355).
- Kept Subtotal, discount, taxable value, CGST/SGST or IGST, Total GST, and Total Amount in a separate right-aligned column.
- Reserved vertical space based on both the GST table and totals before drawing footer content.
- Preserved tax-invoice-only customer details and existing 80mm HSN/FSSAI paths.
- Version updated to 3.60.73 / versionCode 114.

## Validation
- Run `node --check app/src/main/assets/www/app.js`.
- Run all `test_v360*.js` source regression tests.
- Check ZIP integrity with `unzip -t`.
- Android Gradle build and physical A4/80mm printing still require execution in an Android build environment and on the target printer; not claimed here.
