# SiddhiBill v3.64.39 — Customer Sorting and Transaction Bill View

- Added seven Customer List sorting modes: A to Z, Z to A, pending low-to-high, pending high-to-low, latest bill, total sales low-to-high, total sales high-to-low.
- Latest Bill sorting puts customers with no bills at the bottom.
- Sorting is applied to the full filtered customer set before pagination; search and pagination continue to work.
- Added View Bill action to Customer Transaction History for bill-linked transactions. Opens the saved bill in the existing preview screen without entering edit mode.
- Existing customer balances and billing data are not modified.
- Android build/device testing remains pending.
