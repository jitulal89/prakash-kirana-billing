# SiddhiBill v3.64.32 — Native A4 PDF build correction

## Build error fixed
- Removed direct construction of Android framework `PrintDocumentAdapter.LayoutResultCallback` and `WriteResultCallback`, whose constructors are not accessible to the app package.
- Delegated print layout/write callbacks to Android's `PrintManager` using `printManager.print(...)`.

## PDF behavior
- Reports are rendered through Android's native print framework as actual paginated A4 documents, not screenshots of the app WebView.
- Wide reports use A4 landscape; other reports use A4 portrait.
- Print-only CSS hides app action/navigation controls, wraps long table content, repeats table headers, and keeps rows together where possible.
- Android's print preview opens; choose **Save as PDF** and select the destination in the system dialog. This is necessary because Android owns the print callbacks.

## Validation
- Source-level callback constructor error removed.
- ZIP integrity checked.
- Android Gradle build and on-device PDF rendering still need to be verified by GitHub Actions/device.
