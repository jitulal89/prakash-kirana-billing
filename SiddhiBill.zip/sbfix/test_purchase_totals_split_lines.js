const fs=require('fs'),vm=require('vm'),cp=require('child_process');
const src=fs.readFileSync(__dirname+'/app/src/main/assets/www/app.js','utf8');
function part(a,b){const i=src.indexOf(a),j=src.indexOf(b,i);if(i<0||j<0)throw Error('Missing source function '+a);return src.slice(i,j)}
const ctx={console,roundMoney:n=>Math.round((Number(n)||0)*100)/100,toInputDate:s=>s,vendorNum:v=>Number(v)||0};vm.createContext(ctx);
vm.runInContext(part('function parsePurchaseInvoiceTable(','function purchaseOcrEntryLine(')+part('function purchaseOcrEntryLine(','function parsePurchaseOcrRows(')+part('function parsePurchaseOcrMetadata(','function parsePurchaseInvoiceTable('),ctx);
const pdf='/mnt/data/1000024866_RBIN033136_INV (1)(1).pdf';
let raw=cp.execFileSync('pdftotext',['-layout',pdf,'-'],{encoding:'utf8'});
// Simulate Android OCR/PDF extraction where taxable/total are wrapped off the HSN detail line.
raw=raw.replace(/1165\.41\s+1375\.19/, '');
raw=raw.replace(/(54\.91\s+104\.89\s+104\.89\s+0\.00)/, '$1 1165.41 1375.19');
const items=ctx.parsePurchaseInvoiceTable(raw);
if(items.length!==13)throw Error('Expected 13 rows after wrapped totals; got '+items.length);
const first=items[0];
if(first.invoiceTaxableAmount!==1165.41||first.invoiceLineTotal!==1375.19||first.taxRate!==18)throw Error('Split-line total not recovered: '+JSON.stringify({taxable:first.invoiceTaxableAmount,total:first.invoiceLineTotal,tax:first.taxRate}));
for(let i=0;i<items.length;i++){
 if(!(items[i].invoiceLineTotal>0))throw Error('Missing line total on row '+(i+1));
 const ratio=Math.round((items[i].invoiceLineTotal/items[i].invoiceTaxableAmount-1)*100);
 if(![5,18].includes(ratio))throw Error('Bad GST ratio row '+(i+1)+': '+ratio);
}
console.log('PASS: taxable/total pair recovered even when it is not on the HSN detail line');
console.log('PASS: all 13 line totals are non-zero and GST is inferred from taxable-to-total reconciliation');
