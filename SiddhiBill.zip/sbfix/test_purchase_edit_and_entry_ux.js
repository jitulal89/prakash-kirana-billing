const fs=require('fs');const path=require('path');const root=__dirname;
const app=fs.readFileSync(path.join(root,'app/src/main/assets/www/app.js'),'utf8');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/www/index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'app/src/main/assets/www/styles.css'),'utf8');
const java=fs.readFileSync(path.join(root,'app/src/main/java/com/dukaanbill/app/MainActivity.java'),'utf8');
for(const [ok,msg] of [
 [app.includes('function editPurchase(id)'), 'Purchase history edit function exists'],
 [app.includes('state.purchases[ix]=rec'), 'Edit saves by replacing existing purchase record'],
 [app.includes('purchaseDraftItems=nextItems'), 'Add List replaces/synchronizes draft rows'],
 [app.includes('function addBlankPurchaseItem()')&&html.includes('id="purchaseAddItemBtn"'), 'Manual Add Item control exists'],
 [html.indexOf('id="purchaseCameraBtn"')>html.indexOf('id="purchaseEntryCard"'), 'Camera controls are within Purchase Bill Entry markup'],
 [java.includes('"Tax%"')&&java.includes('"CGST"')&&java.includes('"SGST"')&&java.includes('"IGST"'), 'Native PDF has separate tax columns'],
 [java.includes('GST BREAKDOWN BY RATE'), 'Native PDF groups GST breakdown by tax rate'],
 [css.includes('.purchase-draft-row{border:1px solid #d6e0eb;background:#fff;border-radius:8px;padding:7px;margin:5px 0}'), 'Compact item spacing applied']
]){if(!ok)throw new Error('FAIL: '+msg);console.log('PASS:',msg)}
