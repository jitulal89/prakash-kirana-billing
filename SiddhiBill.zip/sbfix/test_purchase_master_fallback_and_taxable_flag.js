const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync(__dirname+'/app/src/main/assets/www/app.js','utf8');
const a=src.indexOf('function purchaseNameKey('),b=src.indexOf('\nfunction vendorTaxContext(',a);
assert(a>=0&&b>a,'purchase master fallback/parser section not found');
const ctx={state:{products:[{name:'Dettol Handwash Original 650ml',unit:'Packet',taxRate:18,hsn:'34013019',rate:100}]},roundMoney:n=>Math.round((Number(n)+Number.EPSILON)*100)/100,$:()=>undefined};vm.createContext(ctx);vm.runInContext(src.slice(a,b),ctx);
let p=ctx.parsePurchaseEntryLine('Dettol Handwash Original 650ml,16,,1600,,,');
assert(!p.error,JSON.stringify(p));assert.equal(p.name,'Dettol Handwash Original 650ml');assert.equal(p.unit,'Packet');assert.equal(p.taxRate,18);assert.equal(p.hsn,'34013019');
p=ctx.parsePurchaseEntryLine('Dettol Handwash Original 650ml,16,Packet,1600,5,99999999,');assert.equal(p.taxRate,5,'explicit tax must not be overwritten by master');assert.equal(p.hsn,'99999999','explicit HSN must not be overwritten by master');
p=ctx.parsePurchaseEntryLine('Unknown item,2,,100,,,');assert.equal(p.unit,'Piece','unknown unit defaults to Piece');assert.equal(p.taxRate,null);assert.equal(p.hsn,'');
console.log('PASS: exact product master match fills missing unit, tax rate and HSN');
console.log('PASS: explicit Quick List fields take precedence over master values');
console.log('PASS: unmatched products default unit to Piece and keep unknown tax/HSN blank');
const os=src.indexOf('function purchaseOcrEntryLine(item){'),oe=src.indexOf('\nfunction parsePurchaseOcrRows(text){',os);vm.runInContext(src.slice(os,oe),ctx);
const ocr=ctx.purchaseOcrEntryLine({name:'Dettol Handwash Original 650ml',qty:16,unit:'Piece',unitWasDefault:true,invoiceLineTotal:1600,taxRate:0,taxRateWasProvided:false,hsn:'',priceIncludesTax:true});
assert(ocr.startsWith('Dettol Handwash Original 650ml,16,Packet,1600,18,34013019,'),'OCR missing fields should use product master: '+ocr);
console.log('PASS: OCR-missing unit, tax and HSN are recovered from the matching product master');

