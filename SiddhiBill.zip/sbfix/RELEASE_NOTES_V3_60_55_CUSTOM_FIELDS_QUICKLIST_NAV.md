SiddhiBill v3.60.55 — Custom Fields, Quick List and Page Persistence

Changes:
- Canvas/PDF bill layout places custom header fields in the invoice metadata flow; fixed-position bill metadata no longer overlaps custom fields.
- Thermal receipt prints configured custom header/footer fields using case-insensitive placement values; fields explicitly set to hidden are not printed.
- Billing Quick List Add List now sets an existing row quantity to the quantity in the list instead of adding it again on every click. Repeating Add List is therefore idempotent for existing matching items.
- Switching away from Billing and returning no longer clears the current bill. The bottom Billing tab navigates without starting a new bill; the explicit New Bill button and Home New Bill tile still clear the editor.
- Switching away from Purchasing and returning no longer resets the purchase editor/draft. New Purchase remains the explicit reset action.

Validation: JavaScript syntax, regression tests, and ZIP integrity should be run. Native Android build and physical PDF/thermal printer verification are not claimed unless separately performed.
