const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync(__dirname+'/app/src/main/assets/www/app.js','utf8');
const a=src.indexOf('function parsePurchaseGenericColumnTable('),b=src.indexOf('\nfunction parsePurchaseOcrRows(text){',a);
assert(a>=0&&b>a,'generic column parser missing');
const ctx={
 state:{products:[{name:'Dettol Handwash Original 650ml',unit:'Packet',taxRate:18,hsn:'34013019'}]},
 purchaseOcrEntryLine:x=>`${x.name},${x.qty},${x.unit},${x.invoiceLineTotal},${x.taxRate??''},${x.hsn||''},`,
 findPurchaseMasterMatch:name=>name.toLowerCase().includes('dettol')?{name:'Dettol Handwash Original 650ml',unit:'Packet',taxRate:18,hsn:'34013019'}:null
};vm.createContext(ctx);vm.runInContext(src.slice(a,b),ctx);
const text=`Sr No  Item Description                 HSN       Qty  Unit  CGST% SGST%  Total Amount\n1      Dettol Handwash Original 650ml    34013019  16   Packet 9     9      1600.00\n2      Unknown Snack                    19059090  2    Each   0     0      100.00\nSubtotal 1700.00\nGrand Total 1700.00`;
const rows=ctx.parsePurchaseGenericColumnTable(text);
assert.equal(rows.length,2,'generic parser should return both item rows: '+JSON.stringify(rows));
assert(rows[0].startsWith('Dettol Handwash Original 650ml,16,Packet,1600,18,34013019,'),'item, qty, unit, total, combined GST and master HSN expected: '+rows[0]);
assert(rows[1].startsWith('Unknown Snack,2,Piece,100,,19059090,'),'unknown item should preserve the detected HSN and leave unknown tax blank: '+rows[1]);

const uomText=`Sr No  Item Description           Qty  UOM  Unit  Total
1      Soap Original              1    16   Each  100.00
2      Soap Lemon                 1    24   Each  200.00
Subtotal 300.00`;
const uomRows=ctx.parsePurchaseGenericColumnTable(uomText);
assert.equal(uomRows.length,2,'UOM/Qty bill rows should be parsed');
assert(uomRows[0].startsWith('Soap Original,1,Piece,100,'),'Quantity must be preferred when the Quantity field exists: '+uomRows[0]);
const html=fs.readFileSync(__dirname+'/app/src/main/assets/www/index.html','utf8');
assert(html.indexOf('purchaseCameraBtn')<html.indexOf('id="purchaseVendor"'),'camera must appear before vendor field');
assert(html.indexOf('purchaseImportBtn')<html.indexOf('id="purchaseVendor"'),'upload must appear before vendor field');
assert(src.includes('Verify New Vendor from OCR'),'new OCR vendor must be reviewed before save');
assert(src.includes('vendorModalFromOcr=true;pendingOcrVendorMeta=meta;'),'new OCR vendor modal flow missing');
assert(!src.includes('function findOrCreateVendorFromOcr('),'OCR should not silently auto-create vendors');
console.log('PASS: generic column parser maps item/qty/unit/last-column total/tax/HSN');
console.log('PASS: Quantity field takes precedence when present');
console.log('PASS: CGST + SGST combined; Product Master fills missing unit/tax/HSN');
console.log('PASS: new OCR vendor is reviewed in editable modal before creation');
console.log('PASS: camera and upload controls precede Vendor field');
