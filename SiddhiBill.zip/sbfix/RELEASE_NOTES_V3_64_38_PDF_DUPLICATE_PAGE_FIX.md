# SiddhiBill v3.64.38 — PDF repeated-page correction

- Corrected the shared A4 PDF renderer used by Customer Ledger, Vendor Ledger, Team Member and other HTML reports.
- The previous implementation scrolled a height-constrained WebView and then drew it; on affected Android WebView builds, each page draw repeated the first viewport.
- The renderer now lays out the WebView at the full document height, captures one full-document Picture, and slices that picture into sequential A4 portrait pages.
- Retains the existing native PDF save flow and direct Downloads/SiddhiBill destination. No print-app chooser is introduced.
- Vendor Ledger section from v3.64.37 is retained.

Validation: JavaScript and regression checks can be run locally. Android Gradle compilation and device PDF output still require GitHub Actions and device verification.
