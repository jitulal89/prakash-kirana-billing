const fs=require('fs'),assert=require('assert');
const src=fs.readFileSync(__dirname+'/app/src/main/assets/www/app.js','utf8');
assert(src.includes('vendorModalFromOcr')&&src.includes('pendingOcrVendorMeta'),'OCR vendor review state should be present');
assert(src.includes('openVendorModal(null,')||src.includes('openVendorModal('),'Editable vendor form should be available');
assert(src.includes('vendorOcrReviewHint')&&src.includes('Save Vendor'),'OCR vendor details should be shown for review before saving');
assert(!src.includes('function findOrCreateVendorFromOcr('),'OCR should not silently create a vendor before the shopkeeper reviews the prefilled form');
console.log('PASS: OCR vendor details are reviewed in an editable form before vendor creation; no silent auto-create');
