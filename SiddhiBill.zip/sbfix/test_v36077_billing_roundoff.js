const fs = require('fs');
const assert = require('assert');
const vm = require('vm');
const appPath = 'app/src/main/assets/www/app.js';
const htmlPath = 'app/src/main/assets/www/index.html';
const javaPath = 'app/src/main/java/com/dukaanbill/app/MainActivity.java';
const app = fs.readFileSync(appPath, 'utf8');
const html = fs.readFileSync(htmlPath, 'utf8');
const java = fs.readFileSync(javaPath, 'utf8');
const start = app.indexOf('function getBillTotals(){');
const end = app.indexOf('\n}\n\nfunction calc(){', start) + 2;
assert(start >= 0 && end > start, 'actual billing totals function must exist');
const context = {
  items: { children: [] },
  formTaxEnabled: () => context.taxEnabled,
  quantityValue: (qty) => Number(qty) || 0,
  normalizeUnitName: x => x,
  roundMoney: n => Math.round((Number(n) + Number.EPSILON) * 100) / 100,
  money: n => "₹" + Number(n || 0).toFixed(2),
  vendorNum: v => { const n = Number(v); return Number.isFinite(n) ? n : 0; },
  taxEnabled: false,
  inclusive: true,
  $(id) {
    if (id === 'discountType') return { value: 'amount' };
    if (id === 'discountValue') return { value: '0' };
    if (id === 'billAmountsIncludeTax') return { checked: context.inclusive };
    return null;
  }
};
vm.createContext(context);
vm.runInContext('function roundMoney(v){return Math.round((vendorNum(v)+Number.EPSILON)*100)/100;}\n'+app.slice(start, end), context);
function totals(rate, {tax=0, taxEnabled=false, inclusive=true, discount=0}={}) {
  context.items.children = [{querySelector(sel) {
    const values = {'.iqty': {value:'1'}, '.iunit': {value:'piece'}, '.irate': {value:String(rate)}, '.itax': {value:String(tax)}, '.amount': {textContent:''}};
    return values[sel];
  }}];
  context.taxEnabled = taxEnabled;
  context.inclusive = inclusive;
  context.$ = id => id === 'discountType' ? {value:'amount'} : id === 'discountValue' ? {value:String(discount)} : id === 'billAmountsIncludeTax' ? {checked:inclusive} : null;
  return context.getBillTotals();
}
assert.strictEqual(totals(125).roundOff, 0, 'whole-rupee total must not have round off');
assert.strictEqual(totals(125).total, 125);
assert.strictEqual(totals(125.24).roundOff, -0.24, 'fraction below half rounds down');
assert.strictEqual(totals(125.24).total, 125);
assert.strictEqual(totals(125.76).roundOff, 0.24, 'fraction above half rounds up');
assert.strictEqual(totals(125.76).total, 126);
assert.strictEqual(totals(125.5).roundOff, 0.5, 'half rupee rounds up');
assert.strictEqual(totals(125.5).total, 126);
const exclusiveTax = totals(100, {tax:5, taxEnabled:true, inclusive:false});
assert.strictEqual(exclusiveTax.calculatedTotal, 105, 'exclusive GST must be included before round-off');
assert.strictEqual(exclusiveTax.total, 105);
const discounted = totals(125.76, {discount:0.76});
assert.strictEqual(discounted.calculatedTotal, 125, 'discount must be applied before round-off');
assert.strictEqual(discounted.roundOff, 0);
assert(app.includes('roundOff:t.roundOff'));
assert(app.includes('Round Off:</td>'));
assert(app.includes('Round Off: "+(billRoundOff>0?"+₹":"-₹")'));
assert(html.includes('id="billRoundOffRow" hidden'));
assert(java.includes('double billRoundOff=b.optDouble("roundOff",0); if(Math.abs(billRoundOff)>=0.005) escLine(out,receiptAmountLine("Round Off:"'));
assert(java.includes('drawText(c,p,"Round Off",margin,y)'));
assert(java.includes('drawTextRight(canvas,p,"Round Off: "'));
console.log('PASS: actual billing totals for exact, round-down, round-up, half-rupee, exclusive GST, and discount scenarios');
console.log('PASS: conditional round-off output hooks in billing UI, saved bill, HTML preview, image export, A4/A6 PDF, 58/80mm PDF, and direct thermal print');
