# SiddhiBill v3.60.82 — Two-device sync fix

- Fixed the native Create Sync File chooser so the available options have explicit readable text colors on Android themes where list text was blending into the dialog background.
- Added a general Android share-sheet option so users can choose Google Drive, Nearby Share, Bluetooth, or another installed file-sharing app.
- Kept WhatsApp sharing and the Android file-save picker.
- Improved sync-file import handling by trimming whitespace/removing a UTF-8 BOM before JSON parsing and resetting the file input after selection so the same file can be selected again.
- Updated app version to 3.60.82 (versionCode 123).

## Sync workflow
1. On phone A, open More → Backup & Restore → Create Sync File.
2. Choose WhatsApp, Share with another app, or Save sync file.
3. Transfer/download the `.siddhisync` file to phone B.
4. On phone B, choose Import Sync File and select the downloaded file.
5. Repeat in the opposite direction to merge changes made on phone B back into phone A.

Sync is a manual file-based merge, not live synchronization. Both devices must use the same shop name.
