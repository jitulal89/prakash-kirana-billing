const fs=require('fs'),assert=require('assert');
const s=fs.readFileSync('app/src/main/java/com/dukaanbill/app/MainActivity.java','utf8');
assert(s.includes('manifestJson.put("stateKeys", new JSONObject(state).length());\n            manifestJson.put("snapshotEntry", "data/modules_snapshot.json");\n            manifestJson.put("snapshotKeys", moduleKeyArray);'),'manifest statements are on real Java lines');
assert(!s.includes('length());\\n            manifestJson.put("snapshotEntry"'),'no literal escaped newline remains');
const g=fs.readFileSync('app/build.gradle','utf8');
assert(g.includes('versionCode 217')&&g.includes('versionName "3.64.42"'));
console.log('v3.64.42 Java backup manifest regression passed');
