SiddhiBill v3.60.64 — GitHub Actions Gradle path fix

- Fixes the workflow assuming that the Android Gradle project is at the repository root.
- Locates settings.gradle/settings.gradle.kts and verifies the app module build file before building.
- Runs :app:assembleDebug without the failing root-level clean task.
- Uses a recursive APK artifact path so nested Android project directories are supported.

Validation: inspected workflow structure and confirmed the workflow YAML includes project discovery and explicit error messages. GitHub Actions build itself has not been run from this environment.
