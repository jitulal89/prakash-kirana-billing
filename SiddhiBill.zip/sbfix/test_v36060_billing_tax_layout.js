const fs=require('fs'),assert=require('assert');
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const js=fs.readFileSync('app/src/main/assets/www/app.js','utf8');
const css=fs.readFileSync('app/src/main/assets/www/styles.css','utf8');
assert(html.includes('id="billTaxToggle"'),'billing tax toggle exists');
assert(js.includes('function formTaxEnabled(){ const toggle=$("billTaxToggle"); return toggle ? !!toggle.checked'),'form tax mode follows billing toggle');
assert(js.includes('taxationEnabled:taxMode'),'saved bill keeps per-bill tax mode');
assert(css.includes('.item-details{display:grid;grid-template-columns:repeat(3,minmax(0,1fr))'),'mobile item grid is responsive');
console.log('v3.60.60 billing tax/layout regression checks passed');
