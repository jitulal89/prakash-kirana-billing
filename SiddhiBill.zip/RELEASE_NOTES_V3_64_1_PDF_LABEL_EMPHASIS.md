# SiddhiBill v3.64.1 — PDF Label Emphasis

- Updated native bill PDF rendering for A4, A6, 58 mm, and 80 mm output so field labels such as Address, Mobile/MO, Payment, Invoice, Date, GSTIN, FSSAI, State, Customer and Bill No. are bold while their values remain regular weight.
- Kept label/value spacing separate instead of bolding the full line; wrapped customer addresses continue below the value portion.
- Updated versionName to 3.64.1 and versionCode to 191.
- Validation: JavaScript syntax check and ZIP integrity check. Android Gradle build was not run because this source archive does not include `gradlew`.
