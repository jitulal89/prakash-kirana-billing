# SiddhiBill v3.64.88 – Android Print Compile Fix

- Fixed the Android Java compile error in A4 landscape report setup.
- Replaced the unsupported `PrintAttributes.MediaSize.ISO_A4.rotate()` call with an explicit A4 landscape media size (11690 x 8270 mils).
- Kept A4 portrait using the platform ISO_A4 constant.
- No report calculations, SQLite data, app identity, or report screen behaviour changed.
- Version code: 261; version name: 3.64.88.

Validation: source checks and ZIP integrity only. Android Gradle compilation/device printing must still be verified by GitHub Actions.
