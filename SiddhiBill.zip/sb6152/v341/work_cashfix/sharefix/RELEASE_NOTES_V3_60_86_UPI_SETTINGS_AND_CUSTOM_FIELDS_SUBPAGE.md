# SiddhiBill v3.60.86 — UPI Settings and Custom Fields sub-pages

- Replaced the inline Custom Billing Fields form on the main Settings screen with a dedicated Configure Custom Billing Fields button and modal.
- Added a dedicated UPI QR Settings button and modal.
- Added per-shop settings for enabling UPI QR, selecting UPI ID vs merchant QR image, shop display name, UPI ID, amount caption preference, and merchant QR image upload/removal.
- Merchant QR images are stored in app settings and limited to 2 MB at selection time.
- Added validation for required UPI ID or merchant QR when QR is enabled.
- Version updated to 3.60.86 (versionCode 127).

Validation performed: JavaScript syntax check and source ZIP integrity. Android Gradle build and physical printer tests were not performed.

Note: This release adds the settings and configuration UI. It does not yet complete bill-specific QR amount selection or embed generated QR codes into all native PDF/thermal output paths; those require a separate print-pipeline implementation and device validation.
