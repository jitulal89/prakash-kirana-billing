# SiddhiBill v3.61.13 — follow-up compile fix

- Corrected the remaining `float` to `int` compile error in the 80 mm/A6 QR placement call by explicitly converting the centered X coordinate to `int`.
- Retained the previous fix for the metadata row coordinate (`float` rather than `int`).
- Retained the missing ESC/POS bitmap and paired Bluetooth printer JSON helper implementations.
- This is a source fix; a full Android Gradle build must still be run in GitHub Actions because the local environment does not provide Gradle/Android SDK.
