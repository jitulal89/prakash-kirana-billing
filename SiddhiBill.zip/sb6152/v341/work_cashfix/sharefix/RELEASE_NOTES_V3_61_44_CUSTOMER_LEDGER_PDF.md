# SiddhiBill v3.61.44 — Customer Ledger PDF

- Added a Customer Ledger PDF section to Reports with customer selection and from/to dates.
- Opens a printable/shareable PDF workflow containing sales bills, item-level purchase history from those bills, and customer payment records for the selected period.
- Includes bill references, item quantities/units/rates/amounts, payment references and period totals.
- Uses existing local transaction data; no backend or internet dependency added.
- Validation: JavaScript syntax check passed. Android build and device PDF/print/share flow not tested.
