SiddhiBill v3.61.52 — Payment Follow-up Report UI

- Redesigned Next Payment Follow-up customer rows as mobile-friendly cards inspired by the supplied SiddhiBill navy/orange mockup.
- Customer name and phone are grouped with a highlighted outstanding balance.
- Reminder date remains editable and saved through the existing customer reminder handler.
- Added OVERDUE / UPCOMING status badges based on the local app date.
- Standardized WhatsApp, Message, and Call action sizing and the Message Template action.
- Added responsive spacing and narrower-screen adjustments.

Validation: app.js passes `node --check`. Android APK/device testing has not been performed.
