# SiddhiBill v3.61.27 — Thermal Table Width and GST Order Fix

- Thermal-only change. PDF renderer was not modified.
- Thermal item table, GST rate summary, and last-five-transactions raster tables now render at 576 dots to use the printable width of typical 80 mm ESC/POS printers.
- Increased table font sizes and row heights for improved readability.
- GST summary header uses a white background with black text and solid table grid lines.
- GST rate summary is printed after the overall bill comment, as requested.
- Existing GST layout logic is retained: intra-state shows Rate, Taxable, CGST, SGST; inter-state shows Rate, Taxable, IGST.

Validation: source changes inspected; ZIP integrity checked. Android build and physical printer output have not been verified in this environment.
