SiddhiBill v3.61.27 - interim 80mm layout test

This interim package replaces app/src/main/java/com/dukaanbill/app/MainActivity.java with the current working source for the agreed first-pass 80mm receipt changes:
- invoice left aligned and date label/value right aligned in the second column
- quantity, unit, rate and GST values right aligned
- whole-number display omits .00; fractional values retain decimals
- compact last-five-transactions layout with DD/MM/YY and short transaction type labels
- final “Bill created using Dukhaan Bill” line centered

This is an interim test package, not a verified release. Android build and physical printer output have not been validated. Please build with GitHub Actions and test before using for live billing.
