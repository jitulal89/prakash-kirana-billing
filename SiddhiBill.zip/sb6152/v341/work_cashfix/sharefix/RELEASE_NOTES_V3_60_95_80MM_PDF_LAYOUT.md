# SiddhiBill v3.60.95 — 80mm PDF layout corrections

- Moved the overall bill comment to immediately after item rows and before GST details/totals.
- Added right-aligned Paid, Bill Balance and Customer Total Balance rows after TOTAL where applicable.
- Increased transaction-table padding and row spacing, and improved compact column allocation for the 80mm/58mm PDF.
- Added a centered “Thank you for shopping with us!” line before the UPI QR section.
- Added “Scan & Pay - Enter Amount” below the QR and kept the SiddhiBill credit footer after the QR.
- Wrapped and reduced footer text size to keep it inside the printable width.
- Increased calculated PDF page height to allow transaction rows, comments and QR/footer content to fit without clipping.
- Populates customer total balance from the customer outstanding calculation for the bill/preview flow.

Validation: JavaScript syntax check and ZIP integrity check performed. Android Gradle build and physical printer/payment-app tests not performed.
