# SiddhiBill v3.61.05 — A4 plain tabular layout

- Removed the black-filled item header; table now uses a white background and black grid lines.
- Reduced item row height to a compact spreadsheet-like row.
- Combined item name and HSN as `Item name - HSN` on one line and removed the `HSN:` label.
- Item comments remain optional and render in a separate thin bordered row only when present.
- Removed two customer-panel separator lines that crossed customer text in the header.
- Customer editor save handler includes safer record lookup, input validation, duplicate checks, and post-save state verification.

Validation: JavaScript syntax and project regression scripts should be run in a Node-enabled environment. Android Gradle build was not run because this source bundle has no Gradle wrapper and this environment does not have the Android Gradle toolchain installed. PDF rendering is not claimed as end-to-end validated without running the Android app.
