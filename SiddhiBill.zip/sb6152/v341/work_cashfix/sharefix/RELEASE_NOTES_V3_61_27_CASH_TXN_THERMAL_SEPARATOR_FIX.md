# SiddhiBill v3.61.27 — Cash Transaction and Thermal Separator Fix

- Added continuous solid horizontal separators between entries in the native ESC/POS last-five-transactions section.
- Fixed cash/non-credit bill transaction classification in the thermal PDF, bitmap thermal table, and full PDF transaction table.
- Cash bill entries now display the bill total as both Bill and Paid when the transaction is a cash/non-credit sale; credit-sale entries continue to use recorded payment values.
- No PDF layout code was intentionally changed beyond correcting transaction values. WhatsApp/Message sharing logic was not changed.
- Validation: Java source checks and ZIP integrity performed; Android APK build and physical printer testing not performed.
