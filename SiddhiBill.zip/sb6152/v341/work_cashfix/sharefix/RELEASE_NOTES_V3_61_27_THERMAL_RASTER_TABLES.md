# SiddhiBill v3.61.27 — Thermal Raster Tables

- Thermal-only change: replaced ESC/POS text-mode item-table borders and last-five-transaction column separators with raster-rendered tables.
- Tables use explicit pixel coordinates and solid horizontal/vertical grid lines to avoid pipe/dash glyphs, character-width wrapping, and split balances.
- Preserved PDF generation code unchanged.
- Preserved the current source's Message/WhatsApp handlers and address/GST PDF implementation.
- Validation: source inspection and ZIP integrity check. Android build and physical printer output have not been verified in this environment.
