SiddhiBill v3.61.06 — Android build error fix

- Fixed Java compilation errors in MainActivity.java caused by assigning float row/comment bottom coordinates to integer y.
- Coordinates now use (int)Math.ceil(...) to safely round down-page cursor positions upward.
- Version updated to 3.61.06 (versionCode 147).

Validation performed:
- JavaScript syntax check passed.
- Source inspection confirms both reported float-to-int assignments are fixed.
- Full Android Gradle build was not run in this environment because no Gradle executable/wrapper is available here. Run the repository GitHub Actions Build APK workflow to confirm Android compilation.
