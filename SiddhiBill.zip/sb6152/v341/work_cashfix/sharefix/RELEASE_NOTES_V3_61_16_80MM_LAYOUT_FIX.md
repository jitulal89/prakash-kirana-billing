# SiddhiBill v3.61.16 — 80 mm receipt layout fixes

- PDF receipt metadata rectangles are explicitly drawn in stroke mode, preventing a filled black customer/bill-details block.
- Corrected item-table value placement for taxable and non-taxable receipts; non-GST rate now uses the rate column boundary.
- Removed the duplicate description line before item rows in PDF receipt output.
- Removed the second PDF QR caption because the QR helper already draws the caption.
- Reworked direct ESC/POS item rows to avoid duplicated item names and use different GST/non-GST column layouts.
- ZIP integrity and JavaScript syntax checks are included in validation; a full Android build still must run in a configured Android/Gradle environment.
