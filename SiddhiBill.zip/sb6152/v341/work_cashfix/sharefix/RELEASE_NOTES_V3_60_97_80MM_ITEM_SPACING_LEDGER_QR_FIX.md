# SiddhiBill v3.60.97 — 80mm PDF item spacing and ledger layout

## Fixes
- Reduced vertical gap before item comments and added a separator line after each item row/comment group in the native receipt PDF layout.
- Added a Previous Balance (P.Bal) column to the last-five-customer-transactions table in HTML bill preview and native receipt/A4 PDF output.
- Reworked transaction table column positions and smaller print font so Payment and Balance values do not collide.
- Removed the extra hard-coded “Thank you for shopping with us!” when a configured footer message is already present.
- Removed the second “Scan & Pay - Enter Amount” label from the native receipt PDF; the QR renderer already prints that caption.
- Bumped version to 3.60.97 / versionCode 138.

## Validation
- `node --check app/src/main/assets/www/app.js` passed.
- ZIP integrity checked after packaging.
- Android Gradle build and physical 80mm printer testing were not performed in this environment.
