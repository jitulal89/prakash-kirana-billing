# SiddhiBill v3.60.93 — Custom fields scope fix

- Fixed Android Java compilation failure in the thermal-size PDF renderer by retrieving the bill's `customFields` JSON object within the method that renders footer custom fields.
- Preserves configured custom-field labels and footer placement before the thank-you/footer and UPI QR section.
- Version code: 134; version name: 3.60.93.

Validation performed: JavaScript syntax checks, targeted regression checks, and ZIP integrity. A full Android Gradle build was not run in this environment.
