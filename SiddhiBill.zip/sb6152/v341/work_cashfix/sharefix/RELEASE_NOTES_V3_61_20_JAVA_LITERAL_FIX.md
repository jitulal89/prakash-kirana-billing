# SiddhiBill v3.61.20 — Java compilation fix

- Fixed invalid Java character literals in the line-break normalization code in `wrapText` and `wrapPlain`.
- Java string literals still use escaped backslashes for CR/LF sequences; Java character literals now use valid `\r` and `\n` escapes.
- Includes the v3.61.19 thermal/non-GST layout changes.
- ZIP integrity and source checks performed. Android Gradle build not run in this workspace; please rerun GitHub Actions to confirm compilation.
