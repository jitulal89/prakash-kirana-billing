# SiddhiBill v3.61.07 — Invoice layout and typography correction

## Changes
- Updated native A4/A6 PDF summary to bordered two-column amount rows.
- Kept compact GST summary in a bordered left panel beside the amount summary.
- Added a full-width bordered customer transaction table.
- Replaced the bill-level `Total Balance` row with `Bill Balance`; removed duplicate `Customer Total Balance` from native invoice output.
- Fixed text drawing so text is rendered with Paint.Style.FILL even when table borders use Paint.Style.STROKE. This prevents outlined/hollow text in PDF output.
- Reduced invoice title and bill-number typography; allowed shop name to use available header width and respect `printShopName`.
- Tightened custom-field and item-table spacing without overlapping the header.
- Retained compact item rows and `Item name - HSN` format without the `HSN:` prefix.
- Updated version to 3.61.07 / versionCode 148.

## Validation status
- `node --check app/src/main/assets/www/app.js`: passed.
- Static source checks for the requested table/label/font changes: passed.
- Android Gradle build and device-exported PDF rendering: not run in this environment because this source package does not include `gradlew` and Gradle is unavailable. Do not treat this as a verified APK release until GitHub Actions succeeds and a fresh app-exported PDF is inspected.
