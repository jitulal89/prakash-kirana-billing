const fs = require('fs');
const java = fs.readFileSync('app/src/main/java/com/dukaanbill/app/MainActivity.java', 'utf8');
function assert(ok, msg) { if (!ok) throw new Error(msg); }
assert(java.includes('private void writeThermalItemTableText'), 'native-text item table renderer missing');
assert(java.includes('private void writeThermalGstSummaryText'), 'native-text GST summary renderer missing');
assert(java.includes('private void writeThermalTransactionsText'), 'native-text transactions renderer missing');
assert(java.includes('writeThermalItemTableText(out,items,tax,b,cfg)'), 'direct print must use native-text item table');
assert(java.includes('writeThermalGstSummaryText(out,ts)'), 'direct print must use native-text GST summary');
assert(java.includes('writeThermalTransactionsText(out,recent)'), 'direct print must use native-text transactions');
assert(java.includes('A two-dot solid rule only (not a rasterized table/receipt)'), 'solid rule should be narrow graphics only');
assert(!java.includes('writeThermalItemTableBitmap(out,items,tax,b,cfg)'), 'direct print must not rasterize item table');
assert(!java.includes('writeThermalGstSummaryBitmap(out,ts)'), 'direct print must not rasterize GST summary');
assert(!java.includes('writeThermalTransactionsBitmap(out,recent)'), 'direct print must not rasterize last transactions');
assert(java.includes('final String digits=phone==null?"":phone.replaceAll("\\\\D","")'), 'message phone normalization missing');
assert(java.includes('Intent.createChooser(send,"Share bill PDF via WhatsApp or another app")'), 'WhatsApp share chooser fallback missing');
console.log('PASS: thermal tables use native ESC/POS text; only narrow solid rule strips use raster; sharing paths include chooser fallbacks');
