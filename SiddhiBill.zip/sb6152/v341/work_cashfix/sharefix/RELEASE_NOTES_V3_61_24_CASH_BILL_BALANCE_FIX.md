# SiddhiBill v3.61.24 — Cash Bill Layout and Balance Logic

- Compact non-tax/cash bill header by reducing unused header height and tightening invoice-number/date positions.
- Cash/non-credit bills default Paid to the bill total when no positive payment amount is recorded, preventing a fully paid cash bill from showing Paid 0.00.
- Bill Balance and Total Balance rows are now rendered only for payment modes marked Credit in the A4/A6 summary and thermal PDF summary.
- Credit bills continue to show Paid, Bill Balance, and Total Balance.

Validation: source changes reviewed; ZIP integrity and Java source structural checks performed. Full Android Gradle build and physical printer verification have not been run in this environment.
