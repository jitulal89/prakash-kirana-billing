# SiddhiBill v3.61.27 — Message Item GST and Total Balance Fix

- Added each item's GST rate to the customer bill message for tax bills.
- Added the customer's overall Total Balance to the message for Credit bills or when Include Last 5 Transactions is enabled.
- The message includes the Total Balance only; it does not append the last-five transaction list.
- Preserved existing thermal printing, PDF rendering, WhatsApp/Message bridge code, and other billing flows.
