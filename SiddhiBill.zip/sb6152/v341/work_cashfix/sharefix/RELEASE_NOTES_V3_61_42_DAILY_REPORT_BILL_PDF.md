SiddhiBill v3.61.42

Changes:
1. Automatic backup regenerates one daily transaction summary PDF per shop and calendar date in the selected backup folder. Repeated runs replace the existing same-day PDF instead of creating hourly PDF copies. Report sections include sales bills, purchase bills, customer receipts, vendor payments and a daily summary, without item-level detail.
2. Bills navigation includes a direct PDF action beside each bill. In the Android app it sends the bill and current print settings to the native PDF generator and opens the PDF directly, without navigating to the bill preview first.

Validation performed: JavaScript syntax check and ZIP integrity check. Android/Gradle build and on-device testing were not performed.
