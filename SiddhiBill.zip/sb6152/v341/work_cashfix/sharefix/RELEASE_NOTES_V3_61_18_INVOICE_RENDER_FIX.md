# SiddhiBill v3.61.18 — invoice rendering correction

- Force outline-only drawing for invoice table and summary rectangles so a previously selected Paint fill style cannot render large solid-black panels.
- Put Terms & Conditions inside the left Overall Comment/GST-summary panel instead of a separate footer-like row; wrap multi-line terms dynamically.
- Allow A4 item descriptions to use up to two lines without shrinking into the numeric columns.
- Retain 80 mm terms height and amount alignment improvements from v3.61.17.
- Date format is DD/MMM/YYYY for bill and transaction dates.
- Validation completed here: ZIP integrity, JavaScript syntax, targeted source assertions and basic Java brace-balance check. Android SDK/Gradle build environment is not available in this workspace, so APK compilation and printer verification remain unconfirmed.
