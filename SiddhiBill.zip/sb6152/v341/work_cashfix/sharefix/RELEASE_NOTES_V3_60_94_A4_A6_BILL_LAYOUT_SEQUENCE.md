# SiddhiBill v3.60.94 — A4/A6 Bill Layout Sequence Fix

- Added vertical spacing between item details, comments, and row separators to reduce row overlap.
- Overall bill comment is left-aligned and appears before the GST summary.
- Moved the Last 5 Customer Transactions table below totals and payment/balance values so it no longer shares the totals row.
- Increased transaction table spacing and widened Date, Type, Bill/Txn No, Payment, and Balance columns for A4/A6.
- Displays Customer Total Balance when a saved customer-ledger balance snapshot is available in the bill; otherwise it falls back to the bill balance.
- Incremented app version to 3.60.94 (versionCode 135).

Validation: JavaScript syntax and ZIP integrity checks passed. Android Gradle build and on-device A4/A6 print validation were not run.
