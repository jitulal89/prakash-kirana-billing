# SiddhiBill v3.61.51 — Billing Payment UI

- Removed Next Payment Follow-up Date from Billing; reminders remain customer-level/customer-payment workflow.
- Added Cheque to bill payment modes.
- Selecting UPI/Card opens a transaction reference dialog; selecting Cheque opens cheque number/date fields.
- Saves payment reference metadata with the bill and with linked partial-payment receipts.
- Kept Credit partial-payment amount field and placed payment controls before Generate Bill/Clear actions.
- Applied SiddhiBill orange styling to primary billing action and compact responsive action layout.

Validation: `node --check app.js` and ZIP integrity check. Android build/device UI not tested.
