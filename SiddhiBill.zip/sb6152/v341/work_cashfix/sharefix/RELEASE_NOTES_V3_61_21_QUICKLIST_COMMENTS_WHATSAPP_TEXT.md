# SiddhiBill v3.61.21 — Quick List Comment Template and WhatsApp Bill Caption

- Billing Quick List accepts a leading `Citem <comment text>` line. The command line is not treated as a product; the comment text is applied to every item parsed below it, including rows already present in the bill when Quick List updates them.
- Example:
  ```
  Citem Handle with care
  Rice 2 kg 50
  Sugar 1 kg 45
  ```
- WhatsApp bill sharing now passes the generated plain-text bill summary as the PDF document caption, alongside the PDF attachment. This includes bill number/date, item lines, subtotal, discount, applicable GST summary, total, payment mode and shop contact where available.
- Android build/device verification is still required. WhatsApp versions may display the text as a document caption rather than a separate standalone chat message; a single Android share intent cannot guarantee two separate WhatsApp messages.
