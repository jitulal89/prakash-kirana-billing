# SiddhiBill v3.61.15 — non-GST and item-column fixes

- Suppress shop GSTIN, FSSAI, state/place-of-supply lines on non-GST bills in the PDF header.
- Suppress customer state on non-GST PDF bills.
- Add a separate Terms & Conditions row beneath the overall-comment row inside the summary/comment panel, when enabled.
- Correct item grid columns for both GST and non-GST PDF output: Qty, Unit, Rate, optional GST %, Amount.
- Correct 80 mm/58 mm thermal item-grid columns: non-GST prints six columns (Sr., Item, Qty, Unit, Rate, Amount); GST prints seven columns including GST %. This fixes Qty/Unit/Rate/Amount column offsets.
- Source and JavaScript checks only; full Android Gradle build still requires CI with the Android SDK.
