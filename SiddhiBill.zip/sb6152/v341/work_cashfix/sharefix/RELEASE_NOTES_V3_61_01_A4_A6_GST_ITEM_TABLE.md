# SiddhiBill v3.61.01 — A4/A6 GST table refinement

- Updated app version to 3.61.01 (versionCode 142).
- Adjusted the A4/A6 GST item-table header spacing so Rate and GST % are more clearly separated.
- Centered GST Summary headers and values within their own bordered cells for a cleaner compact table.
- Kept this patch scoped to the A4/A6 PDF renderer; 80mm/58mm print paths were not intentionally changed.
- Existing item-comment behavior remains: a full-width comment row is drawn only when item comments are enabled and the individual item has a non-empty comment.

Validation: JavaScript syntax check and ZIP integrity check passed. Full Android Gradle build and physical PDF/thermal printer validation were not run in this environment.
