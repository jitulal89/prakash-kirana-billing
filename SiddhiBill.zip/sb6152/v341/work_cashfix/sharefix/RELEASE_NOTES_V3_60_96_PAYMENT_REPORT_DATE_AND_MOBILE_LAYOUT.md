# SiddhiBill v3.60.96 — Payment Report Date Filtering and Mobile Layout

## Changes
- Normalizes payment dates to ISO `YYYY-MM-DD` before applying the report's selected date range. Supports ISO dates and `DD/MM/YYYY` / `DD-MM-YYYY` stored dates.
- Customer receipts and vendor payments are both included when their normalized payment date falls inside the selected range.
- Retains linked partial-payment receipts as payment records exactly once in this report; no bill-derived synthetic receipt is added here.
- Reduces mobile report grid column widths, allows party/reference text to wrap, and keeps Debit/Credit columns fully visible and right-aligned.
- Version 3.60.96, versionCode 137.

## Validation
- `node --check app/src/main/assets/www/app.js` passed.
- ZIP integrity checked after packaging.
- Android Gradle build and on-device report/date-range testing have not been run.

## Note
The report intentionally respects the selected From Date and To Date. Payments dated outside that range remain excluded; select a range covering the payment date to include them.
