# SiddhiBill v3.61.09 — 80 mm thermal layout refresh

## Changes
- Reworked 80 mm / 58 mm PDF generation to use a compact, monochrome, ruled table layout inspired by the supplied reference.
- Added a compact shop header, bordered bill/customer metadata, configurable custom fields, item table, optional item-comment rows, GST rate summary, bordered totals, transaction history, QR payment label, and footer.
- Kept `Bill Balance` and `Total Balance` as separate rows.
- Updated direct ESC/POS thermal printing item section to use a compact tabular layout with item name/HSN and amount details.
- Version updated to 3.61.09 / versionCode 150.

## Validation
- `node --check app/src/main/assets/www/app.js` passes.
- Source inspection confirms thermal PDF and direct thermal print entry points use the updated layout code.
- Full Android/Gradle build and physical printer output were not available for validation in this environment. Please run GitHub Actions and test a real 80 mm print before release.
