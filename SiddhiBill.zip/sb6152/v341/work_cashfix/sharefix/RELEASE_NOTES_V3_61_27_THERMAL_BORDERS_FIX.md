SiddhiBill v3.61.27 – 80mm Thermal Border Fix

- Added printable character-based borders around the 80mm thermal item table and transaction history.
- Kept the current text alignment and compact receipt layout.
- PDF table borders are rendered separately; physical thermal output uses ESC/POS text and printable border characters.
- Android build and physical-printer output must be tested after deployment.
