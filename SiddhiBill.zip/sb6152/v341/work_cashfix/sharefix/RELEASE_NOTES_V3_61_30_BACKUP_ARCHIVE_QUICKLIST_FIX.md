# SiddhiBill v3.61.30 — Backup, Archive and Quick List Fixes

- Added editable automatic backup interval in hours (1–720; default 12).
- Device backup and Google Drive backup now both ask the user to select a destination folder. The selected folder is retained through Android document-provider permissions.
- Automatic backup repeats using the configured interval; Android may delay background execution.
- Archive now creates exactly two user-facing files in sequence: a structured transaction ZIP and a separate tabular PDF summary. The ZIP contains the structured transactions JSON only; no extra README/manifest files or attachments are included.
- Archived records are not removed unless both files save successfully and the user confirms finalization.
- Quick List product-add button is orange; after it adds the product to Quick List and billing items, focus returns to product search.
- Kept Add List below the Quick List text box.

Validation: JavaScript syntax and ZIP integrity checked. Android build and device testing were not available in this environment.
