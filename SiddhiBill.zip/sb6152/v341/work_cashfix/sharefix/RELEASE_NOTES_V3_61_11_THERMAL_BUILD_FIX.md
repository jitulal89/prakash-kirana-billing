# SiddhiBill v3.61.11 — Thermal compile fixes

- Changed thermal PDF layout cursor from `int` to `float` because QR drawing and fractional width calculations use float coordinates.
- Added `findThermalPrinter(String)` to discover a paired printer by configured name/address, or by common thermal-printer name for auto selection.
- Added `openPrinterSocket(BluetoothDevice)` using the standard Bluetooth SPP UUID and an Android 12+ Bluetooth Connect permission check.
- Version code 152.

Validation: source-level checks only. Android Gradle compilation and physical printer output have not been verified in this environment.
