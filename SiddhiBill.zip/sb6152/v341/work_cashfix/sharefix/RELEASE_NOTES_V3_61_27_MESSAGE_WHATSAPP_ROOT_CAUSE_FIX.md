# SiddhiBill v3.61.27 — Message / WhatsApp root-cause fix

## Root cause
The Android methods exposed to JavaScript (`sendBillMessage` and `shareBillPdfToWhatsApp`) launched Android activities directly from a `@JavascriptInterface` callback. Android invokes these callbacks on a WebView bridge thread, not the UI thread. Activity launches must be performed on the UI thread, so the previous handlers could fail when the user tapped Message or WhatsApp.

## Changes
- Move SMS / chooser activity launches to `runOnUiThread`.
- Prepare the bill PDF before dispatching the share intent to the UI thread.
- Retain the PDF content URI, `ClipData`, and read-grant flag for share targets.
- Keep validation and show useful error messages for invalid phone numbers, unavailable SMS apps, and failed share launches.
- No PDF rendering/layout changes made.

## Validation
- ZIP structure and Java source patch inspected.
- Full Android build and real-device SMS/WhatsApp share tests still need to run in GitHub Actions / on device.
