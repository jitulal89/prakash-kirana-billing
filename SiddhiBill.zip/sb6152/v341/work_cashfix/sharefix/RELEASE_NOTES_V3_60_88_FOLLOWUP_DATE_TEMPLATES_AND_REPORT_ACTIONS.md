# SiddhiBill v3.60.88 — Follow-up dates, templates and report actions

- Added Next Payment Follow-up Date to the Billing page, shown for named customers when Payment Mode is Credit or the customer has an outstanding balance.
- Billing and print/PDF customer popup follow-up date fields synchronize.
- Changing the date in the print/PDF popup updates the current saved bill immediately when that bill already exists; new bills persist the selected date when generated.
- Payment follow-up report now offers WhatsApp, SMS/Message and Call actions where a phone number exists.
- Added configurable payment follow-up and custom date-field report message templates with placeholders: `{customer}`, `{shop}`, `{date}`, `{amount}`, `{bill}`, `{phone}`, `{fieldLabel}`, `{details}`.
- Standardized visible report and transaction-history dates to `DD/MMM/YYYY` where updated.
- Version updated to 3.60.88 / versionCode 129.

Validation: JavaScript syntax and ZIP integrity checks. Android Gradle build and device/PDF/thermal tests not run here.
