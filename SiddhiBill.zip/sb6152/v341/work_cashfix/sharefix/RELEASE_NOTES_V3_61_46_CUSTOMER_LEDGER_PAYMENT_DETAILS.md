# SiddhiBill v3.61.46 — Customer Ledger and Payment Details

- Customer Ledger statement now has visible Save / Download PDF, Print, and Back to Reports controls. Save / Download PDF opens the system/browser print flow so the user can choose Save as PDF.
- Customer payment records are matched to the selected customer case-insensitively in the ledger, helping show receipts entered from Customer Setup even if customer-name capitalization differs.
- Customer Setup payment entry now records payment mode: Cash, UPI, Card, Bank Transfer, Cheque, or Other.
- UPI/card/bank-transfer/other payments can store a transaction number / UTR / reference.
- Cheque payments can store cheque number and cheque date; cheque number is required when Cheque is selected.
- Payment mode, transaction reference, cheque details, and notes appear in transaction history and the Customer Ledger payment section. Existing payment records remain compatible.

Validation: JavaScript syntax check and ZIP integrity check passed. Android build and device-level testing were not performed.
