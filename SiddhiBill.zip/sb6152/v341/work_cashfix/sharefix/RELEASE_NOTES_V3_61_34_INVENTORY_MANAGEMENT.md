SiddhiBill v3.61.34 — Inventory Management

- Added optional Inventory Management setting; disabled by default. Inventory navigation is hidden unless enabled.
- Added per-product inventory tracking, minimum stock threshold, base-unit conversion field, and cost/quantity fields.
- Added inventory overview, shop-keyed stock movements, manual opening stock/adjustment/damage/return movements, CSV opening-stock import, movement history and CSV export.
- Added purchase receipt and finalized sales movement hooks, insufficient-stock confirmation, and weighted-average stock valuation.
- Included inventory movements in local persisted state and SiddhiBill sync bundle.
- Existing billing, purchase, printing, tax, OCR and archive code was not intentionally changed beyond stock hooks.

Validation performed: JavaScript syntax check and ZIP integrity check. Android APK compilation and device testing were not performed.
