SiddhiBill v3.61.23 — A4 Tax Bill Layout Fix

Changes:
- Tax invoice item table now has a dedicated HSN column separate from Item.
- Adjusted Qty, Unit, Rate, GST %, and Amount column positions and padding to reduce border collisions.
- Last five customer transactions use Date, Type, Bill/Txn No, Bill Amt, Paid, P.Bal, and Total Balance columns.
- Removed the repeated Terms & Conditions footer rendering; terms remain in the summary panel when enabled.
- Footer now uses one bold thank-you line, centers the creator/contact line, and positions the QR code before the creator footer to prevent the prior overlap.
- Version bumped to 3.61.23 (versionCode 162).

Validation:
- ZIP integrity check performed after packaging.
- Source-level review performed.
- Full Android Gradle build and physical printer/PDF rendering were not run in this environment.
