# SiddhiBill v3.61.12 — Thermal compile fixes

- Added `writeEscPosBitmap(OutputStream, Bitmap, int)` for monochrome ESC/POS raster logo output.
- Added `pairedBluetoothPrintersJson()` used by the Bluetooth printer settings bridge.
- Changed the thermal PDF metadata row coordinate to `float` to match fractional layout coordinates.
- Kept existing paired-printer selection and SPP socket methods.

Validation note: source-level checks are included; an Android/Gradle build could not be run in this environment because no Gradle executable/wrapper or Android SDK `android.jar` is available. Run GitHub Actions to confirm compilation.
