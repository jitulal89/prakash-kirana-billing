# SiddhiBill v3.61.27 — 80mm thermal layout, GST customer fields, and sharing fixes

- Reworked the 80mm PDF metadata block into compact full-width rows to prevent bill/customer/address/payment values from being clipped in half-width cells.
- Printed customer GSTIN, FSSAI, and state in GST thermal PDF bills when present.
- Added customer FSSAI to the A4/A6 GST invoice header, with compact spacing so it can print alongside customer GSTIN, state, mobile, and payment mode.
- Kept 80mm output monochrome and compact, with HSN on a continuation line under the item name and improved thermal transaction details.
- Avoided duplicate footer thank-you text and wrapped the creator/contact footer within printable width.
- Formatted warranty custom fields through the existing date formatter in thermal PDF and ESC/POS print paths.
- Improved Message/SMS fallback and WhatsApp PDF sharing fallback, including a standard Android share chooser if WhatsApp direct sharing is unsupported.
- Populated customer address/state/GSTIN/FSSAI consistently when using Message and WhatsApp actions.
- Preserved credit-only Bill Balance and Total Balance rows in thermal print output.

Validation: JavaScript syntax check passed. Android Gradle build could not be run in this environment because Gradle wrapper/executable is not present. Please verify APK build and actual 80mm printer output in GitHub Actions.
