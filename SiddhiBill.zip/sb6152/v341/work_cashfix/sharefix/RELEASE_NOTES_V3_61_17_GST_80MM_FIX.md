# SiddhiBill v3.61.17 — GST receipt refinements

- 80 mm PDF receipt: terms and conditions are now included in the dynamic page-height estimate and wrap across multiple lines inside a separate bordered row below the overall comment.
- 80 mm PDF receipt: amount values use an explicit right-aligned text helper and a slightly smaller amount font to avoid touching the GST column boundary.
- Date formatter explicitly emits DD/MMM/YYYY for ISO dates (for example, 2026-10-21 -> 21/Oct/2026).
- Retains the earlier fixes for metadata border stroke mode, separate GST/non-GST item columns, and duplicate QR caption removal.
- Validation: ZIP integrity and JavaScript syntax checked. Full Android build and physical printer output still require GitHub Actions/device validation.
