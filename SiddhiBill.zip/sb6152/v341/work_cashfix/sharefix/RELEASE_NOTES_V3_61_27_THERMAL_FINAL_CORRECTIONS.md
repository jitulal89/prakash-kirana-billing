# SiddhiBill v3.61.27 — Thermal Final Corrections

- Moved Paid, Bill Balance and Total Balance directly after TOTAL and before the GST rate summary.
- Removed per-transaction separator bitmap from the Last 5 Transactions section to eliminate extra vertical gap between transaction entries.
- Printed item names on the same row as serial number and quantity/unit/rate/GST/amount fields; HSN and optional notes remain on following lines.
- Aligned GST RATE/TAXABLE/CGST/SGST headings using the exact fixed widths used by their numeric columns.
- No WhatsApp or Message code was intentionally changed.
- PDF rendering code was not changed.

Validation: targeted source assertions passed. Existing `test_v36127_thermal_readability_regression.js` still fails on its pre-existing message phone-normalization assertion, which is unrelated to these thermal-only edits. Android APK build and physical printer output were not tested.
