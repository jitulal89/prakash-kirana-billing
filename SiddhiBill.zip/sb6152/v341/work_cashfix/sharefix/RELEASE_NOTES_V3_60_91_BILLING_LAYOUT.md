# SiddhiBill v3.60.91 — Billing page section order

- Moved the Subtotal, Discount, Round Off and Total Amount summary to directly below the Items section.
- Kept Include item comments, Overall Bill Comment, Include overall comment and Include last 5 customer transactions together above Clear and Generate Bill.
- No calculation or bill-generation logic changed.
- Version code: 132; version name: 3.60.91.
