# SiddhiBill v3.61.19 — thermal/A4 invoice fixes

- Fixed invoice outline drawing so every table/panel border is outline-only, independent of the current Paint fill style.
- Made date formatting tolerant of ISO dates and dd/MM/yyyy dates; output is DD/MMM/YYYY.
- Preserved manual line breaks in terms and conditions and comments, while wrapping long lines to fit the bill width.
- On thermal PDF, long item names wrap to two lines and HSN is printed separately below the name, keeping Qty, Unit, Rate, GST and Amount in their own columns.
- Left-aligned the GST rate summary in thermal PDF.
- Expanded thermal PDF page-height estimation so terms, comments, GST rows, transactions and QR/footer have space.
- Reworked last-customer-transactions section into two-line entries so date/type/reference and bill amount/balance remain readable.
- A4 item names wrap and HSN is shown on a separate line; numeric columns are vertically centered.
- Validation in this workspace: ZIP integrity, JS syntax check, source brace/parenthesis balance, targeted renderer assertions. Android SDK/Gradle build and real printer output were unavailable and are not claimed as passed.
