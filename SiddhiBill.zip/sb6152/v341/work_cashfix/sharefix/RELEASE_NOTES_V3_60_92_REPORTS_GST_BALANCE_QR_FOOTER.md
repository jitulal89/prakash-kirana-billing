# SiddhiBill v3.60.92 — Report and PDF refinements

- Payment Transactions report now uses a consistent table with formatted dates and separately right-aligned Debit and Credit amounts.
- A4 overall bill comment is placed above the GST rate table.
- A4 totals remain in the right summary column, directly following the GST summary; Paid and Total Balance are shown for credit bills and partial payments.
- Footer custom fields are printed before the thank-you/footer message and before the UPI QR in A4/A6, 80mm PDF and direct thermal output.
- UPI ID QR payload no longer hardcodes an amount, allowing the customer to enter or change the payment amount in their UPI app. Printed caption is “Scan & Pay - Enter Amount”.
- Version: 3.60.92 (versionCode 133).

Validation performed: JavaScript syntax check and ZIP integrity check. Android Gradle build and physical printer/UPI app tests were not performed.
