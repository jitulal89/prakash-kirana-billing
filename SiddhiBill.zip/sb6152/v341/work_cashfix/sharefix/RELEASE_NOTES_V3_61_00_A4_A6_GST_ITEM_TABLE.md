# SiddhiBill v3.61.00 — A4/A6 GST and Item Comment Table

## Changes
- Limited changes to the native A4/A6 PDF generation path in `MainActivity.java`; 80mm/58mm rendering paths were not edited.
- Added a GST % column to GST invoice item rows and retained item HSN under the item name.
- Drew item rows as bordered grid cells with vertical column dividers.
- Item comments now render only when enabled and non-empty, in their own full-width bordered row. Empty comments do not create blank comment rows.
- Replaced the HSN/rate-wise GST breakdown with a compact GST Summary under the Overall Comment, showing Taxable Amount, CGST, SGST, IGST and Total GST.
- Updated app version to 3.61.00 (versionCode 141).

## Validation status
- JavaScript syntax check (`node --check app/src/main/assets/www/app.js`): passed.
- ZIP integrity check: passed.
- Android Gradle build and rendered A4/A6 PDF/device print tests: not run in this environment.
