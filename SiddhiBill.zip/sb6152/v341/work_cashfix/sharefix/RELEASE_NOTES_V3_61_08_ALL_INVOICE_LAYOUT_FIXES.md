SiddhiBill v3.61.08 — invoice layout fixes

Changes in MainActivity.java:
- Kept shop statutory state/place-of-supply text inside the shop column to prevent crossing into invoice number/date or customer panel.
- Reduced gap between custom-field strip and item table; item table now starts four layout units after the custom-field row.
- Changed A4 GST summary to a rate-wise table with one row per tax rate, showing rate, taxable amount, CGST, SGST, IGST and total GST. Overall GST totals remain in the right-hand totals table.
- Preserved separate Bill Balance and Total Balance rows; Total Balance uses customerTotalBalance when supplied by the billing payload.
- Increased Scan & Pay label to a more readable 9.5sp-like PDF paint size.
- Updated app version to 3.61.08 / versionCode 149.

Validation performed:
- Source-level checks for required labels and layout changes.
- JavaScript syntax check, if Node.js is available.
- ZIP integrity check.

Not validated here:
- Full Android Gradle build (Gradle wrapper/system Gradle not present in this source environment).
- Actual PDF export from an installed APK or visual comparison against a real bill. Run GitHub Actions and export an A4 bill before treating this as release-ready.
