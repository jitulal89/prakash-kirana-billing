# SiddhiBill v3.61.03 — A4/A6 PDF rendering fix

- Corrected PDF table rectangle drawing so row and panel rectangles are outlined instead of being filled with the current paint color.
- Preserved the black filled item-table header by drawing its fill explicitly, then drawing its border.
- Added a bordered custom-field strip above the item table: one field left-aligned; two fields left/right; three fields left/center/right. Only configured header-position fields with values are included.
- Version code 144; version name 3.61.03.

Validation: source-level patch and ZIP integrity checks only. Full Android Gradle build and rendered PDF testing have not been run.
