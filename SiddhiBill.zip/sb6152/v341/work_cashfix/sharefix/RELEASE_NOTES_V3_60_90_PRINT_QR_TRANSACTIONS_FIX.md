# SiddhiBill v3.60.90 — QR and print layout fixes

- Custom-field follow-up report continues to show WhatsApp, Message/SMS and Call actions and uses the configured custom follow-up template.
- Added centered UPI QR output after the thank-you footer in HTML bill preview, native thermal-size PDF and A4/A6 PDF; UPI ID QR is generated locally, merchant QR image is embedded when configured.
- Added ESC/POS QR printing for UPI ID and raster-image printing for merchant QR on compatible thermal printers.
- Reworked last-five transaction list in HTML preview into a fixed five-column table with cell padding and wrapping.
- Native 80mm PDF transaction table uses full DD/MMM/YYYY dates, short Credit/Payment labels, row padding, and less aggressive reference truncation.
- A4/A6 transaction table gets row spacing and abbreviated types; totals are pushed below the transaction table to prevent overlap. Paid/Balance Due are bold and right-aligned amounts remain aligned.
- Linked partial-payment receipts are no longer shown as separate transaction rows; the linked bill row shows its collected amount and remaining balance.
- Item comments have reduced vertical spacing and more consistent left padding; overall comment is right-aligned in A4/A6 output.

## Validation
- `node --check app/src/main/assets/www/app.js` passed.
- `node test_service_due_report.js` passed.
- Full Android Gradle build and physical printer testing were not run in this environment.
