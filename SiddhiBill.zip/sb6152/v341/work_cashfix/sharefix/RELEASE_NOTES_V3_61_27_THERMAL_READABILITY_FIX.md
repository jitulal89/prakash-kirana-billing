# SiddhiBill v3.61.27 — Thermal Table Readability Fix

- Updated only the direct 80 mm thermal table renderers in `MainActivity.java`.
- Item table uses the full 576-dot image width, larger type, heavier solid grid lines, and taller rows so item names, HSN and optional comments have room.
- GST rate summary uses larger type, stronger solid grid lines and taller rows; intra-state columns remain Rate / Taxable / CGST / SGST and inter-state remains Rate / Taxable / IGST.
- Last-five-transactions section uses larger type and taller rows to reduce cramped labels and improve readability.
- Preserved the existing order: overall comment, GST rate summary, payment/balance details, then last five transactions.
- PDF generation/rendering code was not changed. The bitmap is limited to these thermal table sections; the rest of the receipt remains on the existing ESC/POS text path.

Validation: static regression checks and ZIP integrity check passed. Android APK build and physical output on the Posiflow KP307-UEWB have not been verified here; please test a sample tax and non-tax bill before production use.
