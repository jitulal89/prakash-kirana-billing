# SiddhiBill v3.61.36 — shared-shop sync and thermal/archive fixes

- Sync imports merge inventory movements by stable movement ID, with a deterministic fallback signature for older movements without IDs. Repeated imports no longer duplicate the same movement; balances are rebuilt after movement merge.
- Archive import duplicate detection treats Bill_YYYY/NNN, INV_YYYY/NNN, and INVOICE_YYYY/NNN as equivalent references for matching, while preserving the original imported bill number when it is genuinely new.
- Added the existing approximately 1 mm thermal paper feed after the header separator before the bill-number row and after the item-table separator before subtotal. Existing item-header and item-row gaps remain unchanged.

Validation performed: JavaScript syntax check and ZIP integrity check. Android build/device testing not performed.
