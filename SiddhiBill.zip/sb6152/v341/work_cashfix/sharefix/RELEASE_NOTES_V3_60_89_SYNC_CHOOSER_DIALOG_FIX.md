# SiddhiBill v3.60.89 — Create Sync File chooser fix

- Fixed the Android Create Sync File dialog. Android AlertDialog does not reliably display both a message and a list of selectable items at once; this caused the options to be hidden on the user's device.
- Replaced the hidden list with three explicit visible buttons: WhatsApp, Share with another app, and Save sync file to this phone.
- Kept Cancel available and preserved the existing share/save handlers and `.siddhisync` file format.
- Version updated to 3.60.89 / versionCode 130.

Validation: source-level structure and ZIP integrity checks only; Android Gradle build and device test remain required.
