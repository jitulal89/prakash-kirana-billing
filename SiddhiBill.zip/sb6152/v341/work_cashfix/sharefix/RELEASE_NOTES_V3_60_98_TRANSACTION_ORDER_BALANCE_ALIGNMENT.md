# SiddhiBill v3.60.98

- Customer transactions are now ordered newest-first using stored transaction timestamp/date-time fields when available, with date and reference tie-breakers.
- Running balances are calculated in chronological order and each transaction carries its previous balance for the `P.Bal` column.
- Bill PDF/preview customer total balance is set to the current bill balance as requested.
- Reworked Total Amount, Paid, Bill Balance/Total Balance and Customer Total Balance into a consistent two-column summary: labels right-aligned and values left-aligned within the summary block.
- Applied summary alignment to 80mm and A4/A6 native PDF rendering and HTML bill preview.
