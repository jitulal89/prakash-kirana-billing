# SiddhiBill v3.61.10 — ESC/POS Compile Fix

- Added the missing `escCmd(OutputStream, int...)` and `escLine(OutputStream, String)` helpers used by the direct 80 mm thermal-print implementation.
- `escCmd` writes command bytes unsigned; `escLine` writes UTF-8 text followed by CR/LF.
- Version code: 151.

Validation limitation: source-level checks only. Android Gradle compilation and printer output have not been run in this environment.
