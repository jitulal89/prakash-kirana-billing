# SiddhiBill v3.61.02 — A4/A6 PDF compile fix

- Fixed Java compile error in A4/A6 PDF item-comment layout: explicit ceiling conversion when assigning the calculated floating-point comment bottom position to the integer vertical cursor.
- Preserves optional full-width item comment rows and A4/A6 GST item-table layout from v3.61.01.
- Version code: 143; version name: 3.61.02.

Validation: source change and ZIP integrity checked. Full Android Gradle build and physical PDF printing were not run in this environment.
