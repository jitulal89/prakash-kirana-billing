# SiddhiBill v3.61.27 — Native Thermal Tables and Sharing Fix

## Thermal printing
- The direct 80 mm ESC/POS path now prints item rows, GST rate summary, and the last-five-transactions section as native printer text.
- It no longer rasterizes the three full tables, so the printer's normal text font is used and long rows are wrapped/clipped intentionally rather than scaled down.
- Solid horizontal separators use only a narrow two-dot raster strip. The full table and its text are not bitmap-rendered.
- The PDF rendering methods were not edited.

## Message / WhatsApp
- Message action normalizes the mobile number, tries the SMS composer with the India country code, and falls back to Android's share chooser if no SMS handler is available.
- WhatsApp bill sharing creates the PDF, attaches the content URI with read permission, and launches Android's chooser so the user can select WhatsApp or WhatsApp Business instead of silently swallowing package-launch failures.
- The share action requires a valid 10-digit Indian mobile number in the bill dialog.

## Validation
- Thermal regression test: passed.
- Service-due follow-up sharing regression: passed.
- Existing historical tests for versions 3.60.66 / 3.60.72 and partial-payment wording have stale assertions and were not treated as pass.
- Android APK build and physical printer / WhatsApp testing could not be run in this environment (Gradle executable unavailable).
