# SiddhiBill v3.61.28 — Automatic Backup, Bill Archive, Quick List Flow

## Automatic backup
- Added Android WorkManager periodic backup every 12 hours.
- Destination can be configured as app-specific mobile Documents storage or a user-selected document folder (select Google Drive in Android's folder picker for Drive backup).
- ZIP includes the SQLite database, app state, and purchase document attachments. Android may defer background execution.

## Bill archive
- Added date range and bill-type selection for customer bills, purchase bills, or both.
- Exports structured transaction JSON inside a versioned ZIP and a separate landscape tabular PDF summary without item-level rows or original attachments.
- ZIP import validates archive version and shop name/GSTIN before import; duplicate bill/invoice numbers are skipped.
- Bills and linked bill payment records are removed from active storage only after ZIP save and explicit user confirmation that the PDF was saved.

## Billing Quick List
- “Add to Quick List” now also parses the current Quick List and adds/updates its item rows in the billing Items section.
- Moved “Add List” below the Quick List text box.

## Validation
- JavaScript syntax check passed with `node --check`.
- ZIP archive integrity and Android build/on-device workflow still require verification in an Android build environment.
