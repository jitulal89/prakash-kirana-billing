# SiddhiBill v3.60.99 — Consistent Two-Column Amount Summary

- Native 80mm/58mm PDF amount rows now use a consistent two-column summary: labels right-aligned at the column boundary and values left-aligned at a fixed start position.
- Applied the same alignment to Subtotal, Discount, Taxable, CGST, SGST, IGST, Total GST, Round Off, Total Amount, Paid, and Bill Balance rows.
- Native A4/A6 PDF summary rows now use the same label/value column alignment. GST-rate breakdown remains on the left side as requested; totals remain on the right.
- HTML bill totals already use a two-column table and have been retained.

Validation: JavaScript syntax and ZIP integrity checked. Android Gradle build and printer testing not performed.
