# SiddhiBill v3.61.14 — QR coordinate compile fix

- Corrected both QR placement coordinates to explicit integers at the `drawCenteredBillQr` call. The previous patch cast the center X coordinate but left `y + 4` as a float.
- This addresses the remaining float-to-int compiler error shown for the QR footer line.
- Source ZIP integrity and JavaScript syntax are checked; full Android Gradle compilation must still be confirmed by GitHub Actions.
