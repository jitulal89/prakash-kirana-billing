# SiddhiBill v3.61.33 — Archive bill number and import update

- Archive summary PDF now prints the complete bill/invoice number. If the full value exceeds the column width, it is horizontally scaled to fit rather than truncated.
- Removed the same-shop name/GSTIN restriction from archive import. Archives from any shop can now be imported into the currently open shop.
- Import still validates the archive format and skips duplicate bill/invoice numbers. Review imported records carefully when the archive originates from another shop.
- Updated archive UI help text to describe cross-shop import.

Validation: JavaScript syntax check and ZIP integrity check performed. Android APK build and device testing not performed.
