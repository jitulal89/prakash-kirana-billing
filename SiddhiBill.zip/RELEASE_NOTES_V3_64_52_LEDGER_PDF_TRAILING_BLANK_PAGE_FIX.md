# SiddhiBill v3.64.52 — Ledger PDF trailing blank-page fix

- Updated native HTML-to-PDF pagination to inspect captured page slices from the end of the document.
- Consecutive trailing slices containing only white space are removed before PDF pages are written.
- Pages containing report text/table borders are retained; if blank-page detection fails, the page is retained (fail-safe against data loss).
- Existing customer/vendor ledger content and native PDF generation flow are unchanged.
- Version code: 225.

Validation: JavaScript regression test and ZIP integrity checks. Android Gradle build and physical-device PDF validation remain required.
