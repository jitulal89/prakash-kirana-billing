# SiddhiBill v3.64.92 – Quick List repeated-line replay fix

## Issue
When the Quick List textarea retained previously added rows, tapping Add List again replayed those rows. Example: add two Chana Dal rows using Split, then append Toor Dal and choose Split; the previous Chana Dal rows were added again.

## Fix
- Track the count of each successfully parsed textarea line after the user confirms Merge or Split.
- On subsequent Add List actions, skip only the previously committed occurrences while still processing newly appended lines.
- Preserve duplicate lines within the current batch: two identical new rows still trigger Merge/Split choice and Split adds both.
- Do not mark lines as committed if parsing fails or the user cancels the duplicate-choice dialog.
- Preserve the existing textarea content and manual editing workflow.
- Clearing the textarea resets the committed-line tracking.

## Version
3.64.92; version code 265.

## Validation
JavaScript syntax and source-level regression assertions passed; ZIP integrity checked. Android Gradle build and on-device workflow testing remain pending.
