# SiddhiBill v3.64.55 — Lazy Inventory & Large History Performance Fix

Baseline: v3.64.54
Version code: 228

## Changes
- Excluded `pksInventoryMovements` from the eager SQLite-to-WebView startup transfer.
- Deferred inventory movement JSON parsing and SQLite chunk reads until Inventory or another inventory-dependent workflow actually requests the collection.
- Prevented ordinary saves and startup diagnostics from touching or rewriting lazy sales, purchase, and inventory collections until those collections have been loaded.
- Optimized inventory balance rebuilding to group movements in one pass by product before calculating each product's weighted-average balance.
- Changed purchase edit normalization to normalize only the selected purchase rather than mapping all purchase history before editing.
- Preserved selected vendor values when vendor dropdowns are rebuilt.
- Kept exact customer name + mobile matches prompt-free; same-name/different-mobile conflicts offer update or create, while same-mobile/different-name conflicts also offer **Use Existing** without renaming or overwriting the saved customer profile.
- Added right padding to the final Total column in the Purchase Bill PDF item table.

## Validation
- JavaScript syntax check: passed (`node --check`).
- Targeted v3.64.55 regression assertions: passed.
- Synthetic backup SQLite integrity check: passed (`PRAGMA integrity_check = ok`).
- Confirmed the synthetic database contains 10,000 sales bills, 10,000 purchase bills, and 249,162 inventory movement records. Inventory JSON is approximately 74.6 MB; purchase JSON is approximately 109.5 MB.
- Full historical test suite was attempted. Several older tests are tied to previous version numbers, require external PDF fixtures not present in the archive, or fail in their standalone harness due to missing DOM mocks. These are not counted as passing.
- Android Gradle build and physical-device cold-start/restore test were not available in this environment. The ZIP contains source for the GitHub Actions build; device validation is still required before treating this as production-stable.

## Data safety
No database schema change. Existing SQLite keys and backup/restore format are retained. Unloaded large collections are omitted from unrelated save payloads, leaving their existing SQLite values untouched.
