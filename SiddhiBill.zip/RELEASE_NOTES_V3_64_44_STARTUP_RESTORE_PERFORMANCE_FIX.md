# SiddhiBill v3.64.44 – Startup and restore performance follow-up

## Root-cause corrections
- The one-time legacy product-catalog migration previously called the full `save()` routine during startup. That serialized both complete transaction arrays and forced lazy bill/purchase loading. It now persists only the product list and migration marker.
- The starter-catalog setup check previously read `state.bills.length` and `state.purchases.length`, which forced both large transaction arrays to load during startup. It now checks whether the native database contains the corresponding keys without loading their contents.
- Added a native SQLite single-key upsert API (`saveAppStateValue`) for small targeted state updates.

## Compatibility and safety
- No database schema changes.
- Existing `app_state` records and backup format remain unchanged.
- Existing 50-record client-side history pagination remains unchanged.
- Full transaction arrays are still loaded when a feature explicitly accesses them; this is not yet SQLite-native page-level querying.

## Validation
- JavaScript syntax check passed with Node.js.
- ZIP archive integrity check passed.
- Android Gradle build and physical-device startup timing have not been run in this environment.
