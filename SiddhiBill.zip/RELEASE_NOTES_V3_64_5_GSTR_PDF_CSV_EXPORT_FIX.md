# SiddhiBill v3.64.5 — GSTR PDF reports and CSV save fix

- Added dedicated GSTR-1 PDF working report with invoice-level sales details and rate-wise summary.
- Added dedicated GSTR-3B PDF working report with outward-tax totals, manually entered ITC/adjustments, and explicit reconciliation cautions.
- Kept the existing general GST summary PDF.
- Changed Android CSV export from a share intent using `text/csv` to the system Save As document picker, using a generic MIME type with the `.csv` filename to avoid provider-specific MIME errors.
- The exported CSV includes UTF-8 BOM and quoted/escaped values.
- Existing app ID, SQLite database name, and app data keys were not changed.
- Version: 3.64.5, versionCode 195.

Reports are working papers only, not official GSTN filing returns. Android build/device testing still required.
