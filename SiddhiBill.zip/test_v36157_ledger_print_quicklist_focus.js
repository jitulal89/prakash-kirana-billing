const fs=require('fs');const s=fs.readFileSync('app/src/main/assets/www/app.js','utf8');
if(!s.includes('.ledger-toolbar{position:fixed;left:0;right:0;bottom:calc(16px + env(safe-area-inset-bottom,0px))')) throw Error('ledger toolbar is not fixed above system navigation');
if(!s.includes('padding:0 0 calc(112px + env(safe-area-inset-bottom))')) throw Error('ledger content bottom clearance missing');
if(!s.includes('search.focus({preventScroll:true})')) throw Error('quick list search is not refocused without scrolling');
if(!s.includes('window.scrollTo(savedScrollX,savedScrollY)')) throw Error('quick list add should preserve scroll position');
console.log('v3.61.57 targeted regression checks passed');
