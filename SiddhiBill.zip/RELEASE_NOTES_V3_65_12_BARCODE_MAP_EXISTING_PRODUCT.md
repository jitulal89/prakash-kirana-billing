# SiddhiBill v3.65.12 — Unknown Barcode: Map Existing Product

## Barcode scanning improvement
- When a scanned barcode is not found in the product master, the user can choose **Map to Existing Product** or **Create New Product**.
- Existing product mapping uses a searchable product list.
- The new barcode is saved as an alternate barcode on the selected product; the product's primary barcode is preserved.
- The selected product is staged in the current scanner queue with quantity 1, and the scanner resumes.
- Alternate barcodes are recognized by subsequent scans and duplicate barcode validation.
- Existing scan queue is retained while the mapping dialog is open.

## Version
- versionName: 3.65.12
- versionCode: 284

## Validation
- JavaScript syntax check passed.
- ZIP integrity checked.
- Android Gradle build and physical barcode-camera test were not run in this environment.
