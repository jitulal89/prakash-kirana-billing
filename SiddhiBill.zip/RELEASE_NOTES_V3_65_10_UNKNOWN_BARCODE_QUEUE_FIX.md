# SiddhiBill v3.65.10 — Unknown Barcode Flow and Queue Preservation

## Fixes
- When a barcode is unknown, the scanner pauses only so the existing product form can be displayed; the user is informed that already-scanned products are retained.
- The existing barcode queue is kept in WebView state while the product form is open.
- After saving the new product, it is added to the existing scanner queue with quantity 1, unit and rate; the scanner automatically reopens.
- The just-created barcode is briefly ignored during camera resume to prevent an immediate duplicate scan.
- Canceling product creation or dismissing the unknown-barcode prompt returns to the scanner instead of abandoning the scan session.
- Removed the invalid reference to `barcodeScanModal` (that element does not exist in the HTML), which caused the post-save JavaScript error.
- When the native scanner activity starts again, it requests the current WebView queue and restores previously scanned rows rather than displaying an empty list.
- Duplicate barcode validation now also checks the `itemBarcode` property.

## Validation
- JavaScript syntax check passed.
- Scanner/unknown barcode queue-preservation regression passed.
- Purchase handoff, vendor quick list and purchase barcode/unit tests passed.
- ZIP integrity check passed.

Android Gradle build and physical camera test still need to be run in GitHub Actions/device.
