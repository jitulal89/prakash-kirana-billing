# SiddhiBill v3.65.5 — Continuous Portrait Barcode Scanner + Quick List

- Replaced the one-shot landscape-capable ZXing intent scanner with an in-app continuous ZXing camera activity.
- Locked the scanner to portrait orientation; the camera remains open while multiple products are scanned.
- Added a live Quick List beneath the camera preview with product name, quantity/unit and selling rate.
- Each scan is staged in the Quick List only. It does not add bill lines until the user closes/reviews the scanner and taps **Update Bill**.
- Repeated barcode scans increment quantity; duplicate decode callbacks are throttled to avoid adding a product multiple times while its barcode remains in view.
- Unknown barcodes close the scanner before offering product creation; product-master barcode scan also closes the scanner after capture.
- Preserves existing product barcode mapping, SQLite data, bill calculation, GST and app identity.
- Android camera permission is requested when needed.
