const fs=require('fs'),vm=require('vm'),assert=require('assert');
const js=fs.readFileSync('app/src/main/assets/www/app.js','utf8');
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const gradle=fs.readFileSync('app/build.gradle','utf8');
// Vendor fourth-column semantics: unchecked means line total; checked means unit price.
const start=js.indexOf('function parsePurchaseEntryLine(line){');
const end=js.indexOf('\nfunction vendorTaxContext(',start);
assert(start>=0&&end>start,'purchase parser located');
let perUnit=false;
const ctx={roundMoney:n=>Math.round((Number(n)+Number.EPSILON)*100)/100,state:{products:[]},$:()=>({checked:perUnit}),enrichPurchaseItemFromMaster:item=>({...item,unit:item.unit||'Piece'})};
vm.createContext(ctx);vm.runInContext(js.slice(start,end),ctx);
perUnit=false;let p=ctx.parsePurchaseEntryLine('Toordal|2|Kg|380||||');
assert(!p.error&&p.lineTotalInclusive===380&&p.rate===190,'unchecked fourth value is the line total');
perUnit=true;p=ctx.parsePurchaseEntryLine('Toordal|2|Kg|190||||');
assert(!p.error&&p.lineTotalInclusive===380&&p.rate===190,'checked fourth value is multiplied by quantity');
// Product-picker action must pass the entered fourth value unchanged; parser applies mode once.
assert(js.includes('const enteredPurchaseValue=Number(buy);'),'selected item must not pre-multiply the fourth value');
assert(js.includes('updatePurchaseQuickListPriceMode()')&&js.includes('perUnit?"Purchase Rate / Unit":"Purchase Line Total"'),'picker label follows checkbox state');
assert(html.includes('4th value is per-unit purchase price'),'checkbox label retained');
assert(!html.includes('Unchecked: 4th value is the line total'),'extra checkbox explanation removed');
assert(!html.includes('Dettol Handwash Original 650ml,16,Packet'),'sample rows removed from textarea placeholder');
assert(!html.includes('id="purchaseQuickListHelp"'),'Vendor Quick List explanatory text removed');
assert(html.includes('id="purchaseQuickRateLabel"'),'dynamic line total / per-unit label exists');
// Billing Quick List: same item + same unit + same qty + changed rate is an edit, not duplicate prompt.
assert(js.includes('If a single existing Quick List line is re-submitted with the same product,')&&js.includes('Math.abs(oldQty-newQty)<0.000001&&Math.abs(oldRate-newRate)>=0.005'),'customer rate-edit path exists');
assert(gradle.includes('versionCode 270')&&gradle.includes('versionName "3.64.97"'),'version metadata updated');
console.log('PASS: Vendor Quick List line-total and per-unit fourth-value modes');
console.log('PASS: Purchase Rate / Unit label appears only in checked mode');
console.log('PASS: Vendor Quick List explanatory copy and sample rows removed');
console.log('PASS: Customer Quick List single-line rate edit updates existing row');
console.log('PASS: version 3.64.97 / 270');
