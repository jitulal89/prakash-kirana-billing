# SiddhiBill v3.64.85 – Quick List Dual-Action Fix

## Required behaviour restored
- Selecting a saved product and tapping **Add to Quick List** adds it immediately to the bill Items section.
- The same product line is also appended to the Quick List text area, preserving the text-entry/list workflow.
- The saved-product action processes only the newly selected line, not the entire existing text area.
- When **Add List** is later tapped, lines already inserted by the saved-product action are skipped once, preventing duplicate insertion; other typed/pasted lines are still added.
- Duplicate Merge / Separate Lines choice remains in place for both actions.
- Clearing the Quick List text area resets the in-session duplicate-suppression markers.

## Validation
JavaScript syntax and source-level assertions passed; ZIP integrity passed. Android Gradle build and device testing were not run.
