# SiddhiBill v3.61.53 — Bill History Card Layout

- Updated Bill History cards to match the requested sample layout.
- Bill number appears on the first row.
- Customer name and total amount appear on the second row, with the amount right-aligned.
- Date and item count appear on a separate metadata row.
- View and Edit actions are grouped at the bottom-right, with a compact PDF document icon beside them.
- Added responsive styling for small Android screens; existing bill actions and handlers are preserved.

Validation: `node --check app/src/main/assets/www/app.js` passed. ZIP integrity checked after packaging. No APK/device test performed.
