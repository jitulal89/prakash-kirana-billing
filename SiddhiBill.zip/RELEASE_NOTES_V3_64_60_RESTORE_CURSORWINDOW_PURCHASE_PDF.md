# SiddhiBill v3.64.60 – Restore, Backup and Purchase PDF fixes

- Fixed a restore edge case where a retained transaction-migration marker could cause restored legacy sales/purchase arrays to be ignored. Legacy arrays are now merged into normalized transaction records when present, even if a marker exists.
- Changed backup metadata-state reads to retrieve state values in bounded SQLite `substr()` chunks, avoiding oversized CursorWindow rows.
- Routed Android purchase invoice PDF generation through the same HTML-to-PDF print pipeline used by report PDFs, retaining the browser print fallback.
- Version 3.64.60, versionCode 233.

Validation: JavaScript syntax check and synthetic legacy database migration test. Android Gradle build and device restore/print/backup tests remain to be run through GitHub Actions and on-device.
