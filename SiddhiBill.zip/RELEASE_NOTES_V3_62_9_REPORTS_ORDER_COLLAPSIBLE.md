# SiddhiBill v3.62.9 — Reports order and collapsible sections

- Reordered the Reports page to: Business Reports, Sales Overview, Top Customers, Top Products, Payment Mode Summary, Payment Transactions, Sales by Product, Tax Summary, Outstanding Credits, Daily Sales, Customer Ledger, Next Payment Follow-up, Next Service Due.
- Business Reports remains open and has no collapse arrow.
- All other report sections start collapsed and have a right-aligned toggle arrow beside the heading.
- Existing report controls and IDs are preserved; only the display order and section presentation change.
- Version code 179.
