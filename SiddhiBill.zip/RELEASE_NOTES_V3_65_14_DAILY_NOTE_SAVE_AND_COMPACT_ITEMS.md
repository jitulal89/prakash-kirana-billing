SiddhiBill v3.65.14 – Daily Notebook save diagnostics and compact item entry

Changes:
- Initialized dailyEntries defensively for older saved app states.
- Added explicit save failure handling/status instead of allowing an unhandled error during Save note.
- Changed the global runtime error dialog heading from Sharing diagnostics to App diagnostics so unrelated script failures are not mislabeled.
- Replaced per-item product search with a single continuous Daily Notebook product search field.
- Search results allow selecting existing products or opening Product Master with the search term prefilled.
- Added compact horizontal product note rows with product name/unit/rate, editable quantity/unit/rate, amount and remove action.
- Bumped Android version to 3.65.14 / versionCode 286.

Validation: JavaScript syntax check and ZIP integrity check. Android build and device tests not run.
