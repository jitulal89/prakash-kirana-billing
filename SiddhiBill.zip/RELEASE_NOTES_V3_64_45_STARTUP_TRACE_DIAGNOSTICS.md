# SiddhiBill v3.64.45 – Startup Trace Diagnostics

- Based on the v3.64.44 Startup Restore Performance Fix v2 baseline.
- Adds startup milestone timings, paint timings, module-initialisation duration, supported Long Tasks API measurements, and runtime error capture.
- Adds Settings > Startup Performance Trace with copy/exportable text.
- Does not change database schema, migrations, restore flow, transaction loading, or business logic.
- Retains the Customer Ledger large-PDF page-capture correction.
- Diagnostic limitation: home-ready is a first-two-animation-frames proxy unless the app explicitly calls `window.__siddhiMarkHomeReady()`; Long Tasks API support varies by Android WebView.
