# SiddhiBill v3.65.9 — Barcode Scanner Java Compile Fix

- Fixed the Java compile error in `ProductBarcodeScannerActivity.createItemRow()`.
- Declared and inserted the row's remove button before attaching `remove.setOnClickListener(...)`.
- Kept the on-screen minus/plus quantity controls and editable unit/rate fields.
- Incremented Android version to 3.65.9 (versionCode 281) and updated the WebView cache version.

Validation: Java source scope/static regression and JavaScript syntax/regression checks passed; ZIP integrity passed. An Android Gradle compile was not run in this environment because Android SDK/Gradle wrapper are unavailable. Please run the GitHub Actions build to confirm compilation.
