# v3.65.7 — Barcode Quick List handoff

- Scanner action is now labeled Update Bill and invokes the billing Quick List handoff.
- Scanned rows are formatted as `Item Qty Unit Rate` in the billing Quick List textbox and passed through the existing Add List parser.
- Scanned products are also staged in Vendor Management purchase draft rows; this does not save a purchase invoice.
- Scanner remains portrait and the bottom action receives additional bottom inset padding.

Validation: JavaScript syntax and source ZIP integrity should be checked. Android Gradle build and physical device camera testing are still required.
