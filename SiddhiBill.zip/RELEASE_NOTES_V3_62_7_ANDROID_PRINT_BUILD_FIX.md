# SiddhiBill v3.62.7 — Android print API build fix

- Fixed Android Java compilation errors caused by attempting to instantiate inaccessible `PrintDocumentAdapter.LayoutResultCallback` and `WriteResultCallback` classes and directly calling adapter callbacks.
- Estimate PDF sharing entry point now uses Android's public `PrintManager.print()` API to render the estimate and open the system print dialog with the selected paper size.
- To share an estimate PDF to WhatsApp, choose **Save as PDF** in the system print dialog, then share the saved PDF from the device.

Validation: inspect Java source for removed callback construction and use of `PrintManager.print`; build execution is not guaranteed in this environment.
