# SiddhiBill v3.62.2 — Broker ledger and navigation fixes

- Fixed bill update handling to preserve an existing invoice number when the bill type is unchanged, refuse to silently create a new bill if the original edited bill cannot be found, and remove legacy duplicate copies of the updated invoice within the current shop.
- Broker selection is now reset for new bills and loaded only from the bill being edited, preventing a previous bill's broker from carrying into other bills.
- Broker selection is hidden and disabled when the current shop has no active broker configured.
- Broker dropdown options display the commission rate and percentage label.
- Added one consolidated all-broker ledger PDF report with From/To dates, transaction detail, broker-wise commission/payment summary, and outstanding balance as of the selected To date.
- Moved Team & Attendance, Brokers & Commission, and Estimates / Quotations shortcuts to the Home screen and removed them from More navigation.
- Version updated to 3.62.2 (versionCode 172).

Validation performed: JavaScript syntax check, key HTML/JS feature checks, and ZIP integrity check. No APK build or physical-device test was performed.
