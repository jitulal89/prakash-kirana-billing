# SiddhiBill v3.64.89 – Native GST and Team Member PDF Engine

## Changes
- Added an Android native PDF generator using `android.graphics.pdf.PdfDocument`.
- The generator accepts a structured report model (title, metadata paragraphs, KPI cards, section headings, table headers and rows) from the WebView bridge.
- Pages are drawn incrementally with automatic page breaks, repeated table headers, wrapped cell text, A4 portrait/landscape page dimensions and page numbering.
- Output is validated as a PDF byte stream and saved through SiddhiBill's existing duplicate-check and PDF save/open workflow.
- GST Compliance Summary, GSTR-1 Working Report, GSTR-3B Working Report and Team Member Report now convert their existing report HTML into a structured model and use the native generator. Their existing calculations and on-screen report content are unchanged.
- GSTR-1 uses landscape; the other migrated reports use portrait.
- Existing HTML/WebView print fallback remains for platforms without the native bridge.
- Version: 3.64.89; version code: 262.

## Validation limits
- JavaScript syntax check and source-routing assertions are performed.
- ZIP integrity is checked.
- Android Gradle compilation and on-device PDF output must still be verified through the user's GitHub Actions build and device.
