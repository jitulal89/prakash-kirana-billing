# SiddhiBill v3.65.11 — Daily Entry (Initial Source Implementation)

## Added
- Separate Daily Entry page accessible from More.
- Grouped transaction entry: select one customer/vendor for a transaction and add multiple products.
- Entry types: Sell, Buy, Money Received, Money Paid.
- Cash, Credit and Partial Payment choices for Buy/Sell; party selection required for customer receipts and vendor payments; vendor required for purchases.
- Daily entries persist locally in `pksDailyEntries`.
- Edit/delete entries before accounting finalization.
- Share selected date's entries as `SiddhiBill_DailyEntry_YYYY-MM-DD.siddhibill` through WhatsApp on Android.
- Import Daily Entry `.siddhibill` files from file picker or Android file-open flow.
- Same-shop validation and duplicate entry ID skipping on import.
- Existing whole-shop `.siddhisync` also merges Daily Entry records.
- Existing activation `.siddhibill` processing remains distinguished by the internal file format/type.

## Not yet included in this initial implementation
- End-of-day conversion/posting of Daily Entry groups into actual sales bills, purchase invoices, customer receipts, vendor payments, stock movements and ledger balances. The current Day Summary is review-only; do not use it as accounting finalization.
- Daily Entry GST/tax-invoice configuration and tax-aware posting.

## Validation
- JavaScript syntax (`node --check app/src/main/assets/www/app.js`): passed.
- HTML parser: passed.
- AndroidManifest XML parse: passed.
- ZIP integrity: to be checked at package time.
- Android Gradle build / device WhatsApp file handoff: not run in this environment.
