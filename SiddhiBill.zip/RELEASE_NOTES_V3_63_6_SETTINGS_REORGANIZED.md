# SiddhiBill v3.63.6 — Settings sections reorganized

- Reorganized Settings into six collapsible sections: Shop & Business Profile, Billing Details, Footer & Printer Settings, Modules, Custom Fields & UPI, and Printing & Bill Display.
- Moved individual controls into their requested sections rather than grouping mixed layout grids.
- Corrected FSSAI label spelling to “License Details”.
- Moved “Build the date-based follow-up report” into the Custom Billing Fields popup only.
- Kept Save Settings and settings status at the bottom of the Settings page.
- Existing control IDs and save bindings are preserved.
- No APK build or physical-device test performed.
