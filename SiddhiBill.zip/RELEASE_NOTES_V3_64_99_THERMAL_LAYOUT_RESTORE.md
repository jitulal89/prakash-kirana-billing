# SiddhiBill v3.64.99 — Thermal Print Restore

- Restored the text-based Last 5 Transactions layout for direct 80mm thermal printing, matching the earlier v3.64.92-style compact layout.
- Kept the current item table raster rendering and printer pacing/locking logic.
- Restored Previous Balance display with a fallback derived from balance, debit, and credit when the explicit previous-balance snapshot is absent.
- Added a subtle 3.5% horizontal widening to numeric item values to improve 6/8 readability without changing font size or table structure.
- A4 PDF and WebView rendering were not changed.
