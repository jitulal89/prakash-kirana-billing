# SiddhiBill v3.64.96 — Shared 80mm Credit Transaction History Fix

## Root cause
The 80mm raster/PDF transaction-history renderer classified a transaction using only `type`. Customer sale rows can intentionally carry `type: "Sale"` while their credit classification is carried by `label` and/or `paymentMode`. The type-only check therefore treated credit sales as fully paid and substituted the full bill total.

## Changes
- Added shared native helpers to classify credit-sale and payment-history rows using normalized `label`, `paymentMode`, and `type`.
- Added a shared paid-amount resolver that uses recorded payment fields for credit bills, including explicit zero values.
- Applied the shared calculation to the 80mm PDF/raster history, ESC/POS text history, and bitmap thermal history paths.
- Kept A4 PDF and WebView rendering paths unchanged.
- Bumped app version to 3.64.96 (versionCode 269) and updated the WebView cache-buster.

## Expected examples
- Credit bill ₹100, paid ₹0 => Paid ₹0, balance ₹100.
- Credit bill ₹95, paid ₹50 => Paid ₹50, balance ₹45.
- Cash bill ₹275, no separate payment record => Paid ₹275.

## Validation
- `node --check app/src/main/assets/www/app.js`
- `node test_v36496_shared_80mm_credit_history.js`
- `node test_v36495_credit_thermal_history.js` (historical test updated to assert shared helper usage)
- ZIP integrity check.

Android Gradle compilation and physical 80mm printer testing were not performed in this environment.
