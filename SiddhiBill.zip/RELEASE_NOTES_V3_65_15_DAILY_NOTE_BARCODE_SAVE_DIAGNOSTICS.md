# SiddhiBill v3.65.15 — Daily Notebook barcode scan and save diagnostics

- Added an explicit Scan button next to the Daily Notebook product search.
- Routed barcode scans from the existing native scanner into Daily Notebook: known products are added directly to the current note; unknown barcodes open Add Product with the barcode prefilled, then add the newly created product and resume scanning.
- Tightened mobile notebook line layout so product, Qty, Unit, Rate, amount and remove control use horizontal space and avoid unnecessary wrapping.
- Removed misleading zero-rate text from the product subtitle; unit is shown there while editable rate and computed line amount remain visible.
- Wrapped the entire Daily Entry save/refresh flow in exception diagnostics and show the error details in the Daily Notebook UI. Restore the previous notebook entry array when the save call explicitly fails.
- Preserved the app package, database, existing state keys and offline behavior.

Validation performed: JavaScript syntax check and ZIP integrity check. Android Gradle build and physical-device camera/database test were not run.
