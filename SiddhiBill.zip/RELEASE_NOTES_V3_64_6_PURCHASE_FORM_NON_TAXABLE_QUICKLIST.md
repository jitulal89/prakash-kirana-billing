# SiddhiBill v3.64.6 — Purchase Entry UX and Non-Taxable Quick List

- Reorganized Purchase Bill Entry into clear Bill Details, GST / Tax Details, and Charges & Payment sections styled consistently with the Billing form.
- New purchase bills default to **Taxable bill unchecked**. Existing saved purchase records retain their saved taxable/non-taxable flag when edited.
- GST-specific controls (amount mode, supplier state/state code/PAN, reverse charge, declared taxable value, declared GST, and TCS) are hidden unless Taxable bill is checked.
- Selecting Bill of Supply turns taxable mode off; selecting Tax Invoice no longer automatically overrides the user's checkbox choice.
- Non-taxable Quick List accepts `ITEM,QTY,UNIT,TOTAL`, for example `Button,100,pc,500`.
- Tax %, HSN/SAC, and barcode remain optional additional columns; the existing parser and OCR row formats are retained.
- OCR that clearly detects a declared GST amount or tax-rate-bearing item rows automatically enables taxable mode so detected tax information is not silently ignored.
- Version updated to 3.64.6 / versionCode 196. Application ID, database name, and existing local-storage keys are unchanged.

Validation performed: JavaScript syntax check; four-column Quick List parser test; existing Quick List, product-master fallback, taxable-bill and amount-mode tests. Android Gradle build and physical-device testing were not performed.
