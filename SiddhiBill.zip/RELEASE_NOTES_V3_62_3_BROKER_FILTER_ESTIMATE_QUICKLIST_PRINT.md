# SiddhiBill v3.62.3 — Broker Report Filters and Estimate Quick List / Print

- Added an optional broker filter to the consolidated broker ledger PDF; blank means all brokers. Date range still applies to commissions and payments, and outstanding remains cumulative through the selected To date.
- Estimates now support Billing-style Quick List text entry, product master lookup/autofill on item rows, optional customer name and mobile, and a Print / PDF popup with Message, WhatsApp, PDF, Print, and paper-size selection (58 mm, 80 mm, A6, A4).
- Estimate customer mobile is stored with the estimate and carried into conversion to a bill.
- Version 3.62.3 (versionCode 173).

Validation: JavaScript syntax, feature assertions, and ZIP integrity checked. APK build and physical-device testing were not performed.
