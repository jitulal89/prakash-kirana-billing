# SiddhiBill v3.64.91 – Quick List Merge and Ledger Unit Calculation Fix

## Changes
- Quick List merge now triggers the bill recalculation after programmatically increasing an existing row quantity. The displayed line amount, subtotal, discount, tax and grand total refresh immediately.
- Added a shared unit-aware ledger amount calculation using the same `quantityValue` normalization as billing.
- Customer Ledger item amounts now calculate from normalized quantity × rate, so 500 gram at ₹180/kg displays ₹90 rather than ₹90,000.
- Vendor Ledger uses normalized quantity for its fallback line amount when no persisted line total exists; stored inclusive invoice line totals remain authoritative.
- Existing bill/purchase records are not rewritten. Only ledger calculation/display and current bill recalculation behavior change.
- Version 3.64.91; version code 264.

## Validation
- `node --check app/src/main/assets/www/app.js` passed.
- Customer ledger item-comment regression test passed.
- Source assertions confirm merge calls `calc()` and both ledger amount paths use unit-aware quantity calculation.
- Older tests that expect obsolete source signatures or historical version numbers are not valid for this release; those were not treated as passing.
- Android Gradle build and on-device validation remain pending.
