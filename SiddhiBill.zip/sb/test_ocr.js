const fs=require('fs'),vm=require('vm');
const src=fs.readFileSync(__dirname+'/app/src/main/assets/www/app.js','utf8');
const start=src.indexOf('window.receiveQuickListOCR=function(text){');
const end=src.indexOf('\n};\n\n// SiddhiBill starter catalogues',start)+3;
if(start<0||end<4)throw Error('OCR function not found');
const fn=src.slice(start,end);
const products=['Toor Dal','Chana','Sugar','Rice','Kaju','Shampoo','Elaichi','Lipstick Red','Face Powder','Hair Clips','Imitation Earrings','Ladies Purse'].map(name=>({name,unit:'Kg',rate:100}));
const aliases={};
const units=[
 {name:'Kg',aliases:['kg','kgs','k']},{name:'Gram',aliases:['g','gm','gram','grams']},{name:'Piece',aliases:['pc','pcs','piece','pieces']},{name:'Pair',aliases:['pair']},{name:'Pack',aliases:['pack']},{name:'Packet',aliases:['pkt','packet']},{name:'Bottle',aliases:['b','btl','bottle']},{name:'Litre',aliases:['l','ltr','litre','liter']},{name:'Ml',aliases:['ml']},{name:'Set',aliases:['set','sets']},{name:'Box',aliases:['box']},{name:'Dozen',aliases:['doz','dozen']},{name:'Job',aliases:['job','jobs']},{name:'Hour',aliases:['hour','hours','hr','hrs']},{name:'Meter',aliases:['meter','metre','m']},{name:'Foot',aliases:['foot','feet','ft']},{name:'Roll',aliases:['roll','rolls']}];
const box={value:'',focus(){}};const ctx={window:{},state:{products,settings:{ocrProductAliases:aliases}},$:(id)=>id==='quickList'?box:null,showNotice(){},getUnitDefinitions:()=>units,getOcrProductVocabulary:()=>products.map(p=>({name:p.name,aliases:Object.entries(aliases).filter(([a,t])=>t===p.name).map(([a])=>a)})),ensureOcrAliases:()=>aliases,ocrNorm:s=>String(s||'').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' '),applyOcrProductAliasesToLine:s=>s,normalizeUnitName:u=>{const t=String(u||'').toLowerCase();for(const d of units)if(d.aliases.includes(t))return d.name;return u||'Kg'}};
const dbg=fn.replace('if(vocabFirst){','console.log("VF",line,unitAlt,vocabFirst); if(vocabFirst){').replace('const product=matchShopProduct(vocabFirst[1].trim());','const product=matchShopProduct(vocabFirst[1].trim()); console.log("MATCH",vocabFirst[1],product);'); vm.createContext(ctx);vm.runInContext(dbg,ctx);
const cases=[
 ['Chana - 1 Kg - Rs 100','Chana 1 Kg 100'],
 ['Sugar - 2 Kg - Rs 60','Sugar 2 Kg 60'],
 ['Shampoo - 1 Bottle - Rs 200','Shampoo 1 Bottle 200'],
 ['Elaichi 20g - 1 Packet - Rs 50','Elaichi 20g 1 Packet 50'],
 ['Lipstick Red - 2 Piece - Rs 120','Lipstick Red 2 Piece 120'],
 ['Toondal 1K 170','Toor Dal 1 Kg 170'],
 ['Chane lkg lo0','Chana 1 Kg 100'],
 ['Sugar 1 Kg 60','Sugar 1 Kg 60'],
 ['Rice zkg 0','Rice 2 Kg 0'],
 ['Chana 1 Kg 100','Chana 1 Kg 100'],
 ['Kaju 1 Kg 1100','Kaju 1 Kg 1100'],
 ['Shampoo 1 Bottle 200','Shampoo 1 Bottle 200'],
 ['Sugar lkg 60','Sugar 1 Kg 60'],
 ['Rice 2kg 70','Rice 2 Kg 70'],
 ['Elaichi 20g 1 Packet 50','Elaichi 20g 1 Packet 50'],
 ['1 Lipstick Red 2 Piece 120','Lipstick Red 2 Piece 120'],
 ['Imitation Earrings 1 Pair 250','Imitation Earrings 1 Pair 250']
];
let failed=0;
for(const [input,expected] of cases){box.value='';ctx.window.receiveQuickListOCR(input);const actual=box.value.trim();const pass=actual===expected;console.log(`${pass?'PASS':'FAIL'} | ${input} => ${actual} | expected ${expected}`);if(!pass)failed++;}
if(failed)process.exit(1);
