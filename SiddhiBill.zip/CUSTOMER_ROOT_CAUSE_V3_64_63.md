# Detailed Root Cause — Customer Side Hang (v3.64.62)

## Symptom-to-code mapping

| User symptom | Confirmed path in source | Why it could block the WebView |
|---|---|---|
| Existing bill Update hangs | Bill generation/update calculates `customerTotalBalance` through `customerDue()` | `customerDue()` read `state.bills`, invoking the lazy transaction getter and synchronously reading/parsing the complete sales history. |
| View bill → Print/PDF hangs | Print customer dialog calls `updateBillPaymentFollowUpVisibility()` → `customerDue()`; optional last-five-transaction preparation called `customerTransactions()` | The balance lookup and last-five lookup both had full-history paths. |
| New bill generation hangs | New bill construction calculates `customerTotalBalance` through `customerDue()` | Same full-history load on the bill-generation path. |
| Customer tab does not open | `renderCustomers()` → `getCustomerRecords()` iterated all `state.bills`; sales/latest-date sort helpers filtered all bills once per customer | Full history was loaded and repeatedly scanned on the UI thread; cost grew with both bill count and customer count. |
| Customer Ledger does not work / hangs | `openCustomerLedgerPdf()` filtered `state.bills` before selecting a customer's date range | Full sales history was materialized even though the ledger needs only one customer and a bounded period. Customer transaction View Bill also used a full-array lookup. |

## Root cause

The v3.64.62 source intentionally deferred `pksBills` loading to avoid transferring large transaction history into JavaScript at startup. However, customer-side functions still dereferenced `state.bills`. The lazy getter performs synchronous native SQLite reads in chunks followed by JSON parsing on the WebView JavaScript thread. As a result, unrelated customer actions could trigger a large blocking read and make the application appear frozen.

## Fix architecture in v3.64.63

1. `loadCustomerCreditSummary` returns one compact row per customer with credit sales, total sales, bill count, latest bill date, phone and reminder metadata.
2. `customerDue()` uses that summary plus customer payment records; it no longer dereferences the full bill array on Android.
3. Customer Master combines the saved customer master with compact bill summaries. Sales and latest-bill sorting use summary values, not repeated scans.
4. New `loadCustomerBills(customer, from, to, shopKey)` bridge method returns only the selected customer's bill rows, optionally constrained by date range.
5. Customer Ledger uses that customer/date-scoped query.
6. Customer transaction history loads bills for the selected customer only. The View Bill action loads one exact SQLite transaction only when tapped, rather than loading all bills or making one native lookup per displayed row.
7. Customer renaming updates matching bill JSON directly in SQLite, without loading the full bill array into JavaScript.
8. An additive SQLite expression index supports customer-scoped bill queries. Existing database version, tables, records and app identity are preserved.

## Validation status

Passed: JavaScript syntax check; customer workflow source assertions; report source regression assertions; service-due report regression; Customer Ledger item-comment regression; SQLite expression-index/query smoke test; ZIP integrity check.

Not performed: Android Gradle compilation, GitHub Actions build, and physical-device interaction/print tests. Those are still required before claiming device-level certification. No data-clearing or reinstall step is required for this source change.
