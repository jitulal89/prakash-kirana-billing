# SiddhiBill v3.62.5

- Estimate Print now follows Billing's native printer path for 80 mm direct Bluetooth thermal printing. Estimate heading and estimate number are printed; payment/paid lines are suppressed. The shop-header checkbox is respected by the native print payload. A4/A6 continue to use the Android print dialog.
- Added bulk attendance entry for a selected date range (weekly/monthly or custom), for one active team member or all active team members. Existing entries are skipped by default; an explicit overwrite checkbox allows corrections.
- Added Team Member Report PDF for a selected member or all active team members and a date range. Includes attendance entries/status totals, estimated salary, recorded advances/payments and (for sales-enabled members) sales bill totals and item details.
- Validation: JavaScript syntax and ZIP integrity checks run. No APK build or physical-device test performed.
