const fs=require('fs');
const src=fs.readFileSync('app/src/main/assets/www/app.js','utf8');
function assert(ok,msg){if(!ok)throw new Error(msg);}
assert(src.includes('function vendorById(id){const key=String(id??"").trim();'), 'vendor ID normalization missing');
assert(src.includes('normalizeLedgerDate(p.date||p.invoiceDate)'), 'vendor purchase date normalization missing');
assert(src.includes('String(m.sourceType||\'\').trim().toLowerCase()===\'sale\''), 'P&L sale movement normalization missing');
assert(src.includes('taxTotal??b.taxTotalAmount??b.gstAmount??b.taxAmount'), 'P&L tax fallback missing');
assert(src.includes('const inPeriod=r=>{const d=String(r?.date||\'\').slice(0,10);return d>=from&&d<=to;}'), 'team report date filter missing');
assert(src.includes('visibility:visible;opacity:1'), 'team report visibility fix missing');
assert(src.includes('Android.printHtmlDocument(html,`Team_Member_Report_'), 'team report native PDF bridge missing');
console.log('PASS: 7 report source assertions');
