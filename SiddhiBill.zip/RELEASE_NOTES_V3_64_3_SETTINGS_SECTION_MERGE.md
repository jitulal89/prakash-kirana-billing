# SiddhiBill v3.64.3 — Printing Settings Section Merge

- Moved all Printing & Bill Display controls into the final collapsible settings section.
- Removed the old standalone Printing & Bill Display card so the heading and controls do not appear twice.
- Kept the existing checkbox IDs and save/load wiring so stored preferences continue to be used.
- Reformatted Print Terms & Conditions as the same simple checkbox row as the other print options.
- Updated Android version to 3.64.3 (versionCode 193).

Validation: JavaScript syntax and ZIP integrity checked. Android Gradle build and device UI testing were not performed.
