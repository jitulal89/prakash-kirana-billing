# SiddhiBill v3.64.2 — Print Settings and PDF Item Headers

- Restored the Printing & Bill Display checkbox group for shop name, address, mobile, logo, customer name/mobile, payment mode, and item code.
- Kept the Terms & Conditions print toggle in the same consistent checkbox-list format as the other print options.
- Saved and loaded all restored checkbox values through the existing shop settings.
- In A4/A6 PDF item headers, right-aligned HSN/SAC, UNIT, and GST labels to their respective column edges; changed the GST column label to `GST` (without `%`).
- Changed app version to 3.64.2 (versionCode 192).

Validation: JavaScript syntax check and ZIP integrity check passed. Android Gradle build/device PDF rendering were not run in this environment.
