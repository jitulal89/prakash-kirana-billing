# SiddhiBill v3.64.58 — Report fixes

## Changes
- Vendor lookup now compares IDs as normalized strings, matching HTML select values with stored numeric or string IDs.
- Vendor Ledger now normalizes ISO and DD/MM/YYYY dates, includes shop scoping where shop keys are present, and handles invoice number fallbacks consistently.
- Profit & Loss date filtering now normalizes stored date formats; sale COGS movements are matched case-insensitively and invalid cost values are excluded. Sales GST deduction recognizes the supported tax amount field variants.
- Team report filters use a shared date-range predicate and report sections have explicit visible/block layout with safer page-break behavior for Android WebView PDF capture.

## Validation
- JavaScript syntax checked with `node --check`.
- ZIP integrity checked with `unzip -t`.
- Source-level assertions checked for all three report paths.
- Android Gradle build and physical-device PDF validation were not run in this environment.
