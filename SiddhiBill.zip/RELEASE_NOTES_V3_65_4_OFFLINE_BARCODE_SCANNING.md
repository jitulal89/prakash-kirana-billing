# SiddhiBill v3.65.4 — Offline barcode scanning

## Added
- Native Android ZXing barcode scanning bridge for common 1D product barcodes (EAN/UPC/Code 128 and supported 1D formats).
- Billing `Scan Barcodes` workflow with a staging list before bill insertion.
- Repeated scans of the same barcode increment staged quantity.
- Staged quantities can be adjusted or removed before tapping `Update Bill`.
- Product master barcode field includes a native scan action.
- Unknown barcode prompts to create a product and pre-fills the barcode; saving the product stages it for the current bill.
- Barcode lookup normalizes whitespace and hyphens and checks barcode/EAN/UPC fields.
- Duplicate barcode assignment is prevented when saving a product.
- Existing SQLite state, product records, bill calculation and bill generation remain in use.

## Build metadata
- Version name: 3.65.4
- Version code: 277

## Validation
- `node --check app/src/main/assets/www/app.js` passed.
- `node test_v3654_barcode_scanning.js` passed.
- ZIP integrity check passed.
- Android APK build/device camera test not run in this environment (Gradle executable/wrapper unavailable).
