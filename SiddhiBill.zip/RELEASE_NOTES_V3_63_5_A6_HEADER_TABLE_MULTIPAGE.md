# SiddhiBill v3.63.5 — A6 Header, Table and Multi-page Layout

- Reduced A6 PDF text scaling from 1.45x to 1.16x (approximately 20% smaller than the previous A6 font scaling).
- Increased A6 top header margin to reduce first-line clipping.
- Uppercased key header labels such as GSTIN, FSSAI, MO, ADDRESS, PAYMENT, invoice number and date.
- Standardized item table headings to SR., ITEM, HSN/SAC, QTY, UNIT, RATE and AMOUNT.
- Widened the A6 GST rate summary to the full page width and moved totals into a separate block beneath it.
- Added a compact A6 continuation header for additional pages instead of repeating the full shop/customer header.
- A4 and 58/80mm thermal layouts are intended to remain unchanged.

Validation: source-level checks and ZIP integrity only. APK compilation and physical printer testing have not been performed.
