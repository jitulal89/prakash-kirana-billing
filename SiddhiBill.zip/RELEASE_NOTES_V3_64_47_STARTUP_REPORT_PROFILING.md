# SiddhiBill v3.64.47 – Startup Report Profiling

- Based on the supplied v3.64.46 Startup Trace Diagnostics Settings Fix source.
- Preserves the Settings diagnostics panel and Customer Ledger large-PDF fix already present in the base source.
- Adds timing checkpoints inside the startup-triggered `renderReports()` execution, including transaction loading/filtering, sales summaries, customer balances, product summaries, service due, and payment transaction summaries.
- Adds the overall duration and record count for the startup `setReportThisMonth()` call to the exported startup trace.
- Updates Android version to 3.64.47 (versionCode 220) and refreshes the app.js cache-busting version.
- Diagnostic instrumentation only: no database schema, migration, backup/restore, transaction data, report calculations, or business rules intentionally changed.
- This release identifies which report phase consumes startup time; it does not claim to fix the startup delay.
- JavaScript syntax and ZIP integrity checks passed. Android APK build and device testing have not been performed here.
