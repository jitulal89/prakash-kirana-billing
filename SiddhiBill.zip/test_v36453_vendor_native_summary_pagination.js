const fs = require('fs');
const app = fs.readFileSync('app/src/main/assets/www/app.js','utf8');
const db = fs.readFileSync('app/src/main/java/com/dukaanbill/app/LocalDatabase.java','utf8');
const bridge = fs.readFileSync('app/src/main/java/com/dukaanbill/app/MainActivity.java','utf8');
function ok(v,m){if(!v)throw new Error(m);}
ok(app.includes('readNativeVendorSummary()'), 'vendor summary bridge helper missing');
ok(app.includes('renderVendorAccountsFromSummary(summary)'), 'vendor account aggregate renderer missing');
ok(app.includes('renderVendorPaymentsOnly()'), 'vendor payment isolated renderer missing');
ok(app.includes('readNativePurchasePage(offset,TRANSACTION_PAGE_SIZE,q)'), 'purchase history native pagination missing');
ok(db.includes("json_each(s.state_value)"), 'SQLite JSON aggregation/pagination missing');
ok(db.includes('LIMIT ? OFFSET ?'), 'native page limit/offset missing');
ok(bridge.includes('loadVendorSummary()') && bridge.includes('loadPurchaseHistoryPage('), 'Android bridge endpoints missing');
console.log('v3.64.53 vendor native summary and pagination checks passed');
