# Prakash Kirana Stores Voice Billing V2

This version adds:
- Voice billing
- English/Hindi/Marathi voice language selector
- Automatic date
- Automatic sequential bill number
- Product master with default rates
- Auto-rate lookup when product name is recognized
- Bill history
- Search bills
- Print / Save as PDF
- Installable PWA
- Basic offline cache
- Mobile-first interface

Example:
"Customer Ramesh, Singdana 1 kg 180, Sabudana 2 kg 90, Sugar 10 kg 60."

For installation, deploy over HTTPS. Chrome on Android can install a supported PWA as an app. Voice recognition support depends on browser/platform.
