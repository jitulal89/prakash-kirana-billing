package com.prakashkirana.billing;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONObject;

import java.util.Iterator;

public class LocalDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "prakash_kirana.db";
    private static final int DB_VERSION = 1;

    public LocalDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS app_state (state_key TEXT PRIMARY KEY, state_value TEXT NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS meta (meta_key TEXT PRIMARY KEY, meta_value TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    public synchronized String loadState() {
        JSONObject out = new JSONObject();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT state_key,state_value FROM app_state", null)) {
            while (c.moveToNext()) {
                out.put(c.getString(0), c.getString(1));
            }
        } catch (Exception ignored) {}
        return out.toString();
    }

    public synchronized void saveState(String json) throws Exception {
        JSONObject obj = new JSONObject(json == null ? "{}" : json);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                ContentValues cv = new ContentValues();
                cv.put("state_key", key);
                cv.put("state_value", obj.optString(key, ""));
                db.insertWithOnConflict("app_state", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }
}
