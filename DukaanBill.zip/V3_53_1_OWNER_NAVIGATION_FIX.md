# Dukaan Bill v3.53.1

Fixes:
- Back to Billing from Owner activation/dashboard now uses a UI-thread native navigation path.
- Owner Dashboard opened from Billing now explicitly opens activation.html?owner=1 and the page detects that parameter and opens the Owner Dashboard automatically.
- Owner activation completion uses the same robust Billing navigation.
- Existing simplified multi-shop design is preserved: Owner configures own business in Settings; additional shops are configured/managed from Owner Dashboard; no Owner-created shop activation QR.
