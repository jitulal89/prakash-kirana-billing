package com.dukaanbill.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.print.PageRange;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.graphics.Bitmap.CompressFormat;
import android.view.WindowInsets;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.android.gms.tasks.Tasks;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.UUID;
import java.security.MessageDigest;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;
import android.util.DisplayMetrics;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import javax.crypto.Mac;
import java.nio.charset.StandardCharsets;
import java.nio.charset.Charset;
import java.util.Set;
import android.app.AlertDialog;
import android.widget.EditText;
import android.text.InputType;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import android.util.Base64;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_BT_PRINT = 7001;
    private String pendingDirectPrintJson;
    private static final int REQ_PURCHASE_DOCUMENT = 9011;
    private static final int REQ_BACKUP_CREATE = 9012;
    private static final int REQ_BACKUP_RESTORE = 9013;
    private static final int REQ_WEB_FILE_CHOOSER = 9014;
    private ValueCallback<Uri[]> webFileCallback;
    private static final String BACKUP_DB_ENTRY = "database/dukaanbill.db";
    private static final String BACKUP_STATE_ENTRY = "database/app_state.json";
    private static final String BACKUP_IDENTITY_ENTRY = "security/shop_identity.sig";
    // Shop-name password is never stored in the WebView/JavaScript. The release stores only a salted, iterated digest.
    private static final String SHOP_PASSWORD_SALT_HEX = "b3d98978922aaabc368ea51ec188ff8d";
    private static final String SHOP_PASSWORD_DIGEST_HEX = "bc53398cdf28d9799555c3c64bfcf6f4f767040fba3e23bfc48c3dcf7da5a743";
    private static final int SHOP_PASSWORD_ITERATIONS = 200000;
    private static final String OWNER_PUBLIC_KEY_B64 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtY03iAdf43OFBRxNSkevWkJC4nJXLthXn3PBbPahDd5bleS9NemELweCBfQurYtdI4QGGm6dxpNTcPK6gylJAN8Uu3fZ5hlZ+ecvOMxy2yJAwRKUA9Hn/96LfjuBkuHnnVLUA7aXQqwpM0ggWH0TMEvgp/yBbErjwJEZeuonx96gNnNA2a2IKi/DNtjhgeAnyOBkLuswc+Gma9xHWsYuj7phEW1O6cYaBJJ8w28NgLfkuDKg50ln+9kItxpojrYaVOXWr2gSUVxiWd8GNECgU8KOkWco9F45Qx7HS0ydfpYOorDG9l51DrJ76eVls8xDYiYscaEZ8RPrkSw6UmkRsQIDAQAB";
    private static final String DEVICE_KEY_ALIAS = "DukaanBillDeviceKey";
    private static final String OWNER_PREFS = "owner_security";
    private static final int REQ_SCAN_QR = 9901;
    private static final String OWNER_PRIVATE_PREF = "encrypted_private";
    private static final String OWNER_SALT_PREF = "salt";
    private static final String OWNER_IV_PREF = "iv";

    private File purchaseDocsDir;
    private LocalDatabase localDb;
    private File pendingBackupZip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Keep the WebView inside the Android system bars. The web UI supplies its own safe margins.
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(true);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(242,244,247));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(36,70,111));
        webView = new WebView(this);
        webView.setFitsSystemWindows(true);
        setContentView(webView);

        purchaseDocsDir = new File(getFilesDir(), "purchase_docs");
        if (!purchaseDocsDir.exists()) purchaseDocsDir.mkdirs();
        localDb = new LocalDatabase(this);
        PDFBoxResourceLoader.init(getApplicationContext());

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Clear WebView HTTP/service-worker cache on each launch. App data lives in native SQLite,
        // so this is safe and prevents an older bundled app.js from shadowing current button handlers.
        webView.clearCache(true);
        webView.clearHistory();
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (webFileCallback != null) webFileCallback.onReceiveValue(null);
                webFileCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, REQ_WEB_FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    webFileCallback = null;
                    Toast.makeText(MainActivity.this, "Could not open file picker: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
        if (isActivated()) webView.loadUrl("file:///android_asset/www/index.html");
        else webView.loadUrl("file:///android_asset/www/activation.html");
        handleIncomingDukaanBill(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingDukaanBill(intent);
    }

    private boolean isActivated() { return getSharedPreferences("activation", MODE_PRIVATE).getBoolean("activated", false); }
    private void setActivated(boolean v) { getSharedPreferences("activation", MODE_PRIVATE).edit().putBoolean("activated", v).apply(); }
    private PublicKey ownerPublicKey() throws Exception { return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.decode(OWNER_PUBLIC_KEY_B64, Base64.DEFAULT))); }
    private KeyPair deviceKeyPair() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (ks.containsAlias(DEVICE_KEY_ALIAS)) return ((KeyStore.PrivateKeyEntry)ks.getEntry(DEVICE_KEY_ALIAS,null)).getPrivateKey()==null?null:new KeyPair(ks.getCertificate(DEVICE_KEY_ALIAS).getPublicKey(),((KeyStore.PrivateKeyEntry)ks.getEntry(DEVICE_KEY_ALIAS,null)).getPrivateKey());
        KeyPairGenerator g=KeyPairGenerator.getInstance("RSA","AndroidKeyStore");
        g.initialize(new android.security.keystore.KeyGenParameterSpec.Builder(DEVICE_KEY_ALIAS, android.security.keystore.KeyProperties.PURPOSE_SIGN|android.security.keystore.KeyProperties.PURPOSE_VERIFY).setDigests(android.security.keystore.KeyProperties.DIGEST_SHA256).setSignaturePaddings(android.security.keystore.KeyProperties.SIGNATURE_PADDING_RSA_PKCS1).setKeySize(2048).build());
        return g.generateKeyPair();
    }
    private String b64(byte[] b){ return Base64.encodeToString(b,Base64.NO_WRAP); }
    private byte[] unb64(String s){ return Base64.decode(s,Base64.DEFAULT); }
    private String devicePublicKeyB64() throws Exception { return b64(deviceKeyPair().getPublic().getEncoded()); }
    private String createActivationRequest() throws Exception { return createActivationRequest("SHOP"); }
    private String createActivationRequest(String deviceType) throws Exception {
        JSONObject o=new JSONObject(); o.put("type","DUKAAN_ACTIVATION_REQUEST"); o.put("version",2); o.put("requestId",UUID.randomUUID().toString()); o.put("deviceKey",devicePublicKeyB64()); o.put("deviceType",deviceType==null?"SHOP":deviceType); o.put("appVersion","3.52.0"); o.put("createdAt",System.currentTimeMillis());
        if("SHOP".equalsIgnoreCase(deviceType)) {
            android.content.SharedPreferences sp=getSharedPreferences("activation",MODE_PRIVATE);
            String setup=sp.getString("pending_shop_setup",null);
            if(setup!=null) {
                try { JSONObject inv=verifyShopSetupInvite(setup); o.put("shopSetupId",inv.optString("setupId")); o.put("shopName",inv.optString("shopName")); o.put("shopMobile",inv.optString("shopMobile")); o.put("managerName",inv.optString("managerName")); o.put("address",inv.optString("address")); o.put("gstin",inv.optString("gstin")); o.put("state",inv.optString("state")); } catch(Exception ignored) {}
            }
        }
        return o.toString();
    }
    private byte[] deriveOwnerKey(String pin, byte[] salt) throws Exception { PBEKeySpec spec=new PBEKeySpec(pin.toCharArray(),salt,120000,256); return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
    private String normalizeOwnerPrivateKeyInput(String input) throws Exception {
        if (input == null) throw new Exception("Owner private key is empty");
        String s=input.trim();
        // Accept raw Base64, PEM, or the complete distributed Owner key text file.
        int begin=s.indexOf("-----BEGIN ");
        if(begin>=0){
            int firstNl=s.indexOf('\n',begin);
            int endMarker=s.indexOf("-----END ", begin);
            if(firstNl>=0 && endMarker>firstNl) s=s.substring(firstNl+1,endMarker);
        }
        StringBuilder b=new StringBuilder();
        String[] lines=s.replace("\r","\n").split("\n+");
        for(String line:lines){
            String t=line.trim();
            if(t.isEmpty() || t.startsWith("-----")) continue;
            // Ignore the two human-readable lines in the supplied key file.
            if(t.equalsIgnoreCase("DUKAAN BILL OWNER PRIVATE KEY") || t.equalsIgnoreCase("KEEP THIS FILE PRIVATE. DO NOT SHARE.")) continue;
            if(t.matches("[A-Za-z0-9+/=]+")) b.append(t);
        }
        String out=b.toString();
        if(out.length()<100 || (out.length()%4)!=0) throw new Exception("Invalid Owner private key. Paste the complete contents of DukaanBill_Owner_Private_Key.txt.");
        return out;
    }
    private void saveOwnerPrivate(String keyB64,String pin) throws Exception {
        String normalized=normalizeOwnerPrivateKeyInput(keyB64);
        byte[] raw=unb64(normalized); PrivateKey pk=KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(raw));
        byte[] challenge="DUKAAN-BILL-OWNER-KEY-CHECK".getBytes(StandardCharsets.UTF_8); Signature sig=Signature.getInstance("SHA256withRSA"); sig.initSign(pk); sig.update(challenge); byte[] signed=sig.sign(); Signature vs=Signature.getInstance("SHA256withRSA"); vs.initVerify(ownerPublicKey()); vs.update(challenge); if(!vs.verify(signed)) throw new Exception("Owner key does not match this Dukaan Bill release");
        byte[] salt=new byte[16]; new java.security.SecureRandom().nextBytes(salt); byte[] iv=new byte[12]; new java.security.SecureRandom().nextBytes(iv); byte[] aes=deriveOwnerKey(pin,salt); Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(aes,"AES"),new GCMParameterSpec(128,iv)); byte[] enc=c.doFinal(raw);
        getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).edit().putString(OWNER_PRIVATE_PREF,b64(enc)).putString(OWNER_SALT_PREF,b64(salt)).putString(OWNER_IV_PREF,b64(iv)).apply();
    }
    private PrivateKey loadOwnerPrivate(String pin) throws Exception { android.content.SharedPreferences p=getSharedPreferences(OWNER_PREFS,MODE_PRIVATE); String e=p.getString(OWNER_PRIVATE_PREF,null); if(e==null)throw new Exception("Owner key is not configured"); byte[] aes=deriveOwnerKey(pin,unb64(p.getString(OWNER_SALT_PREF,""))); Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(aes,"AES"),new GCMParameterSpec(128,unb64(p.getString(OWNER_IV_PREF,"")))); return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(c.doFinal(unb64(e)))); }
    private String encryptOwnerKeyForDevice(String keyB64, String deviceKeyB64) throws Exception {
        PublicKey devicePub=KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(unb64(deviceKeyB64)));
        byte[] raw=unb64(keyB64);
        byte[] aesRaw=new byte[32]; new java.security.SecureRandom().nextBytes(aesRaw);
        byte[] iv=new byte[12]; new java.security.SecureRandom().nextBytes(iv);
        Cipher aes=Cipher.getInstance("AES/GCM/NoPadding"); aes.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(aesRaw,"AES"),new GCMParameterSpec(128,iv));
        byte[] enc=aes.doFinal(raw);
        Cipher rsa=Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding"); rsa.init(Cipher.ENCRYPT_MODE,devicePub,new OAEPParameterSpec("SHA-256","MGF1",java.security.spec.MGF1ParameterSpec.SHA256,PSource.PSpecified.DEFAULT));
        JSONObject e=new JSONObject(); e.put("ek",b64(rsa.doFinal(aesRaw))); e.put("iv",b64(iv)); e.put("data",b64(enc)); return e.toString();
    }
    private String decryptOwnerKeyForThisDevice(String envelope) throws Exception {
        JSONObject e=new JSONObject(envelope); KeyPair kp=deviceKeyPair();
        Cipher rsa=Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding"); rsa.init(Cipher.DECRYPT_MODE,kp.getPrivate(),new OAEPParameterSpec("SHA-256","MGF1",java.security.spec.MGF1ParameterSpec.SHA256,PSource.PSpecified.DEFAULT));
        byte[] aesRaw=rsa.doFinal(unb64(e.getString("ek"))); Cipher aes=Cipher.getInstance("AES/GCM/NoPadding"); aes.init(Cipher.DECRYPT_MODE,new SecretKeySpec(aesRaw,"AES"),new GCMParameterSpec(128,unb64(e.getString("iv")))); return b64(aes.doFinal(unb64(e.getString("data"))));
    }
    private String createShopSetupInvite(String shopName,String shopMobile,String managerName,String address,String gstin,String state,String pin) throws Exception {
        if(shopName==null || shopName.trim().isEmpty()) throw new Exception("Shop name is required");
        PrivateKey pk=loadOwnerPrivate(pin);
        JSONObject payload=new JSONObject();
        payload.put("type","DUKAAN_SHOP_SETUP_INVITE_PAYLOAD");
        payload.put("setupId",UUID.randomUUID().toString());
        payload.put("shopName",shopName.trim());
        payload.put("shopMobile",shopMobile==null?"":shopMobile.trim());
        payload.put("managerName",managerName==null?"":managerName.trim());
        payload.put("address",address==null?"":address.trim());
        payload.put("gstin",gstin==null?"":gstin.trim());
        payload.put("state",state==null?"":state.trim());
        payload.put("createdAt",System.currentTimeMillis());
        byte[] data=payload.toString().getBytes(StandardCharsets.UTF_8);
        Signature sig=Signature.getInstance("SHA256withRSA"); sig.initSign(pk); sig.update(data);
        JSONObject invite=new JSONObject(); invite.put("type","DUKAAN_SHOP_SETUP_INVITE"); invite.put("version",1); invite.put("payload",b64(data)); invite.put("signature",b64(sig.sign()));
        return invite.toString();
    }

    private JSONObject verifyShopSetupInvite(String inviteJson) throws Exception {
        JSONObject invite=new JSONObject(inviteJson);
        if(!"DUKAAN_SHOP_SETUP_INVITE".equals(invite.optString("type"))) throw new Exception("Invalid Shop Setup QR");
        byte[] payload=unb64(invite.getString("payload"));
        Signature sig=Signature.getInstance("SHA256withRSA"); sig.initVerify(ownerPublicKey()); sig.update(payload);
        if(!sig.verify(unb64(invite.getString("signature")))) throw new Exception("Shop Setup QR signature is invalid");
        JSONObject p=new JSONObject(new String(payload,StandardCharsets.UTF_8));
        if(!"DUKAAN_SHOP_SETUP_INVITE_PAYLOAD".equals(p.optString("type"))) throw new Exception("Invalid Shop Setup payload");
        return p;
    }

    private String approveActivation(String requestJson,String pin) throws Exception {
        JSONObject req=new JSONObject(requestJson); if(!"DUKAAN_ACTIVATION_REQUEST".equals(req.optString("type")))throw new Exception("Invalid activation request");
        String deviceKey=req.getString("deviceKey"), requestId=req.getString("requestId"), deviceType=req.optString("deviceType","SHOP");
        JSONObject payloadObj=new JSONObject(); payloadObj.put("requestId",requestId); payloadObj.put("deviceKey",deviceKey); payloadObj.put("issuedAt",System.currentTimeMillis()); payloadObj.put("appVersion",req.optString("appVersion","3.52.0")); payloadObj.put("deviceType",deviceType);
        if("SHOP".equalsIgnoreCase(deviceType)) {
            String[] keys={"shopSetupId","shopName","shopMobile","managerName","address","gstin","state"};
            for(String k:keys) if(req.has(k)) payloadObj.put(k,req.optString(k,""));
        }
        if("OWNER".equalsIgnoreCase(deviceType)){ payloadObj.put("type","DUKAAN_OWNER_TOKEN_PAYLOAD"); payloadObj.put("ownerKeyEnvelope",encryptOwnerKeyForDevice(b64(loadOwnerPrivate(pin).getEncoded()),deviceKey)); }
        else payloadObj.put("type","DUKAAN_ACTIVATION_TOKEN_PAYLOAD");
        byte[] payload=payloadObj.toString().getBytes(StandardCharsets.UTF_8); PrivateKey pk=loadOwnerPrivate(pin); Signature s=Signature.getInstance("SHA256withRSA"); s.initSign(pk); s.update(payload);
        JSONObject token=new JSONObject(); token.put("type", "OWNER".equalsIgnoreCase(deviceType)?"DUKAAN_OWNER_ACTIVATION_TOKEN":"DUKAAN_ACTIVATION_TOKEN"); token.put("version",2); token.put("payload",b64(payload)); token.put("signature",b64(s.sign())); return token.toString();
    }
    private boolean applyActivation(String tokenJson) throws Exception {
        JSONObject t=new JSONObject(tokenJson); String type=t.optString("type"); byte[] payload=unb64(t.getString("payload")); String sigB=t.getString("signature");
        Signature s=Signature.getInstance("SHA256withRSA"); s.initVerify(ownerPublicKey()); s.update(payload); if(!s.verify(unb64(sigB)))throw new Exception("Activation signature is invalid");
        JSONObject p=new JSONObject(new String(payload,StandardCharsets.UTF_8)); String localKey=devicePublicKeyB64(); if(!MessageDigest.isEqual(localKey.getBytes(StandardCharsets.UTF_8),p.getString("deviceKey").getBytes(StandardCharsets.UTF_8)))throw new Exception("This activation was issued for another phone");
        if("DUKAAN_OWNER_ACTIVATION_TOKEN".equals(type)){
            getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).edit().putString("pending_owner_key",decryptOwnerKeyForThisDevice(p.getString("ownerKeyEnvelope"))).apply(); return true;
        }
        if("DUKAAN_ACTIVATION_TOKEN".equals(type)) {
            getSharedPreferences("activation",MODE_PRIVATE).edit()
                .putString("shop_setup_id",p.optString("shopSetupId",""))
                .putString("shop_name",p.optString("shopName",""))
                .putString("shop_mobile",p.optString("shopMobile",""))
                .putString("shop_manager",p.optString("managerName",""))
                .putString("shop_address",p.optString("address",""))
                .putString("shop_gstin",p.optString("gstin",""))
                .putString("shop_state",p.optString("state",""))
                .remove("pending_shop_setup").apply();
        }
        setActivated(true); return true;
    }
    private boolean finalizeOwnerActivation(String pin) throws Exception { if(pin==null||pin.length()<6) throw new Exception("Owner PIN must be at least 6 characters"); String k=getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).getString("pending_owner_key",null); if(k==null) throw new Exception("No pending Owner activation"); saveOwnerPrivate(k,pin); getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).edit().remove("pending_owner_key").apply(); setActivated(true); return true; }
    private String qrDataUrl(String text) throws Exception { BitMatrix m=new MultiFormatWriter().encode(text,BarcodeFormat.QR_CODE,800,800); Bitmap bmp=Bitmap.createBitmap(800,800,Bitmap.Config.ARGB_8888); for(int x=0;x<800;x++)for(int y=0;y<800;y++)bmp.setPixel(x,y,m.get(x,y)?android.graphics.Color.BLACK:android.graphics.Color.WHITE); ByteArrayOutputStream out=new ByteArrayOutputStream(); bmp.compress(CompressFormat.PNG,100,out); bmp.recycle(); return "data:image/png;base64,"+b64(out.toByteArray()); }
    private void shareText(String title,String text){ try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,title);i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,title));}catch(Exception e){Toast.makeText(this,"Could not share: "+e.getMessage(),Toast.LENGTH_LONG).show();} }
    private void scanQr(){ try{IntentIntegrator ii=new IntentIntegrator(this);ii.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);ii.setPrompt("Scan Dukaan Bill activation QR");ii.setBeepEnabled(true);ii.setOrientationLocked(false);ii.setRequestCode(REQ_SCAN_QR);ii.initiateScan();}catch(Exception e){Toast.makeText(this,"QR scanner unavailable: "+e.getMessage(),Toast.LENGTH_LONG).show();} }

    private void handleIncomingDukaanBill(Intent intent) {
        if (intent == null || intent.getData() == null) return;
        Uri uri = intent.getData();
        String type = intent.getType();
        if (type == null || !type.equalsIgnoreCase("application/vnd.dukaanbill")) return;
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) throw new Exception("Could not open Dukaan Bill file");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) {
                if (bos.size() > 2 * 1024 * 1024) throw new Exception("Dukaan Bill file is too large");
                bos.write(buf, 0, n);
            }
            in.close();
            String json = new String(bos.toByteArray(), StandardCharsets.UTF_8);
            JSONObject obj = new JSONObject(json);
            if (!"THERMAL_PRINT".equalsIgnoreCase(obj.optString("dukaanBillType", ""))) throw new Exception("Unsupported Dukaan Bill file");
            final String encoded = Base64.encodeToString(json.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            webView.postDelayed(() -> webView.evaluateJavascript("window.openIncomingThermalBill && window.openIncomingThermalBill(atob('" + encoded + "'))", null), 900);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open Dukaan Bill: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private Uri saveToCacheProvider(byte[] data, String filename) throws Exception {
        File dir = new File(getCacheDir(), "share");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create share folder");
        File file = new File(dir, filename);
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(data);
            out.flush();
        }
        return Uri.parse("content://com.dukaanbill.app.share/" + Uri.encode(file.getName()));
    }

    private Uri saveForSharing(byte[] data, String filename, String mime) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    mime.equals("application/pdf") ?
                            Environment.DIRECTORY_DOWNLOADS + "/DukaanBill" :
                            Environment.DIRECTORY_PICTURES + "/DukaanBill");
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);

            Uri collection = mime.equals("application/pdf")
                    ? MediaStore.Downloads.EXTERNAL_CONTENT_URI
                    : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

            Uri uri = resolver.insert(collection, values);
            if (uri != null) {
                try (OutputStream out = resolver.openOutputStream(uri)) {
                    if (out == null) throw new Exception("Could not open output stream");
                    out.write(data);
                    out.flush();
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                resolver.update(uri, done, null, null);
                return uri;
            }
        }
        return saveToCacheProvider(data, filename);
    }

    private void shareFile(byte[] data, String filename, String mime, String title) throws Exception {
        Uri uri = saveForSharing(data, filename, mime);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType(mime);
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_TEXT, "DukaanBill - " + title);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        send.setClipData(ClipData.newRawUri(title, uri));
        Intent chooser = Intent.createChooser(send, title);
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(chooser);
    }

    private void drawText(Canvas c, Paint p, String text, float x, float y) {
        c.drawText(text == null ? "" : text, x, y, p);
    }

    private Bitmap loadLogo(JSONObject cfg) {
        Bitmap source = null;
        try {
            if (cfg != null) {
                String data = cfg.optString("logoData", "");
                if (data.startsWith("data:")) {
                    int comma = data.indexOf(',');
                    if (comma > 0) {
                        byte[] raw = Base64.decode(data.substring(comma + 1), Base64.DEFAULT);
                        source = BitmapFactory.decodeByteArray(raw, 0, raw.length);
                    }
                }
            }
        } catch (Exception ignored) {}
        if (source == null) {
            try (InputStream in = getAssets().open("www/logo.jpg")) {
                source = BitmapFactory.decodeStream(in);
            } catch (Exception ignored) {}
        }
        if (source == null) return null;

        // The PDF only renders the logo at roughly 68pt.  Do not embed the
        // full-resolution uploaded image in every PDF page; it can make a
        // simple one-page bill exceed 1 MB.  A 320px bitmap is more than
        // sufficient for A4/thermal output while keeping PDFs compact.
        final int maxDimension = 320;
        int w = source.getWidth(), h = source.getHeight();
        if (w <= maxDimension && h <= maxDimension) return source;
        float scale = Math.min((float) maxDimension / w, (float) maxDimension / h);
        int nw = Math.max(1, Math.round(w * scale));
        int nh = Math.max(1, Math.round(h * scale));
        Bitmap scaled = Bitmap.createScaledBitmap(source, nw, nh, true);
        if (scaled != source) source.recycle();
        return scaled;
    }

    private List<String> wrapText(String text, Paint paint, float maxWidth) {
        List<String> lines = new ArrayList<>();
        if (text == null || text.trim().isEmpty()) return lines;
        String normalized = text.trim().replaceAll("\\s+", " ");
        String[] words = normalized.split(" ");
        String line = "";
        for (String word : words) {
            String candidate = line.isEmpty() ? word : line + " " + word;
            if (paint.measureText(candidate) <= maxWidth) {
                line = candidate;
            } else {
                if (!line.isEmpty()) lines.add(line);
                if (paint.measureText(word) <= maxWidth) {
                    line = word;
                } else {
                    String part = "";
                    for (int i = 0; i < word.length(); i++) {
                        String c = part + word.charAt(i);
                        if (paint.measureText(c) > maxWidth && !part.isEmpty()) {
                            lines.add(part);
                            part = String.valueOf(word.charAt(i));
                        } else part = c;
                    }
                    line = part;
                }
            }
        }
        if (!line.isEmpty()) lines.add(line);
        return lines;
    }

    private String shopMobileText(JSONObject cfg) {
        if (cfg == null) return "";
        JSONArray arr = cfg.optJSONArray("shopMobiles");
        if (arr != null && arr.length() > 0) {
            StringBuilder sb = new StringBuilder();
            for (int i=0;i<arr.length();i++) { String v=arr.optString(i,"").trim(); if(!v.isEmpty()){ if(sb.length()>0) sb.append(", "); sb.append(v); } }
            if(sb.length()>0) return sb.toString();
        }
        return cfg.optString("shopMobile", "").trim();
    }

    private float drawPdfHeader(Canvas c, Paint p, Bitmap logo, int pageWidth, JSONObject cfg, boolean taxInvoice) {
        String shopName = cfg == null ? "DUKAAN BILL" : cfg.optString("shopName", "DUKAAN BILL");
        String tagline = cfg == null ? "" : cfg.optString("tagline", "");
        String address = cfg == null ? "" : cfg.optString("address", "");
        String shopMobile = shopMobileText(cfg);
        String billTitle = taxInvoice ? "TAX INVOICE" : (cfg == null ? "CASH MEMO / BILL" : cfg.optString("billTitle", "CASH MEMO / BILL"));
        float center = pageWidth / 2f;
        float y = 38;
        p.setTextAlign(Paint.Align.CENTER);
        if (logo != null) {
            float size = 68;
            c.drawBitmap(logo, null, new RectF(center-size/2f, y, center+size/2f, y+size), p);
            // Consistent visible separation after the logo.
            y += size + 22;
        }
        p.setColor(android.graphics.Color.rgb(36,70,111));
        p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));
        p.setTextSize(23);
        drawText(c,p,shopName,center,y);
        // Keep a consistent baseline gap between every header line.
        y += 18;
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(11);
        // Header order: logo -> shop name -> tagline -> address -> mobile -> bill title.
        if(!tagline.trim().isEmpty()){
            p.setTypeface(Typeface.DEFAULT_BOLD);
            for(String line:wrapText(tagline,p,pageWidth-90)){ drawText(c,p,line,center,y); y += 15; }
            p.setTypeface(Typeface.DEFAULT);
            y += 2;
        }
        if(!address.trim().isEmpty()){
            for(String line:wrapText(address,p,pageWidth-90)){ drawText(c,p,line,center,y); y += 15; }
            y += 2;
        }
        if(!shopMobile.isEmpty()){
            p.setTypeface(Typeface.DEFAULT_BOLD);
            for(String line:wrapText("Mo: "+shopMobile,p,pageWidth-90)){ drawText(c,p,line,center,y); y += 15; }
            p.setTypeface(Typeface.DEFAULT);
            y += 2;
        }
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(13);
        y += 8;
        drawText(c,p,billTitle,center,y);
        p.setColor(android.graphics.Color.rgb(36,70,111));
        c.drawLine(35,y+13,pageWidth-35,y+13,p);
        p.setTextAlign(Paint.Align.LEFT);
        return y+13;
    }

    private String unitAlias(String unit) {
        if(unit==null)return "pc"; String u=unit.trim().toLowerCase(Locale.US);
        if(u.matches("packet|packets|pack|pk|pkt|pks"))return "pk"; if(u.matches("piece|pieces|pc|pcs"))return "pc";
        if(u.matches("kilogram|kilograms|kilo|kilos|kg|kgs"))return "kg"; if(u.matches("gram|grams|gm|g"))return "g";
        if(u.matches("bottle|bottles"))return "bt"; if(u.matches("box|boxes"))return "bx"; if(u.equals("dozen"))return "dz";
        return u.length()>4?u.substring(0,4):u;
    }

    private byte[] createThermalPdfBytes(String json) throws Exception {
        JSONObject b=new JSONObject(json);
        JSONObject cfg=b.optJSONObject("settings");
        JSONArray items=b.optJSONArray("items");
        boolean is58="58mm".equalsIgnoreCase(cfg==null?"80mm":cfg.optString("paperSize","80mm"));
        int width=is58?164:227, margin=is58?8:10;
        int itemCount=items==null?0:items.length();
        String address=cfg==null?"":cfg.optString("address","").trim();
        String tagline=cfg==null?"":cfg.optString("tagline","").trim();
        String customer=b.optString("customer","Walk-in Customer").trim();
        boolean walkIn=customer.isEmpty() || customer.equalsIgnoreCase("Walk-in Customer");
        String phone=b.optString("customerPhone","").trim();
        boolean taxInvoice=b.optBoolean("taxationEnabled",false);
        JSONObject tax=calculateTaxSummary(b,cfg);

        Paint measure=new Paint(Paint.ANTI_ALIAS_FLAG);
        measure.setTextSize(is58?6.8f:8.2f);
        int headerLines=wrapText(address,measure,width-margin*2).size()+wrapText(tagline,measure,width-margin*2).size();
        int height=270 + headerLines*10 + itemCount*27 + ((!walkIn)?11:0) + (taxInvoice?88:0);

        PdfDocument doc=new PdfDocument();
        PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(width,height,1).create());
        Canvas c=page.getCanvas();
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap logo=loadLogo(cfg);
        int y=10;

        p.setColor(android.graphics.Color.BLACK);
        p.setTextAlign(Paint.Align.CENTER);
        if(logo!=null){
            int ls=is58?38:48;
            int lx=(width-ls)/2;
            c.drawBitmap(logo,null,new RectF(lx,y,lx+ls,y+ls),p);
            y+=ls+14;
        }

        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(is58?11.5f:14.5f);
        drawText(c,p,cfg==null?"DUKAAN BILL":cfg.optString("shopName","DUKAAN BILL"),width/2f,y);
        y+=13;

        // Keep the same visible, consistent header rhythm in thermal print.
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(is58?7.0f:8.4f);
        if(!tagline.isEmpty()){
            p.setTypeface(Typeface.DEFAULT_BOLD);
            for(String line:wrapText(tagline,p,width-margin*2)){ drawText(c,p,line,width/2f,y); y+=9; }
            p.setTypeface(Typeface.DEFAULT);
            y+=2;
        }
        if(!address.isEmpty()){
            for(String line:wrapText(address,p,width-margin*2)){ drawText(c,p,line,width/2f,y); y+=9; }
            y+=2;
        }
        String shopMobiles = shopMobileText(cfg);
        if(!shopMobiles.isEmpty()){
            p.setTypeface(Typeface.DEFAULT_BOLD);
            for(String line:wrapText("Mo: "+shopMobiles,p,width-margin*2)){ drawText(c,p,line,width/2f,y); y+=9; }
            p.setTypeface(Typeface.DEFAULT);
            y+=2;
        }

        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(is58?8.8f:10.5f);
        y+=6;
        drawText(c,p,taxInvoice?"TAX INVOICE":(cfg==null?"CASH MEMO / BILL":cfg.optString("billTitle","CASH MEMO / BILL")),width/2f,y);
        y+=10;
        p.setStrokeWidth(1);
        c.drawLine(margin,y,width-margin,y,p);
        y+=10;

        // Compact metadata: fixed left/right columns. Left-align the bill number so the # never clips.
        p.setTypeface(Typeface.DEFAULT);
        String billNo=b.optString("billNo","");
        String billLabel="Bill "+(billNo.startsWith("#") ? billNo : "#"+billNo);
        String dateLabel="Dt: "+formatDate(b.optString("date",""));
        float metaGap=is58?5:8;
        float rightX=width-margin;
        float leftMax=(width/2f)-margin-metaGap;
        p.setTextAlign(Paint.Align.LEFT);
        float billSize=is58?6.4f:8.0f;
        p.setTextSize(billSize);
        while(p.measureText(billLabel)>leftMax && billSize>5.0f){billSize-=0.2f;p.setTextSize(billSize);}
        drawText(c,p,billLabel,margin,y);
        p.setTextAlign(Paint.Align.RIGHT);
        float dateSize=is58?6.4f:8.0f;
        p.setTextSize(dateSize);
        while(p.measureText(dateLabel)>leftMax && dateSize>5.0f){dateSize-=0.2f;p.setTextSize(dateSize);}
        drawText(c,p,dateLabel,rightX,y);
        p.setTextAlign(Paint.Align.LEFT);
        y+=10;

        if(!walkIn){
            // Customer and mobile share the same row, aligned left/right like bill/date.
            String customerLabel="Customer: "+customer;
            p.setTextAlign(Paint.Align.LEFT);
            float customerSize=is58?6.0f:7.6f;
            p.setTextSize(customerSize);
            float customerMax=leftMax;
            while(p.measureText(customerLabel)>customerMax && customerSize>4.8f){customerSize-=0.2f;p.setTextSize(customerSize);}
            drawText(c,p,trimText(customerLabel,is58?30:42),margin,y);
            if(!phone.isEmpty()){
                p.setTextAlign(Paint.Align.RIGHT);
                p.setTextSize(is58?6.0f:7.6f);
                drawText(c,p,"Mo: "+phone,rightX,y);
                p.setTextAlign(Paint.Align.LEFT);
            }
            y+=10;
        }
        drawText(c,p,"Pay: "+b.optString("paymentMode","Cash"),margin,y);
        y+=10;
        if(taxInvoice){ p.setTextSize(is58?6.5f:7.6f); drawText(c,p,"GSTIN: "+b.optString("gstin",cfg.optString("gstin","")),margin,y); y+=9; drawText(c,p,"Place of Supply: "+b.optString("placeOfSupply",cfg.optString("businessState","")),margin,y); y+=10; }
        c.drawLine(margin,y,width-margin,y,p);
        y+=10;

        if(items!=null){
            for(int i=0;i<items.length();i++){
                JSONObject it=items.getJSONObject(i);
                String name=it.optString("name","");
                String qty=it.optString("qty","");
                String unit=unitAlias(it.optString("unit","piece"));
                double rate=it.optDouble("rate",0);
                double amount=quantityValue(qty,unit)*rate;

                p.setTypeface(Typeface.DEFAULT_BOLD);
                p.setTextSize(is58?8.0f:9.0f);
                drawText(c,p,(i+1)+". "+trimText(name,is58?29:42),margin,y);
                y+=10;

                p.setTypeface(Typeface.DEFAULT);
                p.setTextSize(is58?7.0f:8.0f);
                drawText(c,p,qty+" "+unit+" x ₹"+String.format(Locale.US,"%.2f",rate)+(taxInvoice?" • "+String.format(Locale.US,"%.0f%%",it.optDouble("taxRate",0)):""),margin+8,y);
                p.setTextAlign(Paint.Align.RIGHT);
                p.setTypeface(Typeface.DEFAULT_BOLD);
                drawText(c,p,"₹"+String.format(Locale.US,"%.2f",amount),width-margin,y);
                p.setTextAlign(Paint.Align.LEFT);
                y+=14;
            }
        }

        double subtotal=b.optDouble("subtotal",0);
        double discount=b.optDouble("discount",0);
        double total=b.optDouble("total",Math.max(0,subtotal-discount));
        c.drawLine(margin,y,width-margin,y,p);
        y+=12;

        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(is58?7.8f:9.0f);
        drawText(c,p,"Subtotal",margin,y);
        p.setTextAlign(Paint.Align.RIGHT);
        drawText(c,p,"₹"+String.format(Locale.US,"%.2f",subtotal),width-margin,y);
        p.setTextAlign(Paint.Align.LEFT);
        y+=11;

        if (discount > 0.000001) {
            drawText(c,p,"Discount",margin,y);
            p.setTextAlign(Paint.Align.RIGHT);
            drawText(c,p,"-₹"+String.format(Locale.US,"%.2f",discount),width-margin,y);
            p.setTextAlign(Paint.Align.LEFT);
            y+=13;
        }

        if(taxInvoice){ p.setTypeface(Typeface.DEFAULT); p.setTextSize(is58?7.8f:9.0f); drawText(c,p,"Taxable",margin,y); p.setTextAlign(Paint.Align.RIGHT); drawText(c,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("taxable",0)),width-margin,y); p.setTextAlign(Paint.Align.LEFT); y+=10; if(tax.optBoolean("inter",false)){drawText(c,p,"IGST",margin,y);p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("igst",0)),width-margin,y);p.setTextAlign(Paint.Align.LEFT);y+=11;}else{drawText(c,p,"CGST",margin,y);p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("cgst",0)),width-margin,y);p.setTextAlign(Paint.Align.LEFT);y+=10;drawText(c,p,"SGST",margin,y);p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("sgst",0)),width-margin,y);p.setTextAlign(Paint.Align.LEFT);y+=11;} drawText(c,p,"GST",margin,y);p.setTextAlign(Paint.Align.RIGHT);drawText(c,p,"₹"+String.format(Locale.US,"%.2f",tax.optDouble("tax",0)),width-margin,y);p.setTextAlign(Paint.Align.LEFT);y+=12; }
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(is58?9.8f:11.5f);
        drawText(c,p,"TOTAL",margin,y);
        p.setTextAlign(Paint.Align.RIGHT);
        drawText(c,p,"₹"+String.format(Locale.US,"%.2f",total),width-margin,y);
        p.setTextAlign(Paint.Align.LEFT);
        y+=16;

        p.setTypeface(Typeface.DEFAULT);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(is58?6.8f:7.8f);
        String footer=cfg==null?"":cfg.optString("footer","").trim();
        if(!footer.isEmpty()){
            for(String line:wrapText(footer,p,width-margin*2)){drawText(c,p,line,width/2f,y);y+=9;}
        }
        drawText(c,p,"Goods once sold will not be taken back.",width/2f,y);
        y+=12;

        String signature=cfg==null?"":cfg.optString("signature","").trim();
        if(!signature.isEmpty()){
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextSize(is58?7.0f:8.0f);
            drawText(c,p,signature,width/2f,y);
            y+=10;
            drawText(c,p,"Authorized Signatory",width/2f,y);
            y+=11;
        }

        p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.ITALIC));
        p.setTextSize(is58?6.0f:7.0f);
        String credit=cfg==null?"Bill created by DukaanBill • Contact 8087794271 for more details":cfg.optString("creditFooter","Bill created by DukaanBill • Contact 8087794271 for more details");
        for(String line:wrapText(credit,p,width-margin*2)){drawText(c,p,line,width/2f,y);y+=8;}
        p.setTextAlign(Paint.Align.LEFT);

        doc.finishPage(page);
        ByteArrayOutputStream bos=new ByteArrayOutputStream();
        doc.writeTo(bos);
        doc.close();
        return bos.toByteArray();
    }

    private byte[] escText(String s) {
        if (s == null) s = "";
        s = s.replace("₹", "Rs.").replace("•", "-").replace("—", "-").replace("–", "-");
        try { return s.getBytes(Charset.forName("CP437")); }
        catch (Exception e) { return s.replaceAll("[^\\x20-\\x7E]", "?").getBytes(StandardCharsets.US_ASCII); }
    }

    private void escWrite(OutputStream out, byte[] b) throws Exception { out.write(b); }
    private void escLine(OutputStream out, String s) throws Exception { escWrite(out, escText(s)); escWrite(out, new byte[]{0x0A}); }
    private void escCmd(OutputStream out, int... bytes) throws Exception { for(int b:bytes) out.write(b & 0xFF); }

    private void writeEscPosBitmap(OutputStream out, Bitmap source, int maxWidth) throws Exception {
        if (source == null) return;
        int w = Math.min(maxWidth, source.getWidth());
        float scale = (float)w / source.getWidth();
        int h = Math.max(1, Math.round(source.getHeight() * scale));
        Bitmap bmp = Bitmap.createScaledBitmap(source, w, h, true);
        int widthBytes = (w + 7) / 8;
        byte[] raster = new byte[widthBytes * h];
        for (int y=0; y<h; y++) {
            for (int x=0; x<w; x++) {
                int px = bmp.getPixel(x,y);
                int r = android.graphics.Color.red(px), g = android.graphics.Color.green(px), b = android.graphics.Color.blue(px);
                int gray = (r*299 + g*587 + b*114) / 1000;
                // Slightly generous threshold keeps the black logo/text clear on thermal paper.
                if (gray < 175) raster[y*widthBytes + (x>>3)] |= (byte)(0x80 >> (x & 7));
            }
        }
        escCmd(out, 0x1D,0x76,0x30,0x00, widthBytes & 0xFF, (widthBytes>>8)&0xFF, h&0xFF, (h>>8)&0xFF);
        out.write(raster);
        escCmd(out, 0x0A);
        if (bmp != source) bmp.recycle();
    }

    private BluetoothDevice findThermalPrinter(String preferredModel) throws Exception {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) throw new Exception("Bluetooth is not available on this phone.");
        if (!adapter.isEnabled()) throw new Exception("Please turn on Bluetooth.");
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            pendingDirectPrintJson = pendingDirectPrintJson == null ? "" : pendingDirectPrintJson;
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT_PRINT);
            return null;
        }
        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        String preferred = preferredModel == null ? "auto" : preferredModel.trim();
        BluetoothDevice autoKnown = null;
        BluetoothDevice first = null;
        for (BluetoothDevice d : bonded) {
            String name = d.getName() == null ? "" : d.getName();
            String upper = name.toUpperCase(Locale.US);
            if (first == null) first = d;
            if (!"auto".equalsIgnoreCase(preferred) && !preferred.isEmpty()) {
                if (upper.equals(preferred.toUpperCase(Locale.US)) || upper.contains(preferred.toUpperCase(Locale.US))) return d;
            }
            if (upper.contains("KPC307") || upper.contains("UEWB") || upper.contains("G-8BT3") || upper.contains("G8BT3") || upper.contains("AMIGOS")) {
                if (autoKnown == null) autoKnown = d;
            }
        }
        if ("auto".equalsIgnoreCase(preferred) && autoKnown != null) return autoKnown;
        if (!"auto".equalsIgnoreCase(preferred)) throw new Exception(preferred + " is not paired. Pair it in Android Bluetooth settings first.");
        if (first != null) return first;
        throw new Exception("No paired Bluetooth printer found. Pair KPC307-UEWB or G-8BT3 first.");
    }

    private BluetoothSocket openPrinterSocket(BluetoothDevice device) throws Exception {
        UUID spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
        BluetoothSocket socket = null;
        try {
            socket = device.createRfcommSocketToServiceRecord(spp);
            socket.connect();
            return socket;
        } catch (Exception e) {
            try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        }
        try {
            socket = device.createInsecureRfcommSocketToServiceRecord(spp);
            socket.connect();
            return socket;
        } catch (Exception e) {
            try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        }
        try {
            java.lang.reflect.Method m = device.getClass().getMethod("createRfcommSocket", int.class);
            socket = (BluetoothSocket)m.invoke(device, 1);
            socket.connect();
            return socket;
        } catch (Exception e) {
            try { if (socket != null) socket.close(); } catch (Exception ignored) {}
            throw new Exception("Could not connect to " + (device.getName()==null?"printer":device.getName()) + " over Bluetooth. Make sure it is paired and not connected to another phone.");
        }
    }

    private void directThermalPrint80(String json) throws Exception {
        pendingDirectPrintJson = json;
        JSONObject preflight = new JSONObject(json);
        JSONObject preCfg = preflight.optJSONObject("settings");
        String preferredPrinter = preCfg == null ? "auto" : preCfg.optString("bluetoothPrinter", "auto");
        BluetoothDevice device = findThermalPrinter(preferredPrinter);
        if (device == null) return; // permission request is in progress
        BluetoothSocket socket = null;
        OutputStream out = null;
        try {
            socket = openPrinterSocket(device);
            try { Thread.sleep(250); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            out = socket.getOutputStream();
            JSONObject b = new JSONObject(json);
            JSONObject cfg = b.optJSONObject("settings");
            JSONArray items = b.optJSONArray("items");
            boolean tax = b.optBoolean("taxationEnabled", false);
            String shop = cfg == null ? "DUKAAN BILL" : cfg.optString("shopName", "DUKAAN BILL");
            String tagline = cfg == null ? "" : cfg.optString("tagline", "").trim();
            String address = cfg == null ? "" : cfg.optString("address", "").trim();
            String mobiles = shopMobileText(cfg);
            String customer = b.optString("customer", "Walk-in Customer").trim();
            String phone = b.optString("customerPhone", "").trim();
            String billNo = b.optString("billNo", "");
            String title = tax ? "TAX INVOICE" : (cfg == null ? "CASH MEMO / BILL" : cfg.optString("billTitle", "CASH MEMO / BILL"));

            escCmd(out,0x1B,0x40); // initialize
            // Slightly darker text for KPC307 thermal output. Double-strike is more reliable than oversized/bold text.
            escCmd(out,0x1B,0x47,0x01); // ESC G 1: double-strike ON
            escCmd(out,0x1B,0x61,0x01); // center
            Bitmap logo=loadLogo(cfg);
            if(logo!=null){ writeEscPosBitmap(out,logo,320); if(logo!=null && !logo.isRecycled()) logo.recycle(); }
            escCmd(out,0x1B,0x45,0x01);
            escLine(out,shop);
            escCmd(out,0x1B,0x45,0x00);
            if(!tagline.isEmpty()) escLine(out,tagline);
            if(!address.isEmpty()) for(String line:wrapPlain(address,48)) escLine(out,line);
            if(!mobiles.isEmpty()){ escCmd(out,0x1B,0x45,0x01); escLine(out,"Mo: "+mobiles); escCmd(out,0x1B,0x45,0x00); }
            escCmd(out,0x1B,0x45,0x01); escLine(out,title); escCmd(out,0x1B,0x45,0x00);
            escLine(out,"-----------------------------------------------");
            escCmd(out,0x1B,0x61,0x00); // left
            escLine(out,"Bill: #"+billNo+"        Dt: "+formatDate(b.optString("date","")));
            if(!customer.isEmpty() && !customer.equalsIgnoreCase("Walk-in Customer")) escLine(out,"Customer: "+customer);
            if(!phone.isEmpty()) escLine(out,"Mo: "+phone);
            escLine(out,"Pay: "+b.optString("paymentMode","Cash"));
            if(tax){ escLine(out,"GSTIN: "+b.optString("gstin",cfg==null?"":cfg.optString("gstin",""))); escLine(out,"Place of Supply: "+b.optString("placeOfSupply",cfg==null?"":cfg.optString("businessState",""))); }
            escLine(out,"-----------------------------------------------");

            if(items!=null){
                for(int i=0;i<items.length();i++){
                    JSONObject it=items.getJSONObject(i);
                    String name=it.optString("name","");
                    String qty=it.optString("qty","");
                    String unit=unitAlias(it.optString("unit","piece"));
                    double rate=it.optDouble("rate",0);
                    double amount=quantityValue(qty,unit)*rate;
                    escCmd(out,0x1B,0x45,0x01); escLine(out,(i+1)+". "+name); escCmd(out,0x1B,0x45,0x00);
                    String detail="   "+qty+" "+unit+" x Rs."+String.format(Locale.US,"%.2f",rate)+(tax?"  Tax "+String.format(Locale.US,"%.0f%%",it.optDouble("taxRate",0)):"");
                    String amountText="Rs."+String.format(Locale.US,"%.2f",amount);
                    // Keep quantity/rate directly under the item name and amount flush-right on 80mm (48 columns).
                    int gap=Math.max(1,48-detail.length()-amountText.length());
                    escLine(out,detail+String.format(Locale.US,"%"+gap+"s","")+amountText);
                }
            }
            escLine(out,"-----------------------------------------------");
            double subtotal=b.optDouble("subtotal",0), discount=b.optDouble("discount",0), total=b.optDouble("total",Math.max(0,subtotal-discount));
            escLine(out,String.format(Locale.US,"Subtotal:%28s","Rs."+String.format(Locale.US,"%.2f",subtotal)));
            if(discount>0.000001) escLine(out,String.format(Locale.US,"Discount:%27s","-Rs."+String.format(Locale.US,"%.2f",discount)));
            if(tax){ JSONObject ts=calculateTaxSummary(b,cfg); escLine(out,String.format(Locale.US,"Taxable:%28s","Rs."+String.format(Locale.US,"%.2f",ts.optDouble("taxable",0)))); if(ts.optBoolean("inter",false)) escLine(out,String.format(Locale.US,"IGST:%31s","Rs."+String.format(Locale.US,"%.2f",ts.optDouble("igst",0)))); else { escLine(out,String.format(Locale.US,"CGST:%31s","Rs."+String.format(Locale.US,"%.2f",ts.optDouble("cgst",0)))); escLine(out,String.format(Locale.US,"SGST:%31s","Rs."+String.format(Locale.US,"%.2f",ts.optDouble("sgst",0)))); } escLine(out,String.format(Locale.US,"GST:%32s","Rs."+String.format(Locale.US,"%.2f",ts.optDouble("tax",0)))); }
            escCmd(out,0x1B,0x45,0x01); escLine(out,String.format(Locale.US,"TOTAL:%30s","Rs."+String.format(Locale.US,"%.2f",total))); escCmd(out,0x1B,0x45,0x00);
            escLine(out,"");
            escCmd(out,0x1B,0x61,0x01);
            String footer=cfg==null?"":cfg.optString("footer","").trim(); if(!footer.isEmpty()) for(String line:wrapPlain(footer,48)) escLine(out,line);
            escLine(out,"Goods once sold will not be taken back.");
            String credit=cfg==null?"Bill created by DukaanBill - Contact 8087794271 for more details":cfg.optString("creditFooter","Bill created by DukaanBill - Contact 8087794271 for more details");
            for(String line:wrapPlain(credit.replace("•","-"),48)) escLine(out,line);
            escLine(out,""); escLine(out,""); escLine(out,"");
            escCmd(out,0x1B,0x47,0x00); // double-strike OFF
            escCmd(out,0x1D,0x56,0x00); // full cut
            out.flush();
            runOnUiThread(()->Toast.makeText(MainActivity.this,"Printed directly to "+(device.getName()==null?"printer":device.getName()),Toast.LENGTH_SHORT).show());
        } finally { try{if(out!=null)out.close();}catch(Exception ignored){} try{if(socket!=null)socket.close();}catch(Exception ignored){} }
    }

    private List<String> wrapPlain(String text,int max){
        List<String> out=new ArrayList<>(); if(text==null||text.trim().isEmpty())return out;
        String s=text.trim().replaceAll("\\s+"," "); while(s.length()>max){int cut=s.lastIndexOf(' ',max);if(cut<1)cut=max;out.add(s.substring(0,cut));s=s.substring(cut).trim();} if(!s.isEmpty())out.add(s);return out;
    }

    private void printBill(String json) throws Exception {
        byte[] pdf=createThermalPdfBytes(json);
        PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
        String name="DukaanBill";
        try{name=new JSONObject(json).optString("billNo","DukaanBill");}catch(Exception ignored){}
        final byte[] data=pdf;
        final String printName=name;
        pm.print(printName,new PrintDocumentAdapter(){
            @Override public void onLayout(android.print.PrintAttributes oldAttrs, android.print.PrintAttributes newAttrs, CancellationSignal cancellationSignal, LayoutResultCallback callback, android.os.Bundle extras){
                if(cancellationSignal.isCanceled()){callback.onLayoutCancelled();return;}
                PrintDocumentInfo info=new PrintDocumentInfo.Builder(printName+".pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build(); callback.onLayoutFinished(info,true);
            }
            @Override public void onWrite(PageRange[] pages, ParcelFileDescriptor destination, CancellationSignal cancellationSignal, WriteResultCallback callback){
                try(FileOutputStream out=new FileOutputStream(destination.getFileDescriptor())){out.write(data);out.flush();callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){callback.onWriteFailed(e.getMessage());}
            }
        },new PrintAttributes.Builder().setMediaSize("58mm".equalsIgnoreCase(new JSONObject(json).optJSONObject("settings").optString("paperSize","80mm")) ? new PrintAttributes.MediaSize("DUKAAN58", "58 mm", 2283, 22000) : new PrintAttributes.MediaSize("DUKAAN80", "80 mm", 3150, 22000)).setColorMode(PrintAttributes.COLOR_MODE_COLOR).build());
    }

    private JSONObject calculateTaxSummary(JSONObject b, JSONObject cfg) throws Exception {
        JSONObject out=new JSONObject();
        boolean enabled=b!=null && b.optBoolean("taxationEnabled",false);
        out.put("enabled",enabled);
        if(!enabled){out.put("taxable",0);out.put("tax",0);out.put("cgst",0);out.put("sgst",0);out.put("igst",0);out.put("inter",false);out.put("groups",new JSONArray());return out;}
        JSONArray items=b.optJSONArray("items");
        double calculatedSubtotal=0;
        if(items!=null){for(int i=0;i<items.length();i++){JSONObject it=items.getJSONObject(i);calculatedSubtotal+=quantityValue(it.optString("qty",""),it.optString("unit","piece"))*it.optDouble("rate",0);}}
        double subtotal=b.has("subtotal")?b.optDouble("subtotal",calculatedSubtotal):calculatedSubtotal;
        double discount=Math.max(0,b.optDouble("discount",0));
        double taxable=0,tax=0;
        TreeMap<Double,double[]> groups=new TreeMap<>();
        if(items!=null){for(int i=0;i<items.length();i++){JSONObject it=items.getJSONObject(i);double gross=quantityValue(it.optString("qty",""),it.optString("unit","piece"))*it.optDouble("rate",0);double net=subtotal>0?gross*(subtotal-discount)/subtotal:gross;double rate=it.optDouble("taxRate",0);double base=rate>0?net/(1.0+rate/100.0):net;double tx=rate>0?net-base:0;taxable+=base;tax+=tx;double[] g=groups.get(rate);if(g==null){g=new double[]{0,0};groups.put(rate,g);}g[0]+=base;g[1]+=tx;}}
        String business=b.optString("businessState",cfg.optString("businessState","")).trim();String pos=b.optString("placeOfSupply",business).trim();boolean inter=!business.isEmpty()&&!pos.isEmpty()&&!business.equalsIgnoreCase(pos);
        out.put("taxable",taxable);out.put("tax",tax);out.put("cgst",inter?0:tax/2.0);out.put("sgst",inter?0:tax/2.0);out.put("igst",inter?tax:0);out.put("inter",inter);
        JSONArray arr=new JSONArray();for(Map.Entry<Double,double[]> e:groups.entrySet()){JSONObject g=new JSONObject();g.put("rate",e.getKey());g.put("taxable",e.getValue()[0]);g.put("tax",e.getValue()[1]);arr.put(g);}out.put("groups",arr);
        return out;
    }

    private Uri createPdf(String json) throws Exception {
        JSONObject b = new JSONObject(json);
        JSONArray items = b.optJSONArray("items");
        JSONObject cfg = b.optJSONObject("settings");
        boolean taxInvoice=b.optBoolean("taxationEnabled",false);
        JSONObject tax=calculateTaxSummary(b,cfg);
        PdfDocument doc = new PdfDocument();
        Bitmap logo = loadLogo(cfg);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int pageNo=1, y;
        PdfDocument.Page page = null;
        Canvas canvas = null;
        int pageWidth=595, pageHeight=842;

        page = doc.startPage(new PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNo).create());
        canvas = page.getCanvas();
        float headerBottom = drawPdfHeader(canvas,p,logo,pageWidth,cfg,taxInvoice);

        p.setColor(android.graphics.Color.BLACK);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(10);
        int metaY = Math.max(130, (int)headerBottom + 22);
        drawText(canvas,p,"Bill No: " + b.optString("billNo",""),40,metaY);
        drawText(canvas,p,"Date: " + formatDate(b.optString("date","")),410,metaY);
        drawText(canvas,p,"Customer: " + b.optString("customer","Walk-in Customer"),40,metaY+18);
        String customerPhone=b.optString("customerPhone","");
        if(!customerPhone.isEmpty()) drawText(canvas,p,"Mobile: " + customerPhone,40,metaY+36);
        drawText(canvas,p,"Payment Mode: " + b.optString("paymentMode","Cash"),410,metaY+18);
        if(taxInvoice){ drawText(canvas,p,"GSTIN: " + (b.has("gstin")?b.optString("gstin",""):(cfg==null?"":cfg.optString("gstin",""))),40,metaY+54); drawText(canvas,p,"Place of Supply: " + b.optString("placeOfSupply",cfg==null?"":cfg.optString("businessState","")),410,metaY+54); }

        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(9);
        int tableY = Math.max(180, metaY + (customerPhone.isEmpty() ? (taxInvoice?60:38) : (taxInvoice?78:56)) + 16);
        canvas.drawRect(35,tableY,560,tableY+25,p);
        p.setColor(android.graphics.Color.WHITE);
        drawText(canvas,p,"Sr.",42,tableY+16);
        drawText(canvas,p,"Item / HSN",70,tableY+16);
        drawText(canvas,p,"Qty",305,tableY+16);
        drawText(canvas,p,"Rate",365,tableY+16);
        if(taxInvoice) drawText(canvas,p,"Tax",440,tableY+16);
        drawText(canvas,p,"Amount",505,tableY+16);
        p.setColor(android.graphics.Color.BLACK);
        p.setTypeface(Typeface.DEFAULT);
        y=tableY+42;

        double calculatedSubtotal=0;
        if(items!=null){
            for(int i=0;i<items.length();i++){
                JSONObject it=items.getJSONObject(i);
                String name=it.optString("name","");
                String hsn=it.optString("hsn","");
                String qty=it.optString("qty","");
                String unit=it.optString("unit","piece");
                double rate=it.optDouble("rate",0);
                double amount=quantityValue(qty,unit)*rate;
                double taxRate=it.optDouble("taxRate",0);
                if(y>770){
                    doc.finishPage(page);
                    pageNo++;
                    page=doc.startPage(new PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNo).create());
                    canvas=page.getCanvas();
                    float nextHeaderBottom = drawPdfHeader(canvas,p,logo,pageWidth,cfg,taxInvoice);
                    y=(int)nextHeaderBottom+22;
                }
                drawText(canvas,p,String.valueOf(i+1),42,y);
                drawText(canvas,p,trimText(name+(hsn.isEmpty()?"":" / HSN "+hsn),34),70,y);
                drawText(canvas,p,trimText(qty+" "+unit,12),305,y);
                drawText(canvas,p,String.format(Locale.US,"%.2f",rate),365,y);
                if(taxInvoice) drawText(canvas,p,String.format(Locale.US,"%.0f%%",taxRate),440,y);
                drawText(canvas,p,String.format(Locale.US,"%.2f",amount),505,y);
                canvas.drawLine(35,y+7,560,y+7,p);
                y+=24;
                calculatedSubtotal+=amount;
            }
        }
        double subtotal=b.has("subtotal")?b.optDouble("subtotal",calculatedSubtotal):calculatedSubtotal;
        double discount=b.optDouble("discount",0);
        double finalTotal=b.has("total")?b.optDouble("total",Math.max(0,subtotal-discount)):Math.max(0,subtotal-discount);
        if (y > 690) {
            doc.finishPage(page);
            pageNo++;
            page=doc.startPage(new PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNo).create());
            canvas=page.getCanvas();
            float nextHeaderBottom = drawPdfHeader(canvas,p,logo,pageWidth,cfg,taxInvoice);
            y=(int)nextHeaderBottom+22;
        }
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(10);
        drawText(canvas,p,"Subtotal: ₹" + String.format(Locale.US,"%.2f",subtotal),390,y+20);
        int totalY = y+38;
        if (discount > 0.000001) {
            drawText(canvas,p,"Discount: -₹" + String.format(Locale.US,"%.2f",discount),390,y+37);
            totalY = y+58;
        }
        if(taxInvoice){
            int ty=totalY+18;
            drawText(canvas,p,"Taxable Value: ₹"+String.format(Locale.US,"%.2f",tax.optDouble("taxable",0)),390,ty);
            if(tax.optBoolean("inter",false)) drawText(canvas,p,"IGST: ₹"+String.format(Locale.US,"%.2f",tax.optDouble("igst",0)),390,ty+17);
            else { drawText(canvas,p,"CGST: ₹"+String.format(Locale.US,"%.2f",tax.optDouble("cgst",0)),390,ty+17); drawText(canvas,p,"SGST: ₹"+String.format(Locale.US,"%.2f",tax.optDouble("sgst",0)),390,ty+34); }
            drawText(canvas,p,"Total GST: ₹"+String.format(Locale.US,"%.2f",tax.optDouble("tax",0)),390,ty+(tax.optBoolean("inter",false)?34:51));
            totalY=ty+(tax.optBoolean("inter",false)?52:69);
        }
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(14);
        drawText(canvas,p,"Total Amount: ₹" + String.format(Locale.US,"%.2f",finalTotal),35,totalY);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(10);
        String footerMsg = cfg == null ? "" : cfg.optString("footer","");
        if (!footerMsg.trim().isEmpty()) {
            p.setTextAlign(Paint.Align.LEFT);
            for (String line : wrapText(footerMsg,p,330)) { drawText(canvas,p,line,35,y+64); y+=14; }
        }
        drawText(canvas,p,"Goods once sold will not be taken back.",35,y+78);
        String signature = cfg == null ? "" : cfg.optString("signature","").trim();
        if(!signature.isEmpty()){
            p.setTypeface(Typeface.DEFAULT_BOLD);
            drawText(canvas,p,signature,410,y+64);
            p.setTypeface(Typeface.DEFAULT);
            drawText(canvas,p,"Authorized Signatory",410,y+80);
        }
        p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.ITALIC));
        p.setTextSize(8); p.setTextAlign(Paint.Align.CENTER);
        drawText(canvas,p,cfg == null ? "Bill created by DukaanBill • Contact 8087794271 for more details" : cfg.optString("creditFooter","Bill created by DukaanBill • Contact 8087794271 for more details"),pageWidth/2f,812);
        p.setTypeface(Typeface.DEFAULT); p.setTextAlign(Paint.Align.LEFT);

        doc.finishPage(page);
        ByteArrayOutputStream bos=new ByteArrayOutputStream();
        doc.writeTo(bos); doc.close();
        String filename="Bill_"+b.optString("billNo","Bill").replaceAll("[^A-Za-z0-9_-]","_")+".pdf";
        return saveForSharing(bos.toByteArray(),filename,"application/pdf");
    }

    private String trimText(String s,int max){ if(s==null)return ""; return s.length()>max?s.substring(0,max-1)+"…":s; }
    private String formatDate(String d){ if(d==null||d.length()<10)return d; return d.substring(8,10)+"/"+d.substring(5,7)+"/"+d.substring(0,4); }

    private double quantityValue(String q, String defaultUnit){
        if(q==null)return 0;
        String s=q.trim().toLowerCase().replace(",","");
        try{
            java.util.regex.Matcher m=java.util.regex.Pattern.compile(
                    "(\\d+(?:\\.\\d+)?)\\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pack|packs|box|boxes|bottle|bottles|dozen)?",
                    java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s);
            if(!m.find()) return 0;
            double n=Double.parseDouble(m.group(1));
            String u=m.group(2); if(u==null)u=defaultUnit==null?"piece":defaultUnit;
            u=u.toLowerCase();
            if(u.equals("mg")||u.startsWith("milligram"))return n/1000000.0;
            if(u.equals("g")||u.equals("gm")||u.startsWith("gram"))return n/1000.0;
            if(u.equals("ml")||u.startsWith("milliliter")||u.startsWith("millilitre"))return n/1000.0;
            if(u.equals("l")||u.equals("ltr")||u.equals("lt")||u.equals("liter")||u.equals("litre")||u.equals("liters")||u.equals("litres"))return n;
            if(u.equals("dozen")||u.equals("dz"))return n*12.0;
            return n;
        }catch(Exception e){return 0;}
    }

    private File copyToPurchaseStorage(Uri uri, String originalName) throws Exception {
        String safe=UUID.randomUUID().toString()+"_"+(originalName==null?"document":originalName).replaceAll("[^A-Za-z0-9._-]","_");
        File outFile=new File(purchaseDocsDir,safe);
        try(InputStream in=getContentResolver().openInputStream(uri); OutputStream out=new FileOutputStream(outFile)){
            if(in==null)throw new Exception("Could not read selected document");
            byte[] buf=new byte[8192]; int n;
            while((n=in.read(buf))>0)out.write(buf,0,n);
        }
        return outFile;
    }

    private void sendPurchaseProgress(String message){
        try{
            String encoded=android.util.Base64.encodeToString(message.getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
            runOnUiThread(()->webView.evaluateJavascript("window.onPurchaseImportProgress && window.onPurchaseImportProgress(atob('"+encoded+"'))",null));
        }catch(Exception ignored){}
    }

    private void sendPurchaseError(String message){
        try{
            String encoded=android.util.Base64.encodeToString((message==null?"Unknown error":message).getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
            runOnUiThread(()->webView.evaluateJavascript("window.onPurchaseImportError && window.onPurchaseImportError(atob('"+encoded+"'))",null));
        }catch(Exception ignored){}
    }

    private void sendPurchaseResult(String attachmentId,String fileName,String mime,String text){
        try{
            JSONObject o=new JSONObject();
            o.put("attachmentId",attachmentId);
            o.put("fileName",fileName==null?"":fileName);
            o.put("mime",mime==null?"":mime);
            o.put("text",text==null?"":text);
            String encoded=android.util.Base64.encodeToString(o.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
            runOnUiThread(()->webView.evaluateJavascript("window.onPurchaseImportResultBase64 && window.onPurchaseImportResultBase64('"+encoded+"')",null));
        }catch(Exception e){sendPurchaseError(e.getMessage());}
    }

    private void ocrImage(Uri uri, File stored, String fileName, String mime){
        sendPurchaseProgress("Reading invoice photo...");
        try{
            Bitmap bitmap=BitmapFactory.decodeFile(stored.getAbsolutePath());
            if(bitmap==null)throw new Exception("Could not decode the selected image");
            InputImage image=InputImage.fromBitmap(bitmap,0);
            TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            recognizer.process(image)
                .addOnSuccessListener(result->{
                    recognizer.close();
                    bitmap.recycle();
                    sendPurchaseProgress("Invoice photo read. Preparing purchase details...");
                    sendPurchaseResult(stored.getName(),fileName,mime,result.getText());
                })
                .addOnFailureListener(e->{recognizer.close();bitmap.recycle();sendPurchaseError("OCR failed: "+e.getMessage());});
        }catch(Exception e){sendPurchaseError("Could not read photo: "+e.getMessage());}
    }

    private String extractPdfText(File stored) throws Exception {
        try (PDDocument document = PDDocument.load(stored)) {
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
            String text = stripper.getText(document);
            return text == null ? "" : text;
        }
    }

    private void ocrPdf(Uri uri, File stored, String fileName, String mime){
        sendPurchaseProgress("Opening PDF invoice...");
        final ExecutorService executor=Executors.newSingleThreadExecutor();
        executor.execute(()->{
            try{
                // First try the PDF's native text layer. Most vendor invoices are
                // generated PDFs and this is considerably more accurate than OCR.
                sendPurchaseProgress("Checking the PDF text layer...");
                String directText=extractPdfText(stored);
                if(directText!=null && directText.trim().length()>50){
                    sendPurchaseProgress("PDF text found. Extracted " + directText.trim().length() + " characters.");
                    sendPurchaseResult(stored.getName(),fileName,mime,directText);
                    executor.shutdown();
                    return;
                }

                // Scanned/image-only PDF: fall back to page rendering + ML Kit OCR.
                sendPurchaseProgress("No usable PDF text layer found. Starting OCR...");
                ParcelFileDescriptor pfd=null;
                PdfRenderer renderer=null;
                try{
                    pfd=ParcelFileDescriptor.open(stored,ParcelFileDescriptor.MODE_READ_ONLY);
                    renderer=new PdfRenderer(pfd);
                    int pages=renderer.getPageCount();
                    StringBuilder all=new StringBuilder();
                    sendPurchaseProgress("PDF opened. " + pages + " page(s) found.");
                    TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                    try{
                        for(int index=0; index<pages; index++){
                            sendPurchaseProgress("Reading PDF page " + (index+1) + " of " + pages + "...");
                            PdfRenderer.Page page=renderer.openPage(index);
                            try{
                                float scale=3.0f;
                                int w=Math.max(1600,Math.round(page.getWidth()*scale));
                                int h=Math.max(2200,Math.round(page.getHeight()*scale));
                                float ratio=(float)page.getWidth()/(float)page.getHeight();
                                if((float)w/(float)h > ratio) w=Math.round(h*ratio); else h=Math.round(w/ratio);
                                Bitmap bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
                                Canvas canvas=new Canvas(bmp);
                                canvas.drawColor(android.graphics.Color.WHITE);
                                page.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT);
                                InputImage image=InputImage.fromBitmap(bmp,0);
                                try{
                                    com.google.mlkit.vision.text.Text result=Tasks.await(recognizer.process(image));
                                    String pageText=result==null?"":result.getText();
                                    if(pageText!=null && !pageText.trim().isEmpty()){
                                        all.append("\n").append(pageText);
                                        sendPurchaseProgress("Page " + (index+1) + " read. " + pageText.length() + " characters found...");
                                    }else{
                                        sendPurchaseProgress("Page " + (index+1) + " read, but no text was detected.");
                                    }
                                } finally { bmp.recycle(); }
                            } finally { page.close(); }
                        }
                    } finally { recognizer.close(); }
                    String finalText=all.toString();
                    sendPurchaseProgress("OCR complete. " + finalText.trim().length() + " characters extracted.");
                    sendPurchaseResult(stored.getName(),fileName,mime,finalText);
                } finally {
                    try{if(renderer!=null)renderer.close();}catch(Exception ignored){}
                    try{if(pfd!=null)pfd.close();}catch(Exception ignored){}
                }
            }catch(Exception e){
                sendPurchaseError("Could not read PDF: " + (e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));
            }finally{
                executor.shutdown();
            }
        });
    }

    private void importPurchaseUri(Uri uri){
        try{
            String original=uri.getLastPathSegment();
            if(original==null||original.trim().isEmpty()) original="vendor_bill_"+System.currentTimeMillis();
            String mime=getContentResolver().getType(uri);
            if(mime==null||mime.trim().isEmpty()) mime=original.toLowerCase().endsWith(".pdf")?"application/pdf":"image/jpeg";
            sendPurchaseProgress("Saving the original vendor bill...");
            File stored=copyToPurchaseStorage(uri,original);
            String lower=original.toLowerCase();
            if(mime.equalsIgnoreCase("application/pdf")||lower.endsWith(".pdf")) ocrPdf(uri,stored,original,mime);
            else ocrImage(uri,stored,original,mime);
        }catch(Exception e){sendPurchaseError("Could not import purchase bill: "+e.getMessage());}
    }

    private void openPurchaseAttachment(String id,String mime){
        try{
            File file=new File(purchaseDocsDir,id);
            if(!file.exists())throw new Exception("Attachment not found");
            byte[] data=readAll(file);
            Uri uri=saveToCacheProvider(data,file.getName());
            Intent view=new Intent(Intent.ACTION_VIEW);
            view.setDataAndType(uri,mime==null?"application/octet-stream":mime);
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            view.setClipData(ClipData.newRawUri(file.getName(),uri));
            startActivity(Intent.createChooser(view,"Open Purchase Bill"));
        }catch(Exception e){Toast.makeText(this,"Could not open attachment: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private byte[] readAll(File f)throws Exception{
        try(InputStream in=new FileInputStream(f);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);return out.toByteArray();
        }
    }

    private String loadAppState() {
        try { return localDb.loadState(); } catch (Exception e) { return "{}"; }
    }

    private void saveAppState(String json) {
        try { localDb.saveState(json); } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "Could not save local data: " + e.getMessage(), Toast.LENGTH_LONG).show());
        }
    }

    private void addFileToZip(ZipOutputStream zos, File file, String entryName) throws Exception {
        ZipEntry entry = new ZipEntry(entryName);
        zos.putNextEntry(entry);
        try (InputStream in = new FileInputStream(file)) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
        }
        zos.closeEntry();
    }

    private static byte[] hexToBytes(String hex) {
        byte[] out = new byte[hex.length()/2];
        for (int i=0;i<out.length;i++) out[i]=(byte)Integer.parseInt(hex.substring(i*2,i*2+2),16);
        return out;
    }

    private static String hex(byte[] data) {
        StringBuilder sb=new StringBuilder(data.length*2);
        for(byte b:data) sb.append(String.format(Locale.US,"%02x",b & 0xff));
        return sb.toString();
    }

    private boolean verifyShopNamePasswordInternal(String password) {
        if (password == null) return false;
        try {
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[] salt=hexToBytes(SHOP_PASSWORD_SALT_HEX);
            byte[] h=md.digest(concat(salt, password.getBytes(StandardCharsets.UTF_8)));
            for(int i=0;i<SHOP_PASSWORD_ITERATIONS;i++) h=md.digest(concat(salt,h));
            return MessageDigest.isEqual(h, hexToBytes(SHOP_PASSWORD_DIGEST_HEX));
        } catch(Exception e){ return false; }
    }

    private static byte[] concat(byte[] a, byte[] b) {
        byte[] out=new byte[a.length+b.length];
        System.arraycopy(a,0,out,0,a.length); System.arraycopy(b,0,out,a.length,b.length); return out;
    }

    /** Create a compact integrity signature for the protected shop name.
     *  Restore never asks the user for a password. The signature lets the app detect
     *  casual/manual edits to the shop name inside a backup while keeping restore portable.
     */
    private String shopNameIntegrity(String shopName) throws Exception {
        if (shopName == null) shopName = "";
        byte[] key = hexToBytes(SHOP_PASSWORD_DIGEST_HEX);
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(key, "HmacSHA256"));
        return hex(mac.doFinal(shopName.getBytes(StandardCharsets.UTF_8)));
    }

    private boolean verifyShopNameIntegrity(String shopName, String signature) {
        try {
            if (signature == null || signature.trim().isEmpty()) return false;
            return MessageDigest.isEqual(shopNameIntegrity(shopName).getBytes(StandardCharsets.UTF_8), signature.trim().toLowerCase(Locale.US).getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) { return false; }
    }

    private File createBackupZip() throws Exception {
        File backupDir = new File(getCacheDir(), "backups");
        if (!backupDir.exists()) backupDir.mkdirs();
        String stamp = new java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new java.util.Date());
        File zip = new File(backupDir, "DukaanBill_Backup_" + stamp + ".zip");
        File dbFile = getDatabasePath("dukaanbill.db");
        if (!dbFile.exists()) throw new Exception("Local database is not available yet");
        String state = localDb.loadState();
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zip))) {
            addFileToZip(zos, dbFile, BACKUP_DB_ENTRY);
            ZipEntry stateEntry = new ZipEntry(BACKUP_STATE_ENTRY);
            zos.putNextEntry(stateEntry);
            zos.write(state.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            zos.closeEntry();

            String shopName = "DUKAAN BILL";
            try { shopName = new JSONObject(state).optString("shopName", shopName); } catch (Exception ignored) {}
            ZipEntry identityEntry = new ZipEntry(BACKUP_IDENTITY_ENTRY);
            zos.putNextEntry(identityEntry);
            JSONObject identity = new JSONObject();
            identity.put("version", 1);
            identity.put("shopNameSignature", shopNameIntegrity(shopName));
            zos.write(identity.toString().getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();

            if (purchaseDocsDir.exists()) {
                File[] files = purchaseDocsDir.listFiles();
                if (files != null) {
                    for (File f : files) if (f.isFile()) addFileToZip(zos, f, "attachments/" + f.getName());
                }
            }
            ZipEntry info = new ZipEntry("backup_info.txt");
            zos.putNextEntry(info);
            String text = "DukaanBill\nBackup created: " + new java.util.Date() + "\nIncludes local SQLite database, app settings, protected shop identity metadata, and purchase invoice attachments.\nRestore does not require a password.\n";
            zos.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            zos.closeEntry();
        }
        return zip;
    }

    private void startBackup() {
        try {
            pendingBackupZip = createBackupZip();
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/zip");
            i.putExtra(Intent.EXTRA_TITLE, pendingBackupZip.getName());
            startActivityForResult(i, REQ_BACKUP_CREATE);
        } catch (Exception e) {
            Toast.makeText(this, "Backup failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void copyFileToUri(File src, Uri dest) throws Exception {
        try (InputStream in = new FileInputStream(src); OutputStream out = getContentResolver().openOutputStream(dest)) {
            if (out == null) throw new Exception("Could not open backup destination");
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            out.flush();
        }
    }

    private void startRestore() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        startActivityForResult(i, REQ_BACKUP_RESTORE);
    }

    private boolean safeZipPath(String name) {
        if (name == null || name.length() == 0 || name.startsWith("/") || name.contains("\\")) return false;
        return !name.contains("../") && !name.equals("..") && !name.contains("/../");
    }

    private void restoreBackup(Uri uri) throws Exception {
        File restoreDir = new File(getCacheDir(), "restore_" + System.currentTimeMillis());
        if (!restoreDir.mkdirs()) throw new Exception("Could not create restore workspace");
        File zipFile = new File(restoreDir, "backup.zip");
        try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(zipFile)) {
            if (in == null) throw new Exception("Could not read backup file");
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) out.write(b,0,n);
        }
        File restoredDb = new File(restoreDir, "dukaanbill.db");
        File restoredState = new File(restoreDir, "app_state.json");
        File restoredAttachments = new File(restoreDir, "attachments");
        File restoredIdentity = new File(restoreDir, "shop_identity.sig");
        if (!restoredAttachments.mkdirs()) restoredAttachments.mkdirs();
        boolean dbFound=false;
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile))) {
            ZipEntry e;
            byte[] b = new byte[8192];
            while ((e = zis.getNextEntry()) != null) {
                if (e.isDirectory() || !safeZipPath(e.getName())) { zis.closeEntry(); continue; }
                File outFile;
                if (e.getName().equals(BACKUP_DB_ENTRY)) { outFile=restoredDb; dbFound=true; }
                else if (e.getName().equals(BACKUP_STATE_ENTRY)) outFile=restoredState;
                else if (e.getName().equals(BACKUP_IDENTITY_ENTRY)) outFile=restoredIdentity;
                else if (e.getName().startsWith("attachments/")) {
                    String fn=e.getName().substring("attachments/".length());
                    if (fn.contains("/") || fn.length()==0) { zis.closeEntry(); continue; }
                    outFile=new File(restoredAttachments, fn);
                } else { zis.closeEntry(); continue; }
                File parent=outFile.getParentFile(); if(parent!=null&&!parent.exists())parent.mkdirs();
                try(OutputStream out=new FileOutputStream(outFile)){int n;while((n=zis.read(b))>0)out.write(b,0,n);}
                zis.closeEntry();
            }
        }
        if(!dbFound || !restoredDb.exists()) throw new Exception("This is not a valid DukaanBill backup");
        // Restore is intentionally password-free. The protected shop-name metadata is used only
        // to detect casual/manual edits to app_state.json. Business data is still restored normally.
        // Older backups without this metadata remain backward-compatible.
        boolean settingsIntegrityValid = true;
        boolean hasIntegrityMetadata = restoredState.exists() && restoredIdentity.exists();
        String currentStateBeforeRestore = localDb.loadState();
        if (hasIntegrityMetadata) {
            try {
                JSONObject st = new JSONObject(new String(readAll(restoredState), StandardCharsets.UTF_8));
                JSONObject id = new JSONObject(new String(readAll(restoredIdentity), StandardCharsets.UTF_8));
                String restoredShopName = st.optString("shopName", "DUKAAN BILL");
                settingsIntegrityValid = verifyShopNameIntegrity(restoredShopName, id.optString("shopNameSignature", ""));
            } catch (Exception ignored) { settingsIntegrityValid = false; }
        }
        localDb.close();
        File currentDb=getDatabasePath("dukaanbill.db");
        if(!deleteDatabase("dukaanbill.db")) {
            if(currentDb.exists() && !currentDb.delete()) throw new Exception("Could not replace local database");
        }
        try(InputStream in=new FileInputStream(restoredDb);OutputStream out=new FileOutputStream(currentDb)){
            byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);
        }
        localDb=new LocalDatabase(this);
        if(hasIntegrityMetadata && !settingsIntegrityValid) {
            // Keep the restored business database, but reject only the tampered settings payload.
            // Do NOT write the complete pre-restore state here, because that would overwrite the
            // restored bills/customers/products as well. Only carry forward the receiving phone's
            // current settings object.
            try {
                JSONObject currentStateObj = new JSONObject(currentStateBeforeRestore);
                JSONObject settingsOnly = new JSONObject();
                if(currentStateObj.has("dukaanBillSettings")) {
                    settingsOnly.put("dukaanBillSettings", currentStateObj.optString("dukaanBillSettings", "{}"));
                }
                localDb.saveState(settingsOnly.toString());
            } catch(Exception ignored) {}
            runOnUiThread(() -> Toast.makeText(this, "Backup restored. Shop settings were kept because the backup settings integrity check failed.", Toast.LENGTH_LONG).show());
        }
        if(purchaseDocsDir.exists()){
            File[] old=purchaseDocsDir.listFiles(); if(old!=null)for(File f:old)if(f.isFile())f.delete();
        } else purchaseDocsDir.mkdirs();
        File[] atts=restoredAttachments.listFiles();
        if(atts!=null)for(File f:atts)if(f.isFile()){
            try(InputStream in=new FileInputStream(f);OutputStream out=new FileOutputStream(new File(purchaseDocsDir,f.getName()))){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}
        }
        getSharedPreferences("app_prefs",MODE_PRIVATE).edit().putBoolean("restored",true).apply();
        runOnUiThread(() -> { Toast.makeText(this, "Backup restored successfully. Reloading app...", Toast.LENGTH_LONG).show(); webView.postDelayed(() -> webView.reload(), 700); });
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == REQ_WEB_FILE_CHOOSER) {
            if (webFileCallback != null) {
                Uri[] results = (resultCode == RESULT_OK && data != null) ? new Uri[]{data.getData()} : null;
                webFileCallback.onReceiveValue(results);
                webFileCallback = null;
            }
            return;
        }
        if(requestCode==REQ_SCAN_QR){
            if(resultCode==RESULT_OK && data!=null){
                IntentResult scanResult = IntentIntegrator.parseActivityResult(resultCode, data);
                if(scanResult != null && scanResult.getContents() != null){
                    String scanned = scanResult.getContents();
                    webView.post(() -> webView.evaluateJavascript("window.onActivationQrScanned && window.onActivationQrScanned(" +
                            JSONObject.quote(scanned) + ");", null));
                }
            }
            return;
        }
        if(resultCode!=RESULT_OK || data==null) return;
        if(requestCode==REQ_PURCHASE_DOCUMENT && data.getData()!=null){
            Uri uri=data.getData();
            try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            importPurchaseUri(uri);
        } else if(requestCode==REQ_BACKUP_CREATE && data.getData()!=null){
            try{
                if(pendingBackupZip==null||!pendingBackupZip.exists())throw new Exception("Backup file is missing");
                copyFileToUri(pendingBackupZip,data.getData());
                Toast.makeText(this,"Backup saved successfully. Keep this ZIP safely in your cloud.",Toast.LENGTH_LONG).show();
            }catch(Exception e){Toast.makeText(this,"Could not save backup: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        } else if(requestCode==REQ_BACKUP_RESTORE && data.getData()!=null){
            new Thread(() -> {
                try { restoreBackup(data.getData()); }
                catch(Exception e){runOnUiThread(() -> Toast.makeText(this,"Restore failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}
            }).start();
        }
    }

    private Uri createBillPdfForSharing(String json) throws Exception {
        JSONObject b = new JSONObject(json);
        JSONObject cfg = b.optJSONObject("settings");
        String paper = cfg == null ? "A4" : cfg.optString("paperSize", "A4");
        if ("58mm".equalsIgnoreCase(paper) || "80mm".equalsIgnoreCase(paper)) {
            byte[] bytes = createThermalPdfBytes(json);
            String filename = "Bill_" + b.optString("billNo", "Bill").replaceAll("[^A-Za-z0-9_-]", "_") + "_" + paper + ".pdf";
            return saveForSharing(bytes, filename, "application/pdf");
        }
        return createPdf(json);
    }

    private class AndroidBridge {
        @JavascriptInterface public void shareBillImage(String base64Png,String billName,String phone){
            try{byte[] data=Base64.decode(base64Png,Base64.DEFAULT);String safe=(billName==null||billName.trim().isEmpty())?"DukaanBill":billName;shareFile(data,safe+".png","image/png","WhatsApp Bill");}
            catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not share bill image: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void printBill(String json){ try{ MainActivity.this.printBill(json); }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not print bill: "+e.getMessage(),Toast.LENGTH_LONG).show());} }
        @JavascriptInterface public void directThermalPrint80(String json){ try{ MainActivity.this.directThermalPrint80(json); }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Direct print failed: "+e.getMessage(),Toast.LENGTH_LONG).show());} }
        @JavascriptInterface public void openBillPdf(String json){
            try{
                Uri uri=createBillPdfForSharing(json);
                Intent view=new Intent(Intent.ACTION_VIEW);
                view.setDataAndType(uri,"application/pdf");
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                view.setClipData(ClipData.newRawUri("DukaanBill PDF",uri));
                try{
                    startActivity(view);
                }catch(Exception noViewer){
                    // The PDF has already been saved to Downloads/DukaanBill on modern Android.
                    // If there is no PDF viewer, let Android offer any compatible app.
                    Intent chooser=new Intent(Intent.ACTION_VIEW);
                    chooser.setDataAndType(uri,"application/pdf");
                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                    chooser.setClipData(ClipData.newRawUri("DukaanBill PDF",uri));
                    startActivity(Intent.createChooser(chooser,"Open PDF with"));
                }
            }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not create/open PDF: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void shareDukaanBillToWhatsApp(String json){
            try{
                byte[] data=json.getBytes(StandardCharsets.UTF_8);
                Uri uri=saveToCacheProvider(data,"DukaanBill_"+new JSONObject(json).optString("billNo","Bill").replaceAll("[^A-Za-z0-9_-]","_")+".dukaanbill");
                Intent send=new Intent(Intent.ACTION_SEND);
                send.setType("application/vnd.dukaanbill");
                send.putExtra(Intent.EXTRA_STREAM,uri);
                send.putExtra(Intent.EXTRA_TEXT,"Dukaan Bill - Thermal Print");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                send.setClipData(ClipData.newRawUri("Dukaan Bill",uri));
                Intent chooser=Intent.createChooser(send,"Send Dukaan Bill");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(chooser);
            }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not share Dukaan Bill: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public boolean isAppActivated(){ return isActivated(); }
        @JavascriptInterface public String createActivationRequest(){ try{return MainActivity.this.createActivationRequest("SHOP");}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public String createShopSetupInvite(String shopName,String shopMobile,String managerName,String address,String gstin,String state,String pin){ try{return MainActivity.this.createShopSetupInvite(shopName,shopMobile,managerName,address,gstin,state,pin);}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public String acceptShopSetupInvite(String invite){ try{ JSONObject p=MainActivity.this.verifyShopSetupInvite(invite); getSharedPreferences("activation",MODE_PRIVATE).edit().putString("pending_shop_setup",invite).putString("shop_setup_id",p.optString("setupId")).putString("shop_name",p.optString("shopName")).putString("shop_mobile",p.optString("shopMobile")).putString("shop_manager",p.optString("managerName")).putString("shop_address",p.optString("address")).putString("shop_gstin",p.optString("gstin")).putString("shop_state",p.optString("state")).apply(); return p.toString(); }catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public String pendingShopSetup(){ return getSharedPreferences("activation",MODE_PRIVATE).getString("pending_shop_setup",null); }
        @JavascriptInterface public String getActivatedShopSetup(){ try{ android.content.SharedPreferences p=getSharedPreferences("activation",MODE_PRIVATE); JSONObject o=new JSONObject(); o.put("shopName",p.getString("shop_name","")); o.put("shopMobile",p.getString("shop_mobile","")); o.put("managerName",p.getString("shop_manager","")); o.put("address",p.getString("shop_address","")); o.put("gstin",p.getString("shop_gstin","")); o.put("state",p.getString("shop_state","")); return o.toString(); }catch(Exception e){return "{}";} }
        @JavascriptInterface public void clearPendingShopSetup(){ getSharedPreferences("activation",MODE_PRIVATE).edit().remove("pending_shop_setup").remove("shop_setup_id").apply(); }

        @JavascriptInterface public String createOwnerActivationRequest(){ try{return MainActivity.this.createActivationRequest("OWNER");}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public String finalizeOwnerActivation(String pin){ try{MainActivity.this.finalizeOwnerActivation(pin);return "OK";}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public boolean pendingOwnerActivation(){ return getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).contains("pending_owner_key"); }
        @JavascriptInterface public String generateQr(String text){ try{return qrDataUrl(text);}catch(Exception e){return "ERROR:"+e.getMessage();} }
        @JavascriptInterface public void shareActivationRequest(String text){shareText("Dukaan Bill Activation Request",text);}
        @JavascriptInterface public void shareActivationToken(String text){shareText("Dukaan Bill Activation Approval",text);}
        @JavascriptInterface public void scanActivationQr(){scanQr();}
        @JavascriptInterface public boolean ownerConfigured(){return getSharedPreferences(OWNER_PREFS,MODE_PRIVATE).contains(OWNER_PRIVATE_PREF);}
        @JavascriptInterface public String configureOwner(String privateKeyB64,String pin){try{if(pin==null||pin.length()<6)return "ERROR:Owner PIN must be at least 6 digits/characters";saveOwnerPrivate(privateKeyB64,pin);return "OK";}catch(Exception e){return "ERROR:"+e.getMessage();}}
        @JavascriptInterface public String approveActivation(String request,String pin){try{return MainActivity.this.approveActivation(request,pin);}catch(Exception e){return "ERROR:"+e.getMessage();}}
        @JavascriptInterface public String applyActivation(String token){try{MainActivity.this.applyActivation(token);return "OK";}catch(Exception e){return "ERROR:"+e.getMessage();}}
        @JavascriptInterface public void openActivatedApp(){ if(isActivated()){ webView.clearHistory(); webView.loadUrl("file:///android_asset/www/index.html"); } }
        @JavascriptInterface public void openBilling(){ if(isActivated()){ webView.clearHistory(); webView.loadUrl("file:///android_asset/www/index.html"); } else { webView.loadUrl("file:///android_asset/www/activation.html"); } }
        @JavascriptInterface public void openOwnerDevice(){ setActivated(true); webView.loadUrl("file:///android_asset/www/index.html"); }
        @JavascriptInterface public void openOwnerMode(){ webView.loadUrl("file:///android_asset/www/activation.html?owner=1"); }
        @JavascriptInterface public void sendBillMessage(String phone,String message){
            try{
                String digits=phone==null?"":phone.replaceAll("\\D","");
                if(digits.startsWith("91")&&digits.length()==12) digits=digits.substring(2);
                if(digits.length()!=10) throw new Exception("Invalid 10 digit mobile number");
                Intent sms=new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"+digits));
                sms.putExtra("sms_body", message==null?"":message);
                sms.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(sms);
            }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not open mobile message: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void shareBillPdfToWhatsApp(String json,String phone){
            try{
                String digits=phone==null?"":phone.replaceAll("\\D","");
                if(digits.startsWith("91")&&digits.length()==12) digits=digits.substring(2);
                if(digits.length()!=10) throw new Exception("Invalid 10 digit mobile number");
                Uri uri=createBillPdfForSharing(json);
                Intent send=new Intent(Intent.ACTION_SEND); send.setType("application/pdf");
                send.putExtra(Intent.EXTRA_STREAM,uri); send.putExtra(Intent.EXTRA_TEXT,"DukaanBill - Bill");
                send.putExtra("jid","91"+digits+"@s.whatsapp.net"); send.setPackage("com.whatsapp");
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                send.setClipData(ClipData.newRawUri("DukaanBill PDF",uri));
                try{startActivity(send);}catch(Exception noDirect){
                    Intent chat=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/91"+digits+"?text=DukaanBill%20-%20Bill"));
                    chat.setPackage("com.whatsapp"); startActivity(chat);
                    Toast.makeText(MainActivity.this,"WhatsApp chat opened. Attach the PDF if direct attachment is not supported by your WhatsApp version.",Toast.LENGTH_LONG).show();
                }
            }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not open WhatsApp: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public String loadAppState(){ return MainActivity.this.loadAppState(); }
        @JavascriptInterface public void saveAppState(String json){ MainActivity.this.saveAppState(json); }
        @JavascriptInterface public void backupData(){ runOnUiThread(MainActivity.this::startBackup); }
        @JavascriptInterface public boolean verifyShopNamePassword(String password){ return MainActivity.this.verifyShopNamePasswordInternal(password); }
        @JavascriptInterface public void restoreData(){ runOnUiThread(MainActivity.this::startRestore); }
        @JavascriptInterface public void pickPurchaseDocument(){
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","image/jpeg","image/png","image/webp"});startActivityForResult(i,REQ_PURCHASE_DOCUMENT);
        }
        @JavascriptInterface public void openPurchaseAttachment(String id,String mime){openPurchaseAttachment(id,mime);}
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==REQ_BT_PRINT){
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED && pendingDirectPrintJson!=null && !pendingDirectPrintJson.isEmpty()){
                String payload=pendingDirectPrintJson; pendingDirectPrintJson=null;
                new Thread(() -> { try{ directThermalPrint80(payload); } catch(Exception e){ runOnUiThread(() -> Toast.makeText(this,"Direct print failed: "+e.getMessage(),Toast.LENGTH_LONG).show()); } }).start();
            } else { pendingDirectPrintJson=null; Toast.makeText(this,"Bluetooth permission is required for direct printing.",Toast.LENGTH_LONG).show(); }
        }
    }

    @Override public void onBackPressed(){
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("window.handleAndroidBack ? window.handleAndroidBack() : false", value -> {
            if ("false".equals(value) || "null".equals(value)) super.onBackPressed();
        });
    }
}

