# Dukaan Bill v3.50 - Offline Owner Activation

## Important
This release uses a no-cloud activation architecture. Billing remains local/offline.

The APK contains only the owner PUBLIC key. The owner PRIVATE key is supplied separately in `DukaanBill_Owner_Private_Key.txt` and must be kept secret.

## One-time owner phone setup
1. Install v3.50 on your own owner/admin phone.
2. Open the app.
3. Tap `Owner / Administrator Setup` on the activation screen.
4. Paste the contents of `DukaanBill_Owner_Private_Key.txt` into Owner Private Key.
5. Create an Owner PIN (minimum 6 characters).
6. Tap `Configure Owner Device`.
7. Tap `Use This Phone as Owner Device`.

After this, your phone can approve shop devices.

## Activate a new shop
1. Install Dukaan Bill v3.50 on the shop phone.
2. The app opens on `Activate Dukaan Bill`.
3. Tap `Generate Activation Request`.
4. The shop can show the request QR to you, or share/copy the request text.
5. On your owner phone open `Settings -> Owner / Activation Management`.
6. Tap `Scan New Shop Request QR`, or paste the request.
7. Enter your Owner PIN and tap `Approve Device`.
8. Show the generated approval QR to the shop phone, or share/copy the approval code remotely.
9. The shop scans the approval QR or pastes the approval code.
10. Dukaan Bill activates and opens normally.

## Reinstall / new phone
Uninstalling Dukaan Bill removes its local activation and device Keystore key. A fresh installation therefore requires owner approval again.

## Remote activation
The request and approval are plain text/QR payloads. WhatsApp, SMS or email may be used only to transport those payloads. No cloud database or authentication server is required.

## Security notes
- Owner private key is encrypted locally using AES-GCM with a key derived from the Owner PIN.
- The owner private key is not stored in the APK.
- Each shop installation has a unique RSA key in Android Keystore.
- The owner signs an activation token containing that device's public key.
- The shop verifies the signature against the public key bundled in this release.
- An activation token issued for another installation/device is rejected.
- Keep `DukaanBill_Owner_Private_Key.txt` private. Anyone who obtains it and the Owner PIN can authorize devices.
