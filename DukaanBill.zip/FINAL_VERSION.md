Dukaan Bill v3.50
Offline owner-controlled device activation with QR request/approval, device-bound cryptographic activation, and retained v3.49 Print/PDF/WhatsApp/SMS/Thermal Share functionality.
