Dukaan Bill v3.51.2

Fixes v3.51.1 QR build and Owner Private Key file parsing.
