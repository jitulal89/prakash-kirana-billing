Dukaan Bill v3.48

Thermal Share + A4 WhatsApp PDF fix + customer Mobile Message feature.
