Dukaan Bill v3.53.2 – Owner Back to Billing E2E Fix

Root cause addressed:
- The Owner Administration page was relying primarily on a JavaScript-to-native WebView bridge call to navigate back to Billing.
- Back to Billing now performs a direct local WebView navigation to index.html first, which is independent of the Android bridge lifecycle.
- Native openBilling/openActivatedApp remain available as fallback paths.

Validation path:
1. Owner activation completes and opens Billing.
2. Billing -> Owner Dashboard opens activation.html?owner=1.
3. Owner Administration renders because owner=1.
4. Back to Billing directly navigates to index.html.
5. Billing page loads without requiring a second activation.
6. Billing -> Owner Dashboard can be opened again.

No shop activation flow or billing functionality was changed.
