
const $=id=>document.getElementById(id);let currentRequest="",currentApproval="",currentInvite=""; const ownerPage=new URLSearchParams(location.search).get("owner")==="1";
function msg(t){$("requestStatus").textContent=t}
function showOwner(){ $("activationCard").classList.add("hidden");$("ownerCard").classList.remove("hidden"); if(window.Android?.ownerConfigured?.()){ $("ownerSetupArea").classList.add("hidden");$("ownerConfiguredArea").classList.remove("hidden");renderShops();refreshOwnerUnlock(); } }
function qr(el,data){const out=Android.generateQr(data);if(out&&out.startsWith("data:"))$(el).src=out;else alert(out||"Could not generate QR")}
function shops(){try{return JSON.parse(localStorage.getItem("dukaan_owner_shops")||"[]")}catch(e){return []}}
function saveShop(s){const a=shops();const i=a.findIndex(x=>x.shopId===s.shopId);if(i>=0)a[i]=s;else a.unshift(s);localStorage.setItem("dukaan_owner_shops",JSON.stringify(a));renderShops();populateShopSelect()}
function registerApprovedDevice(shopId,req){
 const a=shops(); const shop=a.find(x=>x.shopId===shopId); if(!shop)return;
 if(!Array.isArray(shop.devices))shop.devices=[];
 const key=String(req.deviceKey||"");
 if(!key)return;
 let d=shop.devices.find(x=>x.deviceKey===key);
 if(!d){ d={label:nextDeviceLabel(shop),deviceKey:key,deviceShortId:key.slice(-12),requestId:req.requestId||"",deviceType:req.deviceType||"SHOP",status:"ACTIVE",activatedAt:new Date().toISOString()}; shop.devices.push(d); }
 else {d.status="ACTIVE";d.requestId=req.requestId||d.requestId;}
 shop.deviceStatus="Active";
 localStorage.setItem("dukaan_owner_shops",JSON.stringify(a)); renderShops(); populateShopSelect();
}
function refreshOwnerUnlock(){
 const locked=!window.Android?.ownerSessionUnlocked?.();
 $("ownerUnlockArea")?.classList.toggle("hidden",!locked);
 $("ownerAdminArea")?.classList.toggle("hidden",locked);
}
function devicesForShop(shopId){ const all=[]; for(const s of shops()){ if(s.shopId===shopId && Array.isArray(s.devices)) all.push(...s.devices); } return all; }
function nextDeviceLabel(shop){ const n=Array.isArray(shop.devices)?shop.devices.length:0; return "Bill"+String.fromCharCode(65+n); }
function renderShops(){
 const a=shops();
 $("shopsList").innerHTML=a.length?a.map(s=>{const ds=Array.isArray(s.devices)?s.devices:[]; const active=ds.filter(d=>d.status!=="DEACTIVATED").length; const deviceHtml=ds.length?`<div class="muted" style="margin-top:7px">${ds.map(d=>`📱 ${esc(d.label||"Bill") } — ${esc(d.status||"ACTIVE")} <span class="muted">(${esc(d.deviceShortId||"")})</span>`).join("<br>")}</div>`:""; return `<div class="shop"><b>${esc(s.shopName||"Shop")}</b> <span class="pill">${active} device${active===1?"":"s"} active</span><br><span class="muted">${esc(s.shopMobile||"")}${s.managerName?" • "+esc(s.managerName):""}</span>${deviceHtml}</div>`}).join(""):"<div class='status muted'>No additional shops configured yet.</div>";
}
function populateShopSelect(){
 const a=shops(), sel=$("assignedShopSelect"); if(!sel)return;
 sel.innerHTML=a.map(s=>`<option value="${esc(s.shopId)}">${esc(s.shopName||"Shop")}</option>`).join("");
 $("assignedShopLabel")?.classList.toggle("hidden",a.length===0);
}
function esc(s){return String(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]))}

window.restoreOwnerDashboard=function(json){ try{ const o=JSON.parse(json||"{}"); if(Array.isArray(o.shops)) localStorage.setItem("dukaan_owner_shops",JSON.stringify(o.shops)); renderShops(); populateShopSelect(); }catch(e){} };
$("ownerLink").onclick=showOwner; if(ownerPage){ showOwner(); }
$("requestBtn").onclick=()=>{const r=Android.createActivationRequest();if(r.startsWith("ERROR:")){alert(r);return}currentRequest=r;$("requestArea").classList.remove("hidden");msg("Send this request to the Dukaan Bill owner. The owner will approve it and return an activation code.");qr("requestQr",r)};
$("ownerRequestBtn").onclick=()=>{const r=Android.createOwnerActivationRequest();if(r.startsWith("ERROR:")){alert(r);return}currentRequest=r;$("requestArea").classList.remove("hidden");msg("Send this Owner Device request to an existing Dukaan Bill Owner.");qr("requestQr",r)};
$("shareRequestBtn").onclick=()=>Android.shareActivationRequest(currentRequest);$("copyRequestBtn").onclick=()=>navigator.clipboard?.writeText(currentRequest).then(()=>msg("Activation request copied.")).catch(()=>msg(currentRequest));
$("scanApprovalBtn").onclick=()=>Android.scanActivationQr();$("enterApprovalBtn").onclick=()=>{$("approvalLabel").classList.remove("hidden");$("applyApprovalBtn").classList.remove("hidden");$("approvalCode").focus()};
$("applyApprovalBtn").onclick=()=>{const code=$("approvalCode").value.trim();const r=Android.applyActivation(code);if(r!=="OK"){alert(r);return}if(Android.pendingOwnerActivation()){const p=prompt("Create an Owner PIN (minimum 6 characters):","");if(!p){alert("Owner PIN is required.");return}const rr=Android.finalizeOwnerActivation(p);if(rr!=="OK"){alert(rr);return}alert("Owner device activated successfully.");Android.openActivatedApp()}else{alert("Dukaan Bill activated successfully.");Android.openActivatedApp()}};
$("setupOwnerBtn").onclick=()=>{const r=Android.configureOwner($("ownerKey").value.trim(),$("ownerPin").value);if(r==="OK"){alert("Owner device configured successfully.");$("ownerSetupArea").classList.add("hidden");$("ownerConfiguredArea").classList.remove("hidden");renderShops();refreshOwnerUnlock()}else alert(r)};
$("unlockOwnerBtn").onclick=()=>{const pin=$("ownerSessionPin").value; if(!pin){alert("Enter Owner PIN.");return} if(Android.unlockOwner(pin)){ $("ownerSessionPin").value=""; refreshOwnerUnlock(); } else alert("Incorrect Owner PIN.")};
$("saveShopProfileBtn").onclick=()=>{
 const shop={shopId:(crypto.randomUUID?crypto.randomUUID():String(Date.now())+"-"+Math.random()),
 shopName:$("shopName").value.trim(),shopMobile:$("shopMobile").value.trim(),managerName:$("shopManager").value.trim(),
 address:$("shopAddress").value.trim(),gstin:$("shopGstin").value.trim(),state:$("shopState").value.trim(),
 billPrefix:$("shopBillPrefix").value.trim()||"INV",billStart:parseInt($("shopBillStart").value||"1"),
 billTitle:$("shopBillTitle").value.trim()||"Bill",paperSize:$("shopPaperSize").value,
 bluetoothPrinter:$("shopBluetoothPrinter").value,taxInvoicePrefix:$("shopTaxInvoicePrefix").value.trim()||"INV",
 taxInvoiceStart:parseInt($("shopTaxInvoiceStart").value||"1"),vendorManagement:$("shopVendorManagement").checked,
 taxation:$("shopTaxation").checked,reverseCharge:$("shopReverseCharge").checked,showCustomer:$("shopShowCustomer").checked,
 tagline:$("shopTagline").value.trim(),footer:$("shopFooter").value.trim(),signature:$("shopSignature").value.trim(),
 creditFooter:$("shopCreditFooter").value.trim(),deviceStatus:"Not activated"};
 if(!shop.shopName){alert("Shop name is required.");return}
 saveShop(shop);
 $("shopSavedStatus").classList.remove("hidden");$("shopSavedStatus").textContent="Shop setup saved. The shop phone can now generate its activation request.";
};
$("scanRequestBtn").onclick=()=>Android.scanActivationQr();
$("approveBtn").onclick=()=>{
 try{
  const raw=$("ownerRequest").value.trim(); if(!raw){alert("Scan or paste an activation request first.");return}
  const req=JSON.parse(raw);
  if(req.deviceType==="SHOP"){
   const list=shops(); if(!list.length){alert("Configure at least one shop first.");return}
   const shop=list.find(x=>x.shopId===$("assignedShopSelect").value);
   if(!shop){alert("Select the shop for this device.");return}
   req.assignedShop=shop;
  }
  const r=Android.approveActivation(JSON.stringify(req)); if(r.startsWith("ERROR:")){alert(r);return}
  currentApproval=r;$("approvalArea").classList.remove("hidden");$("approvalCodeOut").value=r;qr("approvalQr",r);
  if(req.deviceType==="SHOP"){
   const list=shops(), shop=list.find(x=>x.shopId===req.assignedShop?.shopId); if(shop){shop.deviceStatus="Approval issued";saveShop(shop); registerApprovedDevice(shop.shopId,req);}
  }
 }catch(e){alert("Invalid activation request: "+e.message)}
};
$("shareApprovalBtn").onclick=()=>Android.shareActivationToken(currentApproval);$("copyApprovalBtn").onclick=()=>navigator.clipboard?.writeText(currentApproval).then(()=>alert("Approval copied."));
$("ownerUseBtn").onclick=()=>{if(Android.ownerConfigured()) {Android.openBilling();} else alert("Configure the Owner device first.")};$("ownerCloseBtn").onclick=()=>{try{window.location.replace("index.html");}catch(e){try{Android.openBilling();}catch(e2){try{Android.openActivatedApp();}catch(e3){location.href="index.html";}}}};
window.onActivationQrScanned=data=>{try{const o=JSON.parse(data);if(o.type==="DUKAAN_ACTIVATION_REQUEST"){$("ownerRequest").value=data;showOwner();refreshOwnerUnlock()}else if(o.type==="DUKAAN_SHOP_SETUP_INVITE"){alert("Shop Setup QR is no longer used. Please generate a Shop Activation Request from this phone.")}else if(o.type==="DUKAAN_ACTIVATION_TOKEN"||o.type==="DUKAAN_OWNER_ACTIVATION_TOKEN"){$("approvalLabel").classList.remove("hidden");$("applyApprovalBtn").classList.remove("hidden");$("approvalCode").value=data;$("applyApprovalBtn").click()}else alert("This is not a Dukaan Bill activation QR.")}catch(e){alert("Invalid Dukaan Bill QR.")}};
if(new URLSearchParams(location.search).get("owner")==="1")showOwner(); setTimeout(refreshOwnerUnlock,100); setTimeout(populateShopSelect,100);
