const $=id=>document.getElementById(id);
const state={products:JSON.parse(localStorage.getItem("pksProducts")||"null")||[
{name:"Singdana",rate:180},{name:"Sabudana",rate:90},{name:"Sugar",rate:60},{name:"Rice",rate:55},{name:"Dal",rate:120}
],bills:JSON.parse(localStorage.getItem("pksBills")||"[]")};
let editingProduct=-1, deferredInstall=null;

function save(){localStorage.setItem("pksProducts",JSON.stringify(state.products));localStorage.setItem("pksBills",JSON.stringify(state.bills))}
function today(){let d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
$("billDate").value=today();

function money(n){return "₹"+Number(n||0).toFixed(2)}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]))}
function nextBillNo(){
 const y=new Date().getFullYear(), nums=state.bills.map(b=>Number((b.billNo||"").split("/").pop())).filter(Number.isFinite);
 const next=Math.max(94,...nums)+1; return `#PKS-${y}/${String(next).padStart(3,"0")}`;
}
function addItem(item={name:"",qty:1,rate:0}){
 const row=document.createElement("div");row.className="item";
 row.innerHTML=`<label>Item<input class="iname" list="productNames" value="${esc(item.name)}" placeholder="Sugar"></label>
 <label>Qty<input class="iqty" type="number" min="0" step="0.01" value="${item.qty}"></label>
 <label>Rate<input class="irate" type="number" min="0" step="0.01" value="${item.rate}"></label>
 <div><label>Amount</label><div class="amount">₹0.00</div></div>
 <button class="remove" type="button">×</button>`;
 items.appendChild(row);
 row.querySelectorAll("input").forEach(x=>x.addEventListener("input",()=>{autoRate(row);calc()}));
 row.querySelector(".remove").onclick=()=>{row.remove();calc()};
}
function autoRate(row){
 const name=row.querySelector(".iname").value.trim().toLowerCase(), rate=row.querySelector(".irate").value;
 if(!rate||Number(rate)===0){const p=state.products.find(x=>x.name.toLowerCase()===name);if(p)row.querySelector(".irate").value=p.rate}
}
function calc(){
 let total=0;[...items.children].forEach(r=>{let q=+r.querySelector(".iqty").value||0,rate=+r.querySelector(".irate").value||0,a=q*rate;total+=a;r.querySelector(".amount").textContent=money(a)});$("grandTotal").textContent=money(total)
}
function clearBill(){ $("customer").value="";items.innerHTML="";addItem();$("billDate").value=today();$("voiceStatus").textContent="Ready";calc() }
addItem();

document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
function showPage(name){
 document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.page===name));
 document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
 $(name+"Page").classList.add("active");
 if(name==="products")renderProducts();if(name==="history")renderHistory()
}
$("addItemBtn").onclick=()=>addItem();
$("clearBtn").onclick=()=>clearBill();
$("newBillBtn")?.addEventListener("click",clearBill);

function normalizeVoiceText(text){
  return String(text||"")
    .replace(/[₹,]/g," ")
    .replace(/\s+/g," ")
    .trim();
}

function cleanCommandText(text){
  return normalizeVoiceText(text)
    .replace(/\b(?:please|pls|kindly)\b/gi," ")
    .replace(/\s+/g," ")
    .trim();
}

function findProductInText(text){
  const lower=text.toLowerCase();
  const products=[...state.products].sort((a,b)=>b.name.length-a.name.length);
  for(const p of products){
    const escaped=p.name.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
    const re=new RegExp("(?:^|\\s)"+escaped+"(?:\\s|$)","i");
    const match=re.exec(text);
    if(match) return {product:p,index:match.index+(match[0].length-match[0].trimStart().length),nameEnd:(match.index+(match[0].length-match[0].trimStart().length))+p.name.length};
  }
  return null;
}

function parseVoice(text){
  const raw=cleanCommandText(text);
  if(!raw)return;

  const addCommand=/(?:^|\s)(?:add|new)\s+(?:item|items|samaan|saman|सामान)(?:\s|$)/i.test(raw);
  const cleaned=raw
    .replace(/(?:^|\s)(?:add|new)\s+(?:item|items|samaan|saman|सामान)(?:\s|$)/ig," ")
    .replace(/\s+/g," ")
    .trim();

  // Customer is updated only when the spoken command explicitly says Customer/Grahak.
  const cm=cleaned.match(/(?:^|\s)(?:customer|grahak|ग्राहक)\s+(.+?)(?=\s+(?:item|add|new|samaan|saman|सामान)\b|$)/i);
  if(cm){
    $('customer').value=cm[1].trim().replace(/[,.]+$/,'');
  }

  const found=[];
  let working=cleaned;

  // First look for saved products. This is much more reliable than a generic
  // greedy regex, especially after a pause/restart of Android speech recognition.
  const products=[...state.products].sort((a,b)=>b.name.length-a.name.length);
  for(const p of products){
    const escaped=p.name.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
    const re=new RegExp("(?:^|\\s)"+escaped+"\\s+(\\d+(?:\\.\\d+)?)\\s*(?:kg|kgs|kilo|kilogram|litre|liter|ltr|l|packet|packets|pcs|piece|pieces|किलो|लीटर|पैकेट)?(?:\\s+(?:at|rate|rs|₹|रुपये))?\\s*(\\d+(?:\\.\\d+)?)?","i");
    const m=re.exec(working);
    if(m){
      found.push({name:p.name,qty:+m[1],rate:m[2]?+m[2]:p.rate});
      working=working.replace(m[0]," ");
    }
  }

  // Generic fallback for items not yet in Product Master.
  const regex=/([A-Za-z\u0900-\u097F][A-Za-z\u0900-\u097F0-9 .&()\/-]*?)\s+(\d+(?:\.\d+)?)\s*(?:kg|kgs|kilo|kilogram|litre|liter|ltr|l|packet|packets|pcs|piece|pieces|किलो|लीटर|पैकेट)?\s*(?:at|rate|रुपये|rs|₹)?\s*(\d+(?:\.\d+)?)/gi;
  let m;
  while((m=regex.exec(working))){
    let name=m[1].trim().replace(/^(customer|item|add|new)\s+/i,"").trim();
    if(name && !/^(customer|add|new)$/i.test(name)){
      found.push({name,qty:+m[2],rate:+m[3]});
    }
  }

  if(found.length){
    found.forEach(addItem);
    calc();
    $('voiceStatus').textContent=`Added ${found.length} item(s). Continue speaking or say “add item …”.`;
    return;
  }

  // If the user explicitly says Add Item without details, create a blank row.
  if(addCommand){
    addItem();
    calc();
    const rows=items.children;
    const last=rows[rows.length-1];
    last?.querySelector('.iname')?.focus();
    $('voiceStatus').textContent='New item added. Say “add item Sugar 2 kg 60”.';
    return;
  }

  if(cm){
    $('voiceStatus').textContent='Customer added. Now say an item, for example “Sugar 2 kg 60”.';
  }else{
    $('voiceStatus').textContent='Heard: “'+raw+'” — no item detected. Try “add item Sugar 2 kg 60”.';
  }
}


let rec=null;
let voiceActive=false;
let restartTimer=null;
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(SR){
  rec=new SR();

  // Android WebView/Chrome is much more reliable when each spoken segment
  // ends naturally and recognition is restarted automatically. This allows
  // the shopkeeper to pause between customer and items without losing data.
  rec.interimResults=false;
  rec.continuous=false;
  rec.maxAlternatives=3;

  rec.onstart=()=>{
    $('voiceBtn').classList.add('listening');
    $('voiceStatus').textContent='Listening… Speak a command, then pause if needed.';
  };

  rec.onresult=e=>{
    for(let i=e.resultIndex;i<e.results.length;i++){
      if(e.results[i].isFinal){
        const t=e.results[i][0].transcript.trim();
        if(t){
          $('voiceStatus').textContent='Heard: '+t;
          parseVoice(t);
        }
      }
    }
  };

  rec.onerror=e=>{
    if(!voiceActive)return;

    if(e.error==='not-allowed'||e.error==='service-not-allowed'){
      voiceActive=false;
      $('voiceBtn').classList.remove('listening');
      $('voiceStatus').textContent='Microphone permission is required. Allow microphone access for the app.';
      return;
    }

    // no-speech/aborted/network can happen when the user pauses. Restart.
    $('voiceStatus').textContent='Listening…';
  };

  rec.onend=()=>{
    $('voiceBtn').classList.remove('listening');

    if(voiceActive){
      clearTimeout(restartTimer);
      restartTimer=setTimeout(()=>{
        if(!voiceActive)return;
        try{
          rec.lang=$('voiceLang').value;
          rec.start();
        }catch(e){
          // onend will fire again and retry.
        }
      },300);
    }else{
      $('voiceStatus').textContent='Ready';
    }
  };
}

$('voiceLang').onchange=()=>{
  if(rec)rec.lang=$('voiceLang').value;
};

$('voiceBtn').onclick=()=>{
  if(!rec){
    $('voiceStatus').textContent='Voice recognition is not supported here. Use Chrome on Android.';
    return;
  }

  if(voiceActive){
    voiceActive=false;
    clearTimeout(restartTimer);
    try{rec.stop()}catch(e){}
    $('voiceBtn').classList.remove('listening');
    $('voiceStatus').textContent='Voice stopped. Existing items are kept.';
    return;
  }

  voiceActive=true;
  rec.lang=$('voiceLang').value;

  try{
    rec.start();
  }catch(e){
    // If recognition is already transitioning, onend will restart it.
  }
};

$("generateBtn").onclick=()=>{
 const rows=[...items.children].map(r=>({name:r.querySelector(".iname").value.trim(),qty:+r.querySelector(".iqty").value||0,rate:+r.querySelector(".irate").value||0})).filter(x=>x.name&&x.qty>0);
 if(!rows.length){alert("Add at least one item.");return}
 const bill={billNo:nextBillNo(),date:$("billDate").value,customer:$("customer").value.trim()||"Cash Sale",items:rows,total:rows.reduce((s,x)=>s+x.qty*x.rate,0)};
 state.bills.unshift(bill);save();renderBill(bill);showPage("preview");$("previewPage").classList.add("active");
};

function renderBill(b){
 const date=b.date.split("-").reverse().join("/");
 $("billPreview").innerHTML=`<h1>PRAKASH KIRANA STORES</h1><div class="location">Dantoli, Nagpur</div><div class="pill">CASH MEMO / BILL</div><hr>
 <div class="meta"><div><b>Bill No:</b> ${esc(b.billNo)}</div><div><b>Date:</b> ${date}</div><div><b>Customer:</b> ${esc(b.customer)}</div><div><b>Payment Mode:</b> Cash</div></div>
 <table><thead><tr><th>Sr.</th><th>Item Description</th><th>Qty</th><th>Rate/kg (₹)</th><th>Amount (₹)</th></tr></thead><tbody>
 ${b.items.map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x.name)}</td><td>${x.qty} kg</td><td>${x.rate.toFixed(2)}</td><td>${(x.qty*x.rate).toFixed(2)}</td></tr>`).join("")}
 </tbody><tfoot><tr><td colspan="4">Total Amount:</td><td>${money(b.total)}</td></tr></tfoot></table>
 <div class="thanks">Thank you for shopping with us!</div><div class="muted">Goods once sold will not be taken back.</div>
 <div class="sign">For Prakash Kirana Stores<br><span>(Authorized Signatory)</span></div>`;
}
$("printBtn").onclick=()=>window.print();
$("backToBilling").onclick=()=>showPage("billing");

function renderProducts(){
 const list=$("productList");list.innerHTML="";
 state.products.forEach((p,i)=>{const r=document.createElement("div");r.className="product-row";r.innerHTML=`<div><div class="product-name">${esc(p.name)}</div><div class="muted">₹${p.rate.toFixed(2)} / kg</div></div><div><button class="secondary edit">Edit</button> <button class="danger del">Delete</button></div>`;
 r.querySelector(".edit").onclick=()=>openProduct(i);r.querySelector(".del").onclick=()=>{if(confirm("Delete this product?")){state.products.splice(i,1);save();renderProducts()}};list.appendChild(r)});
}
$("addProductBtn").onclick=()=>openProduct(-1);
function openProduct(i){editingProduct=i;$("modalTitle").textContent=i<0?"Add Product":"Edit Product";$("modalName").value=i<0?"":state.products[i].name;$("modalRate").value=i<0?"":state.products[i].rate;$("modal").classList.remove("hidden")}
$("modalCancel").onclick=()=>$("modal").classList.add("hidden");
$("modalSave").onclick=()=>{const name=$("modalName").value.trim(),rate=+$("modalRate").value;if(!name||rate<0){alert("Enter a product and rate.");return}if(editingProduct<0)state.products.push({name,rate});else state.products[editingProduct]={name,rate};save();$("modal").classList.add("hidden");renderProducts()};
function renderDatalist(){let dl=document.getElementById("productNames");if(dl)dl.remove();dl=document.createElement("datalist");dl.id="productNames";state.products.forEach(p=>{let o=document.createElement("option");o.value=p.name;dl.appendChild(o)});document.body.appendChild(dl)}
renderDatalist();

function renderHistory(){
 const q=$("billSearch").value.toLowerCase(),list=$("historyList");list.innerHTML="";
 const bills=state.bills.filter(b=>JSON.stringify(b).toLowerCase().includes(q));
 if(!bills.length){list.innerHTML='<div class="muted">No bills found.</div>';return}
 bills.forEach(b=>{const r=document.createElement("div");r.className="history-row";r.innerHTML=`<div><div class="history-title">${esc(b.billNo)} • ${esc(b.customer)}</div><div class="muted">${b.date.split("-").reverse().join("/")} • ${b.items.length} item(s) • ${money(b.total)}</div></div><button class="secondary">View</button>`;r.querySelector("button").onclick=()=>{renderBill(b);showPage("preview")};list.appendChild(r)})
}
$("billSearch").oninput=renderHistory;

window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;$("installBtn").classList.remove("hidden")});
$("installBtn").onclick=async()=>{if(deferredInstall){deferredInstall.prompt();deferredInstall=null;$("installBtn").classList.add("hidden")}};

if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
