Build Version 3.0

Required ZIP file: PrakashKiranaBilling_Android_v3_0_LocalBackupRestore.zip

The Android build must preserve the ML Kit dependency:
implementation 'com.google.mlkit:text-recognition:16.0.1'


### Workflow layout note
The workflow searches for the project settings file automatically, so the repository can contain the project directly or under a folder such as `app-source/DukaanBill_complete`.
