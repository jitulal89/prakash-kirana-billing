# DukaanBill

Offline Android billing app for small shops. Voice billing is intentionally disabled in this version.

## Core features
- Offline SQLite billing
- Customer and product masters
- Customer credit/outstanding tracking
- Credit sales automatically create a customer debit ledger entry
- Receive full or partial customer payments with Cash/UPI/Card/Other modes
- Customer ledger and current outstanding balance
- Customer outstanding included in Reports
- Vendor and purchase tracking
- Starting bill number setting (for example 202 -> 202, 203, 204...)
- Saraswati Traders-style invoice layout, without signature section
- Lightweight vector/text PDF generation for smaller files
- Bill history and PDF sharing
- Database backup and restore
- Shop profile and invoice terms settings

## Customer credit workflow
1. Add the customer in **Customers & Balances**.
2. Create a bill and select that customer.
3. Select **Credit** as payment type.
4. The bill total is added to the customer's outstanding balance.
5. Open **Customers & Balances** to see the outstanding amount.
6. Use **Receive Payment** for a full or partial payment.
7. Use **Ledger** to see all credit sales and payments.

Walk-in customers cannot be used for credit sales; the app requires a named customer so the balance is tracked correctly.

## Build
Open the project in Android Studio and build the `app` module. This environment does not include an Android SDK/Gradle installation, so an APK has not been claimed as tested here.
