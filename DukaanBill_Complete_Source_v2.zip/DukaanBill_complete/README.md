# DukaanBill

Offline Android billing app for small shops. Voice billing is intentionally disabled in this version.

## Build baseline
- Android Gradle Plugin: 8.5.2
- Kotlin: 1.9.24
- Gradle: 8.7 (recommended by the GitHub Actions workflow)
- Java/Kotlin JVM target: 17
- compileSdk/targetSdk: 35
- minSdk: 23

## Included features
- Offline SQLite billing
- Customer and product masters
- Customer credit/outstanding tracking
- Credit sales create customer debit ledger entries
- Full/partial customer payments with Cash/UPI/Card/Other modes
- Customer ledger and current outstanding balance
- Customer outstanding in Reports
- Vendor and purchase tracking
- Starting bill number setting (example: 202 -> 202, 203, 204...)
- Protection against resetting the next bill number below an already-used bill number
- Saraswati Traders-style invoice layout, without signature/authorised signatory
- Lightweight vector/text PDF generation for smaller PDF files
- Optional shop logo in the invoice when a logo path is configured
- Bill history and PDF sharing
- Database backup and restore
- Shop profile and invoice terms settings

## Customer credit workflow
1. Add the customer in Customers & Balances.
2. Create a bill and select that customer.
3. Select Credit as payment type.
4. The bill total is added to the customer's outstanding balance.
5. Use Receive Payment for a full or partial payment.
6. Use Ledger to see credit sales and payments.

Walk-in customers cannot be used for credit sales; a named customer is required.

## GitHub Actions build
The project source does not require a Gradle wrapper because the recommended GitHub Actions workflow installs Gradle 8.7 with `gradle/actions/setup-gradle@v4`.

The workflow should build the project from the directory containing `settings.gradle.kts` and run:

    gradle clean
    gradle assembleDebug --stacktrace

The Android SDK step should install at least:
- platform-tools
- platforms;android-35
- build-tools;35.0.0

## Important source fixes in this version
- Fixed the Kotlin `>>=` parsing problem in DatabaseHelper declarations.
- Fixed InvoicePdf number-to-words expression parsing.
- Fixed Canvas numeric arguments to use Float values.
- Fixed nullable shop-profile values passed to text inputs.
- Java and Kotlin compilation targets are both set to JVM 17.
- Invoice PDF generation is split into pages when there are many items instead of overflowing the page.
