# DukaanBill / Prakash Kirana Stores - Final Source

This build combines the latest Prakash Kirana feature source with Quick List, purchasing/vendor accounts, OCR/native PDF invoice extraction, local-first SQLite backup/restore, customer balances, billing template settings and configurable bill numbering.

Voice billing has been removed, including microphone permission and the WebView microphone permission bridge.

## GitHub Actions

The workflow is at `.github/workflows/build-apk.yml`.

It builds a debug APK with Java 17, Gradle 8.9.2 and Android SDK 35 and publishes `app-debug.apk` as the `DukaanBill-debug-apk` artifact.

## Main features

- Billing and bill history
- Quick List: `Item Qty Rate` and `Item Qty Unit Rate`
- Product master with unit/rate
- Customer records and customer balances/payments
- Cash/UPI/Card/Credit payment mode
- Configurable bill prefix and starting number
- Configurable shop/bill title/address/footer/signature
- Daily and monthly sales summary
- Vendor master and vendor accounts
- Purchase entry and vendor payments
- Vendor invoice PDF/photo import
- Native PDF text extraction and ML Kit OCR for invoice images
- Purchase invoice attachment retention
- Local-first SQLite app state
- Backup and restore ZIP including database and purchase attachments
- PDF/print/share bill
- Voice/microphone feature intentionally removed


## Build verification fixes

- GitHub Actions now uses Gradle 8.9.2, which satisfies Android Gradle Plugin 8.7.3 (minimum Gradle 8.9).
- Workflow automatically locates the Android project from settings.gradle/settings.gradle.kts, so it works whether the project is at repository root or inside a folder such as app-source/DukaanBill_complete.
- Fixed duplicate payment-mode HTML IDs; billing and vendor payment modes are now independent.
- Billing template logo visibility is configurable.
- PDF output receives the configured shop name, address, bill title, footer, signature and payment mode.
- Removed remaining user-facing voice/microphone wording and confirmed no RECORD_AUDIO or browser SpeechRecognition API is present.
