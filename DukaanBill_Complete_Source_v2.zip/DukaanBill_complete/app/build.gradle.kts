plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}

android {
    namespace = "com.dukaanbill.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.dukaanbill.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    // Keep Java and Kotlin on the same JVM target for GitHub Actions/Gradle builds.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

}

kotlin {
    jvmToolchain(17)
}
