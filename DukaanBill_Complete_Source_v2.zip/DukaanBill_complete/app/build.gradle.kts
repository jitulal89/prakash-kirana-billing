plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

dependencies { implementation("androidx.core:core-ktx:1.13.1") }

android { namespace = "com.dukaanbill.app"; compileSdk = 35
    defaultConfig { applicationId = "com.dukaanbill.app"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
