package com.dukaanbill.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(ctx: Context) : SQLiteOpenHelper(ctx, "dukaanbill.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE shop_profile(id INTEGER PRIMARY KEY, name TEXT, address TEXT, phone TEXT, place TEXT, terms TEXT, logo_path TEXT)")
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, unit TEXT, rate REAL DEFAULT 0, gst REAL DEFAULT 0, active INTEGER DEFAULT 1)")
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, address TEXT)")
        db.execSQL("CREATE TABLE vendors(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, address TEXT, outstanding REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE bills(id INTEGER PRIMARY KEY AUTOINCREMENT, bill_no INTEGER UNIQUE, bill_date TEXT, customer_id INTEGER, customer_name TEXT, customer_phone TEXT, customer_address TEXT, place TEXT, subtotal REAL, tax REAL, total REAL, payment_type TEXT, notes TEXT)")
        db.execSQL("CREATE TABLE bill_lines(id INTEGER PRIMARY KEY AUTOINCREMENT, bill_id INTEGER, product_id INTEGER, description TEXT, qty REAL, unit TEXT, rate REAL, tax REAL, amount REAL)")
        db.execSQL("CREATE TABLE purchases(id INTEGER PRIMARY KEY AUTOINCREMENT, vendor_id INTEGER, invoice_no TEXT, invoice_date TEXT, subtotal REAL, tax REAL, total REAL, paid REAL, outstanding REAL, attachment_path TEXT, notes TEXT)")
        db.execSQL("CREATE TABLE purchase_lines(id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_id INTEGER, product_id INTEGER, description TEXT, qty REAL, unit TEXT, rate REAL, tax REAL, amount REAL)")
        db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, party_type TEXT, party_id INTEGER, amount REAL, payment_date TEXT, mode TEXT, notes TEXT)")
        db.execSQL("CREATE TABLE customer_ledger(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER, bill_id INTEGER, transaction_date TEXT, description TEXT, debit REAL DEFAULT 0, credit REAL DEFAULT 0, mode TEXT, notes TEXT)")
        db.execSQL("CREATE TABLE app_settings(key TEXT PRIMARY KEY, value TEXT)")
        setSetting(db,"starting_bill_no","1"); setSetting(db,"current_bill_no","1"); setSetting(db,"invoice_template","SARASWATI_STYLE")
        val c=ContentValues(); c.put("id",1); c.put("name","My Shop"); c.put("address",""); c.put("phone",""); c.put("place","Pune"); c.put("terms","Goods once sold will not be taken back or exchanged.\nSubject to local jurisdiction only.\nThank you for your business."); db.insert("shop_profile",null,c)
    }
    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
        if(old<2){ try{db.execSQL("ALTER TABLE shop_profile ADD COLUMN logo_path TEXT")}catch(_:Exception){}; try{db.execSQL("ALTER TABLE bills ADD COLUMN customer_name TEXT")}catch(_:Exception){}; try{db.execSQL("ALTER TABLE bills ADD COLUMN customer_phone TEXT")}catch(_:Exception){}; try{db.execSQL("ALTER TABLE bills ADD COLUMN customer_address TEXT")}catch(_:Exception){} }
        if(old<3){ try{db.execSQL("ALTER TABLE bills ADD COLUMN customer_id INTEGER")}catch(_:Exception){}; db.execSQL("CREATE TABLE IF NOT EXISTS customer_ledger(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER, bill_id INTEGER, transaction_date TEXT, description TEXT, debit REAL DEFAULT 0, credit REAL DEFAULT 0, mode TEXT, notes TEXT)") }
    }
    private fun setSetting(db:SQLiteDatabase,k:String,v:String){val c=ContentValues();c.put("key",k);c.put("value",v);db.insert("app_settings",null,c)}
    fun getSetting(k:String,d:String=""):String=readableDatabase.rawQuery("SELECT value FROM app_settings WHERE key=?",arrayOf(k)).use{if(it.moveToFirst())it.getString(0) else d}
    fun setSetting(k:String,v:String){val c=ContentValues();c.put("key",k);c.put("value",v);writableDatabase.insertWithOnConflict("app_settings",null,c,SQLiteDatabase.CONFLICT_REPLACE)}
    fun nextBillNumber()=getSetting("current_bill_no",getSetting("starting_bill_no","1")).toIntOrNull()?:1
    fun setStartingBillNumber(n:Int){
        require(n>0) { "Starting bill number must be positive" }
        val maxExisting=readableDatabase.rawQuery("SELECT COALESCE(MAX(bill_no),0) FROM bills",null).use{if(it.moveToFirst())it.getInt(0) else 0}
        val next=maxOf(n,maxExisting+1)
        setSetting("starting_bill_no",n.toString())
        setSetting("current_bill_no",next.toString())
    }
    fun consumeBillNumber():Int{val n=nextBillNumber();setSetting("current_bill_no",(n+1).toString());return n}
    fun saveShop(name:String,address:String,phone:String,place:String,terms:String,logo:String?=null){val c=ContentValues();c.put("name",name);c.put("address",address);c.put("phone",phone);c.put("place",place);c.put("terms",terms);if(logo!=null)c.put("logo_path",logo);writableDatabase.update("shop_profile",c,"id=1",null)}
    fun shop():Map<String,String>{val m=mutableMapOf<String,String>();readableDatabase.rawQuery("SELECT * FROM shop_profile WHERE id=1",null).use{if(it.moveToFirst()){for(i in 0 until it.columnCount)m[it.getColumnName(i)]=it.getString(i)?: ""}};return m}
    fun products():List<Array<String>> = list("SELECT id,name,unit,rate,gst FROM products ORDER BY name")
    fun customers():List<Array<String>> = list("SELECT id,name,phone,address FROM customers ORDER BY name")
    fun vendors():List<Array<String>> = list("SELECT id,name,phone,address,outstanding FROM vendors ORDER BY name")
    private fun list(sql:String):List<Array<String>>{val r=mutableListOf<Array<String>>();readableDatabase.rawQuery(sql,null).use{while(it.moveToNext()){val a=Array(it.columnCount){i->it.getString(i)?: ""};r.add(a)}};return r}
    fun addProduct(name:String,unit:String,rate:Double,gst:Double){val c=ContentValues();c.put("name",name);c.put("unit",unit);c.put("rate",rate);c.put("gst",gst);writableDatabase.insert("products",null,c)}
    fun addCustomer(name:String,phone:String,address:String){val c=ContentValues();c.put("name",name);c.put("phone",phone);c.put("address",address);writableDatabase.insert("customers",null,c)}
    fun addVendor(name:String,phone:String,address:String){val c=ContentValues();c.put("name",name);c.put("phone",phone);c.put("address",address);writableDatabase.insert("vendors",null,c)}
    fun deleteProduct(id:Int){writableDatabase.delete("products","id=?",arrayOf(id.toString()))}
    fun deleteCustomer(id:Int){writableDatabase.delete("customers","id=?",arrayOf(id.toString()))}
    fun deleteVendor(id:Int){writableDatabase.delete("vendors","id=?",arrayOf(id.toString()))}
    fun createBill(no:Int,date:String,customerId:Int,customer:String,phone:String,address:String,place:String,items:List<BillItem>,payment:String,notes:String):Long{var sub=0.0;items.forEach{sub+=it.qty*it.rate};val tax=items.sumOf{it.tax};val total=sub+tax;val c=ContentValues();c.put("bill_no",no);c.put("bill_date",date);if(customerId>0)c.put("customer_id",customerId);c.put("customer_name",customer);c.put("customer_phone",phone);c.put("customer_address",address);c.put("place",place);c.put("subtotal",sub);c.put("tax",tax);c.put("total",total);c.put("payment_type",payment);c.put("notes",notes);val id=writableDatabase.insert("bills",null,c);items.forEach{val l=ContentValues();l.put("bill_id",id);l.put("description",it.description);l.put("qty",it.qty);l.put("unit",it.unit);l.put("rate",it.rate);l.put("tax",it.tax);l.put("amount",it.qty*it.rate+it.tax);writableDatabase.insert("bill_lines",null,l)};if(customerId>0 && payment=="Credit"){val l=ContentValues();l.put("customer_id",customerId);l.put("bill_id",id);l.put("transaction_date",date);l.put("description","Credit sale - Bill $no");l.put("debit",total);l.put("credit",0);l.put("mode","Credit");l.put("notes",notes);writableDatabase.insert("customer_ledger",null,l)};return id}
    fun customerBalance(customerId:Int):Double=readableDatabase.rawQuery("SELECT COALESCE(SUM(debit-credit),0) FROM customer_ledger WHERE customer_id=?",arrayOf(customerId.toString())).use{if(it.moveToFirst())it.getDouble(0) else 0.0}
    fun customerLedger(customerId:Int):List<Array<String>> =list("SELECT transaction_date,description,debit,credit,mode FROM customer_ledger WHERE customer_id=$customerId ORDER BY id DESC")
    fun receiveCustomerPayment(customerId:Int,amount:Double,date:String,mode:String,notes:String){if(amount<=0)return;val l=ContentValues();l.put("customer_id",customerId);l.put("transaction_date",date);l.put("description","Payment received");l.put("debit",0);l.put("credit",amount);l.put("mode",mode);l.put("notes",notes);writableDatabase.insert("customer_ledger",null,l);val p=ContentValues();p.put("party_type","CUSTOMER");p.put("party_id",customerId);p.put("amount",amount);p.put("payment_date",date);p.put("mode",mode);p.put("notes",notes);writableDatabase.insert("payments",null,p)}
    fun bills():List<Array<String>> =list("SELECT id,bill_no,bill_date,customer_name,total,payment_type FROM bills ORDER BY id DESC")
    fun billItems(id:Long):List<BillItem>{val r=mutableListOf<BillItem>();readableDatabase.rawQuery("SELECT description,qty,unit,rate,tax FROM bill_lines WHERE bill_id=?",arrayOf(id.toString())).use{while(it.moveToNext())r.add(BillItem(it.getString(0),it.getDouble(1),it.getString(2),it.getDouble(3),it.getDouble(4)))};return r}
    fun bill(id:Long):Array<String>?=readableDatabase.rawQuery("SELECT bill_no,bill_date,customer_name,customer_phone,customer_address,place,total,payment_type FROM bills WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())Array(it.columnCount){i->it.getString(i)?: ""}else null}
    fun deleteBill(id:Long){writableDatabase.delete("bill_lines","bill_id=?",arrayOf(id.toString()));writableDatabase.delete("bills","id=?",arrayOf(id.toString()))}
    fun addPurchase(vendorId:Int,invoiceNo:String,date:String,total:Double,paid:Double,attachment:String,notes:String){val c=ContentValues();c.put("vendor_id",vendorId);c.put("invoice_no",invoiceNo);c.put("invoice_date",date);c.put("subtotal",total);c.put("tax",0);c.put("total",total);c.put("paid",paid);c.put("outstanding",total-paid);c.put("attachment_path",attachment);c.put("notes",notes);writableDatabase.insert("purchases",null,c);writableDatabase.execSQL("UPDATE vendors SET outstanding=outstanding+? WHERE id=?",arrayOf(total-paid,vendorId))}
    fun purchases():List<Array<String>> =list("SELECT p.id,v.name,p.invoice_no,p.invoice_date,p.total,p.paid,p.outstanding FROM purchases p LEFT JOIN vendors v ON v.id=p.vendor_id ORDER BY p.id DESC")
    fun reportTotals():Double=readableDatabase.rawQuery("SELECT COALESCE(SUM(total),0) FROM bills",null).use{it.moveToFirst();it.getDouble(0)}
}
data class BillItem(val description:String,val qty:Double,val unit:String,val rate:Double,val tax:Double=0.0)
