package com.dukaanbill.app
import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.util.*

object InvoicePdf {
    fun create(ctx:Context,shop:Map<String,String>,billNo:Int,date:String,customer:String,phone:String,address:String,place:String,items:List<BillItem>,total:Double):File{
        val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());val c=page.canvas;val p=Paint(Paint.ANTI_ALIAS_FLAG);p.typeface=Typeface.create("sans",Typeface.NORMAL)
        p.color=Color.rgb(185,28,28);p.style=Paint.Style.STROKE;p.strokeWidth=1.2f;c.drawRect(28,28,567,814,p);p.style=Paint.Style.FILL
        p.typeface=Typeface.create("sans",Typeface.BOLD);p.textSize=24f;c.drawText(shop["name"].orEmpty(),44,68,p);p.typeface=Typeface.DEFAULT;p.textSize=9f;p.color=Color.DKGRAY;c.drawText(shop["address"].orEmpty(),44,88,p);c.drawText("Mob: ${shop["phone"].orEmpty()}",44,103,p);c.drawText("Bill No.: $billNo",420,68,p);c.drawText("Date: $date",420,88,p);c.drawText("Place: $place",420,103,p)
        p.color=Color.rgb(185,28,28);c.drawRect(35,118,560,120,p);p.color=Color.BLACK;p.textSize=10f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText("Bill To:",44,142,p);p.typeface=Typeface.DEFAULT;c.drawText(customer,100,142,p);c.drawText(phone,100,157,p);c.drawText(address,100,172,p)
        val top=190f;val xs=floatArrayOf(35f,78f,300f,370f,455f,560f);p.style=Paint.Style.STROKE;p.color=Color.rgb(160,30,30);c.drawRect(35,top,560,top+26+items.size*22+46,p);for(x in xs)c.drawLine(x,top,x,top+26+items.size*22+46,p);var y=top+18;p.style=Paint.Style.FILL;p.typeface=Typeface.DEFAULT_BOLD;p.textSize=9f;c.drawText("Sr.",45,y,p);c.drawText("Description",90,y,p);c.drawText("Qty",315,y,p);c.drawText("Rate",385,y,p);c.drawText("Amount",480,y,p);p.typeface=Typeface.DEFAULT
        var subtotal=0.0;items.forEachIndexed{i,it->y+=22;val amt=it.qty*it.rate+it.tax;subtotal+=amt;c.drawText("${i+1}",48,y,p);c.drawText(it.description.take(31),84,y,p);c.drawText("${fmtQty(it.qty)} ${it.unit}",307,y,p);c.drawText(String.format(Locale.US,"%.2f",it.rate),377,y,p);c.drawText(String.format(Locale.US,"%.2f",amt),470,y,p)}
        y+=34;p.typeface=Typeface.DEFAULT_BOLD;c.drawText("Grand Total (Rs.)",355,y,p);p.color=Color.rgb(185,28,28);p.textSize=14f;c.drawText(String.format(Locale.US,"%.2f",total),475,y,p);p.color=Color.BLACK;p.textSize=9f;c.drawText("Amount in Words: ${words(total)}",44,y+28,p)
        p.color=Color.rgb(255,245,245);c.drawRect(35,y+48,560,y+105,p);p.color=Color.rgb(185,28,28);p.typeface=Typeface.DEFAULT_BOLD;c.drawText("Terms & Conditions",44,y+67,p);p.color=Color.DKGRAY;p.typeface=Typeface.DEFAULT;p.textSize=8f;var ty=y+82;shop["terms"].orEmpty().split("\n").take(4).forEachIndexed{idx,s->c.drawText("${idx+1}. ${s.take(82)}",44,ty,p);ty+=12}
        p.color=Color.rgb(185,28,28);p.typeface=Typeface.create("serif",Typeface.ITALIC);p.textSize=12f;c.drawText("Your Trusted Partner for Everyday Essentials",210,790,p);doc.finishPage(page);val out=File(ctx.cacheDir,"DukaanBill_${billNo}.pdf");FileOutputStream(out).use{doc.writeTo(it)};doc.close();return out
    }
    private fun fmtQty(v:Double)=if(v%1.0==0.0)v.toInt().toString() else String.format(Locale.US,"%.2f",v)
    private fun words(v:Double):String{val n=v.toLong();return if(n==0L)"Rupees Zero Only" else "Rupees ${num(n)} Only"}
    private fun num(n:Long):String{val ones=arrayOf("Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen");val tens=arrayOf("","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety");fun x(v:Long):String=when{v<20->ones[v.toInt()];v<100->tens[(v/10).toInt()]+if(v%10>0)" "+ones[(v%10).toInt()] else "";v<1000->ones[(v/100).toInt()]+" Hundred"+if(v%100>0)" "+x(v%100) else "";v<100000->x(v/1000)+" Thousand"+if(v%1000>0)" "+x(v%1000) else "";v<10000000->x(v/100000)+" Lakh"+if(v%100000>0)" "+x(v%100000) else "";else->x(v/10000000)+" Crore"+if(v%10000000>0)" "+x(v%10000000) else ""};return x(n)}
}
