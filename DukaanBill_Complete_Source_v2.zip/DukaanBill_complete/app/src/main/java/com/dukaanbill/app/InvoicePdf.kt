package com.dukaanbill.app

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

/**
 * Lightweight invoice generator.
 * Uses Android Canvas text/vector drawing instead of a full-page bitmap so PDFs stay small.
 */
object InvoicePdf {
    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val LEFT = 28f
    private const val RIGHT = 567f
    private const val RED = 0xffb91c1c.toInt()

    fun create(
        ctx: Context,
        shop: Map<String, String>,
        billNo: Int,
        date: String,
        customer: String,
        phone: String,
        address: String,
        place: String,
        items: List<BillItem>,
        total: Double
    ): File {
        val document = PdfDocument()
        var pageNumber = 1
        var page = document.startPage(pageInfo(pageNumber))
        var canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        var y = drawHeader(canvas, paint, shop, billNo, date, customer, phone, address, place)
        y = drawTableHeader(canvas, paint, y)

        val rowHeight = 22f
        val maxY = 650f
        val rowsPerPage = ((maxY - y) / rowHeight).toInt().coerceAtLeast(1)

        items.forEachIndexed { index, item ->
            val rowIndex = index % rowsPerPage
            if (index > 0 && rowIndex == 0) {
                document.finishPage(page)
                pageNumber++
                page = document.startPage(pageInfo(pageNumber))
                canvas = page.canvas
                y = drawHeader(canvas, paint, shop, billNo, date, customer, phone, address, place)
                y = drawTableHeader(canvas, paint, y)
            }

            y += rowHeight
            val amount = item.qty * item.rate + item.tax
            paint.style = Paint.Style.FILL
            paint.color = Color.BLACK
            paint.typeface = Typeface.DEFAULT
            paint.textSize = 8.5f
            canvas.drawText((index + 1).toString(), 45f, y, paint)
            canvas.drawText(item.description.take(31), 84f, y, paint)
            canvas.drawText("${formatQty(item.qty)} ${item.unit}", 307f, y, paint)
            canvas.drawText(formatMoney(item.rate), 377f, y, paint)
            canvas.drawText(formatMoney(amount), 470f, y, paint)
        }

        drawFooter(canvas, paint, shop, y + 34f, total)
        document.finishPage(page)

        val output = File(ctx.cacheDir, "DukaanBill_$billNo.pdf")
        FileOutputStream(output).use { document.writeTo(it) }
        document.close()
        return output
    }

    private fun pageInfo(number: Int): PdfDocument.PageInfo =
        PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, number).create()

    private fun drawHeader(
        canvas: Canvas,
        paint: Paint,
        shop: Map<String, String>,
        billNo: Int,
        date: String,
        customer: String,
        phone: String,
        address: String,
        place: String
    ): Float {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.2f
        paint.color = RED
        canvas.drawRect(LEFT, 28f, RIGHT, 814f, paint)

        val logoPath = shop["logo_path"].orEmpty()
        if (logoPath.isNotBlank()) {
            runCatching {
                val bitmap = BitmapFactory.decodeFile(logoPath)
                if (bitmap != null) {
                    val scale = minOf(70f / bitmap.width, 60f / bitmap.height)
                    val w = bitmap.width * scale
                    val h = bitmap.height * scale
                    canvas.drawBitmap(bitmap, null, android.graphics.RectF(40f, 38f, 40f + w, 38f + h), paint)
                }
            }
        }

        paint.style = Paint.Style.FILL
        paint.color = RED
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textSize = 22f
        canvas.drawText(shop["name"].orEmpty().ifBlank { "DukaanBill" }, 120f, 65f, paint)

        paint.color = Color.DKGRAY
        paint.typeface = Typeface.DEFAULT
        paint.textSize = 8.5f
        canvas.drawText(shop["address"].orEmpty().take(70), 120f, 84f, paint)
        canvas.drawText("Mob: ${shop["phone"].orEmpty()}", 120f, 99f, paint)

        canvas.drawText("Bill No.: $billNo", 420f, 65f, paint)
        canvas.drawText("Date: $date", 420f, 84f, paint)
        canvas.drawText("Place: $place", 420f, 103f, paint)

        paint.color = RED
        canvas.drawRect(35f, 118f, 560f, 120f, paint)

        paint.color = Color.BLACK
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textSize = 10f
        canvas.drawText("Bill To:", 44f, 142f, paint)
        paint.typeface = Typeface.DEFAULT
        canvas.drawText(customer.take(55), 100f, 142f, paint)
        canvas.drawText(phone.take(30), 100f, 157f, paint)
        canvas.drawText(address.take(55), 100f, 172f, paint)

        return 190f
    }

    private fun drawTableHeader(canvas: Canvas, paint: Paint, top: Float): Float {
        val xs = floatArrayOf(35f, 78f, 300f, 370f, 455f, 560f)
        val bottom = top + 26f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 0.8f
        paint.color = Color.rgb(160, 30, 30)
        canvas.drawRect(35f, top, 560f, bottom, paint)
        xs.forEach { x -> canvas.drawLine(x, top, x, bottom, paint) }

        paint.style = Paint.Style.FILL
        paint.color = Color.BLACK
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textSize = 9f
        canvas.drawText("Sr.", 45f, top + 18f, paint)
        canvas.drawText("Description", 90f, top + 18f, paint)
        canvas.drawText("Qty", 315f, top + 18f, paint)
        canvas.drawText("Rate", 385f, top + 18f, paint)
        canvas.drawText("Amount", 480f, top + 18f, paint)
        return bottom
    }

    private fun drawFooter(
        canvas: Canvas,
        paint: Paint,
        shop: Map<String, String>,
        top: Float,
        total: Double
    ) {
        var y = top
        paint.color = Color.BLACK
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textSize = 10f
        canvas.drawText("Grand Total (Rs.)", 355f, y, paint)
        paint.color = RED
        paint.textSize = 14f
        canvas.drawText(formatMoney(total), 475f, y, paint)

        paint.color = Color.BLACK
        paint.typeface = Typeface.DEFAULT
        paint.textSize = 9f
        canvas.drawText("Amount in Words: ${amountInWords(total)}", 44f, y + 28f, paint)

        val termsTop = y + 48f
        val termsBottom = minOf(termsTop + 105f, 760f)
        paint.color = Color.rgb(255, 245, 245)
        canvas.drawRect(35f, termsTop, 560f, termsBottom, paint)
        paint.color = RED
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textSize = 10f
        canvas.drawText("Terms & Conditions", 44f, termsTop + 19f, paint)

        paint.color = Color.DKGRAY
        paint.typeface = Typeface.DEFAULT
        paint.textSize = 8f
        var ty = termsTop + 35f
        shop["terms"].orEmpty().split("\n").filter { it.isNotBlank() }.take(5).forEachIndexed { index, term ->
            if (ty < termsBottom - 6f) {
                canvas.drawText("${index + 1}. ${term.take(82)}", 44f, ty, paint)
                ty += 12f
            }
        }

        // No signature / authorised signatory section by design.
        paint.color = RED
        paint.typeface = Typeface.create("serif", Typeface.ITALIC)
        paint.textSize = 11f
        canvas.drawText("Your Trusted Partner for Everyday Essentials", 180f, 790f, paint)
    }

    private fun formatMoney(value: Double): String = String.format(Locale.US, "%.2f", value)

    private fun formatQty(value: Double): String =
        if (value % 1.0 == 0.0) value.toInt().toString() else String.format(Locale.US, "%.2f", value)

    private fun amountInWords(value: Double): String {
        val whole = value.toLong()
        return if (whole == 0L) "Rupees Zero Only" else "Rupees ${numberToWords(whole)} Only"
    }

    private fun numberToWords(n: Long): String {
        val ones = arrayOf(
            "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
            "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen",
            "Eighteen", "Nineteen"
        )
        val tens = arrayOf("", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety")

        fun part(v: Long): String = when {
            v < 20 -> ones[v.toInt()]
            v < 100 -> tens[(v / 10).toInt()] + if (v % 10 > 0) " ${ones[(v % 10).toInt()]}" else ""
            v < 1_000 -> ones[(v / 100).toInt()] + " Hundred" + if (v % 100 > 0) " ${part(v % 100)}" else ""
            v < 100_000 -> part(v / 1_000) + " Thousand" + if (v % 1_000 > 0) " ${part(v % 1_000)}" else ""
            v < 10_000_000 -> part(v / 100_000) + " Lakh" + if (v % 100_000 > 0) " ${part(v % 100_000)}" else ""
            else -> part(v / 10_000_000) + " Crore" + if (v % 10_000_000 > 0) " ${part(v % 10_000_000)}" else ""
        }

        return part(n)
    }
}
