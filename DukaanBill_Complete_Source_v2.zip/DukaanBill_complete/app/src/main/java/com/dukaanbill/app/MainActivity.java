package com.dukaanbill.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.android.gms.tasks.Tasks;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import java.util.ArrayList;
import java.util.List;

import android.util.Base64;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_PURCHASE_DOCUMENT = 9011;
    private static final int REQ_BACKUP_CREATE = 9012;
    private static final int REQ_BACKUP_RESTORE = 9013;
    private static final String BACKUP_DB_ENTRY = "database/dukaanbill.db";
    private static final String BACKUP_STATE_ENTRY = "database/app_state.json";
    private File purchaseDocsDir;
    private LocalDatabase localDb;
    private File pendingBackupZip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        purchaseDocsDir = new File(getFilesDir(), "purchase_docs");
        if (!purchaseDocsDir.exists()) purchaseDocsDir.mkdirs();
        localDb = new LocalDatabase(this);
        PDFBoxResourceLoader.init(getApplicationContext());

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private Uri saveToCacheProvider(byte[] data, String filename) throws Exception {
        File dir = new File(getCacheDir(), "share");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create share folder");
        File file = new File(dir, filename);
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(data);
            out.flush();
        }
        return Uri.parse("content://com.dukaanbill.app.share/" + Uri.encode(file.getName()));
    }

    private Uri saveForSharing(byte[] data, String filename, String mime) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    mime.equals("application/pdf") ?
                            Environment.DIRECTORY_DOWNLOADS + "/DukaanBill" :
                            Environment.DIRECTORY_PICTURES + "/DukaanBill");
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);

            Uri collection = mime.equals("application/pdf")
                    ? MediaStore.Downloads.EXTERNAL_CONTENT_URI
                    : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

            Uri uri = resolver.insert(collection, values);
            if (uri != null) {
                try (OutputStream out = resolver.openOutputStream(uri)) {
                    if (out == null) throw new Exception("Could not open output stream");
                    out.write(data);
                    out.flush();
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                resolver.update(uri, done, null, null);
                return uri;
            }
        }
        return saveToCacheProvider(data, filename);
    }

    private void shareFile(byte[] data, String filename, String mime, String title) throws Exception {
        Uri uri = saveForSharing(data, filename, mime);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType(mime);
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_TEXT, "DukaanBill - " + title);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        send.setClipData(ClipData.newRawUri(title, uri));
        Intent chooser = Intent.createChooser(send, title);
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(chooser);
    }

    private void drawText(Canvas c, Paint p, String text, float x, float y) {
        c.drawText(text == null ? "" : text, x, y, p);
    }

    private Bitmap loadLogo() {
        try (InputStream in = getAssets().open("www/logo.jpg")) {
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) { return null; }
    }

    private void drawPdfHeader(Canvas c, Paint p, Bitmap logo, int pageWidth, JSONObject cfg) {
        if (logo != null) {
            RectF dst = new RectF(40, 28, 105, 93);
            c.drawBitmap(logo, null, dst, p);
        }
        String shopName = cfg == null ? "DUKAAN BILL" : cfg.optString("shopName", "DUKAAN BILL");
        String address = cfg == null ? "" : cfg.optString("address", "");
        String billTitle = cfg == null ? "CASH MEMO / BILL" : cfg.optString("billTitle", "CASH MEMO / BILL");
        p.setColor(android.graphics.Color.rgb(20, 70, 42));
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setTextSize(23);
        drawText(c,p,shopName,120,55);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(12);
        drawText(c,p,address,120,75);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(13);
        drawText(c,p,billTitle,120,92);
        p.setColor(android.graphics.Color.rgb(20, 70, 42));
        c.drawLine(35,105,pageWidth-35,105,p);
    }

    private Uri createPdf(String json) throws Exception {
        JSONObject b = new JSONObject(json);
        JSONArray items = b.optJSONArray("items");
        JSONObject cfg = b.optJSONObject("settings");
        PdfDocument doc = new PdfDocument();
        Bitmap logo = loadLogo();
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int pageNo=1, y;
        PdfDocument.Page page = null;
        Canvas canvas = null;
        int pageWidth=595, pageHeight=842;

        page = doc.startPage(new PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNo).create());
        canvas = page.getCanvas();
        drawPdfHeader(canvas,p,logo,pageWidth,cfg);

        p.setColor(android.graphics.Color.BLACK);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(10);
        drawText(canvas,p,"Bill No: " + b.optString("billNo",""),40,130);
        drawText(canvas,p,"Date: " + formatDate(b.optString("date","")),410,130);
        drawText(canvas,p,"Customer: " + b.optString("customer","Walk-in Customer"),40,148);
        String customerPhone=b.optString("customerPhone","");
        if(!customerPhone.isEmpty()) drawText(canvas,p,"Mobile: " + customerPhone,40,162);
        drawText(canvas,p,"Payment Mode: " + b.optString("paymentMode","Cash"),410,148);

        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(9);
        canvas.drawRect(35,180,560,205,p);
        p.setColor(android.graphics.Color.WHITE);
        drawText(canvas,p,"Sr.",42,196);
        drawText(canvas,p,"Item Description",70,196);
        drawText(canvas,p,"Qty",320,196);
        drawText(canvas,p,"Unit",365,196);
        drawText(canvas,p,"Rate",420,196);
        drawText(canvas,p,"Amount",505,196);
        p.setColor(android.graphics.Color.BLACK);
        p.setTypeface(Typeface.DEFAULT);
        y=222;

        double calculatedSubtotal=0;
        if(items!=null){
            for(int i=0;i<items.length();i++){
                JSONObject it=items.getJSONObject(i);
                String name=it.optString("name","");
                String qty=it.optString("qty","");
                String unit=it.optString("unit","piece");
                double rate=it.optDouble("rate",0);
                double amount=quantityValue(qty,unit)*rate;
                if(y>770){
                    doc.finishPage(page);
                    pageNo++;
                    page=doc.startPage(new PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNo).create());
                    canvas=page.getCanvas();
                    drawPdfHeader(canvas,p,logo,pageWidth,cfg);
                    y=135;
                }
                drawText(canvas,p,String.valueOf(i+1),42,y);
                drawText(canvas,p,trimText(name,35),70,y);
                drawText(canvas,p,qty,320,y);
                drawText(canvas,p,unit,365,y);
                drawText(canvas,p,String.format(Locale.US,"%.2f",rate),420,y);
                drawText(canvas,p,String.format(Locale.US,"%.2f",amount),505,y);
                canvas.drawLine(35,y+7,560,y+7,p);
                y+=24;
                calculatedSubtotal+=amount;
            }
        }
        double subtotal=b.has("subtotal")?b.optDouble("subtotal",calculatedSubtotal):calculatedSubtotal;
        double discount=b.optDouble("discount",0);
        double finalTotal=b.has("total")?b.optDouble("total",Math.max(0,subtotal-discount)):Math.max(0,subtotal-discount);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(10);
        drawText(canvas,p,"Subtotal: ₹" + String.format(Locale.US,"%.2f",subtotal),390,y+20);
        drawText(canvas,p,"Discount: -₹" + String.format(Locale.US,"%.2f",discount),390,y+37);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(14);
        drawText(canvas,p,"Total Amount: ₹" + String.format(Locale.US,"%.2f",finalTotal),35,y+38);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(10);
        drawText(canvas,p,cfg == null ? "" : cfg.optString("footer",""),35,y+64);
        drawText(canvas,p,"Goods once sold will not be taken back.",35,y+80);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        drawText(canvas,p,cfg == null ? "" : cfg.optString("signature",""),410,y+64);
        p.setTypeface(Typeface.DEFAULT);
        drawText(canvas,p,"Authorized Signatory",430,y+80);

        doc.finishPage(page);
        ByteArrayOutputStream bos=new ByteArrayOutputStream();
        doc.writeTo(bos); doc.close();
        String filename="Bill_"+b.optString("billNo","Bill").replaceAll("[^A-Za-z0-9_-]","_")+".pdf";
        return saveForSharing(bos.toByteArray(),filename,"application/pdf");
    }

    private String trimText(String s,int max){ if(s==null)return ""; return s.length()>max?s.substring(0,max-1)+"…":s; }
    private String formatDate(String d){ if(d==null||d.length()<10)return d; return d.substring(8,10)+"/"+d.substring(5,7)+"/"+d.substring(0,4); }

    private double quantityValue(String q, String defaultUnit){
        if(q==null)return 0;
        String s=q.trim().toLowerCase().replace(",","");
        try{
            java.util.regex.Matcher m=java.util.regex.Pattern.compile(
                    "(\\d+(?:\\.\\d+)?)\\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pack|packs|box|boxes|bottle|bottles|dozen)?",
                    java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s);
            if(!m.find()) return 0;
            double n=Double.parseDouble(m.group(1));
            String u=m.group(2); if(u==null)u=defaultUnit==null?"piece":defaultUnit;
            u=u.toLowerCase();
            if(u.equals("mg")||u.startsWith("milligram"))return n/1000000.0;
            if(u.equals("g")||u.equals("gm")||u.startsWith("gram"))return n/1000.0;
            if(u.equals("dozen"))return n*12.0;
            return n;
        }catch(Exception e){return 0;}
    }

    private File copyToPurchaseStorage(Uri uri, String originalName) throws Exception {
        String safe=UUID.randomUUID().toString()+"_"+(originalName==null?"document":originalName).replaceAll("[^A-Za-z0-9._-]","_");
        File outFile=new File(purchaseDocsDir,safe);
        try(InputStream in=getContentResolver().openInputStream(uri); OutputStream out=new FileOutputStream(outFile)){
            if(in==null)throw new Exception("Could not read selected document");
            byte[] buf=new byte[8192]; int n;
            while((n=in.read(buf))>0)out.write(buf,0,n);
        }
        return outFile;
    }

    private void sendPurchaseProgress(String message){
        try{
            String encoded=android.util.Base64.encodeToString(message.getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
            runOnUiThread(()->webView.evaluateJavascript("window.onPurchaseImportProgress && window.onPurchaseImportProgress(atob('"+encoded+"'))",null));
        }catch(Exception ignored){}
    }

    private void sendPurchaseError(String message){
        try{
            String encoded=android.util.Base64.encodeToString((message==null?"Unknown error":message).getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
            runOnUiThread(()->webView.evaluateJavascript("window.onPurchaseImportError && window.onPurchaseImportError(atob('"+encoded+"'))",null));
        }catch(Exception ignored){}
    }

    private void sendPurchaseResult(String attachmentId,String fileName,String mime,String text){
        try{
            JSONObject o=new JSONObject();
            o.put("attachmentId",attachmentId);
            o.put("fileName",fileName==null?"":fileName);
            o.put("mime",mime==null?"":mime);
            o.put("text",text==null?"":text);
            String encoded=android.util.Base64.encodeToString(o.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
            runOnUiThread(()->webView.evaluateJavascript("window.onPurchaseImportResultBase64 && window.onPurchaseImportResultBase64('"+encoded+"')",null));
        }catch(Exception e){sendPurchaseError(e.getMessage());}
    }

    private void ocrImage(Uri uri, File stored, String fileName, String mime){
        sendPurchaseProgress("Reading invoice photo...");
        try{
            Bitmap bitmap=BitmapFactory.decodeFile(stored.getAbsolutePath());
            if(bitmap==null)throw new Exception("Could not decode the selected image");
            InputImage image=InputImage.fromBitmap(bitmap,0);
            TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            recognizer.process(image)
                .addOnSuccessListener(result->{
                    recognizer.close();
                    bitmap.recycle();
                    sendPurchaseProgress("Invoice photo read. Preparing purchase details...");
                    sendPurchaseResult(stored.getName(),fileName,mime,result.getText());
                })
                .addOnFailureListener(e->{recognizer.close();bitmap.recycle();sendPurchaseError("OCR failed: "+e.getMessage());});
        }catch(Exception e){sendPurchaseError("Could not read photo: "+e.getMessage());}
    }

    private String extractPdfText(File stored) throws Exception {
        try (PDDocument document = PDDocument.load(stored)) {
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
            String text = stripper.getText(document);
            return text == null ? "" : text;
        }
    }

    private void ocrPdf(Uri uri, File stored, String fileName, String mime){
        sendPurchaseProgress("Opening PDF invoice...");
        final ExecutorService executor=Executors.newSingleThreadExecutor();
        executor.execute(()->{
            try{
                // First try the PDF's native text layer. Most vendor invoices are
                // generated PDFs and this is considerably more accurate than OCR.
                sendPurchaseProgress("Checking the PDF text layer...");
                String directText=extractPdfText(stored);
                if(directText!=null && directText.trim().length()>50){
                    sendPurchaseProgress("PDF text found. Extracted " + directText.trim().length() + " characters.");
                    sendPurchaseResult(stored.getName(),fileName,mime,directText);
                    executor.shutdown();
                    return;
                }

                // Scanned/image-only PDF: fall back to page rendering + ML Kit OCR.
                sendPurchaseProgress("No usable PDF text layer found. Starting OCR...");
                ParcelFileDescriptor pfd=null;
                PdfRenderer renderer=null;
                try{
                    pfd=ParcelFileDescriptor.open(stored,ParcelFileDescriptor.MODE_READ_ONLY);
                    renderer=new PdfRenderer(pfd);
                    int pages=renderer.getPageCount();
                    StringBuilder all=new StringBuilder();
                    sendPurchaseProgress("PDF opened. " + pages + " page(s) found.");
                    TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                    try{
                        for(int index=0; index<pages; index++){
                            sendPurchaseProgress("Reading PDF page " + (index+1) + " of " + pages + "...");
                            PdfRenderer.Page page=renderer.openPage(index);
                            try{
                                float scale=3.0f;
                                int w=Math.max(1600,Math.round(page.getWidth()*scale));
                                int h=Math.max(2200,Math.round(page.getHeight()*scale));
                                float ratio=(float)page.getWidth()/(float)page.getHeight();
                                if((float)w/(float)h > ratio) w=Math.round(h*ratio); else h=Math.round(w/ratio);
                                Bitmap bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
                                Canvas canvas=new Canvas(bmp);
                                canvas.drawColor(android.graphics.Color.WHITE);
                                page.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT);
                                InputImage image=InputImage.fromBitmap(bmp,0);
                                try{
                                    com.google.mlkit.vision.text.Text result=Tasks.await(recognizer.process(image));
                                    String pageText=result==null?"":result.getText();
                                    if(pageText!=null && !pageText.trim().isEmpty()){
                                        all.append("\n").append(pageText);
                                        sendPurchaseProgress("Page " + (index+1) + " read. " + pageText.length() + " characters found...");
                                    }else{
                                        sendPurchaseProgress("Page " + (index+1) + " read, but no text was detected.");
                                    }
                                } finally { bmp.recycle(); }
                            } finally { page.close(); }
                        }
                    } finally { recognizer.close(); }
                    String finalText=all.toString();
                    sendPurchaseProgress("OCR complete. " + finalText.trim().length() + " characters extracted.");
                    sendPurchaseResult(stored.getName(),fileName,mime,finalText);
                } finally {
                    try{if(renderer!=null)renderer.close();}catch(Exception ignored){}
                    try{if(pfd!=null)pfd.close();}catch(Exception ignored){}
                }
            }catch(Exception e){
                sendPurchaseError("Could not read PDF: " + (e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));
            }finally{
                executor.shutdown();
            }
        });
    }

    private void importPurchaseUri(Uri uri){
        try{
            String original=uri.getLastPathSegment();
            if(original==null||original.trim().isEmpty()) original="vendor_bill_"+System.currentTimeMillis();
            String mime=getContentResolver().getType(uri);
            if(mime==null||mime.trim().isEmpty()) mime=original.toLowerCase().endsWith(".pdf")?"application/pdf":"image/jpeg";
            sendPurchaseProgress("Saving the original vendor bill...");
            File stored=copyToPurchaseStorage(uri,original);
            String lower=original.toLowerCase();
            if(mime.equalsIgnoreCase("application/pdf")||lower.endsWith(".pdf")) ocrPdf(uri,stored,original,mime);
            else ocrImage(uri,stored,original,mime);
        }catch(Exception e){sendPurchaseError("Could not import purchase bill: "+e.getMessage());}
    }

    private void openPurchaseAttachment(String id,String mime){
        try{
            File file=new File(purchaseDocsDir,id);
            if(!file.exists())throw new Exception("Attachment not found");
            byte[] data=readAll(file);
            Uri uri=saveToCacheProvider(data,file.getName());
            Intent view=new Intent(Intent.ACTION_VIEW);
            view.setDataAndType(uri,mime==null?"application/octet-stream":mime);
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            view.setClipData(ClipData.newRawUri(file.getName(),uri));
            startActivity(Intent.createChooser(view,"Open Purchase Bill"));
        }catch(Exception e){Toast.makeText(this,"Could not open attachment: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private byte[] readAll(File f)throws Exception{
        try(InputStream in=new FileInputStream(f);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);return out.toByteArray();
        }
    }

    private String loadAppState() {
        try { return localDb.loadState(); } catch (Exception e) { return "{}"; }
    }

    private void saveAppState(String json) {
        try { localDb.saveState(json); } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "Could not save local data: " + e.getMessage(), Toast.LENGTH_LONG).show());
        }
    }

    private void addFileToZip(ZipOutputStream zos, File file, String entryName) throws Exception {
        ZipEntry entry = new ZipEntry(entryName);
        zos.putNextEntry(entry);
        try (InputStream in = new FileInputStream(file)) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
        }
        zos.closeEntry();
    }

    private File createBackupZip() throws Exception {
        File backupDir = new File(getCacheDir(), "backups");
        if (!backupDir.exists()) backupDir.mkdirs();
        String stamp = new java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new java.util.Date());
        File zip = new File(backupDir, "DukaanBill_Backup_" + stamp + ".zip");
        File dbFile = getDatabasePath("dukaanbill.db");
        if (!dbFile.exists()) throw new Exception("Local database is not available yet");
        String state = localDb.loadState();
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zip))) {
            addFileToZip(zos, dbFile, BACKUP_DB_ENTRY);
            ZipEntry stateEntry = new ZipEntry(BACKUP_STATE_ENTRY);
            zos.putNextEntry(stateEntry);
            zos.write(state.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            zos.closeEntry();
            if (purchaseDocsDir.exists()) {
                File[] files = purchaseDocsDir.listFiles();
                if (files != null) {
                    for (File f : files) if (f.isFile()) addFileToZip(zos, f, "attachments/" + f.getName());
                }
            }
            ZipEntry info = new ZipEntry("backup_info.txt");
            zos.putNextEntry(info);
            String text = "DukaanBill\nBackup created: " + new java.util.Date() + "\nIncludes local SQLite database and purchase invoice attachments.\n";
            zos.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            zos.closeEntry();
        }
        return zip;
    }

    private void startBackup() {
        try {
            pendingBackupZip = createBackupZip();
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/zip");
            i.putExtra(Intent.EXTRA_TITLE, pendingBackupZip.getName());
            startActivityForResult(i, REQ_BACKUP_CREATE);
        } catch (Exception e) {
            Toast.makeText(this, "Backup failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void copyFileToUri(File src, Uri dest) throws Exception {
        try (InputStream in = new FileInputStream(src); OutputStream out = getContentResolver().openOutputStream(dest)) {
            if (out == null) throw new Exception("Could not open backup destination");
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            out.flush();
        }
    }

    private void startRestore() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        startActivityForResult(i, REQ_BACKUP_RESTORE);
    }

    private boolean safeZipPath(String name) {
        if (name == null || name.length() == 0 || name.startsWith("/") || name.contains("\\")) return false;
        return !name.contains("../") && !name.equals("..") && !name.contains("/../");
    }

    private void restoreBackup(Uri uri) throws Exception {
        File restoreDir = new File(getCacheDir(), "restore_" + System.currentTimeMillis());
        if (!restoreDir.mkdirs()) throw new Exception("Could not create restore workspace");
        File zipFile = new File(restoreDir, "backup.zip");
        try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(zipFile)) {
            if (in == null) throw new Exception("Could not read backup file");
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) out.write(b,0,n);
        }
        File restoredDb = new File(restoreDir, "dukaanbill.db");
        File restoredState = new File(restoreDir, "app_state.json");
        File restoredAttachments = new File(restoreDir, "attachments");
        if (!restoredAttachments.mkdirs()) restoredAttachments.mkdirs();
        boolean dbFound=false;
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile))) {
            ZipEntry e;
            byte[] b = new byte[8192];
            while ((e = zis.getNextEntry()) != null) {
                if (e.isDirectory() || !safeZipPath(e.getName())) { zis.closeEntry(); continue; }
                File outFile;
                if (e.getName().equals(BACKUP_DB_ENTRY)) { outFile=restoredDb; dbFound=true; }
                else if (e.getName().equals(BACKUP_STATE_ENTRY)) outFile=restoredState;
                else if (e.getName().startsWith("attachments/")) {
                    String fn=e.getName().substring("attachments/".length());
                    if (fn.contains("/") || fn.length()==0) { zis.closeEntry(); continue; }
                    outFile=new File(restoredAttachments, fn);
                } else { zis.closeEntry(); continue; }
                File parent=outFile.getParentFile(); if(parent!=null&&!parent.exists())parent.mkdirs();
                try(OutputStream out=new FileOutputStream(outFile)){int n;while((n=zis.read(b))>0)out.write(b,0,n);}
                zis.closeEntry();
            }
        }
        if(!dbFound || !restoredDb.exists()) throw new Exception("This is not a valid DukaanBill backup");
        localDb.close();
        File currentDb=getDatabasePath("dukaanbill.db");
        if(!deleteDatabase("dukaanbill.db")) {
            if(currentDb.exists() && !currentDb.delete()) throw new Exception("Could not replace local database");
        }
        try(InputStream in=new FileInputStream(restoredDb);OutputStream out=new FileOutputStream(currentDb)){
            byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);
        }
        localDb=new LocalDatabase(this);
        if(purchaseDocsDir.exists()){
            File[] old=purchaseDocsDir.listFiles(); if(old!=null)for(File f:old)if(f.isFile())f.delete();
        } else purchaseDocsDir.mkdirs();
        File[] atts=restoredAttachments.listFiles();
        if(atts!=null)for(File f:atts)if(f.isFile()){
            try(InputStream in=new FileInputStream(f);OutputStream out=new FileOutputStream(new File(purchaseDocsDir,f.getName()))){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}
        }
        getSharedPreferences("app_prefs",MODE_PRIVATE).edit().putBoolean("restored",true).apply();
        runOnUiThread(() -> { Toast.makeText(this, "Backup restored successfully. Reloading app...", Toast.LENGTH_LONG).show(); webView.postDelayed(() -> webView.reload(), 700); });
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK || data==null) return;
        if(requestCode==REQ_PURCHASE_DOCUMENT && data.getData()!=null){
            Uri uri=data.getData();
            try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            importPurchaseUri(uri);
        } else if(requestCode==REQ_BACKUP_CREATE && data.getData()!=null){
            try{
                if(pendingBackupZip==null||!pendingBackupZip.exists())throw new Exception("Backup file is missing");
                copyFileToUri(pendingBackupZip,data.getData());
                Toast.makeText(this,"Backup saved successfully. Keep this ZIP safely in your cloud.",Toast.LENGTH_LONG).show();
            }catch(Exception e){Toast.makeText(this,"Could not save backup: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        } else if(requestCode==REQ_BACKUP_RESTORE && data.getData()!=null){
            new Thread(() -> {
                try { restoreBackup(data.getData()); }
                catch(Exception e){runOnUiThread(() -> Toast.makeText(this,"Restore failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}
            }).start();
        }
    }

    private class AndroidBridge {
        @JavascriptInterface public void shareBillImage(String base64Png,String billName,String phone){
            try{byte[] data=Base64.decode(base64Png,Base64.DEFAULT);String safe=(billName==null||billName.trim().isEmpty())?"DukaanBill":billName;shareFile(data,safe+".png","image/png","WhatsApp Bill");}
            catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not share bill image: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void openBillPdf(String json){
            try{Uri uri=createPdf(json);Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/pdf");send.putExtra(Intent.EXTRA_STREAM,uri);send.putExtra(Intent.EXTRA_TEXT,"DukaanBill - Bill");send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);send.setClipData(ClipData.newRawUri("DukaanBill PDF",uri));startActivity(Intent.createChooser(send,"Share / Open PDF"));}
            catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Could not create/share PDF: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public String loadAppState(){ return MainActivity.this.loadAppState(); }
        @JavascriptInterface public void saveAppState(String json){ MainActivity.this.saveAppState(json); }
        @JavascriptInterface public void backupData(){ runOnUiThread(MainActivity.this::startBackup); }
        @JavascriptInterface public void restoreData(){ runOnUiThread(MainActivity.this::startRestore); }
        @JavascriptInterface public void pickPurchaseDocument(){
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","image/jpeg","image/png","image/webp"});startActivityForResult(i,REQ_PURCHASE_DOCUMENT);
        }
        @JavascriptInterface public void openPurchaseAttachment(String id,String mime){openPurchaseAttachment(id,mime);}
    }

    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
