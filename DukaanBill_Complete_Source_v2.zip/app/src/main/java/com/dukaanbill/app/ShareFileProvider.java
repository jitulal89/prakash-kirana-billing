package com.dukaanbill.app;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileNotFoundException;

public class ShareFileProvider extends ContentProvider {
    private File shareDir;

    @Override
    public boolean onCreate() {
        shareDir = new File(getContext().getCacheDir(), "share");
        if (!shareDir.exists()) shareDir.mkdirs();
        return true;
    }

    private File getSafeFile(Uri uri) throws FileNotFoundException {
        String name = uri.getLastPathSegment();
        if (name == null || name.contains("/") || name.contains("..")) {
            throw new FileNotFoundException("Invalid file");
        }

        File file = new File(shareDir, name);
        try {
            String base = shareDir.getCanonicalPath() + File.separator;
            String target = file.getCanonicalPath();
            if (!target.startsWith(base)) {
                throw new FileNotFoundException("Invalid path");
            }
        } catch (java.io.IOException e) {
            throw new FileNotFoundException("Invalid path");
        }

        if (!file.exists()) {
            throw new FileNotFoundException("File not found");
        }
        return file;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        return ParcelFileDescriptor.open(
                getSafeFile(uri),
                ParcelFileDescriptor.MODE_READ_ONLY
        );
    }

    @Override
    public String getType(Uri uri) {
        String name = uri.getLastPathSegment();
        String ext = MimeTypeMap.getFileExtensionFromUrl(name == null ? "" : name);

        if ("pdf".equalsIgnoreCase(ext)) return "application/pdf";
        if ("png".equalsIgnoreCase(ext)) return "image/png";
        return "application/octet-stream";
    }

    @Override
    public Cursor query(
            Uri uri,
            String[] projection,
            String selection,
            String[] selectionArgs,
            String sortOrder) {
        try {
            File f = getSafeFile(uri);
            MatrixCursor c = new MatrixCursor(
                    new String[]{"_display_name", "_size"}
            );
            c.addRow(new Object[]{f.getName(), f.length()});
            return c;
        } catch (FileNotFoundException e) {
            return null;
        }
    }

    @Override
    public int delete(
            Uri uri,
            String selection,
            String[] selectionArgs) {
        try {
            return getSafeFile(uri).delete() ? 1 : 0;
        } catch (FileNotFoundException e) {
            return 0;
        }
    }

    @Override
    public int update(
            Uri uri,
            ContentValues values,
            String selection,
            String[] selectionArgs) {
        return 0;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }
}
