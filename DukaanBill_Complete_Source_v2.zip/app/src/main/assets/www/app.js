const $=id=>document.getElementById(id);
window.addEventListener("error",e=>{try{console.error("DukaanBill runtime error",e.error||e.message);}catch(_){}});
window.addEventListener("unhandledrejection",e=>{try{console.error("DukaanBill promise error",e.reason||e);}catch(_){}});
// Explicit DOM references for Android WebView reliability. Do not depend on
// browser-specific named-element globals such as window.items/window.billDate.
const items=$("items");
const billDate=$("billDate");
const PIECE_PRODUCTS=new Set([]);

// Native Android state bridge. Keep this initialization before any state access.
// If the native bridge is unavailable (for browser preview), fall back to localStorage.
let nativeStore={};
try{
 const rawNative=window.Android?.loadAppState?.();
 if(rawNative) nativeStore=JSON.parse(rawNative)||{};
}catch(e){nativeStore={};}
const getStored=(key,fallback)=>{
 try{
   if(Object.prototype.hasOwnProperty.call(nativeStore,key)) return JSON.parse(nativeStore[key]||JSON.stringify(fallback));
   const raw=localStorage.getItem(key);
   return raw==null?fallback:JSON.parse(raw);
 }catch(e){return fallback;}
};

const LEGACY_DEFAULT_PRODUCT_NAMES=new Set(["Singdana","Sabudana","Sugar","Rice","Dal","Wheat","Atta","Maida","Besan","Rava","Sooji","Poha","Moong Dal","Toor Dal","Masoor Dal","Urad Dal","Chana Dal","Rajma","Chole","Kabuli Chana","Moong","Masoor","Black Gram","Tea","Coffee","Salt","Jaggery","Turmeric","Red Chilli Powder","Coriander Powder","Garam Masala","Cumin","Mustard Seeds","Fennel","Black Pepper","Cardamom","Cloves","Cinnamon","Cooking Oil","Sunflower Oil","Groundnut Oil","Mustard Oil","Ghee","Butter","Milk","Curd","Bread","Biscuits","Namkeen","Chips","Papad","Noodles","Pasta","Vermicelli","Corn Flakes","Oats","Jam","Peanut Butter","Honey","Tomato Ketchup","Pickle","Coconut","Dry Coconut","Almonds","Cashews","Raisins","Walnuts","Dates","Mouth Freshener","Chocolate","Toffee","Colgate","Toothpaste","Toothbrush","Soap","Shampoo","Hair Oil","Face Wash","Body Lotion","Detergent","Washing Powder","Dishwash","Dishwash Bar","Floor Cleaner","Toilet Cleaner","Phenyl","Handwash","Sanitizer","Tissue","Toilet Paper","Garbage Bags","Mosquito Coil","Mosquito Repellent","Matchbox","Candles","Battery","Notebook","Pen","Pencil","Eraser","Sharpener"]);

const state={
 products:getStored("pksProducts",[]),
 bills:getStored("pksBills",[]),
 customers:getStored("pksCustomers",[]),
 vendors:getStored("pksVendors",[]),
 purchases:getStored("pksPurchases",[]),
 vendorPayments:getStored("pksVendorPayments",[]),
 customerPayments:getStored("pksCustomerPayments",[]),
 settings:Object.assign({shopName:"DUKAAN BILL",billPrefix:"BILL",billStart:1,billTitle:"CASH MEMO / BILL",address:"",footer:"Thank you for shopping with us!",signature:"",tagline:"",shopMobile:"",shopMobiles:[],showCustomer:true,paperSize:"80mm",logoData:"",creditFooter:"Bill created by DukaanBill • Contact 8087794271 for more details",vendorManagement:true,customUnits:[{name:"Roll",aliases:["roll","r","rl"]}],unitCatalog:[],taxationEnabled:false,gstin:"",businessState:"",taxInvoicePrefix:"INV",taxInvoiceStart:1,reverseCharge:false},getStored("dukaanBillSettings",{})),
 purchaseAttachment:null
};
// Normalize the taxation flag from older backups/storage. Some older builds could
// persist booleans as strings (for example "false"), and Boolean("false") is true.
// Treat only explicit true values as enabled so the billing Tax control never
// appears when taxation is actually disabled.
state.settings.taxationEnabled = state.settings.taxationEnabled === true || state.settings.taxationEnabled === 1 || String(state.settings.taxationEnabled).toLowerCase() === "true";

// Tax mode for the billing form. Historical tax invoices retain their tax
// structure while being edited even if the current global Taxation setting is OFF.
function formTaxEnabled(){ return !!state.settings.taxationEnabled || !!window.editingTaxInvoice; }
function syncTaxUi(){ document.body.classList.toggle("taxation-on",!!state.settings.taxationEnabled); document.body.classList.toggle("taxation-editing",!!window.editingTaxInvoice); document.querySelectorAll(".tax-field").forEach(el=>el.classList.toggle("hidden",!formTaxEnabled())); }
function billTaxEnabled(b){ return !!b?.taxationEnabled; }
// Remove the old preloaded product catalog once. User-created products are preserved.
if(!getStored("dukaanProductCatalogMigrated",false)){
 state.products=state.products.filter(p=>!LEGACY_DEFAULT_PRODUCT_NAMES.has(String(p.name||"")));
 try{localStorage.setItem("dukaanProductCatalogMigrated","true");}catch(e){}
 save();
}
let editingProduct=-1, deferredInstall=null;


// Normalize records coming from older backups/imports so search, selection and
// product auto-fill work consistently across all previous schema variants.
function normalizeImportedRecords(){
 state.products=(Array.isArray(state.products)?state.products:[]).map(p=>({
   ...p,
   name:String(p?.name??p?.productName??p?.itemName??"").trim(),
   rate:Number(p?.rate??p?.price??p?.sellingPrice??0)||0,
   unit:String(p?.unit??p?.unitName??p?.uom??"kg")||"kg",
   hsn:String(p?.hsn??p?.hsnCode??"").trim(),taxRate:Number(p?.taxRate??p?.tax??0)||0
 })).filter(p=>p.name);
 state.customers=(Array.isArray(state.customers)?state.customers:[]).map(c=>({
   ...c,
   name:String(c?.name??c?.customerName??"").trim(),
   phone:normalizePhone(c?.phone??c?.mobile??c?.mobileNumber??c?.phoneNumber??""),
   notes:String(c?.notes??c?.note??c?.additionalDetails??"").trim(),
   gstin:String(c?.gstin??c?.gstinNumber??"").trim().toUpperCase(),state:String(c?.state??c?.customerState??"").trim()
 })).filter(c=>c.name);
}

function logoSource(){ return state.settings.logoData || "logo.jpg"; }
function setShopLogo(data){ state.settings.logoData=data||""; save(); refreshShopHeader(); if(window.currentBill) renderBill(window.currentBill); }
function clearShopLogo(){ state.settings.logoData=""; save(); refreshShopHeader(); if(window.currentBill) renderBill(window.currentBill); }

function refreshShopHeader(){
 const brand=$("shopBrand"), logo=$("shopLogoHeader");
 if(brand) brand.textContent=state.settings.shopName||"DUKAAN BILL";
 if(logo){ logo.src=logoSource(); logo.classList.toggle("hidden",!state.settings.logoData); }

}

refreshShopHeader();
setupLogoPicker();
// Migrate existing WebView local data into the native SQLite store on first run.
if(Object.keys(nativeStore).length===0 && window.Android?.saveAppState){ try{ save(); }catch(e){} }

function save(){
 const payload={
  pksProducts:JSON.stringify(state.products),
  pksBills:JSON.stringify(state.bills),
  pksCustomers:JSON.stringify(state.customers),
  pksVendors:JSON.stringify(state.vendors),
  pksPurchases:JSON.stringify(state.purchases),
  pksVendorPayments:JSON.stringify(state.vendorPayments),
  pksCustomerPayments:JSON.stringify(state.customerPayments),
  dukaanBillSettings:JSON.stringify(state.settings)
 };
 try{ Object.entries(payload).forEach(([k,v])=>localStorage.setItem(k,v)); }catch(e){ console.warn("Web storage save failed",e); }
 try{ if(window.Android?.saveAppState) Android.saveAppState(JSON.stringify(payload)); }catch(e){ console.warn("Native save failed",e); }
}
function today(){let d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
if(billDate)billDate.value=today();$("customer").value="Walk-in Customer";
function money(n){return "₹"+Number(n||0).toFixed(2)}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]))}
let pendingConfirmAction=null;
function showNotice(message,title="DukaanBill"){
  const m=$("appNoticeModal"); if(!m)return;
  $("appNoticeTitle").textContent=title; $("appNoticeMessage").textContent=String(message||""); m.classList.remove("hidden");
}
function closeNotice(){$("appNoticeModal")?.classList.add("hidden");}
function showConfirm(message,onOk,title="Confirm"){
  const m=$("appConfirmModal"); if(!m){onOk?.();return;}
  $("appConfirmTitle").textContent=title; $("appConfirmMessage").textContent=String(message||""); pendingConfirmAction=onOk; m.classList.remove("hidden");
}
function closeConfirm(){pendingConfirmAction=null;$("appConfirmModal")?.classList.add("hidden");}
$("appNoticeOk")?.addEventListener("click",closeNotice);
$("appConfirmCancel")?.addEventListener("click",closeConfirm);
$("appConfirmOk")?.addEventListener("click",()=>{const fn=pendingConfirmAction;closeConfirm();if(fn)fn();});

function nextTaxInvoiceNo(){const y=new Date().getFullYear();const n=Number(state.settings.taxInvoiceStart)||1;return `#${state.settings.taxInvoicePrefix||"INV"}-${y}/${String(n).padStart(3,"0")}`}
function nextBillNo(){const y=new Date().getFullYear(),nums=state.bills.map(b=>Number((b.billNo||"").split("/").pop())).filter(Number.isFinite);const start=Number(state.settings.billStart)||1;const next=Math.max(start-1,...nums)+1;return `#${state.settings.billPrefix||"PKS"}-${y}/${String(next).padStart(3,"0")}`}

const DEFAULT_UNIT_CATALOG=[
 {name:"kg",aliases:["kg","kgs","kilo","kilos","kilogram","kilograms"]},
 {name:"gram",aliases:["g","gm","gram","grams"]},
 {name:"mg",aliases:["mg","milligram","milligrams"]},
 {name:"piece",aliases:["piece","pieces","pc","pcs"]},
 {name:"packet",aliases:["packet","packets","pk","pkt","pks"]},
 {name:"pack",aliases:["pack","packs"]},
 {name:"box",aliases:["box","boxes"]},
 {name:"bottle",aliases:["bottle","bottles","bt"]},
 {name:"liter",aliases:["liter","litre","liters","litres","l","ltr","lt"]},
 {name:"ml",aliases:["ml","milliliter","milliliters","millilitre","millilitres"]},
 {name:"dozen",aliases:["dozen","dz"]},
 {name:"Roll",aliases:["roll","r","rl"]}
];
function ensureUnitCatalog(){
 const existing=Array.isArray(state.settings.unitCatalog)?state.settings.unitCatalog:[];
 if(!existing.length){
   const legacy=Array.isArray(state.settings.customUnits)?state.settings.customUnits:[];
   const merged=DEFAULT_UNIT_CATALOG.map(x=>({name:x.name,aliases:[...x.aliases]}));
   legacy.forEach(u=>{const name=String(u?.name||"").trim();if(!name)return;const aliases=Array.isArray(u.aliases)?u.aliases.map(a=>String(a).trim().toLowerCase()).filter(Boolean):[];const k=name.toLowerCase();const hit=merged.find(x=>String(x.name).toLowerCase()===k);if(hit)hit.aliases=[...new Set([...hit.aliases,...aliases])];else merged.push({name,aliases:[k,...aliases]});});
   state.settings.unitCatalog=merged;
 }
 return state.settings.unitCatalog;
}
function getUnitDefinitions(){
 return ensureUnitCatalog().map(x=>({name:String(x.name||"").trim(),aliases:[String(x.name||"").trim().toLowerCase(),...(Array.isArray(x.aliases)?x.aliases.map(a=>String(a).trim().toLowerCase()).filter(Boolean):[])]})).filter(x=>x.name);
}

ensureUnitCatalog();

function unitAliasPattern(){
 const aliases=[...new Set(getUnitDefinitions().flatMap(x=>x.aliases))].sort((a,b)=>b.length-a.length);
 return aliases.map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|");
}
function normalizeUnitName(unit){
 const u=String(unit||"").toLowerCase().trim();
 for(const d of getUnitDefinitions()) if(d.aliases.includes(u)) return d.name;
 return u||"kg";
}
function unitOptionsHtml(selected){
 const value=normalizeUnitName(selected||"kg");
 return getUnitDefinitions().map(d=>`<option value="${esc(d.name)}" ${d.name===value?"selected":""}>${esc(d.name)}</option>`).join("");
}
function isCountUnit(unit){return !["kg","gram","mg","dozen"].includes(normalizeUnitName(unit));}

function normalizeQtyForRow(row){
 const input=row.querySelector(".iqty");
 const select=row.querySelector(".iunit");
 const text=String(input.value||"").trim().toLowerCase().replace(/,/g," " ).replace(/\s+/g," ");
 const m=text.match(new RegExp(`^(\d+(?:\.\d+)?)\s*(?:(${unitAliasPattern()}))?$`,"i"));
 if(!m)return;
 input.value=m[1];
 if(m[2])select.value=normalizeUnitName(m[2]);
}

function parseQuickListLine(line){
 let raw=String(line||"").trim();
 if(!raw)return null;
 raw=raw.replace(/[|,;]/g," ").replace(/\s+/g," ").trim();
 raw=raw.replace(/^(?:add\s+)?(?:new\s+)?(?:item|tem)\s+/i,"").trim();
 const units=unitAliasPattern();
 let taxRate=null;
 const taxMatch=raw.match(/(?:\s+)(0|5|12|18|28)\s*%?\s*$/i);
 if(taxMatch){taxRate=Number(taxMatch[1]);raw=raw.slice(0,taxMatch.index).trim();}
 const rateMatch=raw.match(/(?:₹\s*)?(\d+(?:\.\d+)?)\s*(?:rs|rs\.|inr|rupees?)?\s*$/i);
 if(!rateMatch)return {error:`Could not find rate in: ${line}`};
 const rate=Number(rateMatch[1]);
 let before=raw.slice(0,rateMatch.index).trim();
 const qtyMatch=before.match(new RegExp(`(\\d+(?:\\.\\d+)?)\\s*(?:(${units}))?\\s*$`,"i"));
 if(!qtyMatch)return {error:`Could not find quantity in: ${line}`};
 const qty=qtyMatch[1];
 const explicitUnit=qtyMatch[2]?normalizeUnitName(qtyMatch[2]):"";
 let name=before.slice(0,qtyMatch.index).trim();
 name=name.replace(/\bx\s*$/i,"").trim();
 if(!name)return {error:`Could not find item name in: ${line}`};
 const saved=findProduct(name);
 const unit=explicitUnit || (saved && saved.unit ? saved.unit : "piece");
 return {name,qty,unit,rate,taxRate:taxRate===null?5:taxRate};
}

function addQuickList(){
 const box=$("quickList");
 const text=String(box.value||"").trim();
 if(!text){box.focus();return}
 const lines=text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 const parsed=[];const errors=[];
 for(const line of lines){const item=parseQuickListLine(line);if(item?.error)errors.push(item.error);else if(item)parsed.push(item)}
 if(errors.length){alert("Please correct these lines:\n\n"+errors.join("\n"));return}

 // Keep the Quick List text on screen.  Re-pressing Add List updates
 // existing billing rows with the same item name and adds only new items.
 const existingRows=[...items.children];
 const updated=[];
 const added=[];
 parsed.forEach(item=>{
   const key=item.name.trim().toLowerCase();
   const row=existingRows.find(r=>String(r.querySelector(".iname")?.value||"").trim().toLowerCase()===key);
   if(row){
     row.querySelector(".iqty").value=item.qty;
     row.querySelector(".iunit").value=item.unit;
     row.querySelector(".irate").value=item.rate;
     if(row.querySelector(".itax") && state.settings.taxationEnabled) row.querySelector(".itax").value=String(item.taxRate??5);
     normalizeQtyForRow(row);
     updated.push(item.name);
   }else{
     addItem(item);
     added.push(item.name);
   }
 });
 calc();
 if(parsed.length){

   const targetName=added.length?added[added.length-1]:updated[updated.length-1];
   const target=[...items.children].find(r=>String(r.querySelector(".iname")?.value||"").trim().toLowerCase()===String(targetName||"").trim().toLowerCase());
   target?.querySelector(".irate")?.focus();
 }
}

function addItem(item={name:"",qty:"",rate:0,unit:"kg",taxRate:5}){
 const row=document.createElement("div");row.className="item";
 const showTax=formTaxEnabled();
 const unit=normalizeUnitName(item.unit||"kg");
 const qtyText=String(item.qty??"").replace(new RegExp(`\\s*(?:${unitAliasPattern()})\\s*$`,"i"),"").trim();
 row.innerHTML=`<label class="item-name">Item<input class="iname" list="productNames" value="${esc(item.name)}" placeholder="Sugar"></label>
 <div class="item-details">
   <label>Qty<input class="iqty" type="text" inputmode="decimal" value="${esc(qtyText)}" placeholder="2"></label>
   <label>Unit<select class="iunit">${unitOptionsHtml(unit)}</select></label>
   <label>Rate / Unit<input class="irate" type="number" min="0" step="0.01" value="${item.rate}"></label>
   <label class="tax-field ${showTax?"":"hidden"}">Tax<select class="itax"><option value="0">0%</option><option value="5">5%</option><option value="12">12%</option><option value="18">18%</option><option value="28">28%</option></select></label>
   <div class="amount-cell"><label>Amount</label><div class="amount">₹0.00</div></div>
   <button class="remove" type="button" aria-label="Remove item">×</button>
 </div>`;
 items.appendChild(row);row.querySelector(".iunit").value=unit;
 const taxSelect=row.querySelector(".itax"); if(taxSelect){const p=findProduct(item.name||""); const savedTax=Number(item.taxRate??item.tax??(p&&Number(p.taxRate||0)>0?p.taxRate:5)); taxSelect.value=[0,5,12,18,28].includes(savedTax)?String(savedTax):"5";}
 if(String(item.name||"").trim() && (item.rate===undefined || Number(item.rate||0)===0)){ autoRate(row); }
 row.querySelectorAll("input,select").forEach(x=>x.addEventListener("input",()=>{
   if(x.classList.contains("iqty"))normalizeQtyForRow(row);
   if(x.classList.contains("irate")) row.dataset.userRateEdited="true";
   calc();
 }));
 // Selecting an existing product from the datalist/search must populate both
 // rate and unit. Android WebView can emit either input or change here.
 const nameInput=row.querySelector(".iname");
 const rateInput=row.querySelector(".irate");
 const applyProduct=()=>{
   row.dataset.userRateEdited="";
   autoRate(row);
   calc();
 };
 nameInput.addEventListener("input",applyProduct);
 nameInput.addEventListener("change",applyProduct);
 nameInput.addEventListener("keyup",applyProduct);
 nameInput.addEventListener("blur",applyProduct);
 row.querySelector(".iqty").addEventListener("blur",()=>{normalizeQtyForRow(row);calc()});
 row.querySelector(".remove").onclick=()=>{row.remove();calc()};
 calc();
}
function autoRate(row){
 const name=row.querySelector(".iname").value.trim();
 if(!name)return;
 const rateInput=row.querySelector(".irate");
 // Only supply the product-master rate if this is a newly named/empty row.
 // Once the user has edited the rate, clearing it must remain blank until
 // the user enters a new rate.
 if(!row.dataset.userRateEdited){
   const p=findProduct(name);
   if(p){
     rateInput.value=Number(p.rate||0);
     rateInput.dataset.autoFilled="true";
     row.querySelector(".iunit").value=normalizeUnitName(p.unit||"kg");
     const ts=row.querySelector(".itax"); if(ts && Number(p.taxRate||0)>0) ts.value=String(p.taxRate);
   }
 }
}

// Quantity is stored/displayed as text. The Unit field controls how the rate is applied.
// kg/gram are converted to kg for a Rate/kg product; piece/packet/box/etc. stay as counts.
function quantityValue(qtyText, defaultUnit="kg"){
 const text=String(qtyText??"").trim().toLowerCase().replace(/,/g," ").replace(/\s+/g," ");
 if(!text)return 0;
 let n=Number(text);
 let rawUnit=String(defaultUnit||"kg");
 const m=text.match(/^(\d+(?:\.\d+)?)(?:\s+(.+))?$/);
 if(m){n=Number(m[1]);if(m[2])rawUnit=m[2].trim();}
 if(!Number.isFinite(n)||n<0)return 0;
 const unit=normalizeUnitName(rawUnit);
 if(unit==="mg")return n/1000000;
 if(unit==="ml")return n/1000;
 if(unit==="gram")return n/1000;
 if(unit==="dozen")return n*12;
 return n;
}
function qtyDisplayUnit(qtyText,defaultUnit="kg"){return normalizeUnitName(defaultUnit||"kg");}
function getBillTotals(){
 let subtotal=0;
 const lines=[];
 [...items.children].forEach(r=>{
   const q=quantityValue(r.querySelector(".iqty").value,r.querySelector(".iunit").value),rate=Number(r.querySelector(".irate").value)||0,gross=q*rate;
   subtotal+=gross;
   const ts=r.querySelector(".itax"); const taxRate=formTaxEnabled()?(Number(ts?.value)||0):0;
   const amountEl=r.querySelector(".amount");if(amountEl)amountEl.textContent=money(gross);
   lines.push({row:r,gross,taxRate});
 });
 const type=$("discountType")?.value||"percent";
 const value=Math.max(0,Number($("discountValue")?.value)||0);
 const discount=type==="amount"?Math.min(value,subtotal):Math.min(subtotal,subtotal*value/100);
 let taxTotal=0,taxableValue=0;
 lines.forEach(x=>{
   const netGross=subtotal>0?x.gross*(subtotal-discount)/subtotal:x.gross;
   const base=formTaxEnabled() && x.taxRate>0?netGross/(1+x.taxRate/100):netGross;
   const tax=formTaxEnabled() && x.taxRate>0?netGross-base:0;
   x.netGross=netGross;x.taxable=base;x.tax=tax;taxableValue+=base;taxTotal+=tax;
 });
 return {subtotal,discount,total:Math.max(0,subtotal-discount),discountType:type,discountValue:value,taxableValue,taxTotal,lines};
}

function calc(){
 const t=getBillTotals();
 $("subTotal").textContent=money(t.subtotal);
 $("discountAmount").textContent=money(t.discount);
 $("grandTotal").textContent=money(t.total);
}
function clearBill(){
 $("customer").value="Walk-in Customer";
 $("quickList").value="";
 hideCustomerSuggestions();
 $("customer").dataset.phone="";
 items.innerHTML="";
 $("billDate").value=today();
 $("paymentMode").value="Cash";
 $("discountType").value="percent";
 $("discountValue").value="0";
 if($("placeOfSupply")) $("placeOfSupply").value=state.settings.businessState||"";
 hideCustomerSuggestions();
 window.editingBillNo=null;
 window.editingTaxInvoice=false;
 syncTaxUi();
 const btn=$("generateBtn"); if(btn) btn.textContent="Generate Bill";
 const mode=$("billingModeLabel"); if(mode) mode.textContent="Create a new bill";
 calc();
}
function loadBillForEdit(b){
 window.editingBillNo=b.billNo;
 window.editingTaxInvoice=!!b.taxationEnabled;
 syncTaxUi();
 $("customer").value=(b.customer&&b.customer!=="Walk-in Customer")?b.customer:"Walk-in Customer";
 $("customer").dataset.phone=normalizePhone(b.customerPhone||"");
 $("billDate").value=b.date||today();
 $("paymentMode").value=b.paymentMode||"Cash";
 $("discountType").value=b.discountType||"percent";
 $("discountValue").value=String(b.discountValue??0);
 if($("placeOfSupply")) $("placeOfSupply").value=b.placeOfSupply||state.settings.businessState||"";
 items.innerHTML="";
 (b.items||[]).forEach(it=>addItem(it));
 const btn=$("generateBtn"); if(btn) btn.textContent="Update Bill";
 const mode=$("billingModeLabel"); if(mode) mode.textContent="Editing "+(b.billNo||"bill");
 calc(); showPage("billing");
}
function startNewBill(){clearBill();showPage("billing");}

window.__pageHistory = ["billing"];
function syncNavigation(name){
 document.querySelectorAll(".bottom-tab[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===name));
 const primary=["billing","history","reports"];
 const moreActive=!primary.includes(name);
 $("moreNavBtn")?.classList.toggle("active",moreActive);
 $("morePurchasingItem")?.classList.toggle("hidden",state.settings.vendorManagement===false);
}
function closeMoreMenu(){ $("moreMenu")?.classList.add("hidden"); }
function showPage(name, addHistory=true){
 if(name==="customers"){customerQuery="";customerPage=1;if($("customerPageSearch"))$("customerPageSearch").value="";}
 if(name==="units"){ensureUnitCatalog();renderCustomUnits();resetCustomUnitEditor();}
 if(name==="products"){productQuery="";productPage=1;if($("productPageSearch"))$("productPageSearch").value="";}
 if(name==="billing" && addHistory){hideCustomerSuggestions();}
 if(name==="purchases" && state.settings.vendorManagement===false){name="billing";}
 const current=window.__pageHistory[window.__pageHistory.length-1];
 if(addHistory && current!==name) window.__pageHistory.push(name);
 document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
 const page=$(name+"Page"); if(page)page.classList.add("active");
 syncNavigation(name);
 closeMoreMenu();
 if(name==="products")renderProducts();if(name==="history")renderHistory();if(name==="reports")renderReports();if(name==="purchases")renderPurchasing();if(name==="customers")renderCustomers();if(name==="settings")loadSettings();
 window.scrollTo(0,0);
}
document.querySelectorAll(".bottom-tab[data-page]").forEach(b=>b.onclick=()=>{if(b.dataset.page==="billing") clearBill(); showPage(b.dataset.page);});
$("moreNavBtn")?.addEventListener("click",()=>$("moreMenu").classList.toggle("hidden"));
$("closeMoreBtn")?.addEventListener("click",closeMoreMenu);
document.querySelectorAll(".more-item[data-page]").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
$("manageUnitsBtn")?.addEventListener("click",()=>showPage("units"));
$("newBillBtn")?.addEventListener("click",()=>startNewBill());
window.handleAndroidBack=function(){
 const openModal=document.querySelector(".modal:not(.hidden)");
 if(openModal){openModal.classList.add("hidden");return true;}
 if(window.__pageHistory.length>1){
   window.__pageHistory.pop();
   const previous=window.__pageHistory[window.__pageHistory.length-1]||"billing";
   showPage(previous,false);
   return true;
 }
 return false;
};
$("addItemBtn").onclick=()=>addItem();$("quickListBtn").onclick=addQuickList;$("clearBtn").onclick=()=>clearBill();
$("discountType").onchange=calc;$("discountValue").oninput=calc;

function normalizeVoiceText(text){return String(text||"").replace(/[₹,]/g," ").replace(/[;|]/g," ").replace(/\s+/g," ").trim()}
function cleanCommandText(text){return normalizeVoiceText(text).replace(/\b(?:please|pls|kindly)\b/gi," ").replace(/\s+/g," ").trim()}

// Common speech-recognition substitutions. These are deliberately conservative.
function normalizeSpokenNumbers(text){
 let s=String(text||"").toLowerCase();
 const replacements={"one":"1","two":"2","three":"3","four":"4","five":"5","six":"6","seven":"7","eight":"8","nine":"9","ten":"10","half":"0.5"};
 for(const [w,n] of Object.entries(replacements))s=s.replace(new RegExp(`\\b${w}\\b`,"gi"),n);
 // Android speech recognition sometimes hears "two" as "to" or "too".
 // Only treat those as 2 when they occur immediately after a quantity keyword.
 s=s.replace(/\b(quantity|qty|quanity|quant|qnty)\s+(?:to|too|tu)\b/gi,"$1 2");
 return s;
}

function normalizeUnits(text){
 return text.toLowerCase()
   .replace(/\bkilograms?\b/g,"kg").replace(/\bkilos?\b/g,"kg").replace(/\bkgs?\b/g,"kg")
   .replace(/\bgrams?\b/g,"gram").replace(/\bgms?\b/g,"gram").replace(/\bmilligrams?\b/g,"mg");
}
function normalizeForParsing(text){return normalizeUnits(normalizeSpokenNumbers(cleanCommandText(text))).replace(/\s+/g," ").trim()}

function levenshtein(a,b){
 a=a.toLowerCase();b=b.toLowerCase();
 const dp=Array.from({length:a.length+1},()=>Array(b.length+1).fill(0));
 for(let i=0;i<=a.length;i++)dp[i][0]=i;
 for(let j=0;j<=b.length;j++)dp[0][j]=j;
 for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++)dp[i][j]=Math.min(dp[i-1][j]+1,dp[i][j-1]+1,dp[i-1][j-1]+(a[i-1]===b[j-1]?0:1));
 return dp[a.length][b.length];
}
function findProduct(spoken){
 const s=String(spoken||"").trim().toLowerCase();if(!s)return null;
 let exact=state.products.find(p=>p.name.toLowerCase()===s);if(exact)return exact;
 let best=null,bestScore=Infinity;
 for(const p of state.products){
   const n=String(p.name??p.productName??p.itemName??"").toLowerCase();
   let d=levenshtein(s,n);
   if(s.includes(n)||n.includes(s))d=Math.min(d,1);
   const threshold=Math.max(2,Math.floor(Math.max(s.length,n.length)*0.4));
   if(d<=threshold&&d<bestScore){best=p;bestScore=d}
 }
 return best;
}

function addProductIfMissing(name,rate,unit="kg"){
 const clean=String(name||"").trim();
 const r=Number(rate)||0;
 if(!clean||r<=0)return false;
 const existing=state.products.find(p=>p.name.toLowerCase()===clean.toLowerCase());
 if(existing){
   if((!Number(existing.rate)||Number(existing.rate)===0)&&r>0){existing.rate=r;save();}
   return false;
 }
 state.products.push({name:clean,rate:r,unit:unit||"kg"});
 save();
 renderDatalist();renderCustomerDatalist();renderCustomUnits();refreshUnitControls();document.body.classList.toggle("taxation-on",!!state.settings.taxationEnabled);document.querySelectorAll(".tax-field").forEach(x=>x.classList.toggle("hidden",!state.settings.taxationEnabled));if($("placeOfSupply"))$("placeOfSupply").value=state.settings.businessState||"";
 return true;
}

function extractQuantity(raw){
 const r=normalizeForParsing(raw);
 // First isolate the words between quantity and rate. This prevents the rate number
 // from ever being accidentally joined to the quantity (for example 1 kg + 50).
 let phrase="";
 const between=r.match(/\b(?:quantity|qty|quanity|quant|qnty)\s*[:=-]?\s*(.*?)\s+(?=(?:rate|price|cost|rs|rupees|rupay|rupaye|right)\b)/i);
 if(between) phrase=between[1].trim();
 else {
   const direct=r.match(/\b(?:quantity|qty|quanity|quant|qnty)\s*[:=-]?\s*(\d+(?:\.\d+)?)\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pk|pkt|pks|pack|packs|box|boxes|bottle|bottles|dozen)?\b/i);
   if(direct) return {value:Number(direct[1]),unit:direct[2]||"",text:direct[1]};
 }
 if(phrase){
   const m=phrase.match(/^(\d+(?:\.\d+)?)\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pk|pkt|pks|pack|packs|box|boxes|bottle|bottles|dozen)?\b/i);
   if(m)return {value:Number(m[1]),unit:m[2]||"",text:m[1]};
 }
 // Also allow: Add Item Sugar 1 kg Rate 50
 const m2=r.match(/\b(?:item|add\s+item|new\s+item)\b\s+.*?\b(\d+(?:\.\d+)?)\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pk|pkt|pks|pack|packs|box|boxes|bottle|bottles|dozen)\b/i);
 if(m2)return {value:Number(m2[1]),unit:m2[2],text:m2[1]};
 return null;
}
function extractRate(raw){
 const r=normalizeForParsing(raw);
 const m=r.match(/\b(?:rate|price|cost|rs|rupees|rupay|rupaye|right)\s*[:=-]?\s*(?:₹\s*)?(\d+(?:\.\d+)?)\b/i);
 return m?Number(m[1]):null;
}
function extractItemName(raw,qty,rate){
 let s=normalizeForParsing(raw);
 // "Item" is optional. Accept "Colgate quantity 1 rate 100",
 // "Add Colgate quantity 1 rate 100", "Tem Colgate...", etc.
 s=s.replace(/^(?:add\s+)?(?:new\s+)?(?:item|tem)\b\s*/i,"");
 s=s.replace(/\b(?:quantity|qty|quanity|quant|qnty)\s*[:=-]?\s*\d+(?:\.\d+)?\s*(?:kg|gram|g|mg)?\b.*$/i,"");
 s=s.replace(/\b(?:rate|price|cost|rs|rupees|rupay|rupaye|right)\s*[:=-]?\s*\d+(?:\.\d+)?\b.*$/i,"");
 if(qty)s=s.replace(new RegExp(`\\s${qty.value}(?:\\s${qty.unit})?\\s*$`,"i"),"");
 return s.replace(/\s+/g," ").trim();
}

function parseVoice(text){
 const raw=normalizeForParsing(text);if(!raw)return null;
 if(/^(?:customer|grahak)\b/i.test(raw))return {type:"customerIgnored"};
  const qty=extractQuantity(raw);const rate=extractRate(raw);
 if(!qty||rate===null)return null;
 let name=extractItemName(raw,qty,rate);
 if(!name)return null;
 let product=findProduct(name);
 if(!product){
   const words=name.split(/\s+/).filter(Boolean);
   for(let i=0;i<words.length&&!product;i++){
     for(let j=words.length;j>i;j--){
       const candidate=findProduct(words.slice(i,j).join(" "));
       if(candidate){product=candidate;break;}
     }
   }
 }
 const finalName=product?product.name:name;
 const qtyText=qty.text;
 const unit=normalizeUnitName(qty.unit||product?.unit||"kg");
 if(quantityValue(qtyText,unit)<=0)return null;
 return {type:"item",name:finalName,qty:qtyText,unit,rate,matched:!!product,spokenName:name};
}

$("generateBtn").onclick=()=>{
 const taxMode=formTaxEnabled();
 const existingBill=window.editingBillNo?state.bills.find(x=>x.billNo===window.editingBillNo):null;
 const rows=[...items.children].map(r=>({name:r.querySelector(".iname").value.trim(),qty:r.querySelector(".iqty").value.trim(),rate:Number(r.querySelector(".irate").value)||0,unit:r.querySelector(".iunit").value||"kg",taxRate:taxMode?(Number(r.querySelector(".itax")?.value)||0):0,hsn:(findProduct(r.querySelector(".iname").value.trim())?.hsn||"")})).filter(x=>x.name&&quantityValue(x.qty,x.unit)>0);
 if(!rows.length){alert("Add at least one item.");return}
 for(const row of rows)addProductIfMissing(row.name,row.rate,row.unit);
 const t=getBillTotals();
 const customer=$("customer").value.trim()||"Walk-in Customer";
 const selectedPhone=normalizePhone($("customer").dataset.phone||"");
 const exactCustomers=state.customers.filter(c=>String(c.name||"").trim().toLowerCase()===customer.toLowerCase());
 const customerPhone=selectedPhone || (exactCustomers.length===1 ? normalizePhone(exactCustomers[0].phone||"") : "");
 const customerGstin=exactCustomers.length===1?String(exactCustomers[0].gstin||"").trim().toUpperCase():"";
 const bill={billNo:taxMode?nextTaxInvoiceNo():nextBillNo(),date:$("billDate").value,customer,customerPhone,customerGstin,paymentMode:$("paymentMode").value||"Cash",items:rows,subtotal:t.subtotal,discountType:t.discountType,discountValue:t.discountValue,discount:t.discount,taxationEnabled:taxMode,taxableValue:t.taxableValue,taxTotal:t.taxTotal,total:t.total,placeOfSupply:$("placeOfSupply")?.value||existingBill?.placeOfSupply||state.settings.businessState||"",gstin:taxMode?(state.settings.gstin||existingBill?.gstin||""):(existingBill?.gstin||""),businessState:taxMode?(state.settings.businessState||existingBill?.businessState||""):(existingBill?.businessState||"")};
 if(window.editingBillNo){
   const idx=state.bills.findIndex(x=>x.billNo===window.editingBillNo);
   if(idx>=0){bill.billNo=window.editingBillNo;bill.taxationEnabled=!!(existingBill?.taxationEnabled||taxMode);bill.gstin=existingBill?.gstin||bill.gstin||"";bill.businessState=existingBill?.businessState||bill.businessState||"";state.bills[idx]=bill;} else state.bills.unshift(bill);
 }else { state.bills.unshift(bill); if(state.settings.taxationEnabled) state.settings.taxInvoiceStart=(Number(state.settings.taxInvoiceStart)||1)+1; }
 save(); window.editingBillNo=null; window.editingTaxInvoice=false; syncTaxUi(); const gen=$("generateBtn"); if(gen) gen.textContent="Generate Bill"; renderBill(bill); showPage("preview"); $("previewPage").classList.add("active");
};

let suppressCustomerSuggestionInput=false;
function hideCustomerSuggestions(){const box=$("customerSuggestions");if(box){box.classList.add("hidden");box.innerHTML=""}}
function showCustomerSuggestions(){
 const box=$("customerSuggestions"), input=$("customer"); if(!box||!input)return;
 let q=input.value.trim().toLowerCase();
 // Treat the default Walk-in Customer value as empty while searching.
 if(q==="walk-in customer") q="";
 const matches=getCustomerRecords().filter(c=>{const name=String(c.name??c.customerName??"");const phone=normalizePhone(c.phone??c.mobile??c.mobileNumber??c.phoneNumber??"");const notes=String(c.notes??c.note??c.additionalDetails??"");const phoneQ=normalizePhone(q); return !q||name.toLowerCase().includes(q)|| (phoneQ && phone.includes(phoneQ)) || notes.toLowerCase().includes(q);}).slice(0,20);
 if(!matches.length){hideCustomerSuggestions();return}
 box.innerHTML=matches.map((c,i)=>`<div class="customer-suggestion" data-name="${esc(c.name)}" data-phone="${esc(c.phone??c.mobile??c.mobileNumber??c.phoneNumber??"")}" tabindex="0"><b>${esc(c.name)}</b>${(c.phone??c.mobile??c.mobileNumber??c.phoneNumber)?`<div class="muted">${esc(c.phone??c.mobile??c.mobileNumber??c.phoneNumber)}</div>`:""}</div>`).join("");
 box.querySelectorAll(".customer-suggestion").forEach(el=>{
   const choose=e=>{e?.preventDefault?.();e?.stopPropagation?.();suppressCustomerSuggestionInput=true;input.value=el.dataset.name||"";input.dataset.phone=normalizePhone(el.dataset.phone||"");const cc=getCustomerRecords().find(c=>String(c.name||"").trim().toLowerCase()===String(input.value||"").trim().toLowerCase());if($("placeOfSupply")&&cc?.state)$("placeOfSupply").value=cc.state;hideCustomerSuggestions();setTimeout(()=>{suppressCustomerSuggestionInput=false;},80);};
   el.addEventListener("pointerdown",choose,{passive:false});
   el.addEventListener("touchstart",choose,{passive:false});
   el.addEventListener("mousedown",choose,{passive:false});
   el.addEventListener("click",choose);
   el.addEventListener("keydown",e=>{if(e.key==="Enter"){choose(e);}});
 });
 box.classList.remove("hidden");
}
$("customer")?.addEventListener("focus",e=>{if(e.target.value.trim().toLowerCase()==="walk-in customer")e.target.select();showCustomerSuggestions();});
$("customer")?.addEventListener("click",showCustomerSuggestions);
$("customer")?.addEventListener("input",e=>{e.target.dataset.phone="";if(!suppressCustomerSuggestionInput)showCustomerSuggestions();});
document.addEventListener("click",e=>{if(!e.target.closest(".customer-search-wrap"))hideCustomerSuggestions()});
$("customer")?.addEventListener("blur",()=>{const c=findCustomer($("customer").value);if(c){$("customer").dataset.phone=normalizePhone(c.phone||c.mobile||c.mobileNumber||c.phoneNumber||"");}});

function setupLogoPicker(){
 const input=$("logoFile"),preview=$("logoPreview");
 if(!input)return;
 input.onchange=()=>{
  const file=input.files&&input.files[0];if(!file)return;
  if(!/^image\/(png|jpeg|webp)$/i.test(file.type)){showNotice("Please select a PNG, JPG or WebP image.","Shop Logo");input.value="";return;}
  const reader=new FileReader();
  reader.onload=()=>{
   const src=String(reader.result||"");const img=new Image();
   img.onload=()=>{
    const max=900,scale=Math.min(1,max/Math.max(img.naturalWidth||1,img.naturalHeight||1));
    const w=Math.max(1,Math.round((img.naturalWidth||1)*scale)),h=Math.max(1,Math.round((img.naturalHeight||1)*scale));
    const c=document.createElement("canvas");c.width=w;c.height=h;const ctx=c.getContext("2d");ctx.fillStyle="#fff";ctx.fillRect(0,0,w,h);ctx.drawImage(img,0,0,w,h);
    const data=c.toDataURL("image/jpeg",0.84);setShopLogo(data);if(preview)preview.src=data;input.value="";showNotice("Shop logo updated successfully.","Shop Logo");
   };
   img.onerror=()=>showNotice("The selected image could not be read.","Shop Logo");img.src=src;
  };
  reader.onerror=()=>showNotice("Could not read the selected image.","Shop Logo");reader.readAsDataURL(file);
 };
 $("clearLogoBtn")?.addEventListener("click",()=>{clearShopLogo();if(preview)preview.src="logo.jpg";input.value="";});
}

function normalizePhone(phone){
 let p=String(phone||"").replace(/\D/g,"");
 if(p.startsWith("0091") && p.length===14)p=p.slice(4);
 else if(p.startsWith("91") && p.length===12)p=p.slice(2);
 return p;
}
function isValidMobile(phone){ return /^\d{10}$/.test(normalizePhone(phone)); }
function normalizeShopMobiles(value){
 const arr=Array.isArray(value)?value:(String(value||"").split(/[\n,;/|]+/));
 const out=[]; arr.forEach(v=>{const n=normalizePhone(v);if(/^\d{10}$/.test(n)&&!out.includes(n))out.push(n);}); return out;
}
function getShopMobiles(){ const arr=normalizeShopMobiles(state.settings.shopMobiles); if(!arr.length&&state.settings.shopMobile)return normalizeShopMobiles(state.settings.shopMobile); return arr; }
function shopMobileText(){return getShopMobiles().join(", ");}
function migrateMobileNumbers(){
 state.customers.forEach(c=>{ const n=normalizePhone(c.phone); if(/^\d{10}$/.test(n)) c.phone=n; });
 state.bills.forEach(b=>{ const n=normalizePhone(b.customerPhone); if(/^\d{10}$/.test(n)) b.customerPhone=n; });
}
migrateMobileNumbers();
normalizeImportedRecords();
save();
function findCustomerByNameOrPhone(name,phone){
 const n=String(name||"").trim().toLowerCase();
 const p=normalizePhone(phone);
 return state.customers.find(c=>{
   const sameName=n && String(c.name||"").trim().toLowerCase()===n;
   const samePhone=p && normalizePhone(c.phone)===p;
   return sameName || samePhone;
 })||null;
}
function saveCustomer(name,phone,openingBalance=0){
 name=String(name||"").trim(); phone=normalizePhone(phone);
 if(!name||!isValidMobile(phone))return false;
 const existing=state.customers.find(c=>normalizePhone(c.phone)===phone || String(c.name||"").trim().toLowerCase()===name.toLowerCase());
 if(existing){existing.name=name;existing.phone=phone;if(openingBalance!==undefined)existing.openingBalance=Number(openingBalance||0);}
 else state.customers.unshift({name,phone,openingBalance:Number(openingBalance||0)});
 state.customers=state.customers.slice(0,500);save();renderCustomerDatalist();renderCustomers();
 return true;
}
function findCustomer(name){return state.customers.find(c=>c.name.toLowerCase()===String(name||"").trim().toLowerCase())||null}
function renderCustomerDatalist(){
 let dl=document.getElementById("customerNames");if(!dl){dl=document.createElement("datalist");dl.id="customerNames";document.body.appendChild(dl)}
 dl.innerHTML="";state.customers.forEach(c=>{const o=document.createElement("option");o.value=c.name;o.label=c.phone||"";dl.appendChild(o)});
}
async function drawBillImage(b){
 const logo=new Image(); logo.src=logoSource();
 try{await new Promise((resolve,reject)=>{logo.onload=resolve;logo.onerror=reject})}catch(e){}
 const scale=2,w=900,pad=45,rowH=54,headH=70;
 const h=430+headH+b.items.length*rowH;
 const c=document.createElement("canvas");c.width=w*scale;c.height=h*scale;const x=c.getContext("2d");x.scale(scale,scale);
 x.fillStyle="#fff";x.fillRect(0,0,w,h);
 x.textAlign="center";
 let hy=20;
 if(logo.complete&&logo.naturalWidth){x.drawImage(logo,(w-85)/2,hy,85,85);hy+=100;}
 x.fillStyle="#24466f";x.font="bold 34px sans-serif";x.fillText(state.settings.shopName||"DUKAAN BILL",w/2,hy);
 hy+=30;
 x.font="18px sans-serif";
 const address=String(state.settings.address||"");
 if(address){address.split(/\n+/).forEach(line=>{x.fillText(line,w/2,hy);hy+=22;});}
 if(state.settings.tagline){hy+=10;x.font="bold 16px sans-serif";x.fillText(state.settings.tagline,w/2,hy);hy+=22;}
 if(state.settings.shopMobile){hy+=5;x.font="17px sans-serif";x.fillText("Mo: "+state.settings.shopMobile,w/2,hy);hy+=22;}
 x.font="bold 22px sans-serif";x.fillText(state.settings.billTitle||"CASH MEMO / BILL",w/2,hy);
 x.textAlign="left";x.fillStyle="#111";x.font="18px sans-serif";x.fillText("Bill No: "+b.billNo,45,150);x.fillText("Date: "+b.date.split("-").reverse().join("/"),560,150);x.fillText("Customer: "+(b.customer||"Cash Sale"),45,180);x.fillText("Payment Mode: "+(b.paymentMode||"Cash"),560,180);
 const top=hy+32;const cols=[45,105,420,540,690,855];x.strokeStyle="#aaa";x.lineWidth=1;x.strokeRect(45,top,w-90,headH+b.items.length*rowH+70);
 x.fillStyle="#24466f";x.fillRect(46,top+1,w-92,headH-1);x.fillStyle="#fff";x.font="bold 16px sans-serif";["Sr.","Item Description","Qty","Unit","Rate/Unit","Amount"].forEach((t,i)=>x.fillText(t,cols[i]+8,top+42));
 x.fillStyle="#111";x.font="16px sans-serif";
 b.items.forEach((it,i)=>{const y=top+headH+i*rowH+34;const amt=quantityValue(it.qty,it.unit||"piece")*it.rate;x.fillText(String(i+1),cols[0]+8,y);x.fillText(it.name,cols[1]+8,y);x.fillText(it.qty,cols[2]+8,y);x.fillText(it.unit||"piece",cols[3]+8,y);x.fillText(Number(it.rate).toFixed(2),cols[4]+8,y);x.fillText(amt.toFixed(2),cols[5]+8,y);x.strokeStyle="#ddd";x.beginPath();x.moveTo(46,y+20);x.lineTo(w-46,y+20);x.stroke()});
 const subtotal=Number(b.subtotal??b.items.reduce((s,it)=>s+quantityValue(it.qty,it.unit||"kg")*Number(it.rate||0),0));const discount=Number(b.discount||0);const ty=top+headH+b.items.length*rowH+50;x.font="17px sans-serif";x.fillText("Subtotal: "+money(subtotal),45,ty);if(discount>0){x.fillText("Discount: -"+money(discount),45,ty+30);}x.font="bold 22px sans-serif";x.fillText("Total Amount: "+money(b.total),45,ty+(discount>0?65:35));x.font="17px sans-serif";x.fillText("Thank you for shopping with us!",45,ty+103);x.font="14px sans-serif";x.fillText("Goods once sold will not be taken back.",45,ty+129);x.font="12px sans-serif";x.fillText(state.settings.creditFooter||"Bill created by DukaanBill • Contact 8087794271 for more details",45,ty+151);
 return c.toDataURL("image/png").split(",")[1];
}
function calculateBillTax(b){
 if(!b?.taxationEnabled) return {taxable:0,tax:0,groups:[],cgst:0,sgst:0,igst:0};
 const subtotal=Number(b.subtotal??(b.items||[]).reduce((s,x)=>s+quantityValue(x.qty,x.unit||"kg")*Number(x.rate||0),0));
 const discount=Math.max(0,Number(b.discount||0));
 const groups={};let taxable=0,tax=0;
 (b.items||[]).forEach(x=>{const gross=quantityValue(x.qty,x.unit||"kg")*Number(x.rate||0);const net=subtotal>0?gross*(subtotal-discount)/subtotal:gross;const rate=Number(x.taxRate||0);const base=rate>0?net/(1+rate/100):net;const tx=rate>0?net-base:0;taxable+=base;tax+=tx;const k=String(rate);if(!groups[k])groups[k]={rate, taxable:0,tax:0};groups[k].taxable+=base;groups[k].tax+=tx;});
 const businessState=String(b.businessState||state.settings.businessState||"");
 const inter=businessState && b.placeOfSupply && businessState.toLowerCase()!==String(b.placeOfSupply).toLowerCase();
 const cgst=inter?0:tax/2,sgst=inter?0:tax/2,igst=inter?tax:0;
 return {taxable,tax,groups:Object.values(groups).sort((a,b)=>a.rate-b.rate),cgst,sgst,igst,inter};
}

function renderBill(b){
 window.currentBill=b;
 const date=b.date.split("-").reverse().join("/");
 const subtotal=Number(b.subtotal ?? (b.items||[]).reduce((s,x)=>s+quantityValue(x.qty,x.unit||"kg")*Number(x.rate||0),0));
 const discount=Number(b.discount||0);
 const total=Number(b.total ?? Math.max(0,subtotal-discount));
 const tax=calculateBillTax(b);
 const taxEnabled=billTaxEnabled(b);
 const title=taxEnabled?"TAX INVOICE":(state.settings.billTitle||"CASH MEMO / BILL");
 const taxHead=taxEnabled?`<div><b>GSTIN:</b> ${esc(b.gstin||state.settings.gstin||"Not specified")}</div><div><b>Place of Supply:</b> ${esc(b.placeOfSupply||state.settings.businessState||"Not specified")}</div>`:"";
 const rows=(b.items||[]).map((x,i)=>{const amt=quantityValue(x.qty,x.unit||"kg")*Number(x.rate||0);return `<tr><td>${i+1}</td><td>${esc(x.name)}${x.hsn?`<div class="muted">HSN: ${esc(x.hsn)}</div>`:""}</td><td>${esc(x.qty)} ${esc(x.unit||"")}</td><td>${Number(x.rate||0).toFixed(2)}</td>${taxEnabled?`<td>${Number(x.taxRate||0)}%</td>`:""}<td>${amt.toFixed(2)}</td></tr>`;}).join("");
 const taxRows=tax.groups.map(g=>`<tr><td colspan="4">GST ${g.rate}% Taxable Value:</td><td>${money(g.taxable)}</td></tr>`).join("");
 const taxSummary=taxEnabled?`<div class="tax-summary"><table><thead><tr><th>Tax Rate</th><th>Taxable</th><th>CGST</th><th>SGST</th><th>IGST</th></tr></thead><tbody>${tax.groups.map(g=>`<tr><td>${g.rate}%</td><td>${money(g.taxable)}</td><td>${tax.inter?"—":money(g.tax/2)}</td><td>${tax.inter?"—":money(g.tax/2)}</td><td>${tax.inter?money(g.tax):"—"}</td></tr>`).join("")}<tr><td><b>Total GST</b></td><td>${money(tax.taxable)}</td><td>${tax.inter?"—":money(tax.cgst)}</td><td>${tax.inter?"—":money(tax.sgst)}</td><td>${tax.inter?money(tax.igst):"—"}</td></tr></tbody></table></div>`:"";
 $("billPreview").innerHTML=`<div class="bill-logo-wrap"><img src="${esc(logoSource())}" class="bill-logo" alt="Shop logo"></div><h1>${esc(state.settings.shopName)}</h1>${state.settings.tagline?`<div class="bill-tagline">${esc(state.settings.tagline)}</div>`:""}<div class="location">${esc(state.settings.address)}</div>${shopMobileText()?`<div class="bill-mobile">Mo: ${esc(shopMobileText())}</div>`:""}<div class="pill">${esc(title)}</div><hr><div class="meta"><div><b>Invoice:</b> ${esc(b.billNo)}</div><div><b>Dt:</b> ${date}</div>${state.settings.showCustomer?`<div><b>Customer:</b> ${esc(b.customer||"Walk-in Customer")}</div>`:""}${b.customerPhone?`<div><b>Mo:</b> ${esc(b.customerPhone)}</div>`:""}${b.customerGstin?`<div><b>Customer GSTIN:</b> ${esc(b.customerGstin)}</div>`:""}${taxHead}<div><b>Pay:</b> ${esc(b.paymentMode||"Cash")}</div></div><table><thead><tr><th>Sr.</th><th>Item Description</th><th>Qty</th><th>Rate / Unit (₹)</th>${taxEnabled?"<th>Tax</th>":""}<th>Amount (₹)</th></tr></thead><tbody>${rows}</tbody><tfoot><tr><td colspan="${taxEnabled?5:4}">Subtotal:</td><td>${money(subtotal)}</td></tr>${discount>0?`<tr><td colspan="${taxEnabled?5:4}">Discount:</td><td>-${money(discount)}</td></tr>`:""}${taxEnabled?`<tr><td colspan="5">Taxable Value:</td><td>${money(tax.taxable)}</td></tr><tr><td colspan="5">Total GST:</td><td>${money(tax.tax)}</td></tr>`:""}<tr><td colspan="${taxEnabled?5:4}"><b>Total Amount:</b></td><td><b>${money(total)}</b></td></tr></tfoot></table>${taxSummary}<div class="thanks">${esc(state.settings.footer)}</div><div class="muted">Goods once sold will not be taken back.</div><div class="sign">${state.settings.signature?`${esc(state.settings.signature)}<br><span>(Authorized Signatory)</span>`:""}</div><div class="credit">${esc(state.settings.creditFooter||"Bill created by DukaanBill • Contact 8087794271 for more details")}</div>`;
 const eb=document.createElement("button"); eb.type="button"; eb.className="secondary bill-edit-button"; eb.textContent="✏️ Edit Bill"; eb.onclick=()=>loadBillForEdit(b); const ea=document.createElement("div"); ea.className="bill-edit-inline"; ea.appendChild(eb); $("billPreview").prepend(ea);
}

$("printBtn").onclick=()=>openPrintCustomerModal(window.currentBill);
$("pdfBtn").onclick=()=>{window.__downloadOnly=true;openPrintCustomerModal(window.currentBill,true);};
function openPrintCustomerModal(b,downloadOnly=false){
 if(!b)return;
 const saved=findCustomer(b.customer);
 $("printCustomerName").value=(b.customer&&b.customer!=="Walk-in Customer")?b.customer:"";
 $("printCustomerPhone").value=b.customerPhone||((saved&&saved.phone)?String(saved.phone):"");
 $("printCustomerModal").classList.remove("hidden");
}
$("printCustomerCancel").onclick=()=>{window.__downloadOnly=false;$("printCustomerModal").classList.add("hidden");};
let pendingCustomerSave=null;
function continueBillAfterCustomerSave(){
 const payload=JSON.stringify(Object.assign({},window.currentBill,{settings:state.settings}));
 $("printCustomerModal").classList.add("hidden");
 if(window.__downloadOnly){ window.__downloadOnly=false; if(window.Android?.openBillPdf)Android.openBillPdf(payload); else window.print(); }
 else if(window.Android?.printBill) Android.printBill(payload); else window.print();
}
function handleCustomerConflict(name,phone,onDecision,extra={}){
 const existing=findCustomerByNameOrPhone(name,phone);
 if(!existing){ onDecision("none",null); return; }
 if(String(existing.name||"").trim().toLowerCase()===name.trim().toLowerCase() && normalizePhone(existing.phone)===phone){ onDecision("same",existing); return; }
 pendingCustomerSave={name,phone,existing,onDecision,extra};
 $("customerConflictText").textContent=`A customer already exists with ${String(existing.name||"")} ${existing.phone?"(Mobile: "+existing.phone+")":""}. You entered ${name}${phone?" (Mobile: "+phone+")":""}.`;
 $("customerConflictModal").classList.remove("hidden");
}
$("customerConflictCancel").onclick=()=>{pendingCustomerSave=null;$("customerConflictModal").classList.add("hidden");};
$("customerConflictUpdate").onclick=()=>{const p=pendingCustomerSave;if(!p)return;p.existing.name=p.name;p.existing.phone=p.phone;Object.assign(p.existing,p.extra||{});save();pendingCustomerSave=null;$("customerConflictModal").classList.add("hidden");p.onDecision("update",p.existing);};
$("customerConflictCreate").onclick=()=>{const p=pendingCustomerSave;if(!p)return;state.customers.unshift({name:p.name,phone:p.phone,openingBalance:0,...(p.extra||{})});state.customers=state.customers.slice(0,500);save();renderCustomerDatalist();renderCustomers();pendingCustomerSave=null;$("customerConflictModal").classList.add("hidden");p.onDecision("create",null);};
$("printCustomerContinue").onclick=()=>{
 const name=$("printCustomerName").value.trim()||"Walk-in Customer";
 let phoneRaw=$("printCustomerPhone").value.trim();
 let phone=phoneRaw?normalizePhone(phoneRaw):"";
 const exact=findCustomer(name);
 if(!phone && exact) phone=normalizePhone(exact.phone??exact.mobile??exact.mobileNumber??exact.phoneNumber??"");
 if(phoneRaw && !isValidMobile(phone)){alert("Enter a valid 10 digit mobile number or leave it blank.");return}
 window.currentBill.customer=name;
 window.currentBill.customerPhone=phone;
 const pc=findCustomer(name);window.currentBill.customerGstin=pc?String(pc.gstin||"").trim().toUpperCase():"";
 $("printCustomerPhone").value=phone;
 if($('customer')) { $('customer').value=name; $('customer').dataset.phone=phone; }
 const finish=()=>{save();renderBill(window.currentBill);continueBillAfterCustomerSave();};
 if(name!=="Walk-in Customer" && phone){
   handleCustomerConflict(name,phone,()=>finish());
 } else finish();
};

function renderPrintCustomerSuggestions(){
 const box=$("printCustomerSuggestions"),input=$("printCustomerName"); if(!box||!input)return;
 const q=String(input.value||"").trim().toLowerCase();
 const matches=state.customers.filter(c=>{const name=String(c.name??c.customerName??"");const phone=normalizePhone(c.phone??c.mobile??c.mobileNumber??c.phoneNumber??"");const notes=String(c.notes??c.note??c.additionalDetails??"");const nq=normalizePhone(q);return !q||name.toLowerCase().includes(q)||phone.includes(nq)||notes.toLowerCase().includes(q);}).slice(0,20);
 if(!matches.length){box.classList.add("hidden");box.innerHTML="";return;}
 box.innerHTML=matches.map(c=>`<div class="customer-suggestion" data-name="${esc(c.name)}" data-phone="${esc(c.phone||c.mobile||c.mobileNumber||"")}"><b>${esc(c.name)}</b>${(c.phone||c.mobile||c.mobileNumber)?`<div class="muted">${esc(c.phone||c.mobile||c.mobileNumber)}</div>`:""}</div>`).join("");
 box.classList.remove("hidden");
 box.querySelectorAll(".customer-suggestion").forEach(el=>{
   const choose=e=>{e?.preventDefault?.();e?.stopPropagation?.();$("printCustomerName").value=el.dataset.name||"";$("printCustomerPhone").value=normalizePhone(el.dataset.phone||"");box.classList.add("hidden");box.innerHTML="";};
   el.addEventListener("pointerdown",choose,{passive:false});
   el.addEventListener("click",choose);
 });
}
$("printCustomerName")?.addEventListener("input",renderPrintCustomerSuggestions);
$("printCustomerName")?.addEventListener("keyup",renderPrintCustomerSuggestions);
$("printCustomerName")?.addEventListener("focus",renderPrintCustomerSuggestions);
$("printCustomerPhone")?.addEventListener("input",e=>{e.target.value=normalizePhone(e.target.value).slice(0,10);});
document.addEventListener("click",e=>{if(!e.target.closest("#printCustomerModal .customer-search-wrap"))$("printCustomerSuggestions")?.classList.add("hidden")});
$("printWhatsApp")?.addEventListener("click",()=>{
 const phone=normalizePhone($("printCustomerPhone")?.value||"");
 if(!isValidMobile(phone)){showNotice("Select an existing customer or enter a valid 10 digit mobile number first.","WhatsApp");return;}
 const name=$("printCustomerName")?.value.trim()||"Walk-in Customer";
 window.currentBill.customer=name;window.currentBill.customerPhone=phone;
 const payload=JSON.stringify(Object.assign({},window.currentBill,{settings:state.settings}));
 if(window.Android?.shareBillPdfToWhatsApp) Android.shareBillPdfToWhatsApp(payload,phone); else showNotice("WhatsApp direct sharing is available in the Android APK.","WhatsApp");
});

$("backToBilling").onclick=()=>showPage("billing");
// ---------------- Purchasing / Vendor Accounts ----------------
function purchaseId(prefix="PUR"){return prefix+"-"+Date.now()+"-"+Math.random().toString(36).slice(2,7).toUpperCase()}
function renderVendorsSelects(){
 const pv=$("purchaseVendor"), pay=$("paymentVendor");
 if(pv){pv.innerHTML='<option value="">Select vendor</option>'+state.vendors.map(v=>`<option value="${esc(v.id)}">${esc(v.name)}</option>`).join("")}
 if(pay){pay.innerHTML='<option value="">Select vendor</option>'+state.vendors.map(v=>`<option value="${esc(v.id)}">${esc(v.name)}</option>`).join("")}
}
function vendorById(id){return state.vendors.find(v=>v.id===id)||null}
function vendorBalance(v){
 const purchases=state.purchases.filter(p=>p.vendorId===v.id).reduce((s,p)=>s+Number(p.total||0),0);
 const paid=state.vendorPayments.filter(p=>p.vendorId===v.id).reduce((s,p)=>s+Number(p.amount||0),0);
 return {purchases,paid,pending:Number(v.openingBalance||0)+purchases-paid};
}
function renderPurchasing(){
 renderVendorsSelects();
 const total=state.purchases.reduce((s,p)=>s+Number(p.total||0),0);
 const paid=state.purchases.reduce((s,p)=>s+Number(p.paid||0),0)+state.vendorPayments.reduce((s,p)=>s+Number(p.amount||0),0);
 const pending=state.vendors.reduce((s,v)=>s+vendorBalance(v).pending,0);
 $("purchaseTotal").textContent=money(total);
 $("purchasePaid").textContent=money(paid);
 $("purchasePending").textContent=money(pending);
 const va=$("vendorAccounts");va.innerHTML="";
 if(!state.vendors.length)va.innerHTML='<div class="muted">No vendors added yet.</div>';
 state.vendors.forEach(v=>{
   const b=vendorBalance(v);
   const r=document.createElement("div");r.className="vendor-account";
   r.innerHTML=`<div class="vendor-account-head"><div><div class="history-title">${esc(v.name)}</div><div class="muted">${esc(v.phone||"")} ${v.gstin?"• "+esc(v.gstin):""}</div></div><button class="secondary pay">Pay</button></div>
   <div class="purchase-summary">
     <div class="sales-box"><span>Purchases</span><strong>${money(b.purchases)}</strong></div>
     <div class="sales-box"><span>Paid</span><strong class="paid">${money(b.paid)}</strong></div>
     <div class="sales-box"><span>Pending</span><strong class="${b.pending>0?"payable":"paid"}">${money(b.pending)}</strong></div>
   </div>`;
   r.querySelector(".pay").onclick=()=>{ $("paymentVendor").value=v.id; $("paymentDate").value=today(); $("paymentModal").classList.remove("hidden"); };
   va.appendChild(r);
 });
 const vp=$("vendorPayments");vp.innerHTML="";
 const payments=[...state.vendorPayments].sort((a,b)=>String(b.date).localeCompare(String(a.date)));
 if(!payments.length)vp.innerHTML='<div class="muted">No vendor payments recorded.</div>';
 payments.slice(0,50).forEach(p=>{const v=vendorById(p.vendorId);const r=document.createElement("div");r.className="history-row";r.innerHTML=`<div><div class="history-title">${esc(v?.name||"Unknown Vendor")} • ${money(p.amount)}</div><div class="muted">${esc(p.date)} • ${esc(p.mode||"")} ${p.note?"• "+esc(p.note):""}</div></div>`;vp.appendChild(r)});
 const q=String($("purchaseSearch")?.value||"").toLowerCase();
 const ph=$("purchaseHistory");ph.innerHTML="";
 const list=state.purchases.filter(p=>JSON.stringify(p).toLowerCase().includes(q)).sort((a,b)=>String(b.date).localeCompare(String(a.date)));
 if(!list.length)ph.innerHTML='<div class="muted">No purchase bills found.</div>';
 list.forEach(p=>{const v=vendorById(p.vendorId);const r=document.createElement("div");r.className="history-row";r.innerHTML=`<div><div class="history-title">${esc(v?.name||p.vendorName||"Vendor")} • ${esc(p.invoiceNo||"No invoice")}</div><div class="muted">${esc(p.date)} • Total ${money(p.total)} • Paid ${money(p.paid)} • Pending ${money(Number(p.total)-Number(p.paid))}</div></div><button class="secondary viewPurchase">View</button>`;r.querySelector(".viewPurchase").onclick=()=>showPurchaseDetail(p);ph.appendChild(r)});
}
function showPurchaseDetail(p){
 const v=vendorById(p.vendorId);
 let lines=(p.items||[]).map((x,i)=>`${i+1}. ${x.name} — ${x.qty} ${x.unit||""} × ₹${Number(x.rate||0).toFixed(2)}`).join("\n");
 alert(`Vendor: ${v?.name||p.vendorName}\nInvoice: ${p.invoiceNo||"-"}\nDate: ${p.date}\n\n${lines||"No item details extracted."}\n\nTotal: ${money(p.total)}\nPaid: ${money(p.paid)}\nPending: ${money(Number(p.total)-Number(p.paid))}\n${p.attachment?.name?"Attachment: "+p.attachment.name:""}`);
 if(p.attachment?.id && window.Android?.openPurchaseAttachment) window.Android.openPurchaseAttachment(p.attachment.id,p.attachment.mime||"application/pdf");
}
function parsePurchaseText(text){
 const raw=String(text||"").replace(/\r/g,"");
 const clean=raw.replace(/[ \t]+/g," ").replace(/\n{3,}/g,"\n");
 const lines=clean.split("\n").map(s=>s.trim()).filter(Boolean);

 const invoiceNo=(clean.match(/(?:Invoice\s*(?:No|Number)|Inv\.?\s*No\.?)\s*[:#-]?\s*([A-Z0-9][A-Z0-9\/-]+)/i)||[])[1]||"";
 const date=(clean.match(/(?:Invoice\s*Date|Dated|Date)\s*[:\-]?\s*(\d{1,2}[\/-][A-Za-z]{3,9}[\/-]\d{2,4}|\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4})/i)||[])[1]||"";

 let total=0;
 const totalPatterns=[
   /Collectable\s+Amount[\s\S]{0,300}?\b(\d{4,7}\.\d{2})\b\s*$/im,
   /(?:Grand\s+Total|Invoice\s+Total|Total\s+Amount)\s*[:\-]?\s*₹?\s*([0-9,]+\.\d{2})/i
 ];
 for(const re of totalPatterns){const m=clean.match(re);if(m){total=Number(m[1].replace(/,/g,""));if(total)break;}}

 let vendorName="";
 const idx=lines.findIndex(x=>/tax invoice/i.test(x));
 if(idx>=0){
   for(let j=idx+1;j<Math.min(idx+8,lines.length);j++){
     const candidate=lines[j].replace(/\s*\(\d+\)\s*$/," ").trim();
     if(/private limited|limited|traders|distributors|agency|enterprises/i.test(candidate)){vendorName=candidate;break;}
   }
 }
 if(!vendorName){
   vendorName=lines.find(x=>/private limited|limited|traders|distributors|agency|enterprises/i.test(x))||"";
 }

 const gstin=(clean.match(/GSTIN\s*\/??\s*UIN\s*[: ]\s*([0-9A-Z]{15})/i)||[])[1]||
             (clean.match(/GSTIN\s*[: ]\s*([0-9A-Z]{15})/i)||[])[1]||"";
 const phone=(clean.match(/(?:Phone|Telephone)\s*[: ]\s*(\d{10})/i)||[])[1]||"";
 const buyerLine=lines.findIndex(x=>/^Buyer \(Billing Address\)/i.test(x));
 const buyer=buyerLine>=0&&lines[buyerLine+1]?lines[buyerLine+1]:"";

 const items=[];
 // Vendor invoice pattern: ITEM CODE - DESCRIPTION, followed by a row containing HSN, MRP, QTY, RATE.
 const codeRe=/(\d{5,8})\s*[-–]\s*([^\n]+)/g;
 const matches=[...raw.matchAll(codeRe)];
 for(let i=0;i<matches.length;i++){
   const code=matches[i][1];
   let block=matches[i][2]||"";
   const start=matches[i].index+matches[i][0].length;
   const end=i+1<matches.length?matches[i+1].index:Math.min(raw.length,start+1000);
   block+=(raw.slice(start,end));
   block=block.replace(/\n+/g," ").replace(/\s+/g," ").trim();

   // Don't treat GST summary or other numeric sections as items.
   if(!/\b(?:340|380|330|210|190)\d{5}\b/.test(block) && !/\b\d{8}\b/.test(block)) continue;

   const qtyMatch=block.match(/\b(\d+(?:\.\d+)?)\s*(EA|CA|PK|UN|PCS?|BOX|BOTTLE)\b/i);
   if(!qtyMatch) continue;
   const qty=qtyMatch[1];
   const unit="piece";
   const after=block.slice(qtyMatch.index+qtyMatch[0].length);
   const rateMatch=after.match(/\b(\d+(?:\.\d{1,2})?)\b/);
   const rate=rateMatch?Number(rateMatch[1]):0;

   let name=(matches[i][2]||"").trim();
   name=name.replace(/\s+/g," ").replace(/\s+$/g,"");
   if(name && rate) items.push({name,itemCode:code,qty,unit,rate});
 }

 // Remove duplicates caused by OCR/table header artifacts.
 const seen=new Set();
 const uniqueItems=items.filter(x=>{const k=x.itemCode+"|"+x.name;if(seen.has(k))return false;seen.add(k);return true;});
 return {vendorName,invoiceNo,date,total,buyer,gstin,phone,items:uniqueItems,rawText:raw,rawLength:raw.trim().length};
}
function applyPurchaseImport(data){
 const p=parsePurchaseText(data.text||"");
 const rawCount=Number(p.rawLength||String(data.text||"").trim().length||0);
 // Render first so the vendor list is populated, then apply extracted values.
 renderPurchasing();
 if(p.vendorName){
   let v=state.vendors.find(x=>String(x.name||"").toLowerCase()===p.vendorName.toLowerCase());
   if(!v){v={id:purchaseId("VEN"),name:p.vendorName,phone:p.phone||"",gstin:p.gstin||"",address:"",openingBalance:0};state.vendors.push(v);}
   else { if(p.phone&&!v.phone)v.phone=p.phone; if(p.gstin&&!v.gstin)v.gstin=p.gstin; }
   renderVendorsSelects();
   $("purchaseVendor").value=v.id;
 }
 $("purchaseInvoice").value=p.invoiceNo||"";
 const d=toInputDate(p.date);if(d)$("purchaseDate").value=d;
 $("purchaseTotalInput").value=p.total||"";
 $("purchasePaidInput").value="0";updatePurchasePending();
 $("purchaseItemsText").value=(p.items||[]).map(x=>`${x.name} ${x.qty} ${x.unit||"piece"} ${x.rate||""}`.trim()).join("\n");
 state.purchaseAttachment={id:data.attachmentId,name:data.fileName,mime:data.mime};
 $("purchaseAttachmentBox").innerHTML=`Attached: <b>${esc(data.fileName)}</b> • OCR finished. ${p.items?.length||0} item(s) extracted from ${rawCount} OCR characters.`;
 $("purchaseImportStatus").textContent=p.error?`Import completed with a warning: ${esc(p.error)}`:"Bill imported successfully. Please review the extracted fields before saving.";
 save();
}
window.onPurchaseImportProgress=function(message){
 const el=$("purchaseImportStatus"); if(el) el.textContent=String(message||"Reading vendor bill...");
};
window.onPurchaseImportError=function(message){
 const el=$("purchaseImportStatus"); if(el) el.textContent="Could not read the vendor bill: "+String(message||"Unknown error");
 alert("Purchase bill import failed.\n\n"+String(message||"Please try another PDF/photo."));
};
window.onPurchaseImportResultBase64=function(encoded){
 try{
   const bin=atob(encoded); let s=""; for(let i=0;i<bin.length;i++)s+=String.fromCharCode(bin.charCodeAt(i));
   const json=decodeURIComponent(Array.prototype.map.call(s,c=>"%"+("00"+c.charCodeAt(0).toString(16)).slice(-2)).join(""));
   applyPurchaseImport(JSON.parse(json));
 }catch(e){ window.onPurchaseImportError(e.message); }
};
function toInputDate(s){
 if(!s)return "";
 const m=String(s).match(/(\d{1,2})[\/-]([A-Za-z]{3}|\d{1,2})[\/-](\d{2,4})/);
 if(!m)return "";
 let mon=isNaN(Number(m[2]))?({jan:1,feb:2,mar:3,apr:4,may:5,jun:6,jul:7,aug:8,sep:9,oct:10,nov:11,dec:12}[m[2].slice(0,3).toLowerCase()]||0):Number(m[2]);
 let y=Number(m[3]);if(y<100)y+=2000;
 return mon?`${y}-${String(mon).padStart(2,"0")}-${String(m[1]).padStart(2,"0")}`:"";
}
function updatePurchasePending(){const t=Number($("purchaseTotalInput").value||0),p=Number($("purchasePaidInput").value||0);$("purchasePendingInput").value=Math.max(0,t-p).toFixed(2)}
function savePurchase(){
 const vendorId=$("purchaseVendor").value, vendor=vendorById(vendorId);
 if(!vendor){alert("Select a vendor.");return}
 const total=Number($("purchaseTotalInput").value||0),paid=Number($("purchasePaidInput").value||0);
 if(total<=0){alert("Enter purchase total.");return}
 const items=[];
 String($("purchaseItemsText").value||"").split(/\r?\n/).map(x=>x.trim()).filter(Boolean).forEach(line=>{const p=parseQuickListLine(line);if(p&&!p.error)items.push(p)});
 const rec={id:purchaseId(),vendorId,vendorName:vendor.name,invoiceNo:$("purchaseInvoice").value.trim(),date:$("purchaseDate").value||today(),total,paid:Math.min(paid,total),pending:Math.max(0,total-paid),items,notes:$("purchaseNotes").value.trim(),attachment:state.purchaseAttachment||null};
 state.purchases.unshift(rec);state.purchaseAttachment=null;save();
 $("purchaseInvoice").value="";$("purchaseTotalInput").value="";$("purchasePaidInput").value="";$("purchasePendingInput").value="";$("purchaseItemsText").value="";$("purchaseNotes").value="";$("purchaseAttachmentBox").textContent="";
 $("purchaseImportStatus").textContent="Purchase saved.";
 renderPurchasing();
}
function openVendorModal(){ $("vendorName").value="";$("vendorPhone").value="";$("vendorGstin").value="";$("vendorAddress").value="";$("vendorModal").classList.remove("hidden")}
function saveVendor(){
 const name=$("vendorName").value.trim();if(!name){alert("Enter vendor name.");return}
 state.vendors.unshift({id:purchaseId("VEN"),name,phone:$("vendorPhone").value.trim(),gstin:$("vendorGstin").value.trim(),address:$("vendorAddress").value.trim(),openingBalance:0});
 save();$("vendorModal").classList.add("hidden");renderPurchasing();
}
function savePayment(){
 const vendorId=$("paymentVendor").value,amount=Number($("paymentAmount").value||0);
 if(!vendorId||amount<=0){alert("Select vendor and enter amount.");return}
 state.vendorPayments.unshift({id:purchaseId("PAY"),vendorId,date:$("paymentDate").value||today(),amount,mode:$("vendorPaymentMode").value,note:$("paymentNote").value.trim()});
 save();$("paymentModal").classList.add("hidden");$("paymentAmount").value="";$("paymentNote").value="";renderPurchasing();
}
$("purchaseImportBtn").onclick=()=>{if(window.Android?.pickPurchaseDocument)Android.pickPurchaseDocument();else alert("Purchase document import is available in the Android APK.");};
$("purchaseSampleBtn").onclick=async()=>{try{const r=await fetch("sample_vendor_invoice.pdf");const blob=await r.blob();if(window.Android?.pickPurchaseDocument)alert("For the sample, please use Upload Bill / PDF and select the supplied sample invoice from your phone.");else alert("Open the sample invoice with Upload Bill / PDF.")}catch(e){alert("Use Upload Bill / PDF to import the sample invoice.")}};
$("savePurchaseBtn").onclick=savePurchase;
$("purchaseTotalInput").oninput=updatePurchasePending;$("purchasePaidInput").oninput=updatePurchasePending;
$("addVendorBtn").onclick=openVendorModal;$("vendorCancel").onclick=()=>$("vendorModal").classList.add("hidden");$("vendorSave").onclick=saveVendor;
$("addPaymentBtn").onclick=()=>{$("paymentDate").value=today();$("paymentModal").classList.remove("hidden")};$("paymentCancel").onclick=()=>$("paymentModal").classList.add("hidden");$("paymentSave").onclick=savePayment;
$("vendorRefreshBtn").onclick=renderPurchasing;$("purchaseSearch").oninput=renderPurchasing;
$("purchaseDate").value=today();
let productPage=1, productPageSize=20, productQuery="";
function renderProducts(){
 const list=$("productList"); if(!list)return;
 const q=String(productQuery||"").trim().toLowerCase();
 const all=state.products.filter(p=>{const name=String(p.name??p.productName??p.itemName??"");const unit=String(p.unit??p.unitName??p.uom??"");const rate=String(p.rate??p.price??p.sellingPrice??"");const hay=[name,unit,rate].join(" ").toLowerCase();return !q||hay.includes(q);});
 const pages=Math.max(1,Math.ceil(all.length/productPageSize)); productPage=Math.min(Math.max(1,productPage),pages);
 const slice=all.slice((productPage-1)*productPageSize,productPage*productPageSize);
 list.innerHTML="";
 if(!all.length){list.innerHTML='<div class="muted">No products found.</div>';}
 slice.forEach(p=>{
   const i=state.products.indexOf(p); const r=document.createElement("div"); r.className="product-row";
   r.innerHTML=`<div><div class="product-name">${esc(p.name)}</div><div class="muted">${money(p.rate)} / ${esc(p.unit||"kg")} ${state.settings.taxationEnabled?`• GST ${Number(p.taxRate||0)}%`:""}${p.hsn?` • HSN ${esc(p.hsn)}`:""}</div></div><div><button type="button" class="secondary edit">Edit</button> <button type="button" class="danger del">Delete</button></div>`;
   r.querySelector(".edit").onclick=()=>openProduct(i);
   r.querySelector(".del").onclick=()=>showConfirm("Delete "+p.name+" from the product master?",()=>{state.products.splice(i,1);save();renderProducts();renderDatalist();},"Delete Product");
   list.appendChild(r);
 });
 const pager=$("productPagination"); if(pager){pager.innerHTML=`<button type="button" class="secondary" ${productPage<=1?"disabled":""}>‹ Previous</button><span>Page ${productPage} of ${pages} • ${all.length} products</span><button type="button" class="secondary" ${productPage>=pages?"disabled":""}>Next ›</button>`;const bs=pager.querySelectorAll("button");bs[0].onclick=()=>{if(productPage>1){productPage--;renderProducts()}};bs[1].onclick=()=>{if(productPage<pages){productPage++;renderProducts()}};}
}
function openProduct(i){editingProduct=i;$("modalTitle").textContent=i<0?"Add Product":"Edit Product";$("modalName").value=i<0?"":state.products[i].name;$("modalRate").value=i<0?"":state.products[i].rate;$("modalUnit").value=i<0?"kg":(state.products[i].unit||"kg");$("modalHsn").value=i<0?"":(state.products[i].hsn||"");$("modalTax").value=i<0?"0":String(state.products[i].taxRate??0);$("modal").classList.remove("hidden");setTimeout(()=>$("modalName")?.focus(),50);}
$("addProductBtn")?.addEventListener("click",()=>openProduct(-1));
function handleProductPageSearch(e){productQuery=String(e.target.value||"");productPage=1;renderProducts();}
$("productPageSearch")?.addEventListener("input",handleProductPageSearch);
$("productPageSearch")?.addEventListener("keyup",handleProductPageSearch);
$("productPageSearch")?.addEventListener("change",handleProductPageSearch);
$("modalCancel").onclick=()=>$("modal").classList.add("hidden");$("modalSave").onclick=()=>{const name=$("modalName").value.trim(),rate=+$("modalRate").value;if(!name||!Number.isFinite(rate)||rate<0){showNotice("Enter a product name and a valid rate.","Product");return}const unit=$("modalUnit").value||"kg";const hsn=$("modalHsn").value.trim();const taxRate=Math.max(0,Number($("modalTax").value)||0);const duplicate=state.products.find((p,i)=>i!==editingProduct&&String(p.name||"").trim().toLowerCase()===name.toLowerCase());if(duplicate){showNotice("A product with this name already exists.","Product");return}if(editingProduct<0)state.products.unshift({name,rate,unit,hsn,taxRate});else state.products[editingProduct]={...state.products[editingProduct],name,rate,unit,hsn,taxRate};save();$("modal").classList.add("hidden");renderProducts();renderDatalist();};
function renderDatalist(){let dl=document.getElementById("productNames");if(dl)dl.remove();dl=document.createElement("datalist");dl.id="productNames";state.products.forEach(p=>{let o=document.createElement("option");o.value=p.name;dl.appendChild(o)});document.body.appendChild(dl)}
renderDatalist();renderCustomerDatalist();renderCustomUnits();refreshUnitControls();document.body.classList.toggle("taxation-on",!!state.settings.taxationEnabled);document.querySelectorAll(".tax-field").forEach(x=>x.classList.toggle("hidden",!state.settings.taxationEnabled));if($("placeOfSupply"))$("placeOfSupply").value=state.settings.businessState||"";
function renderHistory(){const q=$("billSearch").value.toLowerCase(),list=$("historyList");list.innerHTML="";const bills=state.bills.filter(b=>JSON.stringify(b).toLowerCase().includes(q));if(!bills.length){list.innerHTML='<div class="muted">No bills found.</div>';return}bills.forEach(b=>{const r=document.createElement("div");r.className="history-row";r.innerHTML=`<div><div class="history-title">${esc(b.billNo)} • ${esc(b.customer)}</div><div class="muted">${b.date.split("-").reverse().join("/")} • ${b.items.length} item(s) • ${money(b.total)}</div></div><div class="row-actions"><button class="secondary view-bill">View</button><button class="secondary edit-bill">Edit</button></div>`;r.querySelector(".view-bill").onclick=()=>{renderBill(b);showPage("preview")};r.querySelector(".edit-bill").onclick=()=>loadBillForEdit(b);list.appendChild(r)})}
$("billSearch").oninput=renderHistory;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;$("installBtn").classList.remove("hidden")});$("installBtn").onclick=async()=>{if(deferredInstall){deferredInstall.prompt();deferredInstall=null;$("installBtn").classList.add("hidden")}};
// Android WebView uses the APK-bundled assets directly. Remove any stale service-worker
// registrations/caches left by older releases so updated button handlers cannot be shadowed.
if("serviceWorker" in navigator){
  try{navigator.serviceWorker.getRegistrations().then(rs=>Promise.all(rs.map(r=>r.unregister()))).catch(()=>{});
  try{caches.keys().then(keys=>Promise.all(keys.map(k=>caches.delete(k)))).catch(()=>{});}catch(e){}}catch(e){}
  try{caches?.keys?.().then(keys=>keys.forEach(k=>caches.delete(k))).catch(()=>{});}catch(e){}
}

function reportRange(){
 const from=String($("reportFrom")?.value||today());
 const to=String($("reportTo")?.value||today());
 return from<=to?{from,to}:{from:to,to:from};
}
function renderReports(){
 const {from,to}=reportRange();
 const bills=state.bills.filter(b=>String(b.date||"")>=from&&String(b.date||"")<=to);
 const sales=bills.reduce((s,b)=>s+Number(b.total||0),0);
 const day=$('reportSalesDate')?.value||today();
 const dayBills=state.bills.filter(b=>String(b.date||"")===day);
 const daySales=dayBills.reduce((s,b)=>s+Number(b.total||0),0);
 $("reportDaySales")&&( $("reportDaySales").textContent=money(daySales) );
 $("reportDayBills")&&( $("reportDayBills").textContent=String(dayBills.length) );
 $("reportDayAverage")&&( $("reportDayAverage").textContent=money(dayBills.length?daySales/dayBills.length:0) );
 if($("reportDayList")){ $("reportDayList").innerHTML=dayBills.length?dayBills.slice().sort((a,b)=>String(a.billNo).localeCompare(String(b.billNo))).map(b=>`<div class="report-row"><span>${esc(b.billNo)} • ${esc(b.customer||"Walk-in Customer")}</span><b>${money(b.total)}</b></div>`).join(""): '<div class="muted">No bills for this date.</div>'; }
 const discount=bills.reduce((s,b)=>s+Number(b.discount||0),0);
 const credit=bills.filter(b=>(b.paymentMode||"Cash")==="Credit").reduce((s,b)=>s+Number(b.total||0),0);
 const nonCredit=sales-credit;
 $("reportSales").textContent=money(sales);$("reportBills").textContent=String(bills.length);$("reportAverage").textContent=money(bills.length?sales/bills.length:0);$("reportDiscount").textContent=money(discount);$("reportCredit").textContent=money(credit);$("reportNonCredit").textContent=money(nonCredit);
 const custMap={}; bills.forEach(b=>{const n=b.customer&&b.customer!=="Walk-in Customer"?b.customer:"Walk-in Customer";custMap[n]=(custMap[n]||0)+Number(b.total||0)});
 const topCust=Object.entries(custMap).sort((a,b)=>b[1]-a[1]).slice(0,10);
 $("reportCustomers").innerHTML=topCust.length?topCust.map((x,i)=>`<div class="report-row"><span>${i+1}. ${esc(x[0])}</span><b>${money(x[1])}</b></div>`).join(""):'<div class="muted">No sales in this period.</div>';
 const prod={}; bills.forEach(b=>(b.items||[]).forEach(it=>{const key=String(it.name||"").trim();if(!key)return;const qty=quantityValue(it.qty,it.unit||"kg");prod[key]=(prod[key]||0)+qty;}));
 const topProd=Object.entries(prod).sort((a,b)=>b[1]-a[1]).slice(0,10);
 $("reportProducts").innerHTML=topProd.length?topProd.map((x,i)=>`<div class="report-row"><span>${i+1}. ${esc(x[0])}</span><b>${Number(x[1]).toFixed(2)}</b></div>`).join(""):'<div class="muted">No products sold in this period.</div>';
 const pm={};bills.forEach(b=>{const k=b.paymentMode||"Cash";pm[k]=(pm[k]||0)+Number(b.total||0)});
 $("reportPayments").innerHTML=Object.entries(pm).sort((a,b)=>b[1]-a[1]).map(x=>`<div class="report-row"><span>${esc(x[0])}</span><b>${money(x[1])}</b></div>`).join("")||'<div class="muted">No payment data.</div>';
 const due=getCustomerRecords().map(c=>({name:c.name,due:customerDue(c.name)})).filter(x=>x.due>0).sort((a,b)=>b.due-a.due).slice(0,10);
 $("reportOutstanding").innerHTML=due.length?due.map(x=>`<div class="report-row"><span>${esc(x.name)}</span><b>${money(x.due)}</b></div>`).join(""):'<div class="muted">No outstanding credit.</div>';
}
function setReportThisMonth(){const d=new Date();const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,"0");$("reportFrom").value=`${y}-${m}-01`;$("reportTo").value=today();renderReports();}
$("reportSalesDate")?.addEventListener("change",renderReports);$("reportFrom")?.addEventListener("change",renderReports);$("reportTo")?.addEventListener("change",renderReports);$("reportRefreshBtn")?.addEventListener("click",renderReports);$("reportClearBtn")?.addEventListener("click",setReportThisMonth);
setReportThisMonth();
if($("reportSalesDate"))$("reportSalesDate").value=today();
syncNavigation("billing");

function customerDue(name){
 if(!name||name==="Cash Sale")return 0;
 const sales=state.bills.filter(b=>b.customer===name && (b.paymentMode||"Cash")==="Credit").reduce((s,b)=>s+Number(b.total||0),0);
 const paid=state.customerPayments.filter(p=>p.customer===name).reduce((s,p)=>s+Number(p.amount||0),0);
 const c=state.customers.find(x=>x.name===name); return Number(c?.openingBalance||0)+sales-paid;
}
let customerPage=1, customerPageSize=20, customerQuery="";
function getCustomerRecords(){
 const map=new Map();
 state.customers.forEach(c=>{if(c?.name)map.set(c.name.trim().toLowerCase(),c);});
 state.bills.forEach(b=>{const n=String(b.customer||"").trim();if(n&&n!=="Walk-in Customer"&&!map.has(n.toLowerCase()))map.set(n.toLowerCase(),{name:n,phone:b.customerPhone||"",openingBalance:0,notes:""});});
 return [...map.values()];
}
function renderCustomers(){
 const box=$("customerBalances"); if(!box)return;
 const all=getCustomerRecords(); const q=String($("customerPageSearch")?.value??customerQuery??"").trim().toLowerCase(); customerQuery=q;
 const filtered=all.filter(c=>{const name=String(c.name??c.customerName??"");const phone=normalizePhone(c.phone??c.mobile??c.mobileNumber??c.phoneNumber??"");const notes=String(c.notes??c.note??c.additionalDetails??"");const hay=[name,phone,notes].join(" ").toLowerCase();const phoneQ=normalizePhone(q); return !q||hay.includes(q)|| (phoneQ && phone.includes(phoneQ));});
 const pages=Math.max(1,Math.ceil(filtered.length/customerPageSize)); customerPage=Math.min(Math.max(1,customerPage),pages);
 const slice=filtered.slice((customerPage-1)*customerPageSize,customerPage*customerPageSize);
 box.innerHTML="";
 if(!filtered.length){box.innerHTML='<div class="muted">No customers found.</div>';return;}
 slice.forEach(c=>{
   const name=c.name||"", r=document.createElement("div"); r.className="history-row customer-card";
   r.innerHTML=`<div class="customer-main"><div class="history-title">${esc(name)}</div><div class="customer-detail-grid"><span>📱 ${esc(c.phone||"No mobile")}</span><span>Opening: ${money(c.openingBalance||0)}</span><span>Due: <b>${money(customerDue(name))}</b></span></div>${c.notes?`<div class="muted customer-notes">📝 ${esc(c.notes)}</div>`:"<div class=\"muted\">No notes</div>"}</div><div class="customer-row-actions"><button class="secondary edit-customer">Edit</button><button class="secondary pay-customer">Payment</button></div>`;
   r.querySelector(".pay-customer").onclick=()=>openCustomerPayment(c);
   r.querySelector(".edit-customer").onclick=()=>openCustomerEditor(c);
   box.appendChild(r);
 });
 const pager=document.createElement("div"); pager.className="pagination";
 pager.innerHTML=`<button class="secondary" ${customerPage<=1?"disabled":""}>‹ Previous</button><span>Page ${customerPage} of ${pages} • ${filtered.length} customers</span><button class="secondary" ${customerPage>=pages?"disabled":""}>Next ›</button>`;
 const bs=pager.querySelectorAll("button"); bs[0].onclick=()=>{if(customerPage>1){customerPage--;renderCustomers()}}; bs[1].onclick=()=>{if(customerPage<pages){customerPage++;renderCustomers()}}; box.appendChild(pager);
}
function openCustomerEditor(c){
 const m=$("customerEditModal"); if(!m)return;
 $("editCustomerName").value=c.name||""; $("editCustomerPhone").value=c.phone||""; $("editCustomerGstin").value=c.gstin||""; $("editCustomerState").value=c.state||""; $("editCustomerNotes").value=c.notes||""; $("editCustomerOpening").value=String(c.openingBalance||0); m.dataset.key=String(c.name||""); m.classList.remove("hidden");
}
function closeCustomerEditor(){$("customerEditModal")?.classList.add("hidden");}
function saveCustomerEditor(){
 const m=$("customerEditModal"), oldName=m.dataset.key||"", c=state.customers.find(x=>String(x.name||"")===oldName); if(!c){closeCustomerEditor();return;}
 const newName=$("editCustomerName").value.trim(), newPhone=normalizePhone($("editCustomerPhone").value), gstin=$("editCustomerGstin").value.trim().toUpperCase(), customerState=$("editCustomerState").value.trim(), notes=$("editCustomerNotes").value.trim(), opening=Number($("editCustomerOpening").value||0);
 if(!newName){alert("Customer name cannot be blank.");return;} if(newPhone && !isValidMobile(newPhone)){alert("Enter a valid 10 digit mobile number or leave it blank.");return;}
 const conflict=state.customers.find(x=>x!==c&&(String(x.name||"").trim().toLowerCase()===newName.toLowerCase()||(newPhone&&normalizePhone(x.phone)===newPhone)));
 if(conflict){alert(`Another customer already exists with this name or mobile number.\n\n${conflict.name}${conflict.phone?" • "+conflict.phone:""}`);return;}
 c.name=newName;c.phone=newPhone;c.gstin=gstin;c.state=customerState;c.notes=notes;c.openingBalance=opening;
 state.bills.forEach(b=>{if(String(b.customer||"").trim().toLowerCase()===oldName.toLowerCase())b.customer=newName;});
 state.customerPayments.forEach(p=>{if(String(p.customer||"").trim().toLowerCase()===oldName.toLowerCase())p.customer=newName;});
 save(); renderCustomerDatalist(); customerQuery=""; renderCustomers(); closeCustomerEditor();
}
function editCustomer(c){openCustomerEditor(c)}

function renderCustomUnits(){
 const box=$("customUnitsList");if(!box)return;const arr=ensureUnitCatalog();
 box.innerHTML="";
 arr.forEach((u,i)=>{
  const row=document.createElement("div");row.className="custom-unit-row";
  row.innerHTML=`<div class="unit-info"><b>${esc(u.name)}</b><div class="muted">Aliases: ${esc((u.aliases||[]).join(", "))}</div></div><div class="unit-actions"><button type="button" class="secondary unit-edit">Edit</button><button type="button" class="secondary unit-delete">Delete</button></div>`;
  row.querySelector(".unit-edit").onclick=()=>{const name=$("customUnitName"),aliases=$("customUnitAliases"),btn=$("addCustomUnitBtn"),cancel=$("cancelCustomUnitBtn");if(name){name.value=u.name;name.focus();}if(aliases)aliases.value=(u.aliases||[]).filter(a=>String(a).toLowerCase()!==String(u.name).toLowerCase()).join(", ");if(btn){btn.textContent="Update Unit";btn.dataset.editIndex=String(i);}cancel?.classList.remove("hidden");};
  row.querySelector(".unit-delete").onclick=()=>{
   const canonical=String(u.name).toLowerCase();
   const usedProduct=state.products.some(p=>normalizeUnitName(p.unit)===canonical);
   const usedBill=state.bills.some(b=>(b.items||[]).some(it=>normalizeUnitName(it.unit)===canonical));
   if(usedProduct||usedBill){showNotice("This unit is already used in Products or Bills. Edit its aliases instead of deleting it.","Unit in use");return;}
   ensureUnitCatalog().splice(i,1);state.settings.customUnits=ensureUnitCatalog().map(x=>({name:x.name,aliases:[...(x.aliases||[])]}));save();renderCustomUnits();refreshUnitControls();showNotice("Unit deleted.","Units & Aliases");
  };
  box.appendChild(row);
 });
 if(!arr.length)box.innerHTML='<div class="muted">No units configured.</div>';
}
function resetCustomUnitEditor(){
 $("customUnitName")&&( $("customUnitName").value="");$("customUnitAliases")&&($("customUnitAliases").value="");
 const btn=$("addCustomUnitBtn");if(btn){btn.textContent="+ Add Unit";delete btn.dataset.editIndex;}
 $("cancelCustomUnitBtn")?.classList.add("hidden");
}
function addCustomUnit(){
 const name=$("customUnitName")?.value.trim()||"",raw=$("customUnitAliases")?.value||"",btn=$("addCustomUnitBtn");
 if(!name){showNotice("Enter a unit name.","Units & Aliases");return;}
 const aliases=[...new Set(raw.split(/[,\/;\n]+/).map(x=>x.trim().toLowerCase()).filter(Boolean))];
 const canonical=name.toLowerCase();if(!aliases.includes(canonical))aliases.unshift(canonical);
 const arr=ensureUnitCatalog();const editIndex=Number.isInteger(Number(btn?.dataset.editIndex))&&btn?.dataset.editIndex!==""?Number(btn.dataset.editIndex):-1;
 const duplicate=arr.findIndex((x,i)=>i!==editIndex&&String(x.name||"").toLowerCase()===canonical);
 if(duplicate>=0){showNotice("A unit with this name already exists.","Units & Aliases");return;}
 if(editIndex>=0&&arr[editIndex])arr[editIndex]={name,aliases};else arr.push({name,aliases});
 state.settings.unitCatalog=arr;state.settings.customUnits=arr.map(x=>({name:x.name,aliases:[...(x.aliases||[])]}));save();resetCustomUnitEditor();renderCustomUnits();refreshUnitControls();showNotice(editIndex>=0?"Unit updated.":"Unit added.","Units & Aliases");
}
$("addCustomUnitBtn")?.addEventListener("click",addCustomUnit);$("cancelCustomUnitBtn")?.addEventListener("click",resetCustomUnitEditor);
function refreshUnitControls(){
 document.querySelectorAll(".iunit").forEach(s=>{const v=s.value;s.innerHTML=unitOptionsHtml(v);s.value=normalizeUnitName(v);});
 const p=$("modalUnit");if(p){const v=p.value;p.innerHTML=unitOptionsHtml(v);p.value=normalizeUnitName(v);}
}

function loadSettings(){
 if(!$('setShopName'))return;
 const x=state.settings;const mobiles=getShopMobiles();
 if(JSON.stringify(x.shopMobiles||[])!==JSON.stringify(mobiles)){x.shopMobiles=mobiles;x.shopMobile=mobiles[0]||'';save();}
 $('setShopName').value=x.shopName;$('setBillPrefix').value=x.billPrefix;$('setBillStart').value=x.billStart;$('setBillTitle').value=x.billTitle;$('setAddress').value=x.address;$('setShopMobile').value=mobiles.join(', ');$('setTagline').value=x.tagline||'';$('setFooter').value=x.footer;$('setSignature').value=x.signature;$('setShowCustomer').checked=x.showCustomer!==false;$('setPaperSize').value=x.paperSize||'80mm';$('setCreditFooter').value=x.creditFooter||'Bill created by DukaanBill • Contact 8087794271 for more details';$('setVendorManagement').checked=x.vendorManagement!==false;
 ensureUnitCatalog();$('setTaxation').checked=!!x.taxationEnabled;$('setGstin').value=x.gstin||'';$('setBusinessState').value=x.businessState||'';$('setTaxInvoicePrefix').value=x.taxInvoicePrefix||'INV';$('setTaxInvoiceStart').value=x.taxInvoiceStart||1;$('setReverseCharge').checked=!!x.reverseCharge;
 $('logoPreview').src=logoSource();renderCustomUnits();refreshUnitControls();syncTaxUi();if($('placeOfSupply'))$('placeOfSupply').value=$('placeOfSupply').value||x.businessState||'';$('morePurchasingItem')?.classList.toggle('hidden',x.vendorManagement===false);
}

if($('saveSettingsBtn'))$('saveSettingsBtn').onclick=()=>{
 state.settings=Object.assign({},state.settings,{shopName:state.settings.shopName||'DUKAAN BILL',billPrefix:$('setBillPrefix').value.trim()||'BILL',billStart:Number($('setBillStart').value)||1,billTitle:$('setBillTitle').value.trim()||'CASH MEMO / BILL',address:$('setAddress').value.trim(),shopMobiles:normalizeShopMobiles($('setShopMobile').value),shopMobile:normalizeShopMobiles($('setShopMobile').value)[0]||"",tagline:$('setTagline').value.trim(),footer:$('setFooter').value.trim(),signature:$('setSignature').value.trim(),showCustomer:$('setShowCustomer').checked,paperSize:$('setPaperSize').value||'80mm',logoData:state.settings.logoData||'',creditFooter:$('setCreditFooter').value.trim()||'Bill created by DukaanBill • Contact 8087794271 for more details',vendorManagement:$('setVendorManagement').checked,customUnits:Array.isArray(state.settings.customUnits)?state.settings.customUnits:[],unitCatalog:ensureUnitCatalog(),taxationEnabled:$('setTaxation').checked,gstin:$('setGstin').value.trim().toUpperCase(),businessState:$('setBusinessState').value.trim(),taxInvoicePrefix:$('setTaxInvoicePrefix').value.trim()||'INV',taxInvoiceStart:Math.max(1,Number($('setTaxInvoiceStart').value)||1),reverseCharge:$('setReverseCharge').checked});
 save();refreshShopHeader();syncTaxUi();refreshUnitControls();$('setShopName').value=state.settings.shopName;$('settingsStatus').textContent='Settings saved.';syncNavigation(window.__pageHistory[window.__pageHistory.length-1]||'billing');if(!state.settings.vendorManagement&&window.__pageHistory[window.__pageHistory.length-1]==='purchases')showPage('billing');
};
function openShopNameModal(){
 const m=$("shopNameModal");if(!m)return;$("shopNamePassword").value="";$("shopNameNew").value=state.settings.shopName||"DUKAAN BILL";m.classList.remove("hidden");setTimeout(()=>$("shopNamePassword")?.focus(),50);
}
function closeShopNameModal(){$("shopNameModal")?.classList.add("hidden");}
$("changeShopNameBtn")?.addEventListener("click",openShopNameModal);
$("shopNameCancel")?.addEventListener("click",closeShopNameModal);
$("shopNameSave")?.addEventListener("click",()=>{
 const pass=$("shopNamePassword").value;const trimmed=$("shopNameNew").value.trim();
 if(!pass){showNotice("Enter the password to change the shop name.","Change Shop Name");return;}
 if(!trimmed){showNotice("Shop name cannot be blank.","Change Shop Name");return;}
 let ok=false;try{ok=!!window.Android?.verifyShopNamePassword?.(pass);}catch(e){ok=false;}
 if(!ok){showNotice("Incorrect password. Shop name was not changed.","Change Shop Name");return;}
 state.settings.shopName=trimmed;save();$("setShopName").value=trimmed;refreshShopHeader();if(window.currentBill)renderBill(window.currentBill);$("settingsStatus").textContent="Shop name updated.";closeShopNameModal();
});

function openCustomerAddModal(){
 const m=$("customerAddModal");if(!m)return;$("addCustomerName").value="";$("addCustomerPhone").value="";$("addCustomerGstin").value="";$("addCustomerState").value="";$("addCustomerNotes").value="";$("addCustomerOpening").value="0";m.classList.remove("hidden");setTimeout(()=>$("addCustomerName")?.focus(),50);
}
function closeCustomerAddModal(){$("customerAddModal")?.classList.add("hidden");}
$("addCustomerBtn")?.addEventListener("click",openCustomerAddModal);
$("addCustomerCancel")?.addEventListener("click",closeCustomerAddModal);
$("addCustomerSave")?.addEventListener("click",()=>{
 const name=$("addCustomerName").value.trim(),phoneRaw=$("addCustomerPhone").value.trim(),phone=normalizePhone(phoneRaw),gstin=$("addCustomerGstin").value.trim().toUpperCase(),customerState=$("addCustomerState").value.trim(),notes=$("addCustomerNotes").value.trim(),opening=Number($("addCustomerOpening").value||0);
 if(!name){showNotice("Enter customer name.","Add Customer");return;}
 if(phoneRaw&&!isValidMobile(phone)){showNotice("Enter a valid 10 digit mobile number or leave it blank.","Add Customer");return;}
 if(!Number.isFinite(opening)||opening<0){showNotice("Enter a valid opening balance.","Add Customer");return;}
 if(phone){
   handleCustomerConflict(name,phone,(decision,existing)=>{
     try{
       if(decision==="same"||decision==="update"){
         const c=existing||findCustomerByNameOrPhone(name,phone);
         if(!c) throw new Error("Customer record not found");
         c.name=name;c.phone=phone;c.gstin=gstin;c.state=customerState;c.notes=notes;c.openingBalance=opening;
       }else if(decision==="create"||decision==="none"){
         state.customers.unshift({name,phone,notes,openingBalance:opening});
         state.customers=state.customers.slice(0,500);
       }else{return;}
       save();renderCustomerDatalist();renderCustomers();closeCustomerAddModal();
       showNotice("Customer saved successfully.","Add Customer");
     }catch(e){showNotice("Customer could not be saved. Please try again.","Add Customer");}
   },{gstin,state:customerState,notes,openingBalance:opening});
 }
 else {const same=state.customers.find(c=>String(c.name||"").trim().toLowerCase()===name.toLowerCase());if(same){showNotice("A customer with this name already exists. Add a mobile number or edit the existing customer.","Customer Already Exists");return;}state.customers.unshift({name,phone:"",gstin,state:customerState,notes,openingBalance:opening});state.customers=state.customers.slice(0,500);save();renderCustomerDatalist();renderCustomers();closeCustomerAddModal();}
});

let customerPaymentTarget=null;
function openCustomerPayment(c){customerPaymentTarget=c;$("customerPaymentLabel").textContent="Payment received from "+(c.name||"");$("customerPaymentAmount").value="0";$("customerPaymentModal").classList.remove("hidden");setTimeout(()=>$("customerPaymentAmount")?.focus(),50);}
$("customerPaymentCancel")?.addEventListener("click",()=>{$("customerPaymentModal").classList.add("hidden");customerPaymentTarget=null;});
$("customerPaymentSave")?.addEventListener("click",()=>{const a=Number($("customerPaymentAmount").value||0);if(!customerPaymentTarget||a<=0){showNotice("Enter a payment amount greater than zero.","Customer Payment");return;}state.customerPayments.unshift({id:Date.now(),customer:customerPaymentTarget.name,date:today(),amount:a});save();renderCustomers();$("customerPaymentModal").classList.add("hidden");customerPaymentTarget=null;});

function handleCustomerPageSearch(e){customerQuery=String(e.target.value||"");customerPage=1;renderCustomers();}
$("customerPageSearch")?.addEventListener("input",handleCustomerPageSearch);
$("customerPageSearch")?.addEventListener("keyup",handleCustomerPageSearch);
$("customerPageSearch")?.addEventListener("change",handleCustomerPageSearch);
document.addEventListener("input",e=>{if(e.target?.id==="productPageSearch"){productQuery=String(e.target.value||"");productPage=1;renderProducts();}});
if($("customerEditCancel")) $("customerEditCancel").onclick=closeCustomerEditor;
if($("customerEditSave")) $("customerEditSave").onclick=saveCustomerEditor;
// Backup / restore is handled by the Android native layer so the ZIP can include the SQLite DB and invoice attachments.
if($("backupNowBtn")) $("backupNowBtn").onclick=()=>{
  if(window.Android?.backupData){$("backupStatus").textContent="Creating backup...";Android.backupData();}
  else $("backupStatus").textContent="Backup is available in the Android APK.";
};
if($("restoreBackupBtn")) $("restoreBackupBtn").onclick=()=>{
  showConfirm("Restore will replace the current local shop data on this phone. Continue?",()=>{if(window.Android?.restoreData){$("backupStatus").textContent="Choose your backup ZIP...";Android.restoreData();}else $("backupStatus").textContent="Restore is available in the Android APK.";},"Restore Backup");
};
