# DukaanBill release shrinking rules.
# Keep Android components and WebView bridge methods used by the app.
-keepclassmembers class com.dukaanbill.app.MainActivity { public *; }
-keep class com.dukaanbill.app.** { *; }
