Build Version 3.0

Required ZIP file: DukaanBill_Android_v3_0_LocalBackupRestore.zip

The Android build must preserve the ML Kit dependency:
implementation 'com.google.mlkit:text-recognition:16.0.1'
