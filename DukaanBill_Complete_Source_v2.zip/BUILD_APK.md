DukaanBill v3.34 build

Use the included GitHub Actions workflow:
.github/workflows/build-apk.yml

Expected Android version:
- versionName: 3.34
- versionCode: 52

The project preserves:
implementation 'com.google.mlkit:text-recognition:16.0.1'
implementation 'com.tom-roush:pdfbox-android:2.0.27.0'

This environment does not contain the Android SDK/Gradle toolchain or emulator, so no APK build/runtime success is claimed here. Build the APK with GitHub Actions/Android Studio.
