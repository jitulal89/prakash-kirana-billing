# Dukaan Bill v3.23

Final clean UI/navigation baseline from v3.21.

Primary footer navigation:
- Billing
- Bills
- Reports
- More

More contains:
- Products
- Purchasing (only when Vendor Management is enabled)
- Customers
- Settings
- Backup

The Reports section now contains the daily sales view, so Sales is no longer a separate navigation item.

A + New Bill button is available directly on Billing and clears edit mode.

Zero discount remains hidden on PDF/thermal print output.
