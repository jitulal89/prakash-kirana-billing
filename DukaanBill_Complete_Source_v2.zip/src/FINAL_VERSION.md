# Dukaan Bill v3.24 — Final UI / Interaction Fix Baseline

This release is based on v3.23 and focuses on reliability of interactive controls and completion of Product Management.

## Fixed / Added
- Footer navigation: Billing, Bills, Reports, More.
- Vendor Management setting controls visibility of Purchasing.
- New Bill button resets billing state after editing a bill.
- Zero-value discount remains hidden on PDF/print.
- Add Customer is now an in-app modal with Name, Mobile, Notes and Opening Balance.
- Change Shop Name is now an in-app modal with password and new name.
- Customer page supports search, 20 customers per page, pagination and full edit.
- Billing customer search has explicit suggestions and keyboard interaction.
- Products page now has Add Product, Search, 20-per-page pagination, Edit and Delete.
- Product Add/Edit uses Name, Rate and Unit together.
- Modal z-index/layering is hardened so dialogs appear above the header and footer navigation.
- Existing PDF, print, purchasing, OCR, backup/restore and reports functionality is preserved.

## Release
- applicationId: com.dukaanbill.app
- versionName: 3.24
- versionCode: 43
