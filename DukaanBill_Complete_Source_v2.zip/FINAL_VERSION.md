Dukaan Bill v3.28 - Final Validation Baseline

This version is based on the v3.27 source and fixes the interaction issues found during testing of the user-supplied APK:
- Customer/Product search reliability
- Print/PDF customer suggestion selection and auto mobile fill
- Existing-product rate/unit auto-fill in Billing
- Legacy/imported customer and product field normalization
- Android WebView touch/pointer event reliability

Build using the included GitHub Actions workflow. This environment does not contain the Android SDK/Gradle toolchain, so an APK build is not claimed here.
