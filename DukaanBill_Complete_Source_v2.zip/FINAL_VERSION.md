Dukaan Bill v3.31
- Fixed shop logo upload in Android WebView with image compression and preview.
- Added configurable custom units and comma/slash/semicolon-separated aliases.
- Roll unit is available by default with aliases roll, r, rl.
- Custom units appear in billing and product unit selectors and Quick List parsing.
- Preserved existing billing, PDF, print, backup, customer, product and purchasing functionality.
