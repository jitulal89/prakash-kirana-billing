const fs=require('fs');
const js=fs.readFileSync('app/src/main/assets/www/app.js','utf8');
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const checks={
 'global group metadata key':js.includes("SBP_GROUP_KEY='siddhibillplus_business_groups_v1'"),
 'group registry persisted through app state':js.includes('saveAppStateValue?.(SBP_GROUP_KEY,raw)'),
 'group membership limited to selected firms':js.includes('g.firmIds.includes(f.id)'),
 'group inventory aggregation':js.includes('function sbpGroupRows()'),
 'firm product mapping':js.includes('groupProductId:id'),
 'transfer approval state':js.includes("t.status='approved'"),
 'source dispatch movement':js.includes("'transfer_out'"),
 'destination receipt movement':js.includes("'transfer_in'"),
 'partial receipt support':js.includes("partially_received"),
 'transfer audit trail':js.includes('sbpGroupData.audit||(sbpGroupData.audit=[])'),
 'inventory UI added':html.includes('id="groupInventoryCard"'),
 'transfer UI added':html.includes('id="groupTransfersCard"')
};
for(const [k,v] of Object.entries(checks)) console.log((v?'PASS':'FAIL')+' '+k);
if(Object.values(checks).some(v=>!v))process.exit(1);
