const fs=require('fs');const s=fs.readFileSync('app/src/main/assets/www/app.js','utf8');
const checks={
 'non-active firm product records read from localStorage':/localStorage\.getItem\(k\)\|\|nativeStore\[k\]/.test(s),
 'active firm products use current state':/f\.id===__sbActiveFirmId\?JSON\.stringify\(state\.products\|\|\[\]\)/.test(s),
 'transfer product selector checks destination mapped IDs':/destIds\.has\(sbpMappedProduct\(src,p\)\)/.test(s),
 'destination change refreshes product selector':/groupTransferDestination'\)\?\.addEventListener\('change',sbpRenderTransferProductOptions\)/.test(s),
 'automatic group product mapping supported at dispatch/receipt':/fProducts\.find\(x=>sbpMappedProduct\(f,x\)===t\.groupProductId\)/.test(s),
 'missing destination firm has explanatory option':/No other active firm in this group/.test(s),
 'missing shared mapping has explanatory option':/No products mapped in both selected firms/.test(s)
};for(const [k,v] of Object.entries(checks))console.log((v?'PASS':'FAIL')+' '+k);if(Object.values(checks).some(v=>!v))process.exit(1);
