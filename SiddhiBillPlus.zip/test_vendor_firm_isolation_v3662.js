const fs=require('fs');
const p='app/src/main/assets/www/app.js';
const s=fs.readFileSync(p,'utf8');
const checks=[
 ['Vendor master loaded from active firm namespace',s.includes('vendors:getStored("pksVendors",[])')],
 ['Vendor payment collection loaded from active firm namespace',s.includes('vendorPayments:getStored("pksVendorPayments",[])')],
 ['Vendor records with another shopKey are excluded',s.includes("if(owner&&owner!==shopKey){changed=true;return false;}")],
 ['Legacy untagged vendors are assigned to active firm',s.includes('shopKey,shopName,pan:String(v.pan||')],
 ['New vendor records are tagged with active firm',s.includes('address:$("vendorAddress").value.trim(),shopKey:String(__sbActiveFirm().shopKey||__sbActiveFirm().id).toLowerCase()')],
 ['Vendor payments are tagged with active firm',s.includes('vendorPayments.unshift({id:purchaseId("PAY"),vendorId,shopKey:String(__sbActiveFirm().shopKey||__sbActiveFirm().id).toLowerCase()')],
 ['Vendor isolation migration persists changes',s.includes('if(changed)save();')]
];
for(const [n,ok] of checks) console.log((ok?'PASS ':'FAIL ')+n);
if(checks.some(x=>!x[1])) process.exit(1);
