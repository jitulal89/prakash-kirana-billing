const fs=require('fs');
const app=fs.readFileSync('app/src/main/assets/www/app.js','utf8');
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const checks=[
 ['per-firm mapping diagnostics function',/function sbpMappingDiagnostics\(\)/.test(app)],
 ['mapping status UI target',/id="groupMappingDiagnostics"/.test(html)],
 ['firm-specific missing mapping text',/missing a mapping in/.test(app)],
 ['transfer-specific diagnostics UI target',/id="groupTransferDiagnostics"/.test(html)],
 ['active firm excluded from destination options',/f\.id!==__sbActiveFirmId&&g\?\.firmIds\?\.includes\(f\.id\)/.test(app)],
 ['destination change refreshes products and diagnostics',/groupTransferDestination'\)\?\.addEventListener\('change',\(\)=>\{[\s\S]*?sbpRenderTransferProductOptions\(\)/.test(app)],
 ['same-firm transfer blocked',/src\.id===dst\.id/.test(app)],
 ['diagnostics use group firm registry',/function sbpGroupFirms\(\)/.test(app)],
 ['transfer dropdown retains valid selection',/rows\.some\(r=>r\.id===prior\)/.test(app)],
 ['version bumped',/versionName "3\.66\.3"/.test(fs.readFileSync('app/build.gradle','utf8'))]
];
for(const [n,ok] of checks) console.log((ok?'PASS':'FAIL')+' '+n);
if(checks.some(x=>!x[1])) process.exit(1);
