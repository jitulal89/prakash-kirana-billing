/* SiddhiBill v3.64.67 regression fixes: migration preparation, reports, team, customer and purchase workflows */
const __sbTraceClock=()=>((typeof performance!=="undefined"&&performance.now)?performance.now():Date.now());
const __sbTraceStart=__sbTraceClock();
window.__siddhiStartupTrace={
 version:"3.65.0",
 startedAt:new Date().toISOString(),
 marks:[{name:"app.js execution started",ms:0}],
 longTasks:[],
 profile:[],
 errors:[],
 screen:"startup",
 homeReadyMs:null,
 domReadyMs:null,
 loadEventMs:null,
 firstPaintMs:null,
 firstContentfulPaintMs:null,
 nativeTransferMs:null,
 jsInitialStateMs:null,
 initModulesMs:null
};
window.__sbTraceMark=(name)=>{try{window.__siddhiStartupTrace.marks.push({name:String(name),ms:Math.round(__sbTraceClock()-__sbTraceStart)});}catch(_){}};
window.__sbTraceProfile=(name,start,details={})=>{try{window.__siddhiStartupTrace.profile.push({name:String(name),durationMs:Math.round(__sbTraceClock()-start),atMs:Math.round(__sbTraceClock()-__sbTraceStart),...details});}catch(_){}};
window.addEventListener("error",e=>{try{window.__siddhiStartupTrace.errors.push({type:"error",message:String(e.message||"Runtime error").slice(0,220),atMs:Math.round(__sbTraceClock()-__sbTraceStart)});}catch(_){}});
window.addEventListener("unhandledrejection",e=>{try{window.__siddhiStartupTrace.errors.push({type:"unhandledrejection",message:String(e.reason?.message||e.reason||"Promise rejection").slice(0,220),atMs:Math.round(__sbTraceClock()-__sbTraceStart)});}catch(_){}});
try{
 if(typeof PerformanceObserver!=="undefined"){
  const __sbLongTaskObserver=new PerformanceObserver(list=>{
   for(const entry of list.getEntries()){
    try{window.__siddhiStartupTrace.longTasks.push({startMs:Math.round(entry.startTime),durationMs:Math.round(entry.duration)});}catch(_){}
   }
  });
  __sbLongTaskObserver.observe({type:"longtask",buffered:true});
 }
}catch(_){}
try{
 const __sbPaintObserver=new PerformanceObserver(list=>{
  for(const entry of list.getEntries()){
   if(entry.name==="first-paint")window.__siddhiStartupTrace.firstPaintMs=Math.round(entry.startTime);
   if(entry.name==="first-contentful-paint")window.__siddhiStartupTrace.firstContentfulPaintMs=Math.round(entry.startTime);
  }
 });
 __sbPaintObserver.observe({type:"paint",buffered:true});
}catch(_){}
document.addEventListener("DOMContentLoaded",()=>{
 window.__siddhiStartupTrace.domReadyMs=Math.round(__sbTraceClock()-__sbTraceStart);
 window.__sbTraceMark("DOMContentLoaded");
 requestAnimationFrame(()=>{window.__sbTraceMark("first animation frame after DOMContentLoaded");});
},{once:true});
window.addEventListener("load",()=>{
 window.__siddhiStartupTrace.loadEventMs=Math.round(__sbTraceClock()-__sbTraceStart);
 window.__sbTraceMark("window load event");
},{once:true});

const $=id=>document.getElementById(id);
window.addEventListener("error",e=>{try{console.error("SiddhiBill runtime error",e.error||e.message); if(typeof showNotice==="function") showNotice("App script error: "+String(e.message||e.error||"Unknown error"),"Sharing diagnostics");}catch(_){}});
window.addEventListener("unhandledrejection",e=>{try{console.error("SiddhiBill promise error",e.reason||e); if(typeof showNotice==="function") showNotice("App operation failed: "+String(e.reason?.message||e.reason||"Unknown error"),"Sharing diagnostics");}catch(_){}});
// Explicit DOM references for Android WebView reliability. Do not depend on
// browser-specific named-element globals such as window.items/window.billDate.
const items=$("items");
const billDate=$("billDate");
const PIECE_PRODUCTS=new Set([]);

// Native Android state bridge. Read SQLite state in bounded chunks so large backups
// do not have to cross the WebView bridge as one multi-megabyte string.
// If Android is present but native loading fails, fail closed: never migrate stale
// localStorage over the restored SQLite database.
let nativeStore={};
let nativeStateKeySet=new Set();
const nativeBridgePresent=!!(window.Android?.loadAppStateKeys && window.Android?.loadAppStateValueChunk);
const __sbNativeTraceStart=__sbTraceClock();
let nativeLoadFailed=false;
if(nativeBridgePresent){
 try{
   const keys=JSON.parse(window.Android.loadAppStateKeys()||"[]");
   if(!Array.isArray(keys)) throw new Error("Native state key list is invalid");
   nativeStateKeySet=new Set(keys.map(String));
   const chunkSize=32768;
   for(const key of keys){
     // Transaction history is intentionally excluded from startup transfer.
     // It is fetched from SQLite only when application code first requests it.
     if(key==="pksBills" || key==="pksPurchases" || key==="pksInventoryMovements") continue;
     let value="", offset=0, part="", codePoints=0;
     do{
       part=window.Android.loadAppStateValueChunk(String(key),offset,chunkSize);
       if(typeof part!=="string") throw new Error("Native state chunk is invalid for "+key);
       value+=part;
       // SQLite substr() counts Unicode code points; JavaScript String.length
       // counts UTF-16 code units. Array.from() keeps offsets correct for emoji.
       codePoints=Array.from(part).length;
       offset+=codePoints;
       if(codePoints===0) break;
     }while(codePoints===chunkSize);
     // Empty strings are valid stored values; key listing confirms existence.
     nativeStore[String(key)]=value;
   }
 }catch(e){nativeStore={};nativeStateKeySet=new Set();nativeLoadFailed=true;window.siddhiBillNativeLoadError=String(e&&e.message?e.message:e);console.error("SiddhiBill native state load failed; writes are disabled to protect restored data",e);}
}
window.__siddhiStartupTrace.nativeTransferMs=Math.round(__sbTraceClock()-__sbNativeTraceStart);
window.__sbTraceMark("native state transfer complete");
// SiddhiBillPlus firm registry and per-firm state namespaces.
const SBP_REGISTRY_KEY='siddhibillplus_firm_registry', SBP_ACTIVE_KEY='siddhibillplus_active_firm';
const __sbLegacySettings=(()=>{try{return JSON.parse(nativeStore.dukaanBillSettings||localStorage.getItem('dukaanBillSettings')||'{}')}catch(_){return {}}})();
const __sbLegacyName=String(__sbLegacySettings.shopName||'My Business').trim()||'My Business';
const __sbLegacyShopKey=__sbLegacyName.toLowerCase().replace(/\s+/g,' ');
let __sbFirmRegistry=(()=>{try{const raw=nativeStore[SBP_REGISTRY_KEY]||localStorage.getItem(SBP_REGISTRY_KEY);const v=raw?JSON.parse(raw):null;if(v&&Array.isArray(v.firms)&&v.firms.length)return v}catch(_){}return {version:1,firms:[{id:'firm_default',shopKey:__sbLegacyShopKey,name:__sbLegacyName,status:'active',createdAt:new Date().toISOString(),isDefault:true}]}})();
let __sbActiveFirmId=String(nativeStore[SBP_ACTIVE_KEY]||localStorage.getItem(SBP_ACTIVE_KEY)||__sbFirmRegistry.firms.find(f=>f.isDefault)?.id||__sbFirmRegistry.firms[0].id);
if(!__sbFirmRegistry.firms.some(f=>f.id===__sbActiveFirmId&&f.status!=='inactive'))__sbActiveFirmId=__sbFirmRegistry.firms.find(f=>f.isDefault&&f.status!=='inactive')?.id||__sbFirmRegistry.firms.find(f=>f.status!=='inactive')?.id||__sbFirmRegistry.firms[0].id;
const __sbActiveFirm=()=>__sbFirmRegistry.firms.find(f=>f.id===__sbActiveFirmId)||__sbFirmRegistry.firms[0];
const firmStorageKey=key=>'sbp_'+__sbActiveFirmId+'__'+key;
function persistSbpRegistry(){const j=JSON.stringify(__sbFirmRegistry);try{localStorage.setItem(SBP_REGISTRY_KEY,j);localStorage.setItem(SBP_ACTIVE_KEY,__sbActiveFirmId)}catch(_){}try{if(window.Android?.saveAppStateValue){Android.saveAppStateValue(SBP_REGISTRY_KEY,j);Android.saveAppStateValue(SBP_ACTIVE_KEY,__sbActiveFirmId)}}catch(e){console.warn('Firm registry persistence failed',e)}}
persistSbpRegistry();
try{const df=__sbFirmRegistry.firms.find(f=>f.isDefault);if(nativeBridgePresent&&df&&window.Android?.assignUnassignedRecordsToFirm){const migrated=Number(Android.assignUnassignedRecordsToFirm(String(df.shopKey||df.id)));if(migrated<0)window.__sbFirmMigrationFailed=true;}}catch(e){window.__sbFirmMigrationFailed=true;console.error('Legacy firm data migration could not be confirmed',e);}
const getStored=(key,fallback)=>{
 try{
  if(nativeLoadFailed)return fallback;
  const scoped=firmStorageKey(key);
  if(Object.prototype.hasOwnProperty.call(nativeStore,scoped))return JSON.parse(nativeStore[scoped]||JSON.stringify(fallback));
  if(!nativeBridgePresent){const sr=localStorage.getItem(scoped);if(sr!=null)return JSON.parse(sr)}
  if(__sbActiveFirm().isDefault){if(Object.prototype.hasOwnProperty.call(nativeStore,key))return JSON.parse(nativeStore[key]||JSON.stringify(fallback));if(!nativeBridgePresent){const raw=localStorage.getItem(key);return raw==null?fallback:JSON.parse(raw)}}
  return fallback;
 }catch(e){nativeLoadFailed=nativeBridgePresent;return fallback}
};

const LEGACY_DEFAULT_PRODUCT_NAMES=new Set(["Singdana","Sabudana","Sugar","Rice","Dal","Wheat","Atta","Maida","Besan","Rava","Sooji","Poha","Moong Dal","Toor Dal","Masoor Dal","Urad Dal","Chana Dal","Rajma","Chole","Kabuli Chana","Moong","Masoor","Black Gram","Tea","Coffee","Salt","Jaggery","Turmeric","Red Chilli Powder","Coriander Powder","Garam Masala","Cumin","Mustard Seeds","Fennel","Black Pepper","Cardamom","Cloves","Cinnamon","Cooking Oil","Sunflower Oil","Groundnut Oil","Mustard Oil","Ghee","Butter","Milk","Curd","Bread","Biscuits","Namkeen","Chips","Papad","Noodles","Pasta","Vermicelli","Corn Flakes","Oats","Jam","Peanut Butter","Honey","Tomato Ketchup","Pickle","Coconut","Dry Coconut","Almonds","Cashews","Raisins","Walnuts","Dates","Mouth Freshener","Chocolate","Toffee","Colgate","Toothpaste","Toothbrush","Soap","Shampoo","Hair Oil","Face Wash","Body Lotion","Detergent","Washing Powder","Dishwash","Dishwash Bar","Floor Cleaner","Toilet Cleaner","Phenyl","Handwash","Sanitizer","Tissue","Toilet Paper","Garbage Bags","Mosquito Coil","Mosquito Repellent","Matchbox","Candles","Battery","Notebook","Pen","Pencil","Eraser","Sharpener"]);

const state={
 products:getStored("pksProducts",[]),
 inventoryMovements:[],
 bills:[],
 customers:getStored("pksCustomers",[]),
 vendors:getStored("pksVendors",[]),
 purchases:[],
 vendorPayments:getStored("pksVendorPayments",[]),
 customerPayments:[],
 teamMembers:getStored("pksTeamMembers",[]),
 teamAttendance:getStored("pksTeamAttendance",[]),
 teamPayments:getStored("pksTeamPayments",[]),
 brokers:getStored("pksBrokers",[]),
 brokerCommissions:getStored("pksBrokerCommissions",[]),
 brokerPayments:getStored("pksBrokerPayments",[]),
 estimates:getStored("pksEstimates",[]),
 expenses:getStored("pksExpenses",[]),
 gstCompliance:getStored("pksGstCompliance",{}),
 settings:Object.assign({shopName:"",billPrefix:"BILL",billStart:1,billTitle:"CASH MEMO / BILL",taxBillTitle:"TAX INVOICE",address:"",footer:"Thank you for shopping with us!",signature:"",tagline:"",shopMobile:"",shopMobiles:[],showCustomer:true,printCustomerMobile:true,printPaymentMode:true,printItemCode:false,printShopName:true,printShopAddress:true,printShopMobile:true,printShopLogo:true,paperSize:"80mm",bluetoothPrinter:"auto",logoData:"",creditFooter:"Bill created by SiddhiBill • Contact 8087794271 for more details",vendorManagement:true,inventoryManagement:false,customUnits:[{name:"Roll",aliases:["roll","r","rl"]}],unitCatalog:[],showDateFollowUpReport:true,taxationEnabled:false,gstin:"",businessState:"",taxInvoicePrefix:"INV",taxInvoiceStart:1,reverseCharge:false,ocrProductAliases:{},ocrOwnerKeywords:"",termsConditions:"",printTermsConditions:false},getStored("dukaanBillSettings",{})),
 purchaseAttachment:null,
 purchaseImportRows:[],
 purchaseImportMeta:null
};
// Defer parsing the two largest transaction arrays until a screen or operation
// actually needs them. Their raw JSON remains in nativeStore until first access.
window.__siddhiStartupTrace.jsInitialStateMs=Math.round(__sbTraceClock()-__sbNativeTraceStart);window.__sbTraceMark("initial state object ready");

function defineLazyTransactionState(propertyName, storageKey){
 let loaded=false, cached=[];
 window.__siddhiLazyState=window.__siddhiLazyState||{};
 window.__siddhiLazyState[propertyName]=()=>loaded;
 Object.defineProperty(state,propertyName,{
   enumerable:true, configurable:true,
   get(){
     if(!loaded){
       const __sbLazyStart=__sbTraceClock();
       let __sbReadMs=0,__sbParseMs=0,__sbRawLength=0;
       try{
         let raw;
         const __sbReadStart=__sbTraceClock();
         if(Object.prototype.hasOwnProperty.call(nativeStore,storageKey)) raw=nativeStore[storageKey];
         else if(nativeBridgePresent && window.Android?.loadTransactionCollectionPage){
           cached=[];let offset=0;
           while(true){
             const page=JSON.parse(window.Android.loadTransactionCollectionPage(storageKey,offset,500)||"{}");
             if(!page.supported||!Array.isArray(page.records))throw new Error("Native transaction page is unavailable for "+storageKey);
             cached.push(...page.records);
             if(page.records.length<500)break;
             offset+=page.records.length;
           }
           raw=null;
         }else if(nativeBridgePresent){
           let offset=0,part="",codePoints=0;raw="";
           do{
             part=window.Android.loadAppStateValueChunk(storageKey,offset,32768);
             if(typeof part!=="string") throw new Error("Native transaction chunk is invalid for "+storageKey);
             raw+=part;codePoints=Array.from(part).length;offset+=codePoints;
             if(codePoints===0)break;
           }while(codePoints===32768);
         }else {raw=localStorage.getItem(firmStorageKey(storageKey));if(raw===null&&__sbActiveFirm().isDefault)raw=localStorage.getItem(storageKey);}
         __sbReadMs=Math.round(__sbTraceClock()-__sbReadStart);
         __sbRawLength=String(raw||"").length;
         const __sbParseStart=__sbTraceClock();
         if(raw!==null)cached=raw?JSON.parse(raw):[];
         __sbParseMs=Math.round(__sbTraceClock()-__sbParseStart);
         if(!Array.isArray(cached)) cached=[];
         const activeFirm=__sbActiveFirm(), activeKey=String(activeFirm.shopKey||activeFirm.id).toLowerCase();
         const defaultFirm=__sbFirmRegistry.firms.find(f=>f.isDefault), defaultKey=String(defaultFirm?.shopKey||defaultFirm?.id||'').toLowerCase();
         cached=cached.map(r=>{const row={...r};let k=String(row.shopKey||'').trim().toLowerCase();const legacyName=String(defaultFirm?.name||'').trim().toLowerCase().replace(/\s+/g,' '),recordName=String(row.shopName||'').trim().toLowerCase().replace(/\s+/g,' ');if(defaultFirm&&(!k||k===legacyName||recordName===legacyName)){row.shopKey=defaultKey;k=defaultKey}return row}).filter(r=>String(r.shopKey||'').trim().toLowerCase()===activeKey);
       }catch(e){
         nativeLoadFailed=nativeBridgePresent;
         window.siddhiBillNativeLoadError=String(e?.message||e);
         cached=[];
         __sbReadMs=Math.round(__sbTraceClock()-__sbLazyStart);
       }
       __sbTraceProfile("lazy transaction load: "+storageKey,__sbLazyStart,{readMs:__sbReadMs,jsonParseMs:__sbParseMs,jsonChars:__sbRawLength,records:cached.length});
       loaded=true;
       try{delete nativeStore[storageKey];}catch(_){}
       Object.defineProperty(state,propertyName,{value:cached,writable:true,enumerable:true,configurable:true});
     }
     return cached;
   },
   set(value){loaded=true;cached=Array.isArray(value)?value:[];Object.defineProperty(state,propertyName,{value:cached,writable:true,enumerable:true,configurable:true});}
 });
}
defineLazyTransactionState("bills","pksBills");
defineLazyTransactionState("purchases","pksPurchases");
defineLazyTransactionState("inventoryMovements","pksInventoryMovements");
defineLazyTransactionState("customerPayments","pksCustomerPayments");
// Apply shop details delivered through the offline Owner activation flow. The Owner's
// local logo/printer settings are never copied; only shop identity/contact fields are used.
try{
 const activatedShop=JSON.parse(window.Android?.getActivatedShopSetup?.()||"{}");
 if(__sbActiveFirm().isDefault && activatedShop.shopName){
   state.settings.shopName=activatedShop.shopName;
   if(activatedShop.shopMobile){state.settings.shopMobile=activatedShop.shopMobile;state.settings.shopMobiles=[activatedShop.shopMobile];}
   if(activatedShop.address) state.settings.address=activatedShop.address;
   if(activatedShop.gstin) state.settings.gstin=activatedShop.gstin;
   if(activatedShop.state) state.settings.businessState=activatedShop.state;
   try{localStorage.setItem(firmStorageKey("dukaanBillSettings"),JSON.stringify(state.settings));}catch(e){}
 }
}catch(e){}

// Do not print the legacy default disclaimer unless the shop explicitly configured it.
if(!nativeLoadFailed && String(state.settings.termsConditions||"").trim()==="Goods once sold cannot be taken back."){state.settings.termsConditions="";state.settings.printTermsConditions=false;try{localStorage.setItem(firmStorageKey("dukaanBillSettings"),JSON.stringify(state.settings));}catch(e){} try{if(window.Android?.saveAppState)window.Android.saveAppState(JSON.stringify({[firmStorageKey("dukaanBillSettings")]:JSON.stringify(state.settings)}));}catch(e){}}
if(typeof state.settings.printTermsConditions!=="boolean") state.settings.printTermsConditions=false;

// Normalize the taxation flag from older backups/storage. Some older builds could
// persist booleans as strings (for example "false"), and Boolean("false") is true.
// Treat only explicit true values as enabled so the billing Tax control never
// appears when taxation is actually disabled.
state.settings.taxationEnabled = state.settings.taxationEnabled === true || state.settings.taxationEnabled === 1 || String(state.settings.taxationEnabled).toLowerCase() === "true";

// Tax mode for the billing form. Historical tax invoices retain their tax
// structure while being edited even if the current global Taxation setting is OFF.
function formTaxEnabled(){ const toggle=$("billTaxToggle"); return toggle ? !!toggle.checked : (!!state.settings.taxationEnabled || !!window.editingTaxInvoice); }
function syncTaxUi(){ const enabled=formTaxEnabled(); document.body.classList.toggle("taxation-on",enabled); document.body.classList.toggle("taxation-editing",!!window.editingTaxInvoice); document.querySelectorAll(".tax-field").forEach(el=>el.classList.toggle("hidden",!enabled)); const toggle=$("billTaxToggle"); if(toggle) toggle.checked=enabled; const supply=$("placeOfSupplyLabel"); if(supply) supply.classList.toggle("tax-only-field",!enabled); }
function billTaxEnabled(b){ return !!b?.taxationEnabled; }
$("billAmountsIncludeTax")?.addEventListener("change",()=>calc());
$("billTaxToggle")?.addEventListener("change",()=>{window.editingTaxInvoice=false;syncTaxUi();[...items.children].forEach(row=>{if(!formTaxEnabled()){const t=row.querySelector(".itax");if(t)t.value="0";}else{const t=row.querySelector(".itax");if(t&&(!t.value||t.value==="0"))t.value="5";}});calc();});
// Remove the old preloaded product catalog once. User-created products are preserved.
if(!nativeLoadFailed && !getStored("dukaanProductCatalogMigrated",false)){
 state.products=state.products.filter(p=>!LEGACY_DEFAULT_PRODUCT_NAMES.has(String(p.name||"")));
 // This is a one-time product-only migration. Do not call save() here: save()
 // serializes every module, which would force the 10k bill/purchase arrays to load
 // and send them back to SQLite during application startup.
 try{localStorage.setItem(firmStorageKey("pksProducts"),JSON.stringify(state.products));localStorage.setItem(firmStorageKey("dukaanProductCatalogMigrated"),"true");}catch(e){}
 try{if(window.Android?.saveAppStateValue){Android.saveAppStateValue(firmStorageKey("pksProducts"),JSON.stringify(state.products));Android.saveAppStateValue(firmStorageKey("dukaanProductCatalogMigrated"), "true");}}catch(e){console.warn("Product migration persistence failed",e);}
}
let editingProduct=-1, deferredInstall=null;
// Inventory movement history is lazy-loaded; do not touch it during startup.


// Normalize records coming from older backups/imports so search, selection and
// product auto-fill work consistently across all previous schema variants.
function normalizeImportedRecords(){
 state.products=(Array.isArray(state.products)?state.products:[]).map(p=>({
   ...p,
   name:String(p?.name??p?.productName??p?.itemName??"").trim(),
   rate:Number(p?.rate??p?.price??p?.sellingPrice??0)||0,
   unit:String(p?.unit??p?.unitName??p?.uom??"kg")||"kg",
   hsn:String(p?.hsn??p?.hsnCode??"").trim(),taxRate:Number(p?.taxRate??p?.tax??0)||0
 })).filter(p=>p.name);
 state.customers=(Array.isArray(state.customers)?state.customers:[]).map(c=>({
   ...c,
   name:String(c?.name??c?.customerName??"").trim(),
   phone:normalizePhone(c?.phone??c?.mobile??c?.mobileNumber??c?.phoneNumber??""),
   notes:String(c?.notes??c?.note??c?.additionalDetails??"").trim(),
   gstin:String(c?.gstin??c?.gstinNumber??"").trim().toUpperCase(),fssai:String(c?.fssai??c?.fssaiNumber??"").trim(),state:String(c?.state??c?.customerState??"").trim(),paymentFollowUpDate:String(c?.paymentFollowUpDate??c?.nextPaymentReminderDate??"").trim()
 })).filter(c=>c.name);
}

function logoSource(){ return state.settings.logoData || "logo.jpg"; }
function setShopLogo(data){ state.settings.logoData=data||""; save(); refreshShopHeader(); if(window.currentBill) renderBill(window.currentBill); }
function clearShopLogo(){ state.settings.logoData=""; save(); refreshShopHeader(); if(window.currentBill) renderBill(window.currentBill); }

function refreshShopHeader(){
 const brand=$("shopBrand"), logo=$("shopLogoHeader");
 if(brand) brand.textContent=state.settings.shopName||"Your Shop";
 if(logo){ logo.src=logoSource(); logo.classList.toggle("hidden",!state.settings.logoData); }

}

refreshShopHeader();
setupLogoPicker();
// Migrate existing WebView local data into the native SQLite store on first run.
if(!nativeBridgePresent && window.Android?.saveAppState){ try{ save(); }catch(e){} }

function save(options={}){
 const __sbSaveStart=__sbTraceClock();
 if(nativeLoadFailed){console.error("SiddhiBill save blocked because native SQLite state did not load; reload the app to retry.");return false;}
 const payload={
  [firmStorageKey("pksProducts")]:JSON.stringify(state.products),
  [firmStorageKey("pksCustomers")]:JSON.stringify(state.customers),
  [firmStorageKey("pksVendors")]:JSON.stringify(state.vendors),
  [firmStorageKey("pksVendorPayments")]:JSON.stringify(state.vendorPayments),
  ...(!nativeBridgePresent&&!options.skipCustomerPayments?{[firmStorageKey("pksCustomerPayments")]:JSON.stringify(state.customerPayments)}:{}),
  [firmStorageKey("pksTeamMembers")]:JSON.stringify(state.teamMembers||[]),
  [firmStorageKey("pksTeamAttendance")]:JSON.stringify(state.teamAttendance||[]),
  [firmStorageKey("pksTeamPayments")]:JSON.stringify(state.teamPayments||[]),
  [firmStorageKey("pksBrokers")]:JSON.stringify(state.brokers||[]),
  [firmStorageKey("pksBrokerCommissions")]:JSON.stringify(state.brokerCommissions||[]),
  [firmStorageKey("pksBrokerPayments")]:JSON.stringify(state.brokerPayments||[]),
  [firmStorageKey("pksEstimates")]:JSON.stringify(state.estimates||[]),
  [firmStorageKey("pksExpenses")]:JSON.stringify(state.expenses||[]),
  [firmStorageKey("pksGstCompliance")]:JSON.stringify(state.gstCompliance||{}),
  [firmStorageKey("dukaanBillSettings")]:JSON.stringify(state.settings)
 };
 // Persist a large collection only after it has been explicitly loaded. This
 // prevents unrelated saves from pulling 10k+ transactions / inventory rows
 // into JavaScript and rewriting them back to SQLite.
 // Transaction histories are stored as individual SQLite rows on Android.
 // Never serialize an already-loaded 10k+ history as part of an ordinary save.
 if(!nativeBridgePresent){
  if(window.__siddhiLazyState?.bills?.()) payload[firmStorageKey("pksBills")]=JSON.stringify(state.bills);
  if(window.__siddhiLazyState?.purchases?.()) payload[firmStorageKey("pksPurchases")]=JSON.stringify(state.purchases);
  if(window.__siddhiLazyState?.inventoryMovements?.()) payload[firmStorageKey("pksInventoryMovements")]=JSON.stringify(state.inventoryMovements);
 }
 const __sbPayloadBuildMs=Math.round(__sbTraceClock()-__sbSaveStart);
 const __sbStorageStart=__sbTraceClock();
 try{ Object.entries(payload).forEach(([k,v])=>localStorage.setItem(k,v)); }catch(e){ console.warn("Web storage save failed",e); }
 // Keep browser-only mode backward compatible. Native Android transaction records
 // are committed explicitly by the bill/purchase save handlers below.
 const __sbLocalStorageMs=Math.round(__sbTraceClock()-__sbStorageStart);
 const __sbNativeStart=__sbTraceClock();
 let __sbNativePayloadChars=0;
 try{ if(window.Android?.saveAppState){const __sbNativePayload=JSON.stringify(payload);__sbNativePayloadChars=__sbNativePayload.length;Android.saveAppState(__sbNativePayload);} }catch(e){ console.warn("Native save failed",e); }
 const __sbNativeSaveMs=Math.round(__sbTraceClock()-__sbNativeStart);
 __sbTraceProfile("save() complete",__sbSaveStart,{payloadBuildMs:__sbPayloadBuildMs,localStorageMs:__sbLocalStorageMs,nativeSaveMs:__sbNativeSaveMs,nativePayloadChars:__sbNativePayloadChars,bills:window.__siddhiLazyState?.bills?.()?state.bills.length:null,purchases:window.__siddhiLazyState?.purchases?.()?state.purchases.length:null,inventoryMovements:window.__siddhiLazyState?.inventoryMovements?.()?state.inventoryMovements.length:null});
}
function today(){let d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
function displayDate(value){const v=String(value||"").slice(0,10);const m=v.match(/^(\d{4})-(\d{2})-(\d{2})$/);if(!m)return v;const d=new Date(Number(m[1]),Number(m[2])-1,Number(m[3]));return `${String(d.getDate()).padStart(2,"0")}/${["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][d.getMonth()]}/${d.getFullYear()}`}
if(billDate)billDate.value=today();$("customer").value="Walk-in Customer";
function money(n){return "₹"+Number(n||0).toFixed(2)}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]))}
let pendingConfirmAction=null;
function showNotice(message,title="SiddhiBill"){
  const m=$("appNoticeModal"); if(!m)return;
  $("appNoticeTitle").textContent=title; $("appNoticeMessage").textContent=String(message||""); m.classList.remove("hidden");
}
function closeNotice(){$("appNoticeModal")?.classList.add("hidden");}
if(nativeLoadFailed){showNotice("SiddhiBill could not read its local database. Your existing database has been protected from overwrite. Diagnostic: "+(window.siddhiBillNativeLoadError||"Unknown native state loading error")+". Please share this message with support. Do not clear app storage.","Local database load failed");}
function showConfirm(message,onOk,title="Confirm"){
  const m=$("appConfirmModal"); if(!m){onOk?.();return;}
  $("appConfirmTitle").textContent=title; $("appConfirmMessage").textContent=String(message||""); pendingConfirmAction=onOk; m.classList.remove("hidden");
}
function closeConfirm(){pendingConfirmAction=null;$("appConfirmModal")?.classList.add("hidden");}
$("appNoticeOk")?.addEventListener("click",closeNotice);
$("appConfirmCancel")?.addEventListener("click",closeConfirm);
$("appConfirmOk")?.addEventListener("click",()=>{const fn=pendingConfirmAction;closeConfirm();if(fn)fn();});

function nextTaxInvoiceNo(){const y=new Date().getFullYear();const n=Number(state.settings.taxInvoiceStart)||1;return `#${state.settings.taxInvoicePrefix||"INV"}-${y}/${String(n).padStart(3,"0")}`}
function nextBillNo(){const y=new Date().getFullYear(),start=Number(state.settings.billStart)||1;let next=start;try{if(nativeBridgePresent&&window.Android?.nextInvoiceSequence){const n=Number(Android.nextInvoiceSequence(String(state.settings.billPrefix||"PKS"),String(y),String(moduleShopKey()),String(start)));if(Number.isFinite(n)&&n>=start)next=n;else{console.error("Native invoice sequence lookup failed; using configured starting sequence to avoid loading bill history.");next=start;}}else{const nums=(state.bills||[]).map(b=>Number(String(b.billNo||"").split("/").pop())).filter(Number.isFinite);next=Math.max(start-1,...nums)+1;}}catch(e){console.error("Bounded invoice sequence lookup failed; refusing a full bill-history load",e);next=start;}return `#${state.settings.billPrefix||"PKS"}-${y}/${String(next).padStart(3,"0")}`}

const DEFAULT_UNIT_CATALOG=[
 {name:"kg",aliases:["kg","kgs","kilo","kilos","kilogram","kilograms"]},
 {name:"gram",aliases:["g","gm","gram","grams"]},
 {name:"mg",aliases:["mg","milligram","milligrams"]},
 {name:"piece",aliases:["piece","pieces","pc","pcs"]},
 {name:"packet",aliases:["packet","packets","pk","pkt","pks"]},
 {name:"pack",aliases:["pack","packs"]},
 {name:"box",aliases:["box","boxes"]},
 {name:"bottle",aliases:["bottle","bottles","bt"]},
 {name:"liter",aliases:["liter","litre","liters","litres","l","ltr","lt"]},
 {name:"ml",aliases:["ml","milliliter","milliliters","millilitre","millilitres"]},
 {name:"dozen",aliases:["dozen","dz"]},
 {name:"Roll",aliases:["roll","r","rl"]},
 {name:"Case",aliases:["case","ca","cs","carton"]},
 {name:"Each",aliases:["each","ea","unit"]}
];
function ensureUnitCatalog(){
 const existing=Array.isArray(state.settings.unitCatalog)?state.settings.unitCatalog:[];
 if(!existing.length){
   const legacy=Array.isArray(state.settings.customUnits)?state.settings.customUnits:[];
   const merged=DEFAULT_UNIT_CATALOG.map(x=>({name:x.name,aliases:[...x.aliases]}));
   legacy.forEach(u=>{const name=String(u?.name||"").trim();if(!name)return;const aliases=Array.isArray(u.aliases)?u.aliases.map(a=>String(a).trim().toLowerCase()).filter(Boolean):[];const k=name.toLowerCase();const hit=merged.find(x=>String(x.name).toLowerCase()===k);if(hit)hit.aliases=[...new Set([...hit.aliases,...aliases])];else merged.push({name,aliases:[k,...aliases]});});
   state.settings.unitCatalog=merged;
 }
 return state.settings.unitCatalog;
}
function getUnitDefinitions(){
 return ensureUnitCatalog().map(x=>({name:String(x.name||"").trim(),aliases:[String(x.name||"").trim().toLowerCase(),...(Array.isArray(x.aliases)?x.aliases.map(a=>String(a).trim().toLowerCase()).filter(Boolean):[])]})).filter(x=>x.name);
}

// Shop-specific OCR vocabulary. Product and unit lists are derived from live shop data,
// while aliases are learned only after an explicit confirmation by the shopkeeper/owner.
function ocrNorm(s){return String(s||"").toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g," ").trim().replace(/\s+/g," ");}
function ensureOcrAliases(){if(!state.settings.ocrProductAliases||typeof state.settings.ocrProductAliases!=="object"||Array.isArray(state.settings.ocrProductAliases))state.settings.ocrProductAliases={};return state.settings.ocrProductAliases;}
function getOcrProductVocabulary(){
 const aliases=ensureOcrAliases(),out=[];
 state.products.forEach(p=>{const name=String(p?.name||p?.productName||p?.itemName||"").trim();if(!name)return;const learned=Object.entries(aliases).filter(([a,target])=>ocrNorm(target)===ocrNorm(name)).map(([a])=>a);out.push({name,aliases:[...new Set(learned)]});});
 return out;
}
function renderOcrVocabulary(){
 const productBox=$("ocrProductVocabulary"),unitBox=$("ocrUnitVocabulary"),select=$("ocrAliasProduct");
 const products=getOcrProductVocabulary(),units=getUnitDefinitions();
 if(productBox)productBox.value=products.map(p=>p.name+(p.aliases.length?" (OCR aliases: "+p.aliases.join(", ")+")":"")).join("; ");
 if(unitBox)unitBox.value=units.map(u=>u.name+(u.aliases.length?" ("+[...new Set(u.aliases)].join(", ")+")":"")).join("; ");
 const ownerKeywords=$("ocrOwnerKeywords");if(ownerKeywords&&ownerKeywords!==document.activeElement)ownerKeywords.value=String(state.settings.ocrOwnerKeywords||"");
 if(select){const prior=select.value;select.innerHTML='<option value="">Select product</option>'+state.products.filter(p=>p?.name).map(p=>'<option value="'+esc(p.name)+'">'+esc(p.name)+'</option>').join("");if([...select.options].some(o=>o.value===prior))select.value=prior;}
}
function canonicalizeOcrProductName(name){
 const source=String(name||'').trim();if(!source)return source;
 const aliasLine=applyOcrProductAliasesToLine(source);
 if(aliasLine!==source)return aliasLine.trim();
 const norm=ocrNorm(source), compact=norm.replace(/\s+/g,'');
 const edit=(a,b)=>{let prev=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){const cur=[i];for(let j=1;j<=b.length;j++)cur[j]=Math.min(cur[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));prev=cur;}return prev[b.length];};
 const candidates=[];
 for(const entry of getOcrProductVocabulary()){
   const names=[entry.name,...(entry.aliases||[])];
   for(const candidate of names){const cn=ocrNorm(candidate),cc=cn.replace(/\s+/g,'');if(!cn)continue;
     if(cn===norm||cc===compact)return entry.name;
     const d=edit(compact,cc),max=Math.max(compact.length,cc.length),threshold=max>=8?2:(max>=5?1:0);
     // Require close spelling and comparable word coverage; never pick a near-tie.
     const words=norm.split(' ').filter(x=>x.length>1),cw=cn.split(' ').filter(x=>x.length>1),common=words.filter(x=>cw.includes(x)).length;
     if(d<=threshold&&d/Math.max(1,max)<=0.18&&(common>=Math.min(2,words.length)||d<=1))candidates.push({name:entry.name,d,ratio:d/Math.max(1,max)});
   }
 }
 candidates.sort((a,b)=>a.d-b.d||a.ratio-b.ratio);
 if(candidates.length&&!(candidates.length>1&&candidates[0].name!==candidates[1].name&&candidates[0].d===candidates[1].d&&Math.abs(candidates[0].ratio-candidates[1].ratio)<0.04))return candidates[0].name;
 return source;
}
function applyOcrProductAliasesToLine(line){
 const aliases=ensureOcrAliases();let out=String(line||"");
 // Longest aliases first, and only at the start of a row so prices/quantities are untouched.
 const entries=Object.entries(aliases).filter(([a,target])=>String(a).trim()&&state.products.some(p=>ocrNorm(p.name)===ocrNorm(target))).sort((a,b)=>b[0].length-a[0].length);
 for(const [alias,target] of entries){
   // An alias may be followed by invoice suffixes such as +20% EXTRA, a batch,
   // or punctuation. Match the alias only at the start and only when the next
   // character is not another letter/digit; retain all suffix text verbatim.
   const escaped=String(alias).trim().replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
   const re=new RegExp("^\\s*"+escaped+"(?=$|[^a-z0-9])","i");
   if(re.test(out)){const product=state.products.find(p=>ocrNorm(p.name)===ocrNorm(target));if(product){out=out.replace(re,product.name);break;}}
 }
 return out;
}
$("saveOcrAliasBtn")?.addEventListener("click",()=>{
 const observed=String($("ocrAliasObserved")?.value||"").trim(),target=String($("ocrAliasProduct")?.value||"").trim();
 if(!observed||!target){if($("ocrVocabularyStatus"))$("ocrVocabularyStatus").textContent="Enter the OCR spelling and select its correct catalogue product.";return;}
 if(ocrNorm(observed)===ocrNorm(target)){if($("ocrVocabularyStatus"))$("ocrVocabularyStatus").textContent="The OCR spelling already matches the product name.";return;}
 const product=state.products.find(p=>ocrNorm(p.name)===ocrNorm(target));if(!product){if($("ocrVocabularyStatus"))$("ocrVocabularyStatus").textContent="That product is no longer in this shop's catalogue.";return;}
 const aliases=ensureOcrAliases();aliases[observed]=product.name;save();$("ocrAliasObserved").value="";renderOcrVocabulary();if($("ocrVocabularyStatus"))$("ocrVocabularyStatus").textContent='Saved "'+observed+'" as an OCR alias for '+product.name+'. This correction is shop-specific and works offline.';
});

function openOcrVocabularyModal(){renderOcrVocabulary();$("ocrVocabularyModal")?.classList.remove("hidden");}
$("openOcrVocabularyProducts")?.addEventListener("click",openOcrVocabularyModal);
$("openOcrVocabularyUnits")?.addEventListener("click",openOcrVocabularyModal);
$("ocrVocabularyCancel")?.addEventListener("click",()=>$("ocrVocabularyModal")?.classList.add("hidden"));
$("saveOcrOwnerKeywords")?.addEventListener("click",()=>{state.settings.ocrOwnerKeywords=String($("ocrOwnerKeywords")?.value||"").trim();save();renderOcrVocabulary();if($("ocrVocabularyStatus"))$("ocrVocabularyStatus").textContent="Your shop keywords were saved and will be used as additional OCR hints.";});

ensureUnitCatalog();

function unitAliasPattern(){
 // Case/Each are accepted as invoice packaging units even when the shop has not
 // added them to its normal retail unit catalogue.
 const aliases=[...new Set([...getUnitDefinitions().flatMap(x=>x.aliases),"case","ca","cs","carton","each","ea","unit"])].sort((a,b)=>b.length-a.length);
 return aliases.map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|");
}
function normalizeUnitName(unit){
 const u=String(unit||"").toLowerCase().trim();
 for(const d of getUnitDefinitions()) if(d.aliases.includes(u)) return d.name;
 if(["case","ca","cs","carton"].includes(u))return "case";
 if(["each","ea"].includes(u))return "piece";
 if(["unit"].includes(u))return "Unit";
 return u||"piece";
}
function unitOptionsHtml(selected){
 const value=normalizeUnitName(selected||"piece");
 return getUnitDefinitions().map(d=>`<option value="${esc(d.name)}" ${d.name===value?"selected":""}>${esc(d.name)}</option>`).join("");
}
function isCountUnit(unit){return !["kg","gram","mg","dozen"].includes(normalizeUnitName(unit));}

function normalizeQtyForRow(row){
 const input=row.querySelector(".iqty");
 const select=row.querySelector(".iunit");
 const text=String(input.value||"").trim().toLowerCase().replace(/,/g," " ).replace(/\s+/g," ");
 const m=text.match(new RegExp(`^(\d+(?:\.\d+)?)\s*(?:(${unitAliasPattern()}))?$`,"i"));
 if(!m)return;
 input.value=m[1];
 if(m[2])select.value=normalizeUnitName(m[2]);
}

function parseQuickListLine(line, options={}){
 let raw=String(line||"").trim();
 if(!raw)return null;
 raw=raw.replace(/[|,;]/g," ").replace(/\s+/g," ").trim();
 raw=raw.replace(/^(?:add\s+)?(?:new\s+)?(?:item|tem)\s+/i,"").trim();
 let explicitHsn="";const hsnMatch=raw.match(/\s+HSN\s*:\s*([A-Za-z0-9/-]+)\s*$/i);if(hsnMatch){explicitHsn=hsnMatch[1];raw=raw.slice(0,hsnMatch.index).trim();}
 const units=unitAliasPattern();
 const defaultTaxRate=Object.prototype.hasOwnProperty.call(options,'defaultTaxRate')?options.defaultTaxRate:5;
 const allowBareTax=options.allowBareTax!==false;
 let taxRate=null;
 // Vendor Quick List requires an explicit percent/GST marker to avoid reading a price
 // ending in 5/12/18/28 as a tax rate. Customer billing retains its prior bare-tax behavior.
 const taxMatch=allowBareTax
   ? raw.match(/(?:\s+)(0|5|12|18|28)\s*%?\s*$/i)
   : raw.match(/(?:\s+)(?:GST\s*)?(0|5|12|18|28)\s*%\s*$/i);
 if(taxMatch){taxRate=Number(taxMatch[1]);raw=raw.slice(0,taxMatch.index).trim();}
 const rateMatch=raw.match(/(?:₹\s*)?(\d+(?:\.\d+)?)\s*(?:rs|rs\.|inr|rupees?)?\s*$/i);
 let rate=null, qty=null, explicitUnit="", name=raw;
 if(rateMatch){
   const trailing=Number(rateMatch[1]);
   const before=raw.slice(0,rateMatch.index).trim();
   const qtyMatch=before.match(new RegExp(`(\\d+(?:\\.\\d+)?)\\s*(?:(${units}))?\\s*$`,"i"));
   if(qtyMatch){
     qty=qtyMatch[1]; explicitUnit=qtyMatch[2]?normalizeUnitName(qtyMatch[2]):"";
     name=before.slice(0,qtyMatch.index).trim(); rate=trailing;
   }else{
     const savedOnly=findProduct(before);
     if(savedOnly){name=before;qty=String(trailing);rate=Number(savedOnly.rate);explicitUnit=savedOnly.unit||"";}
   }
 }
 name=name.replace(/\\bx\\s*$/i,"").trim();
 const numericQty=Number(qty), numericRate=Number(rate);
 if(!name || qty===null || rate===null || !Number.isFinite(numericQty) || numericQty<=0 || !Number.isFinite(numericRate) || numericRate<0){
   return {error:`${raw} — missing or invalid quantity/price. Use: Item Qty Unit Price.`};
 }
 const saved=findProduct(name);
 const unit=explicitUnit || (saved && saved.unit ? saved.unit : "piece");
 return {name,qty:String(numericQty),unit,rate:numericRate,taxRate:taxRate===null?defaultTaxRate:taxRate,hsn:explicitHsn};
}

function parseBillingQuickListEntry(line){
 const raw=String(line||"").trim();if(!raw)return null;
 const normalized=raw.replace(/[|,;]/g," ").replace(/\s+/g," ").trim();
 // Explicit six-column billing format: Item Qty+Unit Rate Tax HSN.
 // Examples: "ABC 2kg 100 5 12345678" and "Screw 2inch 100pc 2 5 132222222".
 // Parse the trailing numeric columns first so numbers embedded in product names are preserved.
 const structured=normalized.match(new RegExp(`^(.+?)\\s+(\\d+(?:\\.\\d+)?)\\s*(${unitAliasPattern()})\\s+(\\d+(?:\\.\\d+)?)\\s+(0|5|12|18|28)%?\\s+([A-Za-z0-9/-]{4,})$`,`i`));
 if(structured){
   const name=structured[1].trim(),qty=Number(structured[2]),unit=normalizeUnitName(structured[3]),rate=Number(structured[4]),taxRate=Number(structured[5]),hsn=String(structured[6]).trim();
   if(name&&qty>0&&Number.isFinite(rate)&&rate>=0)return {name,qty:String(qty),unit,rate,taxRate,hsn,preventFuzzyAutoFill:true};
 }
 // Billing Quick List four-part format: Item Qty Unit Rate.
 // Check this before parseQuickListLine because a final bare value such as 5
 // can otherwise be mistaken for a GST percentage.
 const simpleRateMatch=normalized.match(new RegExp(String.raw`^(.+?)\s+(\d+(?:\.\d+)?)\s*(${unitAliasPattern()})\s+(?:₹\s*)?(\d+(?:\.\d+)?)(?:\s+(?:GST\s*)?(0|5|12|18|28)\s*%?)?$`,"i"));
 if(simpleRateMatch){
   const name=simpleRateMatch[1].trim(),qty=Number(simpleRateMatch[2]),unit=normalizeUnitName(simpleRateMatch[3]),rate=Number(simpleRateMatch[4]),taxRate=simpleRateMatch[5]==null?0:Number(simpleRateMatch[5]);
   if(name&&qty>0&&Number.isFinite(rate)&&rate>=0)return {name,qty:String(qty),unit,rate,taxRate,hsn:"",preventFuzzyAutoFill:true};
 }
 const products=Array.isArray(state.products)?state.products:[];
 const exactByName=name=>products.find(p=>String(p?.name??p?.productName??p?.itemName??"").trim().toLowerCase()===String(name||"").trim().toLowerCase())||null;
 const fromMaster=(p,name,qty)=>({name:String(p?.name??p?.productName??p?.itemName??name).trim(),qty:String(qty),unit:normalizeUnitName(p?.unit||p?.unitName||p?.uom||"Piece"),rate:Number(p?.rate??p?.price??p?.sellingPrice??0)||"",taxRate:Number(p?.taxRate??p?.tax??0)||0,hsn:String(p?.hsn??p?.hsnCode??"").trim(),preventFuzzyAutoFill:true});
 // Exact Product Master name takes priority so names ending in a number, such as 500ml, stay intact.
 const exact=exactByName(normalized);
 if(exact)return fromMaster(exact,normalized,1);
 // Minimal format: product name followed by quantity. Resolve only exact master names;
 // an unknown name must not be fuzzy-matched to a different catalogue product.
 const qtyMatch=normalized.match(/^(.+?)\s+(\d+(?:\.\d+)?)$/);
 const hasFullFormat= new RegExp(`\\s\\d+(?:\\.\\d+)?\\s*(?:${unitAliasPattern()})\\s+\\d+(?:\\.\\d+)?(?:\\s+(?:GST\\s*)?(?:0|5|12|18|28)\\s*%?)?$`,`i`).test(normalized);
 if(qtyMatch&&!hasFullFormat){
   const name=qtyMatch[1].trim(),qty=Number(qtyMatch[2]);
   if(!name||!Number.isFinite(qty)||qty<=0)return {error:`${raw} — enter a product name and a quantity greater than zero.`};
   const product=exactByName(name);
   return product?fromMaster(product,name,qty):{name,qty:String(qty),unit:"Piece",rate:"",taxRate:0,hsn:"",preventFuzzyAutoFill:true};
 }
 // Preserve existing detailed Quick List formats (name, quantity, unit, rate, optional tax).
 const full=parseQuickListLine(raw);
 if(full&&!full.error){
   const product=exactByName(full.name);
   if(product){if(!String(full.hsn||"").trim())full.hsn=String(product.hsn??product.hsnCode??"").trim();if(!/(?:^|\s)(?:GST\s*)?(?:0|5|12|18|28)\s*%\s*$/i.test(raw))full.taxRate=Number(product.taxRate??product.tax??0)||0;}
   return full;
 }
 // Name-only fallback: unknown product stays intact, quantity defaults to one, and no price is invented.
 return {name:normalized,qty:"1",unit:"Piece",rate:"",taxRate:0,hsn:"",preventFuzzyAutoFill:true};
}

function addQuickList(){
 const viewportBefore={x:window.scrollX,y:window.scrollY};
 const box=$("quickList");
 const text=String(box.value||"").trim();
 if(!text){box.focus();return}
 const lines=text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 // A leading "Citem <comment>" line applies one comment to every item below it.
 // Example: Citem Handle with care
 let defaultItemComment="";
 if(lines.length && /^citem\s+/i.test(lines[0])){
   defaultItemComment=lines.shift().replace(/^citem\s+/i,"").trim();
   if(!defaultItemComment){alert('Enter comment text after "Citem", for example: Citem Handle with care');return;}
 }
 const parsed=[];const errors=[];
 for(const line of lines){
   if(/^(?:quick list(?:\s*-\s*ocr test)?|item\s*(?:\/|\|)?\s*qty(?:\s+unit)?(?:\s+unit price(?:\s*\([^)]*\))?)?|no\.?\s+item|please keep each item.*)$/i.test(line))continue;
   const item=parseBillingQuickListEntry(line);if(item?.error)errors.push(item.error);else if(item){if(defaultItemComment)item.comment=defaultItemComment;parsed.push(item)}
 }
 if(errors.length){
   box.classList.add("quicklist-invalid");
   alert("These rows need correction before they can be added. They have been highlighted in Quick List:\n\n"+errors.join("\n"));
   return;
 }
 box.classList.remove("quicklist-invalid");
 // Merge repeated item/unit/price rows before adding them to the bill.
 const merged=[]; const duplicateNotes=[]; const indexByKey=new Map();
 for(const item of parsed){
   const key=[item.name.trim().toLowerCase(),String(item.unit||'').trim().toLowerCase(),Number(item.rate).toFixed(2)].join('|');
   if(indexByKey.has(key)){
     const prior=merged[indexByKey.get(key)]; prior.qty=String(Number(prior.qty)+Number(item.qty)); duplicateNotes.push(item.name);
   }else{indexByKey.set(key,merged.length);merged.push({...item});}
 }
 if(duplicateNotes.length){
   alert(`Repeated items with the same unit price were found and merged: ${[...new Set(duplicateNotes)].join(', ')}. Quantities were added together.`);
 }
 parsed.length=0; parsed.push(...merged);
 // Keep the Quick List text on screen. Re-pressing Add List updates existing billing rows.
 const existingRows=[...items.children];
 const updated=[];
 const added=[];
 parsed.forEach(item=>{
   const key=item.name.trim().toLowerCase();
   const row=existingRows.find(r=>String(r.querySelector(".iname")?.value||"").trim().toLowerCase()===key);
   if(row){
     row.querySelector(".iqty").value=String(Number(item.qty||0));
     row.querySelector(".iunit").value=item.unit;
     row.querySelector(".irate").value=item.rate;
     if(row.querySelector(".itax") && state.settings.taxationEnabled) row.querySelector(".itax").value=String(item.taxRate??5);
     if(defaultItemComment && row.querySelector(".iComment")) row.querySelector(".iComment").value=defaultItemComment;
     normalizeQtyForRow(row);
     updated.push(item.name);
   }else{
     addItem(item);
     added.push(item.name);
   }
 });
 calc();
 // Adding a Quick List must not steal focus or jump the page to a newly added row.
 requestAnimationFrame(()=>window.scrollTo(viewportBefore.x,viewportBefore.y));
}

function addItem(item={name:"",qty:"",rate:0,unit:"piece",taxRate:5}){
 const row=document.createElement("div");row.className="item";
 const showTax=formTaxEnabled();
 const unit=normalizeUnitName(item.unit||"piece");
 const qtyText=String(item.qty??"").replace(new RegExp(`\\s*(?:${unitAliasPattern()})\\s*$`,"i"),"").trim();
 row.innerHTML=`<label class="item-name product-search-wrap">Item<input class="iname" autocomplete="off" value="${esc(item.name)}" placeholder="Search item name"><div class="product-suggestions hidden"></div></label>
 <div class="item-details">
   <label>Qty<input class="iqty" type="text" inputmode="decimal" value="${esc(qtyText)}" placeholder="2"></label>
   <label>Unit<select class="iunit">${unitOptionsHtml(unit)}</select></label>
   <label>Rate / Unit<input class="irate" type="number" min="0" step="0.01" value="${item.rate}"></label>
   <label class="tax-field ${showTax?"":"hidden"}">Tax<select class="itax"><option value="0">0%</option><option value="5">5%</option><option value="12">12%</option><option value="18">18%</option><option value="28">28%</option></select></label>
   <label class="tax-field ${showTax?"":"hidden"}">HSN<input class="ihsn" value="${esc(item.hsn??item.hsnCode??findProduct(item.name||"")?.hsn??findProduct(item.name||"")?.hsnCode??"")}" placeholder="HSN/SAC"></label>
   <label class="item-comment-label">Item Comment (optional)<textarea class="iComment" rows="2" placeholder="Comment for this item">${esc(item.comment||"")}</textarea></label>
   <div class="amount-cell"><label>Amount</label><div class="amount">₹0.00</div></div>
   <button class="remove" type="button" aria-label="Remove item">×</button>
 </div>`;
 items.appendChild(row);row.querySelector(".iunit").value=unit;
 const taxSelect=row.querySelector(".itax"); if(taxSelect){const p=findProduct(item.name||""); const savedTax=Number(item.taxRate??item.tax??(p&&Number(p.taxRate||0)>0?p.taxRate:5)); taxSelect.value=[0,5,12,18,28].includes(savedTax)?String(savedTax):"5";}
 if(!item.preventFuzzyAutoFill && String(item.name||"").trim() && (item.rate===undefined || Number(item.rate||0)===0)){ autoRate(row); }
 row.querySelectorAll("input,select,textarea").forEach(x=>x.addEventListener("input",()=>{
   if(x.classList.contains("iqty"))normalizeQtyForRow(row);
   if(x.classList.contains("irate")) row.dataset.userRateEdited="true";
   calc();
 }));
 // Search products like Customer Search instead of relying on a native dropdown.
 const nameInput=row.querySelector(".iname");
 const suggestionBox=row.querySelector(".product-suggestions");
 const applyProduct=()=>{ row.dataset.userRateEdited=""; autoRate(row); calc(); };
 const hideProductSuggestions=()=>{suggestionBox?.classList.add("hidden");if(suggestionBox)suggestionBox.innerHTML="";};
 const showProductSuggestions=()=>{
   if(!suggestionBox)return;
   const q=String(nameInput.value||"").trim().toLowerCase();
   const products=(Array.isArray(state.products)?state.products:[]).filter(p=>p&&String(p.name||p.productName||p.itemName||"").trim())
     .filter(p=>!q||String(p.name||p.productName||p.itemName||"").toLowerCase().includes(q)||String(p.itemCode||p.code||"").toLowerCase().includes(q))
     .slice(0,15);
   if(!products.length){hideProductSuggestions();return;}
   suggestionBox.innerHTML=products.map(p=>{const n=String(p.name||p.productName||p.itemName||"");return `<div class="product-suggestion" data-name="${esc(n)}" tabindex="0"><b>${esc(n)}</b>${p.itemCode?`<div class="muted">Code: ${esc(p.itemCode)}</div>`:""}${Number(p.rate||0)>0?`<div class="muted">Rate: ₹${Number(p.rate).toFixed(2)}${p.unit?` / ${esc(p.unit)}`:""}</div>`:""}</div>`}).join("");
   suggestionBox.classList.remove("hidden");
   suggestionBox.querySelectorAll(".product-suggestion").forEach(el=>{
     const choose=()=>{nameInput.value=el.dataset.name||"";hideProductSuggestions();applyProduct();nameInput.focus();};
     el.addEventListener("mousedown",e=>{e.preventDefault();choose();});
     el.addEventListener("click",choose);
     el.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();choose();}});
   });
 };
 nameInput.addEventListener("focus",showProductSuggestions);
 nameInput.addEventListener("click",showProductSuggestions);
 nameInput.addEventListener("input",()=>{row.dataset.userRateEdited="";showProductSuggestions();});
 nameInput.addEventListener("change",()=>{hideProductSuggestions();applyProduct();});
 nameInput.addEventListener("blur",()=>{setTimeout(()=>{hideProductSuggestions();const inputValue=String(nameInput.value||"").trim().toLowerCase();const exact=(state.products||[]).find(p=>String(p.name||p.productName||p.itemName||"").trim().toLowerCase()===inputValue||String(p.itemCode||p.code||"").trim().toLowerCase()===inputValue);if(exact){nameInput.value=String(exact.name||exact.productName||exact.itemName||"");applyProduct();}},120);});
 row.querySelector(".iqty").addEventListener("blur",()=>{normalizeQtyForRow(row);calc()});
 row.querySelector(".remove").onclick=()=>{row.remove();calc()};
 calc();
}
function autoRate(row){
 const name=row.querySelector(".iname").value.trim();
 if(!name)return;
 const rateInput=row.querySelector(".irate");
 // Only supply the product-master rate if this is a newly named/empty row.
 // Once the user has edited the rate, clearing it must remain blank until
 // the user enters a new rate.
 if(!row.dataset.userRateEdited){
   const p=findProduct(name);
   if(p){
     rateInput.value=Number(p.rate||0);
     rateInput.dataset.autoFilled="true";
     row.querySelector(".iunit").value=normalizeUnitName(p.unit||"piece");
     const ts=row.querySelector(".itax"); if(ts) ts.value=String(Number(p.taxRate??p.tax??0)||0);
     const hsn=row.querySelector(".ihsn"); if(hsn&&!hsn.value.trim()) hsn.value=String(p.hsn??p.hsnCode??"").trim();
   }
 }
}

// Quantity is stored/displayed as text. The Unit field controls how the rate is applied.
// kg/gram are converted to kg for a Rate/kg product; piece/packet/box/etc. stay as counts.
function quantityValue(qtyText, defaultUnit="piece"){
 const text=String(qtyText??"").trim().toLowerCase().replace(/,/g," ").replace(/\s+/g," ");
 if(!text)return 0;
 let n=Number(text);
 let rawUnit=String(defaultUnit||"piece");
 const m=text.match(/^(\d+(?:\.\d+)?)(?:\s+(.+))?$/);
 if(m){n=Number(m[1]);if(m[2])rawUnit=m[2].trim();}
 if(!Number.isFinite(n)||n<0)return 0;
 const unit=normalizeUnitName(rawUnit);
 if(unit==="mg")return n/1000000;
 if(unit==="ml")return n/1000;
 if(unit==="gram")return n/1000;
 if(unit==="dozen")return n*12;
 return n;
}
function qtyDisplayUnit(qtyText,defaultUnit="piece"){return normalizeUnitName(defaultUnit||"piece");}
function getBillTotals(){
 let subtotal=0;
 const lines=[];
 [...items.children].forEach(r=>{
   const q=quantityValue(r.querySelector(".iqty").value,r.querySelector(".iunit").value),rate=Number(r.querySelector(".irate").value)||0,gross=q*rate;
   subtotal+=gross;
   const ts=r.querySelector(".itax"); const taxRate=formTaxEnabled()?(Number(ts?.value)||0):0;
   const amountEl=r.querySelector(".amount");if(amountEl)amountEl.textContent=money(gross);
   lines.push({row:r,gross,taxRate});
 });
 const type=$("discountType")?.value||"percent";
 const value=Math.max(0,Number($("discountValue")?.value)||0);
 const discount=type==="amount"?Math.min(value,subtotal):Math.min(subtotal,subtotal*value/100);
 let taxTotal=0,taxableValue=0;
 lines.forEach(x=>{
   const netGross=subtotal>0?x.gross*(subtotal-discount)/subtotal:x.gross;
   const inclusive=$("billAmountsIncludeTax")?!!$("billAmountsIncludeTax").checked:true;
   const base=formTaxEnabled() && x.taxRate>0?(inclusive?netGross/(1+x.taxRate/100):netGross):netGross;
   const tax=formTaxEnabled() && x.taxRate>0?(inclusive?netGross-base:netGross*x.taxRate/100):0;
   x.netGross=netGross;x.taxable=base;x.tax=tax;taxableValue+=base;taxTotal+=tax;
 });
 const inclusive=$("billAmountsIncludeTax")?!!$("billAmountsIncludeTax").checked:true;
 const calculatedTotal=Math.max(0,subtotal-discount+(formTaxEnabled()&&!inclusive?taxTotal:0));
 const roundedTotal=Math.round(calculatedTotal+Number.EPSILON);
 const roundOff=roundMoney(roundedTotal-calculatedTotal);
 return {subtotal,discount,calculatedTotal,roundOff,total:roundMoney(roundedTotal),discountType:type,discountValue:value,taxableValue,taxTotal,lines};
}

function calc(){
 const t=getBillTotals();
 $("subTotal").textContent=money(t.subtotal);
 $("discountAmount").textContent=money(t.discount);
 $("grandTotal").textContent=money(t.total);
 const roundRow=$("billRoundOffRow");if(roundRow)roundRow.hidden=Math.abs(t.roundOff)<0.005;const roundAmount=$("billRoundOffAmount");if(roundAmount)roundAmount.textContent=(t.roundOff>0?"+₹":"-₹")+Math.abs(t.roundOff).toFixed(2);
}
function customBillFieldDefinitions(){
 const x=state.settings||{};
 return [
  {key:"field1",label:String(x.customBillField1Label||"").trim(),position:x.customBillField1Position||"header",type:"text"},
  {key:"field2",label:String(x.customBillField2Label||"").trim(),position:x.customBillField2Position||"header",type:"text"},
  {key:"field3",label:String(x.customBillField3Label||"").trim(),position:x.customBillField3Position||"footer",type:"date"}
 ];
}
function renderCustomBillInputs(values={}){
 const host=$("customBillingFields");if(!host)return;
 host.innerHTML="";
 customBillFieldDefinitions().forEach(def=>{
  if(!def.label)return;
  const label=document.createElement("label");label.textContent=def.label;
  const input=document.createElement("input");input.id="billCustom_"+def.key;input.dataset.customBillKey=def.key;input.type=def.type;input.value=String(values?.[def.key]||"");input.placeholder=def.type==="date"?"Select date":"Enter "+def.label.toLowerCase();
  label.appendChild(input);host.appendChild(label);
 });
 host.classList.toggle("hidden",!host.children.length);
}
function readCustomBillFields(){const values={};customBillFieldDefinitions().forEach(def=>{const el=$("billCustom_"+def.key);values[def.key]=el?String(el.value||"").trim():String(window.__editingCustomBillFields?.[def.key]||"").trim();});return values;}
function customBillFieldsMarkup(b,position){return customBillFieldDefinitions().filter(d=>d.label&&d.position===position&&String(b?.customFields?.[d.key]||"").trim()).map(d=>`<div class="custom-bill-value${d.key==="field3"?" custom-bill-date-value":""}"><b>${esc(d.label)}:</b> <span>${esc(b.customFields[d.key])}</span></div>`).join("");}
function clearBill(){
 window.convertingEstimateId=null;
 $("customer").value="Walk-in Customer";
 $("quickList").value="";
 // Clear the Quick List product search controls as well as its multiline text.
 const quickSearch=$("quickListProductSearch");if(quickSearch)quickSearch.value="";
 const quickSuggestions=$("quickListProductSuggestions");if(quickSuggestions){quickSuggestions.innerHTML="";quickSuggestions.classList.add("hidden");}
 if($("quickListProductQty"))$("quickListProductQty").value="1";
 if($("quickListProductRate"))$("quickListProductRate").value="";
 if($("quickListProductTax"))$("quickListProductTax").value="5";
 if($("quickListProductHsn"))$("quickListProductHsn").value="";
 if($("quickListProductUnit"))$("quickListProductUnit").value="piece";
 hideCustomerSuggestions();
 $("customer").dataset.phone="";
 items.innerHTML="";
 $("billDate").value=today();
 
 $("paymentMode").value="Cash";
 if($("partialPaymentAmount"))$("partialPaymentAmount").value="0";
 if($("partialPaymentMode"))$("partialPaymentMode").value="Cash";if($("partialPaymentTransactionNo"))$("partialPaymentTransactionNo").value="";if($("partialPaymentChequeNo"))$("partialPaymentChequeNo").value="";if($("partialPaymentChequeDate"))$("partialPaymentChequeDate").value="";
 if($("partialPaymentWrap"))$("partialPaymentWrap").classList.add("hidden");
 if($("includeItemComments"))$("includeItemComments").checked=false;
 if($("overallBillComment"))$("overallBillComment").value="";
 if($("includeOverallComment"))$("includeOverallComment").checked=false;
 if($("includeLast5TransactionsBilling"))$("includeLast5TransactionsBilling").checked=false;
 $("discountType").value="percent";
 $("discountValue").value="0";
 if($("placeOfSupply")) $("placeOfSupply").value=state.settings.businessState||"";
 if($("billBrokerSelect"))$("billBrokerSelect").value="";
 if($("billSalespersonSelect"))$("billSalespersonSelect").value="";
 window.__editingCustomBillFields={};renderCustomBillInputs({});
 hideCustomerSuggestions();
 window.editingBillNo=null;
 window.editingBillRecord=null;
 window.editingTaxInvoice=false;
 const taxToggle=$("billTaxToggle"); if(taxToggle) taxToggle.checked=!!state.settings.taxationEnabled;
 syncTaxUi();
 const btn=$("generateBtn"); if(btn) btn.textContent="Generate Bill";
 const mode=$("billingModeLabel"); if(mode) mode.textContent="Create a new bill";
 calc();
}
function loadBillForEdit(b){
 window.editingBillRecord=b;
 window.editingBillNo=b.billNo;
 window.editingTaxInvoice=!!b.taxationEnabled;
 if($("billTaxToggle")) $("billTaxToggle").checked=!!b.taxationEnabled;
 syncTaxUi();
 $("customer").value=(b.customer&&b.customer!=="Walk-in Customer")?b.customer:"Walk-in Customer";
 $("customer").dataset.phone=normalizePhone(b.customerPhone||"");
 $("billDate").value=b.date||today();
 
 $("paymentMode").value=b.paymentMode||"Cash";
 if($("partialPaymentAmount"))$("partialPaymentAmount").value=String(b.partialPaymentAmount||0);if($("partialPaymentMode"))$("partialPaymentMode").value=b.partialPaymentMode||"Cash";if($("partialPaymentTransactionNo"))$("partialPaymentTransactionNo").value=b.partialPaymentTransactionNo||"";if($("partialPaymentChequeNo"))$("partialPaymentChequeNo").value=b.partialPaymentChequeNo||"";if($("partialPaymentChequeDate"))$("partialPaymentChequeDate").value=b.partialPaymentChequeDate||"";
 if($("partialPaymentWrap"))$("partialPaymentWrap").classList.toggle("hidden",(b.paymentMode||"Cash")!=="Credit");
 if($("includeItemComments"))$("includeItemComments").checked=!!b.includeItemComments;
 if($("overallBillComment"))$("overallBillComment").value=b.overallComment||"";
 if($("includeOverallComment"))$("includeOverallComment").checked=!!b.includeOverallComment;
 if($("includeLast5TransactionsBilling"))$("includeLast5TransactionsBilling").checked=!!b.includeLast5Transactions;
 $("discountType").value=b.discountType||"percent";
 $("discountValue").value=String(b.discountValue??0);
 if($("placeOfSupply")) $("placeOfSupply").value=b.placeOfSupply||state.settings.businessState||"";
 renderBrokerSelect(b);
 window.__editingCustomBillFields=Object.assign({},b.customFields||{});renderCustomBillInputs(b.customFields||{});
 items.innerHTML="";
 (b.items||[]).forEach(it=>addItem(it));
 const btn=$("generateBtn"); if(btn) btn.textContent="Update Bill";
 const mode=$("billingModeLabel"); if(mode) mode.textContent="Editing "+(b.billNo||"bill");
 calc(); showPage("billing");
}
function startNewBill(){clearBill();showPage("billing");}

window.__pageHistory = ["billing"];
function syncNavigation(name){
 document.querySelectorAll(".bottom-tab[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===name));
 const primary=["billing","history","reports"];
 const moreActive=!primary.includes(name);
 $("moreNavBtn")?.classList.toggle("active",moreActive);
 $("morePurchasingItem")?.classList.toggle("hidden",state.settings.vendorManagement===false);
 $("inventoryHomeTile")?.classList.toggle("hidden",state.settings.inventoryManagement!==true);
 document.querySelectorAll("[data-home-page=inventory]").forEach(el=>el.classList.toggle("hidden",state.settings.inventoryManagement!==true));
}
function closeMoreMenu(){ $("moreMenu")?.classList.add("hidden"); }
function showPage(name, addHistory=true){
 if(name==="customers"){customerQuery="";customerPage=1;if($("customerPageSearch"))$("customerPageSearch").value="";}
 if(name==="units"){ensureUnitCatalog();renderCustomUnits();resetCustomUnitEditor();}
 if(name==="products"){productQuery="";productPage=1;if($("productPageSearch"))$("productPageSearch").value="";}
 if(name==="billing" && addHistory){hideCustomerSuggestions();}
 if(name==="purchases" && state.settings.vendorManagement===false){name="billing";}
 if(name==="inventory" && state.settings.inventoryManagement!==true){name="billing";}
 const current=window.__pageHistory[window.__pageHistory.length-1];
 if(addHistory && current!==name) window.__pageHistory.push(name);
 document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
 const page=$(name+"Page"); if(page)page.classList.add("active");
 syncNavigation(name);
 closeMoreMenu();
 if(name==="products")renderProducts();if(name==="history")renderHistory();if(name==="reports")renderReports();if(name==="purchases"){renderVendorEntryScreen();showVendorSection("purchaseEntryCard");}if(name==="customers")renderCustomers();if(name==="team")renderTeamModule();if(name==="brokers")renderBrokerModule();if(name==="estimates")renderEstimateModule();if(name==="expenses")renderExpenses();if(name==="profitLoss")renderProfitLoss();if(name==="gstCompliance")renderGstCompliance();if(name==="billing"){const bill=window.editingBillRecord||null;renderBrokerSelect(bill);renderSalespersonSelect(bill);}if(name==="backup")try{window.Android?.refreshAutoBackupStatus?.();}catch(e){}if(name==="settings")loadSettings();if(name==="inventory"){renderInventory();sbpInitGroupInventory();}if(name==="banking")renderBanking();if(name==="home")updateHomeShopName();refreshOwnerDashboardButton();
 window.scrollTo(0,0);
}
document.querySelectorAll(".bottom-tab[data-page]").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
$("moreNavBtn")?.addEventListener("click",()=>$("moreMenu").classList.toggle("hidden"));
$("closeMoreBtn")?.addEventListener("click",closeMoreMenu);
document.querySelectorAll(".more-item[data-page]").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
$("manageUnitsBtn")?.addEventListener("click",()=>showPage("units"));
$("ownerModeBtn")?.addEventListener("click",()=>window.Android?.openOwnerMode?.());
$("ownerDashboardTopBtn")?.addEventListener("click",()=>{if(window.Android?.openOwnerMode) Android.openOwnerMode();});
$("homeOwnerDashboardTile")?.addEventListener("click",()=>{if(window.Android?.isOwnerDevice?.() && window.Android?.openOwnerMode) Android.openOwnerMode();});
function refreshOwnerDashboardButton(){let ok=false;try{ok=!!(window.Android?.isOwnerDevice?.());}catch(e){}["ownerDashboardTopBtn","ownerModeBtn","homeOwnerDashboardTile"].forEach(id=>$(id)?.classList.toggle("hidden",!ok));}
setTimeout(refreshOwnerDashboardButton,300);
$("homeDashboardBtn")?.addEventListener("click",()=>showPage("home"));
document.querySelectorAll("[data-home-page]").forEach(b=>b.addEventListener("click",()=>{const target=b.dataset.homePage;if(target==="more"){$("moreMenu")?.classList.remove("hidden");return}if(target==="billing")clearBill();showPage(target)}));
function updateHomeShopName(){const n=$("homeShopName");if(n)n.textContent=state.settings.shopName||"Your Shop";}
setTimeout(updateHomeShopName,300);
setInterval(refreshOwnerDashboardButton,1000);
$("newBillBtn")?.addEventListener("click",()=>startNewBill());
window.addEventListener("message",function(event){if(event&&event.data&&event.data.type==="siddhibill-ledger-back"){showPage("reports");}});
window.handleAndroidBack=function(){
 const openModal=document.querySelector(".modal:not(.hidden)");
 if(openModal){openModal.classList.add("hidden");return true;}
 if(window.__pageHistory.length>1){
   window.__pageHistory.pop();
   const previous=window.__pageHistory[window.__pageHistory.length-1]||"billing";
   showPage(previous,false);
   return true;
 }
 return false;
};
$("addItemBtn").onclick=()=>addItem();$("quickListBtn").onclick=addQuickList;initQuickListProductSearch();$("clearBtn").onclick=()=>clearBill();
$("discountType").onchange=calc;$("discountValue").oninput=calc;

function initQuickListProductSearch(){
 const $q=id=>document.getElementById(id),search=$q("quickListProductSearch"),list=$q("quickListProductSuggestions"),qty=$q("quickListProductQty"),unit=$q("quickListProductUnit"),rate=$q("quickListProductRate"),tax=$q("quickListProductTax"),hsn=$q("quickListProductHsn"),add=$q("quickListAddSelectedBtn");
 if(!search||!list||!qty||!unit||!rate||!tax||!hsn||!add)return;
 unit.innerHTML=unitOptionsHtml("piece");
 const taxWrap=$q("quickListProductTaxWrap"),hsnWrap=$q("quickListProductHsnWrap");
 const syncTax=()=>{const on=formTaxEnabled();taxWrap.classList.toggle("hidden",!on);hsnWrap.classList.toggle("hidden",!on);};
 const hide=()=>{list.classList.add("hidden");list.innerHTML="";};
 const aliasMap=()=>state.settings?.ocrProductAliases||{};
 const render=()=>{const q=search.value.trim().toLowerCase(),products=(state.products||[]).filter(p=>p&&String(p.name||p.productName||p.itemName||"").trim()).filter(p=>{const name=String(p.name||p.productName||p.itemName||"");const aliases=Object.entries(aliasMap()).filter(([,target])=>String(target||"").trim().toLowerCase()===name.trim().toLowerCase()).map(([a])=>a);return !q||name.toLowerCase().includes(q)||String(p.itemCode||p.code||p.barcode||"").toLowerCase().includes(q)||aliases.some(a=>a.toLowerCase().includes(q));}).slice(0,15);if(!products.length){hide();return;}list.innerHTML=products.map((p,i)=>`<div class="product-suggestion" data-index="${i}" tabindex="0"><b>${esc(p.name||p.productName||p.itemName||"")}</b><div class="muted">${esc(p.unit||p.unitName||p.uom||"piece")}${Number(p.rate??p.price??p.sellingPrice??0)>0?` · ₹${Number(p.rate??p.price??p.sellingPrice).toFixed(2)}`:""}${formTaxEnabled()?` · GST ${Number(p.taxRate??p.tax??0)||0}%`:""}</div></div>`).join("");list.classList.remove("hidden");list.querySelectorAll(".product-suggestion").forEach(el=>{const choose=()=>{const p=products[Number(el.dataset.index)];search.value=String(p.name||p.productName||p.itemName||"");unit.value=normalizeUnitName(p.unit||p.unitName||p.uom||"piece");rate.value=Number(p.rate??p.price??p.sellingPrice??0)||"";tax.value=String([0,5,12,18,28].includes(Number(p.taxRate??p.tax))?Number(p.taxRate??p.tax):5);hsn.value=String(p.hsn??p.hsnCode??p.hsnSac??"");qty.value="1";hide();qty.focus();qty.select();};el.addEventListener("mousedown",e=>{e.preventDefault();choose();});el.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();choose();}});});};
 search.addEventListener("input",()=>{if(search.value.trim())render();else hide();});search.addEventListener("focus",()=>{if(search.value.trim())render();else hide();});search.addEventListener("blur",()=>setTimeout(hide,150));$q("billTaxToggle")?.addEventListener("change",syncTax);syncTax();
 add.addEventListener("click",()=>{const name=search.value.trim();if(!name){hide();search.blur();return;}const n=Number(qty.value||1);if(!Number.isFinite(n)||n<=0){qty.focus();qty.select();return;}const line=`${name} ${n} ${unit.value||"piece"} ${String(rate.value||"0")}${formTaxEnabled()?` ${Number(tax.value||0)}%`:""}${formTaxEnabled()&&hsn.value.trim()?` HSN:${hsn.value.trim()}`:""}`;const box=$q("quickList");box.value=box.value.trim()?box.value.trimEnd()+"\n"+line:line;box.dispatchEvent(new Event("input",{bubbles:true}));const savedScrollX=window.scrollX,savedScrollY=window.scrollY;addQuickList();search.value="";qty.value="1";rate.value="";tax.value="5";hsn.value="";hide();requestAnimationFrame(()=>{try{search.focus({preventScroll:true});}catch(e){search.focus();}window.scrollTo(savedScrollX,savedScrollY);});});
}

function normalizeVoiceText(text){return String(text||"").replace(/[₹,]/g," ").replace(/[;|]/g," ").replace(/\s+/g," ").trim()}
function cleanCommandText(text){return normalizeVoiceText(text).replace(/\b(?:please|pls|kindly)\b/gi," ").replace(/\s+/g," ").trim()}

// Common speech-recognition substitutions. These are deliberately conservative.
function normalizeSpokenNumbers(text){
 let s=String(text||"").toLowerCase();
 const replacements={"one":"1","two":"2","three":"3","four":"4","five":"5","six":"6","seven":"7","eight":"8","nine":"9","ten":"10","half":"0.5"};
 for(const [w,n] of Object.entries(replacements))s=s.replace(new RegExp(`\\b${w}\\b`,"gi"),n);
 // Android speech recognition sometimes hears "two" as "to" or "too".
 // Only treat those as 2 when they occur immediately after a quantity keyword.
 s=s.replace(/\b(quantity|qty|quanity|quant|qnty)\s+(?:to|too|tu)\b/gi,"$1 2");
 return s;
}

function normalizeUnits(text){
 return text.toLowerCase()
   .replace(/\bkilograms?\b/g,"kg").replace(/\bkilos?\b/g,"kg").replace(/\bkgs?\b/g,"kg")
   .replace(/\bgrams?\b/g,"gram").replace(/\bgms?\b/g,"gram").replace(/\bmilligrams?\b/g,"mg");
}
function normalizeForParsing(text){return normalizeUnits(normalizeSpokenNumbers(cleanCommandText(text))).replace(/\s+/g," ").trim()}

function levenshtein(a,b){
 a=a.toLowerCase();b=b.toLowerCase();
 const dp=Array.from({length:a.length+1},()=>Array(b.length+1).fill(0));
 for(let i=0;i<=a.length;i++)dp[i][0]=i;
 for(let j=0;j<=b.length;j++)dp[0][j]=j;
 for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++)dp[i][j]=Math.min(dp[i-1][j]+1,dp[i][j-1]+1,dp[i-1][j-1]+(a[i-1]===b[j-1]?0:1));
 return dp[a.length][b.length];
}
function findProduct(spoken){
 const s=String(spoken||"").trim().toLowerCase();if(!s)return null;
 let exact=state.products.find(p=>p.name.toLowerCase()===s);if(exact)return exact;
 let best=null,bestScore=Infinity;
 for(const p of state.products){
   const n=String(p.name??p.productName??p.itemName??"").toLowerCase();
   let d=levenshtein(s,n);
   if(s.includes(n)||n.includes(s))d=Math.min(d,1);
   const threshold=Math.max(2,Math.floor(Math.max(s.length,n.length)*0.4));
   if(d<=threshold&&d<bestScore){best=p;bestScore=d}
 }
 return best;
}

function addProductIfMissing(name,rate,unit="piece"){
 const clean=String(name||"").trim();
 const r=Number(rate)||0;
 if(!clean)return false;
 const chosenUnit=normalizeUnitName(unit||"piece");
 const existing=state.products.find(p=>String(p.name||p.productName||p.itemName||"").trim().toLowerCase()===clean.toLowerCase());
 if(existing){
   let changed=false;
   if((!Number(existing.rate)||Number(existing.rate)===0)&&r>0){existing.rate=r;changed=true;}
   // Sales bill unit is the latest explicitly selected unit for this product.
   if(chosenUnit&&normalizeUnitName(existing.unit||existing.unitName||existing.uom||"piece")!==chosenUnit){existing.unit=chosenUnit;changed=true;}
   if(changed)save();
   return false;
 }
 state.products.push({name:clean,rate:Math.max(0,r),unit:chosenUnit});
 save();
 renderDatalist();renderCustomerDatalist();renderCustomUnits();refreshUnitControls();renderOcrVocabulary();document.body.classList.toggle("taxation-on",!!state.settings.taxationEnabled);document.querySelectorAll(".tax-field").forEach(x=>x.classList.toggle("hidden",!state.settings.taxationEnabled));if($("placeOfSupply"))$("placeOfSupply").value=state.settings.businessState||"";
 return true;
}

function extractQuantity(raw){
 const r=normalizeForParsing(raw);
 // First isolate the words between quantity and rate. This prevents the rate number
 // from ever being accidentally joined to the quantity (for example 1 kg + 50).
 let phrase="";
 const between=r.match(/\b(?:quantity|qty|quanity|quant|qnty)\s*[:=-]?\s*(.*?)\s+(?=(?:rate|price|cost|rs|rupees|rupay|rupaye|right)\b)/i);
 if(between) phrase=between[1].trim();
 else {
   const direct=r.match(/\b(?:quantity|qty|quanity|quant|qnty)\s*[:=-]?\s*(\d+(?:\.\d+)?)\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pk|pkt|pks|pack|packs|box|boxes|bottle|bottles|dozen)?\b/i);
   if(direct) return {value:Number(direct[1]),unit:direct[2]||"",text:direct[1]};
 }
 if(phrase){
   const m=phrase.match(/^(\d+(?:\.\d+)?)\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pk|pkt|pks|pack|packs|box|boxes|bottle|bottles|dozen)?\b/i);
   if(m)return {value:Number(m[1]),unit:m[2]||"",text:m[1]};
 }
 // Also allow: Add Item Sugar 1 kg Rate 50
 const m2=r.match(/\b(?:item|add\s+item|new\s+item)\b\s+.*?\b(\d+(?:\.\d+)?)\s*(kg|kgs|kilo|kilos|kilogram|kilograms|g|gm|gram|grams|mg|milligram|milligrams|piece|pieces|pc|pcs|packet|packets|pk|pkt|pks|pack|packs|box|boxes|bottle|bottles|dozen)\b/i);
 if(m2)return {value:Number(m2[1]),unit:m2[2],text:m2[1]};
 return null;
}
function extractRate(raw){
 const r=normalizeForParsing(raw);
 const m=r.match(/\b(?:rate|price|cost|rs|rupees|rupay|rupaye|right)\s*[:=-]?\s*(?:₹\s*)?(\d+(?:\.\d+)?)\b/i);
 return m?Number(m[1]):null;
}
function extractItemName(raw,qty,rate){
 let s=normalizeForParsing(raw);
 // "Item" is optional. Accept "Colgate quantity 1 rate 100",
 // "Add Colgate quantity 1 rate 100", "Tem Colgate...", etc.
 s=s.replace(/^(?:add\s+)?(?:new\s+)?(?:item|tem)\b\s*/i,"");
 s=s.replace(/\b(?:quantity|qty|quanity|quant|qnty)\s*[:=-]?\s*\d+(?:\.\d+)?\s*(?:kg|gram|g|mg)?\b.*$/i,"");
 s=s.replace(/\b(?:rate|price|cost|rs|rupees|rupay|rupaye|right)\s*[:=-]?\s*\d+(?:\.\d+)?\b.*$/i,"");
 if(qty)s=s.replace(new RegExp(`\\s${qty.value}(?:\\s${qty.unit})?\\s*$`,"i"),"");
 return s.replace(/\s+/g," ").trim();
}

function parseVoice(text){
 const raw=normalizeForParsing(text);if(!raw)return null;
 if(/^(?:customer|grahak)\b/i.test(raw))return {type:"customerIgnored"};
  const qty=extractQuantity(raw);const rate=extractRate(raw);
 if(!qty||rate===null)return null;
 let name=extractItemName(raw,qty,rate);
 if(!name)return null;
 let product=findProduct(name);
 if(!product){
   const words=name.split(/\s+/).filter(Boolean);
   for(let i=0;i<words.length&&!product;i++){
     for(let j=words.length;j>i;j--){
       const candidate=findProduct(words.slice(i,j).join(" "));
       if(candidate){product=candidate;break;}
     }
   }
 }
 const finalName=product?product.name:name;
 const qtyText=qty.text;
 const unit=normalizeUnitName(qty.unit||product?.unit||"piece");
 if(quantityValue(qtyText,unit)<=0)return null;
 return {type:"item",name:finalName,qty:qtyText,unit,rate,matched:!!product,spokenName:name};
}

let billingPaymentMeta={mode:"Cash",transactionNo:"",chequeNo:"",chequeDate:""};
let billingPaymentMetaConfirmed=true;
function syncBillingPaymentMetaSummary(){
 const box=$("billingPaymentInfoSummary"); if(!box)return;
 const m=billingPaymentMeta;
 let text="";
 if(m.mode==="UPI"||m.mode==="Card")text=m.transactionNo?`${m.mode} reference: ${m.transactionNo}`:"";
 if(m.mode==="Cheque")text=m.chequeNo?`Cheque ${m.chequeNo}${m.chequeDate?" · "+m.chequeDate:""}`:"";
 box.textContent=text;box.classList.toggle("hidden",!text);
}
function openBillingPaymentInfo(mode){
 const modal=$("billingPaymentInfoModal"); if(!modal)return;
 $("billingPaymentInfoTitle").textContent=mode==="Cheque"?"Cheque Details":`${mode} Transaction Details`;
 $("billingTransactionWrap").classList.toggle("hidden",mode==="Cheque");
 $("billingChequeFields").classList.toggle("hidden",mode!=="Cheque");
 $("billingTransactionNo").value=billingPaymentMeta.mode===mode?billingPaymentMeta.transactionNo:"";
 $("billingChequeNo").value=billingPaymentMeta.mode===mode?billingPaymentMeta.chequeNo:"";
 $("billingChequeDate").value=billingPaymentMeta.mode===mode?billingPaymentMeta.chequeDate:"";
 modal.dataset.mode=mode;modal.classList.remove("hidden");
}
$("billingPaymentInfoCancel")?.addEventListener("click",()=>{
 const mode=$("billingPaymentInfoModal")?.dataset.mode||$("paymentMode").value||"Cash";
 // Details are optional: Cancel closes the dialog and proceeds with blank references.
 billingPaymentMeta={mode,transactionNo:"",chequeNo:"",chequeDate:""};
 billingPaymentMetaConfirmed=true;
 $("billingPaymentInfoModal")?.classList.add("hidden");
 syncBillingPaymentMetaSummary();
});
$("billingPaymentInfoSave")?.addEventListener("click",()=>{
 const mode=$("billingPaymentInfoModal")?.dataset.mode||$("paymentMode").value;
 const transactionNo=String($("billingTransactionNo")?.value||"").trim();
 const chequeNo=String($("billingChequeNo")?.value||"").trim();
 const chequeDate=String($("billingChequeDate")?.value||"").trim();
 // Transaction and cheque metadata are optional; allow saving empty fields.
 billingPaymentMeta={mode,transactionNo:mode==="UPI"||mode==="Card"?transactionNo:"",chequeNo:mode==="Cheque"?chequeNo:"",chequeDate:mode==="Cheque"?chequeDate:""};
 billingPaymentMetaConfirmed=true;$("billingPaymentInfoModal")?.classList.add("hidden");syncBillingPaymentMetaSummary();
});
$("paymentMode")?.addEventListener("change",()=>{
 const mode=$("paymentMode").value;
 if($("partialPaymentWrap"))$("partialPaymentWrap").classList.toggle("hidden",mode!=="Credit");
 if(mode!=="Credit"&&$("partialPaymentAmount"))$("partialPaymentAmount").value="0";
 if(["UPI","Card","Cheque"].includes(mode)){billingPaymentMetaConfirmed=false;openBillingPaymentInfo(mode);}
 else {billingPaymentMeta={mode,transactionNo:"",chequeNo:"",chequeDate:""};billingPaymentMetaConfirmed=true;syncBillingPaymentMetaSummary();}
});

$("generateBtn").onclick=()=>{
 const taxMode=formTaxEnabled();
 const selectedPaymentMode=$("paymentMode").value||"Cash";
 if(["UPI","Card","Cheque"].includes(selectedPaymentMode) && (!billingPaymentMetaConfirmed || billingPaymentMeta.mode!==selectedPaymentMode)){
   // Open the optional details dialog once for the selected payment mode; blank details are allowed.
   openBillingPaymentInfo(selectedPaymentMode);return;
 }
 const existingBill=window.editingBillNo?(window.editingBillRecord||null):null;
 const rows=[...items.children].map(r=>({name:r.querySelector(".iname").value.trim(),itemCode:String(findProduct(r.querySelector(".iname").value.trim())?.itemCode||findProduct(r.querySelector(".iname").value.trim())?.code||""),qty:r.querySelector(".iqty").value.trim(),rate:Number(r.querySelector(".irate").value)||0,unit:r.querySelector(".iunit").value||"kg",taxRate:taxMode?(Number(r.querySelector(".itax")?.value)||0):0,hsn:taxMode?String(r.querySelector(".ihsn")?.value||findProduct(r.querySelector(".iname").value.trim())?.hsn||findProduct(r.querySelector(".iname").value.trim())?.hsnCode||"").trim():"",comment:String(r.querySelector(".iComment")?.value||"").trim()})).filter(x=>x.name&&quantityValue(x.qty,x.unit)>0);
 if(!rows.length){alert("Add at least one item.");return}
 if(state.settings.inventoryManagement===true){const shortages=[];rows.forEach(row=>{const p=inventoryProductByName(row.name);if(p?.trackInventory===true){const qty=inventoryQty(row.qty,row.unit,p);const available=Number(p.stockQty)||0;if(available-qty<0)shortages.push(`${p.name}: available ${available}, requested ${qty}`);}});if(shortages.length&&!window.confirm("Insufficient stock warning:\n\n"+shortages.join("\n")+"\n\nContinue with negative stock?"))return;}
 for(const row of rows)addProductIfMissing(row.name,row.rate,row.unit);
 const t=getBillTotals();
 const partialPayment=taxMode && false ? 0 : (($("paymentMode").value||"Cash")==="Credit"?Math.max(0,Number($("partialPaymentAmount")?.value||0)):0);
 if(partialPayment>t.total+0.005){alert("Partial payment cannot exceed the bill total.");$("partialPaymentAmount")?.focus();return;}
 const customer=$("customer").value.trim()||"Walk-in Customer";
 if(partialPayment>0&&customer==="Walk-in Customer"){alert("Select a named customer to record a partial payment against a credit bill.");$("customer")?.focus();return;}
 const selectedPhone=normalizePhone($("customer").dataset.phone||"");
 const exactCustomers=state.customers.filter(c=>String(c.name||"").trim().toLowerCase()===customer.toLowerCase());
 // Free-typed new customers must be saved as customer records before generating the bill.
 if(customer!=="Walk-in Customer" && exactCustomers.length===0){
   // Use the full Customer Master form so all customer details can be entered before the bill is saved.
   const modal=$("customerAddModal");
   if(modal){
     openCustomerAddModal();
     $("addCustomerName").value=customer;
     $("addCustomerPhone").value=selectedPhone||"";
     modal.dataset.billingContinue="1";
     const heading=modal.querySelector("h3");if(heading)heading.textContent="Add Customer Before Saving Bill";
     const saveBtn=$("addCustomerSave");if(saveBtn)saveBtn.textContent="Save Customer & Continue";
     $("addCustomerName")?.focus();
   }else{
     showNotice("The Customer setup form is unavailable. Open Customer Master and add this customer before generating the bill.","Customer Setup");
   }
   return;
 }
 const customerPhone=selectedPhone || (exactCustomers.length===1 ? normalizePhone(exactCustomers[0].phone||"") : "");
 
 
 const matchedCustomer=exactCustomers.length===1?exactCustomers[0]:null;
 const customerGstin=matchedCustomer?String(matchedCustomer.gstin||"").trim().toUpperCase():"";
 const customerFssai=matchedCustomer?String(matchedCustomer.fssai||"").trim():String(existingBill?.customerFssai||"").trim();
 if(taxMode && (!customer || customer==="Walk-in Customer")){alert("Customer name is required for a tax invoice.");$("customer")?.focus();return;}
 const chosenBrokerId=String($("billBrokerSelect")?.value||"");const chosenBroker=(state.brokers||[]).find(x=>String(x.id)===chosenBrokerId&&x.active!==false&&moduleRecordShopKey(x)===moduleShopKey());const chosenSalespersonId=String($("billSalespersonSelect")?.value??existingBill?.salespersonId??"");const chosenSalesperson=moduleRows(state.teamMembers).find(x=>String(x.id)===chosenSalespersonId&&x.active!==false&&moduleSalesTrackingEnabled(x));const bill={billNo:(existingBill&&!!existingBill.taxationEnabled===!!taxMode)?String(existingBill.billNo):(taxMode?nextTaxInvoiceNo():nextBillNo()),date:$("billDate").value,customer,customerPhone,customerGstin,customerFssai,customerAddress:String(matchedCustomer?.address||existingBill?.customerAddress||"").trim(),customerState:String(matchedCustomer?.state||existingBill?.customerState||"").trim(),amountsIncludeTax:$("billAmountsIncludeTax")?!!$("billAmountsIncludeTax").checked:(existingBill?.amountsIncludeTax!==false),paymentMode:$("paymentMode").value||"Cash",paymentTransactionNo:billingPaymentMeta.transactionNo||"",paymentChequeNo:billingPaymentMeta.chequeNo||"",paymentChequeDate:billingPaymentMeta.chequeDate||"",partialPaymentAmount:$("paymentMode").value==="Credit"?Math.max(0,Number($("partialPaymentAmount")?.value||0)):0,partialPaymentMode:String($("partialPaymentMode")?.value||"Cash"),partialPaymentTransactionNo:String($("partialPaymentTransactionNo")?.value||""),partialPaymentChequeNo:String($("partialPaymentChequeNo")?.value||""),partialPaymentChequeDate:String($("partialPaymentChequeDate")?.value||""),includeItemComments:!!$("includeItemComments")?.checked,overallComment:String($("overallBillComment")?.value||"").trim(),includeOverallComment:!!$("includeOverallComment")?.checked,includeLast5Transactions:!!$("includeLast5TransactionsBilling")?.checked,paymentFollowUpDate:String(existingBill?.paymentFollowUpDate||""),customerTotalBalance:customer==="Walk-in Customer"?0:Math.max(0,Number(typeof customerDue==="function"?customerDue(customer):0)+Math.max(0,t.total-partialPayment)),items:rows,subtotal:t.subtotal,discountType:t.discountType,discountValue:t.discountValue,discount:t.discount,calculatedTotal:t.calculatedTotal,roundOff:t.roundOff,taxationEnabled:taxMode,taxableValue:t.taxableValue,taxTotal:t.taxTotal,total:t.total,placeOfSupply:$("placeOfSupply")?.value||existingBill?.placeOfSupply||state.settings.businessState||"",gstin:taxMode?(state.settings.gstin||existingBill?.gstin||""):(existingBill?.gstin||""),businessState:taxMode?(state.settings.businessState||existingBill?.businessState||""):(existingBill?.businessState||""),fssai:taxMode?(state.settings.fssai||existingBill?.fssai||""):(existingBill?.fssai||""),customFields:readCustomBillFields(),shopKey:moduleShopKey(),salespersonId:chosenSalesperson?chosenSalesperson.id:"",salespersonName:chosenSalesperson?chosenSalesperson.name:"",brokerId:chosenBroker?chosenBroker.id:"",brokerName:chosenBroker?chosenBroker.name:"",brokerCommissionRate:chosenBroker?Number(chosenBroker.commissionRate)||0:0,brokerCommissionAmount:chosenBroker?roundMoney(t.total*(Number(chosenBroker.commissionRate)||0)/100):0};
 // Every bill must carry its firm identity. SQLite's bill key is shopKey|billNo.
 bill.shopKey=moduleShopKey();
 bill.shopName=moduleCurrentShop();
 if(window.editingBillNo){
   const oldNo=String(window.editingBillNo),prior=window.editingBillRecord;
   if(!prior||String(prior.billNo)!==oldNo||moduleRecordShopKey(prior)!==moduleShopKey()){showNotice('The selected bill details are no longer available. Return to Bill History and open the bill again before updating.','Bill not updated');return;}
   const wasTax=!!prior.taxationEnabled;
   if(wasTax===taxMode)bill.billNo=String(prior.billNo);
   else { if(taxMode) state.settings.taxInvoiceStart=(Number(state.settings.taxInvoiceStart)||1)+1; else state.settings.billStart=(Number(state.settings.billStart)||1)+1; }
   if(window.__siddhiLazyState?.bills?.()){
     const arr=state.bills,idx=arr.findIndex(x=>String(x.billNo)===oldNo&&moduleRecordShopKey(x)===moduleShopKey());
     if(idx>=0)arr.splice(idx,1);state.bills=arr.filter(x=>String(x.billNo)!==String(bill.billNo)||moduleRecordShopKey(x)!==moduleShopKey());state.bills.unshift(bill);
   }
 }else { if(window.__siddhiLazyState?.bills?.())state.bills.unshift(bill); if(taxMode) state.settings.taxInvoiceStart=(Number(state.settings.taxInvoiceStart)||1)+1; else state.settings.billStart=(Number(state.settings.billStart)||1)+1; }
 // Keep any partial payment as a linked customer receipt so outstanding and transaction history reconcile.
 const oldBillNo=window.editingBillNo;
 let billPartialPaymentRecord=null;
 if(oldBillNo) state.customerPayments=state.customerPayments.filter(p=>String(p.sourceBillNo||"")!==String(oldBillNo));
 if(partialPayment>0 && customer!=="Walk-in Customer") {billPartialPaymentRecord={id:"bill-partial-"+bill.billNo,sourceBillNo:bill.billNo,billNo:bill.billNo,customer,shopKey:moduleShopKey(),shopName:moduleCurrentShop(),date:bill.date||today(),amount:partialPayment,note:"Partial payment against "+bill.billNo,mode:bill.partialPaymentMode||"Cash",paymentMode:bill.partialPaymentMode||"Cash",transactionNo:bill.partialPaymentTransactionNo||"",chequeNo:bill.partialPaymentChequeNo||"",chequeDate:bill.partialPaymentChequeDate||""};state.customerPayments.unshift(billPartialPaymentRecord);}
 if(state.settings.inventoryManagement===true)postBillInventoryMovement(bill,oldBillNo);
 if(typeof syncBillBrokerCommission==="function")syncBillBrokerCommission(bill,oldBillNo);
 if(window.convertingEstimateId){const est=(state.estimates||[]).find(x=>String(x.id)===String(window.convertingEstimateId));if(est){est.status="converted";est.convertedBillNo=bill.billNo;est.convertedAt=new Date().toISOString();}window.convertingEstimateId=null;}
 save({skipCustomerPayments:!!nativeBridgePresent});__customerBillSummaryCache=null;
 if(nativeBridgePresent && window.Android?.saveTransactionRecord){
   try{
     if(oldBillNo && String(oldBillNo)!==String(bill.billNo)){Android.deleteTransactionRecord?.("pksBills",moduleShopKey()+"|"+String(oldBillNo));}
     if(Android.saveTransactionRecord("pksBills",JSON.stringify(bill))===false)throw new Error("Native bill record save returned false");
     if(oldBillNo)Android.deleteTransactionRecord?.("pksCustomerPayments","bill-partial-"+String(oldBillNo));
     if(billPartialPaymentRecord&&Android.saveTransactionRecord("pksCustomerPayments",JSON.stringify(billPartialPaymentRecord))===false)throw new Error("Native partial payment save returned false");
   }catch(e){console.error("Bill record persistence failed",e);showNotice("Bill was updated on screen but its database record could not be confirmed. Do not close the app; please retry and share diagnostics.","Bill save warning");}
 }
 // Keep the generated bill in edit mode until the user explicitly starts a New Bill.
 // This prevents returning to Billing and generating the same items as a new bill number.
 window.editingBillNo=bill.billNo;
 window.editingBillRecord=bill;
 window.editingTaxInvoice=!!bill.taxationEnabled;
 syncTaxUi();
 const gen=$("generateBtn"); if(gen) gen.textContent="Update Bill";
 renderBill(bill); showPage("preview"); $("previewPage").classList.add("active");
};

let suppressCustomerSuggestionInput=false;
function hideCustomerSuggestions(){const box=$("customerSuggestions");if(box){box.classList.add("hidden");box.innerHTML=""}}
function showCustomerSuggestions(){
 const box=$("customerSuggestions"), input=$("customer"); if(!box||!input)return;
 let q=input.value.trim().toLowerCase();
 // Treat the default Walk-in Customer value as empty while searching.
 if(q==="walk-in customer") q="";
 const matches=getCustomerRecords().filter(c=>{const name=String(c.name??c.customerName??"");const phone=normalizePhone(c.phone??c.mobile??c.mobileNumber??c.phoneNumber??"");const notes=String(c.notes??c.note??c.additionalDetails??"");const phoneQ=normalizePhone(q); return !q||name.toLowerCase().includes(q)|| (phoneQ && phone.includes(phoneQ)) || notes.toLowerCase().includes(q);}).slice(0,20);
 if(!matches.length){hideCustomerSuggestions();return}
 box.innerHTML=matches.map((c,i)=>`<div class="customer-suggestion" data-name="${esc(c.name)}" data-phone="${esc(c.phone??c.mobile??c.mobileNumber??c.phoneNumber??"")}" tabindex="0"><b>${esc(c.name)}</b>${(c.phone??c.mobile??c.mobileNumber??c.phoneNumber)?`<div class="muted">${esc(c.phone??c.mobile??c.mobileNumber??c.phoneNumber)}</div>`:""}</div>`).join("");
 box.querySelectorAll(".customer-suggestion").forEach(el=>{
   const choose=e=>{e?.preventDefault?.();e?.stopPropagation?.();suppressCustomerSuggestionInput=true;input.value=el.dataset.name||"";input.dataset.phone=normalizePhone(el.dataset.phone||"");const cc=getCustomerRecords().find(c=>String(c.name||"").trim().toLowerCase()===String(input.value||"").trim().toLowerCase());if($("placeOfSupply")&&cc?.state)$("placeOfSupply").value=cc.state;hideCustomerSuggestions();setTimeout(()=>{suppressCustomerSuggestionInput=false;},80);};
   el.addEventListener("pointerdown",choose,{passive:false});
   el.addEventListener("touchstart",choose,{passive:false});
   el.addEventListener("mousedown",choose,{passive:false});
   el.addEventListener("click",choose);
   el.addEventListener("keydown",e=>{if(e.key==="Enter"){choose(e);}});
 });
 box.classList.remove("hidden");
}
$("customer")?.addEventListener("focus",e=>{if(e.target.value.trim().toLowerCase()==="walk-in customer")e.target.select();showCustomerSuggestions();});
$("customer")?.addEventListener("click",showCustomerSuggestions);
$("customer")?.addEventListener("input",e=>{e.target.dataset.phone="";if(!suppressCustomerSuggestionInput)showCustomerSuggestions();});
document.addEventListener("click",e=>{if(!e.target.closest(".customer-search-wrap"))hideCustomerSuggestions()});
document.addEventListener("click",e=>{if(!e.target.closest(".product-search-wrap"))document.querySelectorAll(".product-suggestions").forEach(box=>{box.classList.add("hidden");box.innerHTML=""})});
$("customer")?.addEventListener("blur",()=>{const c=findCustomer($("customer").value);if(c){$("customer").dataset.phone=normalizePhone(c.phone||c.mobile||c.mobileNumber||c.phoneNumber||"");}});

function setupLogoPicker(){
 const input=$("logoFile"),preview=$("logoPreview");
 if(!input)return;
 input.onchange=()=>{
  const file=input.files&&input.files[0];if(!file)return;
  if(!/^image\/(png|jpeg|webp)$/i.test(file.type)){showNotice("Please select a PNG, JPG or WebP image.","Shop Logo");input.value="";return;}
  const reader=new FileReader();
  reader.onload=()=>{
   const src=String(reader.result||"");const img=new Image();
   img.onload=()=>{
    const max=900,scale=Math.min(1,max/Math.max(img.naturalWidth||1,img.naturalHeight||1));
    const w=Math.max(1,Math.round((img.naturalWidth||1)*scale)),h=Math.max(1,Math.round((img.naturalHeight||1)*scale));
    const c=document.createElement("canvas");c.width=w;c.height=h;const ctx=c.getContext("2d");ctx.fillStyle="#fff";ctx.fillRect(0,0,w,h);ctx.drawImage(img,0,0,w,h);
    const data=c.toDataURL("image/jpeg",0.84);setShopLogo(data);if(preview)preview.src=data;input.value="";showNotice("Shop logo updated successfully.","Shop Logo");
   };
   img.onerror=()=>showNotice("The selected image could not be read.","Shop Logo");img.src=src;
  };
  reader.onerror=()=>showNotice("Could not read the selected image.","Shop Logo");reader.readAsDataURL(file);
 };
 $("clearLogoBtn")?.addEventListener("click",()=>{clearShopLogo();if(preview)preview.src="logo.jpg";input.value="";});
}

function normalizePhone(phone){
 let p=String(phone||"").replace(/\D/g,"");
 if(p.startsWith("0091") && p.length===14)p=p.slice(4);
 else if(p.startsWith("91") && p.length===12)p=p.slice(2);
 return p;
}
function isValidMobile(phone){ return /^\d{10}$/.test(normalizePhone(phone)); }
function normalizeShopMobiles(value){
 const arr=Array.isArray(value)?value:(String(value||"").split(/[\n,;/|]+/));
 const out=[]; arr.forEach(v=>{const n=normalizePhone(v);if(/^\d{10}$/.test(n)&&!out.includes(n))out.push(n);}); return out;
}
function getShopMobiles(){ const arr=normalizeShopMobiles(state.settings.shopMobiles); if(!arr.length&&state.settings.shopMobile)return normalizeShopMobiles(state.settings.shopMobile); return arr; }
function shopMobileText(){return getShopMobiles().join(", ");}
function migrateMobileNumbers(){
 // Customer master is small and safe to normalize during startup. Sales history
 // is intentionally NOT traversed here; it remains lazy until a sales screen needs it.
 state.customers.forEach(c=>{ const n=normalizePhone(c.phone); if(/^\d{10}$/.test(n)) c.phone=n; });
}
const __sbMigrationStart=__sbTraceClock();
let __sbOpStart=__sbTraceClock();
migrateMobileNumbers();
__sbTraceProfile("startup migration: migrateMobileNumbers",__sbOpStart,{customers:state.customers.length,bills:"deferred"});
__sbOpStart=__sbTraceClock();
normalizeImportedRecords();
__sbTraceProfile("startup migration: normalizeImportedRecords",__sbOpStart,{products:state.products.length,customers:state.customers.length});
__sbOpStart=__sbTraceClock();
normalizeVendorSchema();
__sbTraceProfile("startup migration: normalizeVendorSchema",__sbOpStart,{vendors:state.vendors.length,purchases:"deferred"});
__sbTraceProfile("startup migrations TOTAL",__sbMigrationStart,{bills:"deferred",purchases:"deferred"});
__sbTraceMark("startup migrations complete");
// Persist only the small master/settings keys touched by startup migrations.
// Never call save() here: full-state save forces both large transaction histories
// to load and transfers their combined payload back through the Android bridge.
function saveStartupMigrations(){
 if(nativeLoadFailed)return false;
 const values={[firmStorageKey("pksProducts")]:JSON.stringify(state.products),[firmStorageKey("pksCustomers")]:JSON.stringify(state.customers),[firmStorageKey("pksVendors")]:JSON.stringify(state.vendors),[firmStorageKey("pksVendorPayments")]:JSON.stringify(state.vendorPayments),[firmStorageKey("pksTeamMembers")]:JSON.stringify(state.teamMembers),[firmStorageKey("pksTeamAttendance")]:JSON.stringify(state.teamAttendance),[firmStorageKey("pksTeamPayments")]:JSON.stringify(state.teamPayments),[firmStorageKey("pksBrokers")]:JSON.stringify(state.brokers),[firmStorageKey("pksBrokerCommissions")]:JSON.stringify(state.brokerCommissions),[firmStorageKey("pksBrokerPayments")]:JSON.stringify(state.brokerPayments),[firmStorageKey("pksEstimates")]:JSON.stringify(state.estimates),[firmStorageKey("pksExpenses")]:JSON.stringify(state.expenses),[firmStorageKey("pksGstCompliance")]:JSON.stringify(state.gstCompliance),[firmStorageKey("dukaanBillSettings")]:JSON.stringify(state.settings)};
 try{Object.entries(values).forEach(([k,v])=>localStorage.setItem(k,v));}catch(e){console.warn("Startup migration local persistence failed",e);}
 try{
  if(window.Android?.saveAppStateValue){
   Object.entries(values).forEach(([k,v])=>window.Android.saveAppStateValue(k,v));
  }else if(!nativeBridgePresent&&window.Android?.saveAppState){
   window.Android.saveAppState(JSON.stringify(values));
  }
 }catch(e){console.warn("Startup migration native persistence failed",e);}
 return true;
}
const __sbStartupPersistStart=__sbTraceClock();
saveStartupMigrations();
__sbTraceProfile("startup targeted master save",__sbStartupPersistStart,{keys:4,transactionHistories:"not loaded or rewritten"});
__sbTraceMark("startup save complete");
function findCustomerByNameOrPhone(name,phone){
 const n=String(name||"").trim().toLowerCase();
 const p=normalizePhone(phone);
 return state.customers.find(c=>{
   const sameName=n && String(c.name||"").trim().toLowerCase()===n;
   const samePhone=p && normalizePhone(c.phone)===p;
   return sameName || samePhone;
 })||null;
}
function saveCustomer(name,phone,openingBalance=0){
 name=String(name||"").trim(); phone=normalizePhone(phone);
 if(!name||!isValidMobile(phone))return false;
 const existing=state.customers.find(c=>normalizePhone(c.phone)===phone || String(c.name||"").trim().toLowerCase()===name.toLowerCase());
 if(existing){existing.name=name;existing.phone=phone;if(openingBalance!==undefined)existing.openingBalance=Number(openingBalance||0);}
 else state.customers.unshift({name,phone,openingBalance:Number(openingBalance||0)});
 state.customers=state.customers.slice(0,500);save();renderCustomerDatalist();renderCustomers();
 return true;
}

$("newBillingCustomerCancel")?.addEventListener("click",()=>$("newBillingCustomerModal")?.classList.add("hidden"));
$("newBillingCustomerSave")?.addEventListener("click",()=>{
 const name=String($("newBillingCustomerName")?.value||"").trim();
 const phone=normalizePhone($("newBillingCustomerPhone")?.value||"");
 if(!name){showNotice("Enter the customer name.","Customer Details");$("newBillingCustomerName")?.focus();return;}
 if(!/^\d{10}$/.test(phone)){showNotice("Enter a valid 10 digit customer mobile number.","Customer Details");$("newBillingCustomerPhone")?.focus();return;}
 const samePhone=state.customers.find(c=>normalizePhone(c.phone||c.mobile||c.mobileNumber||"")===phone);
 if(samePhone && String(samePhone.name||"").trim().toLowerCase()!==name.toLowerCase()){
   showConfirm(`Mobile ${phone} already belongs to ${samePhone.name}. Use that existing customer instead?`,()=>{
     $("customer").value=samePhone.name;$("customer").dataset.phone=phone;$("newBillingCustomerModal")?.classList.add("hidden");hideCustomerSuggestions();showNotice("Existing customer selected for this bill. Add items and tap Generate Bill when ready.","Customer Details");
   },"Customer Already Exists");return;
 }
 const existing=state.customers.find(c=>String(c.name||"").trim().toLowerCase()===name.toLowerCase());
 if(existing)existing.phone=phone;else state.customers.unshift({name,phone,openingBalance:0});
 state.customers=state.customers.slice(0,500);save();renderCustomerDatalist();renderCustomers();
 $("customer").value=name;$("customer").dataset.phone=phone;$("newBillingCustomerModal")?.classList.add("hidden");hideCustomerSuggestions();showNotice("New customer selected for this bill. Add items and tap Generate Bill when ready.","Customer Details");
});

function findCustomer(name){return state.customers.find(c=>c.name.toLowerCase()===String(name||"").trim().toLowerCase())||null}
function renderCustomerDatalist(){
 let dl=document.getElementById("customerNames");if(!dl){dl=document.createElement("datalist");dl.id="customerNames";document.body.appendChild(dl)}
 dl.innerHTML="";state.customers.forEach(c=>{const o=document.createElement("option");o.value=c.name;o.label=c.phone||"";dl.appendChild(o)});
}
async function drawBillImage(b){
 const logo=new Image(); logo.src=logoSource();
 try{await new Promise((resolve,reject)=>{logo.onload=resolve;logo.onerror=reject})}catch(e){}
 const scale=2,w=900,pad=45,rowH=billTaxEnabled(b)?64:54,headH=70;
 const customDefs=customBillFieldDefinitions();const customHeader=customDefs.filter(d=>d.label&&d.position==="header"&&String(b.customFields?.[d.key]||"").trim());const customFooter=customDefs.filter(d=>d.label&&d.position==="footer"&&String(b.customFields?.[d.key]||"").trim());const h=620+headH+b.items.length*rowH+(customHeader.length+customFooter.length)*26;
 const c=document.createElement("canvas");c.width=w*scale;c.height=h*scale;const x=c.getContext("2d");x.scale(scale,scale);
 x.fillStyle="#fff";x.fillRect(0,0,w,h);
 x.textAlign="center";
 let hy=20;
 if(state.settings.printShopLogo!==false&&logo.complete&&logo.naturalWidth){x.drawImage(logo,(w-85)/2,hy,85,85);hy+=100;}
 x.fillStyle="#24466f";if(state.settings.printShopName!==false){x.font="bold 34px sans-serif";x.fillText(state.settings.shopName||"Your Shop",w/2,hy);hy+=30;}
 x.font="18px sans-serif";
 const address=state.settings.printShopAddress!==false?String(state.settings.address||""):"";
 if(address){address.split(/\n+/).forEach(line=>{x.fillText(line,w/2,hy);hy+=22;});}
 if(state.settings.tagline){hy+=10;x.font="bold 16px sans-serif";x.fillText(state.settings.tagline,w/2,hy);hy+=22;}
 if(state.settings.printShopMobile!==false&&state.settings.shopMobile){hy+=5;x.font="17px sans-serif";x.fillText("Mo: "+state.settings.shopMobile,w/2,hy);hy+=22;}
 x.font="bold 22px sans-serif";x.fillText((billTaxEnabled(b)?(state.settings.taxBillTitle||"TAX INVOICE"):(state.settings.billTitle||"CASH MEMO / BILL")),w/2,hy);
 x.textAlign="left";x.fillStyle="#111";x.font="18px sans-serif";
 const metaY=hy+34;
 x.fillText("Bill No: "+b.billNo,45,metaY);x.fillText("Date: "+b.date.split("-").reverse().join("/"),560,metaY);
 x.fillText("Customer: "+(b.customer||"Cash Sale"),45,metaY+28);if(b.customerPhone){x.textAlign="right";x.fillText("Mobile: "+String(b.customerPhone),w-45,metaY+28);x.textAlign="left";}
 let customHeaderY=metaY+48;
 const printDetails=[];
 const customerAddress=String(b.customerAddress||b.address||"").trim(); if(billTaxEnabled(b)&&customerAddress) printDetails.push("Address: "+customerAddress);
 if(billTaxEnabled(b)){
   const customerGstin=String(b.customerGstin||"").trim(); if(customerGstin) printDetails.push("Customer GSTIN: "+customerGstin); const customerFssai=String(b.customerFssai||"").trim(); if(billTaxEnabled(b)&&customerFssai) printDetails.push("Customer FSSAI: "+customerFssai);
   const shopGstin=String(b.gstin||state.settings.gstin||"").trim(); if(shopGstin) printDetails.push("GSTIN: "+shopGstin);
   const fssai=String(b.fssai||state.settings.fssai||"").trim(); if(fssai) printDetails.push("FSSAI: "+fssai);
 }
 if(state.settings.printPaymentMode!==false) printDetails.push("Payment Mode: "+String(b.paymentMode||"Cash"));
 const wrapCanvasText=(value,maxWidth)=>{const output=[];String(value).split(/\n/).forEach(part=>{let current="";part.split(/\s+/).forEach(word=>{const candidate=current?current+" "+word:word;if(current&&x.measureText(candidate).width>maxWidth){output.push(current);current=word;}else current=candidate;});if(current)output.push(current);});return output;};
 printDetails.forEach(line=>{x.font="15px sans-serif";for(const wrappedLine of wrapCanvasText(line,w-90)){x.fillText(wrappedLine,45,customHeaderY);customHeaderY+=20;}});
 customHeader.forEach(d=>{x.font="16px sans-serif";x.fillText(d.label+": "+String(b.customFields[d.key]),45,customHeaderY);customHeaderY+=22;});
 const top=Math.max(hy+32,customHeaderY+10);const cols=[45,105,405,495,585,705,855];x.strokeStyle="#aaa";x.lineWidth=1;x.strokeRect(45,top,w-90,headH+b.items.length*rowH+70);
 x.fillStyle="#24466f";x.fillRect(46,top+1,w-92,headH-1);x.fillStyle="#fff";x.font="bold 16px sans-serif";["Sr.",billTaxEnabled(b)?"Item name - HSN/SAC":"Item Description","Qty","Unit","Rate/Unit","Amount"].forEach((t,i)=>{if(i===5){x.textAlign="right";x.fillText(t,cols[6]-8,top+42);x.textAlign="left"}else{x.fillText(t,cols[i]+8,top+42)}});
 x.fillStyle="#111";x.font="16px sans-serif";
 b.items.forEach((it,i)=>{const y=top+headH+i*rowH+(billTaxEnabled(b)?28:34);const amt=quantityValue(it.qty,it.unit||"piece")*it.rate;const itemLabel=String(it.name||"")+(billTaxEnabled(b)&&(it.hsn||it.hsnCode)?" - "+String(it.hsn||it.hsnCode):"");x.fillText(String(i+1),cols[0]+8,y);x.fillText(itemLabel,cols[1]+8,y,Math.max(80,cols[2]-cols[1]-16));x.textAlign="right";x.fillText(it.qty,cols[3]-8,y);x.fillText(it.unit||"piece",cols[4]-8,y);x.fillText(Number(it.rate).toFixed(2),cols[5]-8,y);x.fillText(amt.toFixed(2),cols[6]-8,y);x.textAlign="left";x.strokeStyle="#ddd";x.beginPath();x.moveTo(46,y+20);x.lineTo(w-46,y+20);x.stroke()});
 const subtotal=Number(b.subtotal??b.items.reduce((s,it)=>s+quantityValue(it.qty,it.unit||"piece")*Number(it.rate||0),0));const discount=Number(b.discount||0);let ty=top+headH+b.items.length*rowH+50;x.textAlign="left";if(billTaxEnabled(b)){const tax=calculateBillTax(b);x.font="12px sans-serif";tax.groups.forEach(g=>{x.fillText("GST @"+g.rate+"%   Taxable: "+money(g.taxable)+"   GST: "+money(g.tax),45,ty);ty+=19;});}x.font="17px sans-serif";x.textAlign="right";x.fillText("Subtotal: "+money(subtotal),w-45,ty);let summaryOffset=30;if(discount>0){x.fillText("Discount: -"+money(discount),w-45,ty+summaryOffset);summaryOffset+=30;}const billRoundOff=Number(b.roundOff||0);if(Math.abs(billRoundOff)>=0.005){x.fillText("Round Off: "+(billRoundOff>0?"+₹":"-₹")+Math.abs(billRoundOff).toFixed(2),w-45,ty+summaryOffset);summaryOffset+=30;}x.font="bold 22px sans-serif";x.fillText("Total Amount: "+money(b.total),w-45,ty+summaryOffset+5);x.textAlign="left";x.font="17px sans-serif";x.fillText("Thank you for shopping with us!",45,ty+summaryOffset+48);let footerY=ty+summaryOffset+74;customFooter.forEach(d=>{x.font="14px sans-serif";x.fillText(d.label+": "+String(b.customFields[d.key]),45,footerY);footerY+=20;});if(state.settings.printTermsConditions!==false&&String(state.settings.termsConditions||"").trim()){x.font="14px sans-serif";String(state.settings.termsConditions).split(/\n/).forEach(line=>{x.fillText(line,45,footerY);footerY+=18;});}x.font="12px sans-serif";if(String(state.settings.creditFooter??"").trim())x.fillText(String(state.settings.creditFooter).trim(),45,footerY+4);
 return c.toDataURL("image/png").split(",")[1];
}
function calculateBillTax(b){
 if(!b?.taxationEnabled) return {taxable:0,tax:0,groups:[],cgst:0,sgst:0,igst:0};
 const subtotal=Number(b.subtotal??(b.items||[]).reduce((s,x)=>s+quantityValue(x.qty,x.unit||"piece")*Number(x.rate||0),0));
 const discount=Math.max(0,Number(b.discount||0));
 const groups={};let taxable=0,tax=0;
 (b.items||[]).forEach(x=>{const gross=quantityValue(x.qty,x.unit||"piece")*Number(x.rate||0);const net=subtotal>0?gross*(subtotal-discount)/subtotal:gross;const rate=Number(x.taxRate||0);const inclusive=b.amountsIncludeTax!==false;const base=rate>0?(inclusive?net/(1+rate/100):net):net;const tx=rate>0?(inclusive?net-base:net*rate/100):0;taxable+=base;tax+=tx;const k=String(rate);if(!groups[k])groups[k]={rate, taxable:0,tax:0};groups[k].taxable+=base;groups[k].tax+=tx;});
 const businessState=String(b.businessState||state.settings.businessState||"");
 const inter=businessState && b.placeOfSupply && businessState.toLowerCase()!==String(b.placeOfSupply).toLowerCase();
 const cgst=inter?0:tax/2,sgst=inter?0:tax/2,igst=inter?tax:0;
 return {taxable,tax,groups:Object.values(groups).sort((a,b)=>a.rate-b.rate),cgst,sgst,igst,inter};
}

function renderBill(b){
 window.currentBill=b;
 const date=b.date.split("-").reverse().join("/");
 const subtotal=Number(b.subtotal ?? (b.items||[]).reduce((s,x)=>s+quantityValue(x.qty,x.unit||"piece")*Number(x.rate||0),0));
 const discount=Number(b.discount||0);
 const total=Number(b.total ?? Math.max(0,subtotal-discount));
 const tax=calculateBillTax(b);
 const taxEnabled=billTaxEnabled(b);
 if(b.customer&&b.customer!=="Walk-in Customer")b.customerTotalBalance=Math.max(0,Number(b.total||0)-Number(b.partialPaymentAmount||0));
 if(b.includeLast5Transactions&&b.customer&&b.customer!=="Walk-in Customer"&&typeof customerTransactions==="function")b.last5Transactions=customerRecentTransactions(b.customer).slice(0,5);
 const title=taxEnabled?(state.settings.taxBillTitle||"TAX INVOICE"):(state.settings.billTitle||"CASH MEMO / BILL");
 const paperForHeader=String(window.__printPaperSize||state.settings.paperSize||"80mm").toLowerCase();
 const allShopDetailsOff=state.settings.printShopName===false&&state.settings.printShopAddress===false&&state.settings.printShopMobile===false&&state.settings.printShopLogo===false;
 const isA4A6Header=(paperForHeader==="a4"||paperForHeader==="a6");
 const onlyShopNameEnabled=state.settings.printShopName!==false&&state.settings.printShopAddress===false&&state.settings.printShopMobile===false&&state.settings.printShopLogo===false;
 const compactNoShopHeader=(allShopDetailsOff&&isA4A6Header);
 const compactA4A6Header=(isA4A6Header&&(allShopDetailsOff||onlyShopNameEnabled));
 const taxHead=taxEnabled?`${(b.gstin||state.settings.gstin)?`<div><b>GSTIN:</b> ${esc(b.gstin||state.settings.gstin)}</div>`:""}${(b.fssai||state.settings.fssai)?`<div><b>FSSAI Number:</b> ${esc(b.fssai||state.settings.fssai)}</div>`:""}${(b.placeOfSupply||state.settings.businessState)?`<div><b>State:</b> ${esc(b.placeOfSupply||state.settings.businessState)}</div>`:""}`:"";
 const rows=(b.items||[]).map((x,i)=>{const amt=quantityValue(x.qty,x.unit||"piece")*Number(x.rate||0);return `<tr><td>${i+1}</td><td>${esc(state.settings.printItemCode&&(x.itemCode||findProduct(x.name)?.itemCode)?String(x.itemCode||findProduct(x.name)?.itemCode)+" - ":"")}${esc(x.name)}${b.includeItemComments&&x.comment?`<div class="printed-item-comment">${esc(x.comment)}</div>`:""}</td>${taxEnabled?`<td>${esc(x.hsn||x.hsnCode||"")}</td>`:""}<td>${esc(x.qty)} ${esc(x.unit||"")}</td><td>${Number(x.rate||0).toFixed(2)}</td>${taxEnabled?`<td>${Number(x.taxRate||0)}%</td>`:""}<td class="amount-col">${amt.toFixed(2)}</td></tr>`;}).join("");
 const taxRows=tax.groups.map(g=>`<tr><td colspan="4">GST ${g.rate}% Taxable Value:</td><td>${money(g.taxable)}</td></tr>`).join("");
 const taxSummary=taxEnabled?`<div class="tax-summary"><table><thead><tr><th>Tax Rate</th><th>Taxable</th><th>CGST</th><th>SGST</th><th>IGST</th></tr></thead><tbody>${tax.groups.map(g=>`<tr><td>${g.rate}%</td><td>${money(g.taxable)}</td><td>${tax.inter?"—":money(g.tax/2)}</td><td>${tax.inter?"—":money(g.tax/2)}</td><td>${tax.inter?money(g.tax):"—"}</td></tr>`).join("")}<tr><td><b>Total GST</b></td><td>${money(tax.taxable)}</td><td>${tax.inter?"—":money(tax.cgst)}</td><td>${tax.inter?"—":money(tax.sgst)}</td><td>${tax.inter?money(tax.igst):"—"}</td></tr></tbody></table></div>`:"";
 $("billPreview").innerHTML=`${!compactA4A6Header&&state.settings.printShopLogo!==false?`<div class="bill-logo-wrap"><img src="${esc(logoSource())}" class="bill-logo" alt="Shop logo"></div>`:""}${!compactA4A6Header&&state.settings.printShopName!==false?`<h1>${esc(state.settings.shopName)}</h1>`:""}${!compactA4A6Header&&state.settings.tagline?`<div class="bill-tagline">${esc(state.settings.tagline)}</div>`:""}${!compactA4A6Header&&state.settings.printShopAddress!==false?`<div class="location">${esc(state.settings.address)}</div>`:""}${!compactA4A6Header&&state.settings.printShopMobile!==false&&shopMobileText()?`<div class="bill-mobile">Mo: ${esc(shopMobileText())}</div>`:""}${!compactA4A6Header?`<div class="pill">${esc(title)}</div><hr>`:""}${compactA4A6Header?`<div class="meta compact-invoice-meta${onlyShopNameEnabled?" compact-shop-name-only":""}"><section class="compact-customer-details">${onlyShopNameEnabled?`<div class="compact-shop-name">${esc(state.settings.shopName||"")}</div>`:""}${!onlyShopNameEnabled?`<b>Customer Details</b>`:""}${state.settings.showCustomer?`<div><b>Name:</b> ${esc(b.customer||"Walk-in Customer")}</div>`:""}${state.settings.printCustomerMobile!==false&&b.customerPhone?`<div><b>Mobile:</b> ${esc(b.customerPhone)}</div>`:""}${taxEnabled&&b.customerGstin?`<div><b>Customer GSTIN:</b> ${esc(b.customerGstin)}</div>`:""}${taxEnabled&&b.customerFssai?`<div><b>Customer FSSAI:</b> ${esc(b.customerFssai)}</div>`:""}${taxEnabled&&b.customerAddress?`<div><b>Address:</b> ${esc(b.customerAddress)}</div>`:""}</section><section class="compact-invoice-details"><div class="compact-document-title">${esc(title)}</div><b>Invoice Details</b><div><b>Invoice:</b> ${esc(b.billNo)}</div><div><b>Date:</b> ${date}</div>${state.settings.printPaymentMode!==false?`<div><b>Payment:</b> ${esc(({Credit:"Cr",Cash:"Cash",UPI:"UPI",Cheque:"Chq",Card:"Card",Bank:"Bank"})[b.paymentMode||"Cash"]||b.paymentMode||"Cash")}</div>`:""}${taxHead}${customBillFieldsMarkup(b,"header")}</section></div>`:`<div class="meta"><div class="meta-bill-date"><span><b>Invoice:</b> ${esc(b.billNo)}</span><span><b>Dt:</b> ${date}</span></div>${(state.settings.showCustomer||state.settings.printCustomerMobile!==false)&&((state.settings.showCustomer&&(b.customer||"Walk-in Customer"))||(state.settings.printCustomerMobile!==false&&b.customerPhone))?`<div class="meta-customer-phone"><span>${state.settings.showCustomer?`<b>Customer:</b> ${esc(b.customer||"Walk-in Customer")}`:""}</span><span>${state.settings.printCustomerMobile!==false&&b.customerPhone?`<b>Mo:</b> ${esc(b.customerPhone)}`:""}</span></div>`:""}${taxEnabled&&b.customerGstin?`<div class="customer-tax-detail"><b>Customer GSTIN:</b> ${esc(b.customerGstin)}</div>`:""}${taxEnabled&&b.customerFssai?`<div class="customer-tax-detail"><b>Customer FSSAI:</b> ${esc(b.customerFssai)}</div>`:""}${taxEnabled&&b.customerAddress?`<div class="customer-tax-detail"><b>Customer Address:</b> ${esc(b.customerAddress)}</div>`:""}${taxHead}${customBillFieldsMarkup(b,"header")}${state.settings.printPaymentMode!==false?`<div><b>Pay:</b> ${esc(({Credit:"Cr",Cash:"Cash",UPI:"UPI",Cheque:"Chq",Card:"Card",Bank:"Bank"})[b.paymentMode||"Cash"]||b.paymentMode||"Cash")}</div>`:""}</div>`}<table class="bill-items-table"><thead><tr><th>Sr.</th><th>Item Description</th>${taxEnabled?"<th>HSN/SAC</th>":""}<th>Qty</th><th>Rate / Unit (₹)</th>${taxEnabled?"<th>Tax</th>":""}<th class="amount-col">Amount (₹)</th></tr></thead><tbody>${rows}</tbody></table><div class="bill-bottom-layout ${taxEnabled?"with-tax":"no-tax"}">${taxEnabled?`<div class="bill-gst-side">${taxSummary}</div>`:'<div class="bill-gst-side"></div>'}<div class="bill-totals-side"><table class="bill-totals-table"><tbody><tr><td>Subtotal:</td><td class="amount-col">${money(subtotal)}</td></tr>${discount>0?`<tr><td>Discount:</td><td class="amount-col">-${money(discount)}</td></tr>`:""}${taxEnabled?`<tr><td>Taxable Value:</td><td class="amount-col">${money(tax.taxable)}</td></tr><tr><td>Total GST:</td><td class="amount-col">${money(tax.tax)}</td></tr>`:""}${Math.abs(Number(b.roundOff||0))>=0.005?`<tr><td>Round Off:</td><td class="amount-col">${Number(b.roundOff)>0?"+₹":"-₹"}${Math.abs(Number(b.roundOff)).toFixed(2)}</td></tr>`:""}<tr><td><b>Total Amount:</b></td><td class="amount-col"><b>${money(total)}</b></td></tr>${Number(b.partialPaymentAmount||0)>0?`<tr><td>Paid:</td><td class="amount-col">${money(b.partialPaymentAmount)}</td></tr><tr><td><b>Balance Due:</b></td><td class="amount-col"><b>${money(Math.max(0,total-Number(b.partialPaymentAmount||0)))}</b></td></tr>`:""}</tbody></table></div></div>${b.includeOverallComment&&b.overallComment?`<div class="bill-overall-comment"><b>Comment:</b> ${esc(b.overallComment)}</div>`:""}${b.includeLast5Transactions&&b.last5Transactions?.length?`<div class="last-transactions"><b>Last 5 Customer Transactions</b><table class="last-transactions-table"><thead><tr><th>Date</th><th>Type</th><th>Bill/Txn No</th><th>P.Bal</th><th>Payment</th><th>Bal</th></tr></thead><tbody>${b.last5Transactions.map(t=>{const dt=displayDate(t.date||"");const typ=String(t.type||"").replace(/Credit sale/i,"Credit").replace(/Payment received/i,"Payment").replace(/Purchase/i,"Bill");const bal=Number(t.balance!=null?t.balance:(t.balanceDue||0));const prev=Number(t.previousBalance!=null?t.previousBalance:(bal-Number(t.debit||0)+Number(t.credit||0)));return `<tr><td>${esc(dt)}</td><td>${esc(typ)}</td><td>${esc(t.reference||"")}</td><td class="amount-col">${money(prev)}</td><td class="amount-col">${money(t.paymentAmount!=null?t.paymentAmount:t.amount)}</td><td class="amount-col">${money(bal)}</td></tr>`}).join("")}</tbody></table></div>`:""}${customBillFieldsMarkup(b,"footer")}<div class="thanks">${esc(state.settings.footer)}</div>${state.settings.upiQrEnabled?`<div class="bill-upi-qr" id="billUpiQrWrap"><div class="bill-upi-qr-image" id="billUpiQrImage"></div>${state.settings.upiPrintAmount!==false?`<div>Scan &amp; Pay ${money(Number(b.upiQrAmount||b.partialPaymentAmount||b.total||0))}</div>`:""}</div>`:""}${state.settings.printTermsConditions!==false&&String(state.settings.termsConditions||"").trim()?`<div class="muted bill-terms">${esc(state.settings.termsConditions).replace(/\n/g,"<br>")}</div>`:""}<div class="sign">${state.settings.signature?`${esc(state.settings.signature)}<br><span>(Authorized Signatory)</span>`:""}</div>${String(state.settings.creditFooter??"").trim()?`<div class="credit">${esc(String(state.settings.creditFooter).trim())}</div>`:""}`;
 const qrWrap=$("billUpiQrImage");if(qrWrap&&state.settings.upiQrEnabled){try{if(state.settings.upiQrSource==="merchant"&&state.settings.merchantQrData)qrWrap.innerHTML=`<img alt="UPI QR" src="${esc(state.settings.merchantQrData)}">`;else{const amount=Number(b.upiQrAmount||b.partialPaymentAmount||b.total||0);const payload=`upi://pay?pa=${encodeURIComponent(state.settings.upiId||"")}&pn=${encodeURIComponent(state.settings.upiPayeeName||state.settings.shopName||"")}&am=${amount.toFixed(2)}&cu=INR&tn=${encodeURIComponent(b.billNo||"SiddhiBill")}`;const data=window.Android?.generateQr?.(payload);if(data&&String(data).startsWith("data:image"))qrWrap.innerHTML=`<img alt="UPI QR" src="${data}">`;}}catch(e){console.warn("UPI QR generation failed",e)}}
 const eb=document.createElement("button"); eb.type="button"; eb.className="secondary bill-edit-button"; eb.textContent="✏️ Edit Bill"; eb.onclick=()=>loadBillForEdit(b); const ea=document.createElement("div"); ea.className="bill-edit-inline"; ea.appendChild(eb); $("billPreview").prepend(ea);
}

$("printBtn").onclick=()=>openPrintCustomerModal(window.currentBill);
function matchedReminderFallback(name){return customerReminderDate(name);}
function customerReminderDate(name){const c=findCustomer(name);return String(c?.paymentFollowUpDate||c?.nextPaymentReminderDate||"");}
function updateBillPaymentFollowUpVisibility(){
 const wrap=$("billPaymentFollowUpWrap"),billingWrap=$("billingFollowUpWrap");const customer=String($("printCustomerName")?.value||$("customer")?.value||"").trim();const mode=String($("paymentMode")?.value||window.currentBill?.paymentMode||"Cash");const due=customer&&customer!=="Walk-in Customer"&&typeof customerDue==="function"?customerDue(customer):0;const owes=mode==="Credit"||due>0;const show=!!(customer&&customer!=="Walk-in Customer"&&owes);if(wrap)wrap.classList.toggle("hidden",!show);if(billingWrap)billingWrap.classList.toggle("hidden",!show);const d=customerReminderDate(customer);if(show){if($("billPaymentFollowUpDate")&&!$("billPaymentFollowUpDate").value)$("billPaymentFollowUpDate").value=d;}}
function saveCustomerReminderDate(name,value){const key=String(name||"").trim().toLowerCase();if(!key||!name||name==="Walk-in Customer")return;let c=state.customers.find(x=>String(x.name||"").trim().toLowerCase()===key);if(!c){c={name:String(name).trim(),phone:"",openingBalance:0};state.customers.unshift(c);}c.paymentFollowUpDate=String(value||"");c.nextPaymentReminderDate=c.paymentFollowUpDate;save();renderCustomers();renderPaymentFollowUpReport();}
function openPrintCustomerModal(b){
 if(!b)return;
 if($("printLast5Transactions"))$("printLast5Transactions").checked=!!b.includeLast5Transactions;if($("billPaymentFollowUpDate"))$("billPaymentFollowUpDate").value=b.paymentFollowUpDate||"";
 const saved=findCustomer(b.customer);
 $("printCustomerName").value=(b.customer&&b.customer!=="Walk-in Customer")?b.customer:"";
 $("printCustomerPhone").value=b.customerPhone||((saved&&saved.phone)?String(saved.phone):"");
 $("printPaperSize").value=({"a4":"A4","a6":"A6","58mm":"58mm","80mm":"80mm"})[String(state.settings?.paperSize||"80mm").toLowerCase()]||"80mm";
 window.__printPaperSize=$("printPaperSize").value;
 // Open the modal without focusing an input: Android should not raise the
 // soft keyboard until the user explicitly taps a field.
 $("printCustomerSuggestions")?.classList.add("hidden");
 if($("printCustomerSuggestions")) $("printCustomerSuggestions").innerHTML="";
 $("printCustomerModal").classList.remove("hidden");
 updateBillPaymentFollowUpVisibility();
}
$("printPaperSize")?.addEventListener("change",e=>{
 window.__printPaperSize=e.target.value;
 state.settings=Object.assign({},state.settings,{paperSize:e.target.value});
 save();
});
function selectedPrintSettings(){
 const paper=window.__printPaperSize||$("printPaperSize")?.value||state.settings?.paperSize||"80mm";
 return Object.assign({},state.settings,{paperSize:paper});
}
function prepareLast5Transactions(){const b=window.currentBill;if(!b)return;b.includeLast5Transactions=$("includeLast5TransactionsBilling")?$("includeLast5TransactionsBilling").checked===true:$("printLast5Transactions")?.checked===true;if(b.includeLast5Transactions&&b.customer&&b.customer!=="Walk-in Customer")b.last5Transactions=customerTransactions(b.customer).slice(0,5);else b.last5Transactions=[];}
$("includeLast5TransactionsBilling")?.addEventListener("change",()=>{if($("printLast5Transactions"))$("printLast5Transactions").checked=$("includeLast5TransactionsBilling").checked;if(window.currentBill){window.currentBill.includeLast5Transactions=$("includeLast5TransactionsBilling").checked;prepareLast5Transactions();renderBill(window.currentBill);}});
$("printLast5Transactions")?.addEventListener("change",()=>{if($("includeLast5TransactionsBilling"))$("includeLast5TransactionsBilling").checked=$("printLast5Transactions").checked;});
function selectedPrintPayload(){prepareLast5Transactions();return JSON.stringify(Object.assign({},window.currentBill,{settings:selectedPrintSettings()}));}
$("printCustomerCancel").onclick=()=>{window.__downloadOnly=false;$("printCustomerModal").classList.add("hidden");};
let pendingCustomerSave=null;
function continueBillAfterCustomerSave(){
 prepareLast5Transactions();
 const selectedSettings=selectedPrintSettings();
 const payload=JSON.stringify(Object.assign({},window.currentBill,{settings:selectedSettings}));
 $("printCustomerModal").classList.add("hidden");
 const paper=String(selectedSettings.paperSize||"80mm").toLowerCase();
 if(paper==="80mm" && window.Android?.directThermalPrint80) Android.directThermalPrint80(payload);
 else if((paper==="a4" || paper==="a6") && window.Android?.openBillPdf) Android.openBillPdf(payload);
 else if(window.Android?.printBill) Android.printBill(payload);
 else window.print();
}

// PDF inside the Print/PDF popup follows the selected paper size.
$("printCustomerPdf")?.addEventListener("click",()=>{
 const name=$("printCustomerName")?.value.trim()||"Walk-in Customer";
 let phone=normalizePhone($("printCustomerPhone")?.value||"");
 const exact=findCustomer(name);
 if(!phone && exact) phone=normalizePhone(exact.phone??exact.mobile??exact.mobileNumber??exact.phoneNumber??"");
 if(phone && !isValidMobile(phone)){showNotice("Enter a valid 10 digit mobile number or leave it blank.","PDF");return;}
 window.currentBill.customer=name; window.currentBill.customerPhone=phone;
 const pc=findCustomer(name); window.currentBill.customerGstin=pc?String(pc.gstin||"").trim().toUpperCase():String(window.currentBill.customerGstin||""); window.currentBill.customerFssai=pc?String(pc.fssai||"").trim():String(window.currentBill.customerFssai||""); window.currentBill.customerAddress=pc?String(pc.address||"").trim():String(window.currentBill.customerAddress||""); window.currentBill.customerState=pc?String(pc.state||"").trim():String(window.currentBill.customerState||"");
 save(); renderBill(window.currentBill);
 const payload=selectedPrintPayload();
 $("printCustomerModal").classList.add("hidden");
 if(window.Android?.openBillPdf) Android.openBillPdf(payload); else window.print();
});

// Special app-to-app print package. It contains bill + shop settings, but never the logo.
$("thermalShare")?.addEventListener("click",()=>{
 const name=$("printCustomerName")?.value.trim()||"Walk-in Customer";
 const phone=normalizePhone($("printCustomerPhone")?.value||"");
 if(phone && !isValidMobile(phone)){showNotice("Enter a valid 10 digit mobile number or leave it blank.","Thermal Share");return;}
 window.currentBill.customer=name; window.currentBill.customerPhone=phone;
 const pc=findCustomer(name); window.currentBill.customerGstin=pc?String(pc.gstin||"").trim().toUpperCase():String(window.currentBill.customerGstin||""); window.currentBill.customerFssai=pc?String(pc.fssai||"").trim():String(window.currentBill.customerFssai||""); window.currentBill.customerAddress=pc?String(pc.address||"").trim():String(window.currentBill.customerAddress||""); window.currentBill.customerState=pc?String(pc.state||"").trim():String(window.currentBill.customerState||"");
 save();
 const sharedSettings=selectedPrintSettings(); delete sharedSettings.logoData;
 const payload=JSON.stringify(Object.assign({},window.currentBill,{settings:sharedSettings,dukaanBillType:"THERMAL_PRINT",dukaanBillVersion:1}));
 $("printCustomerModal").classList.add("hidden");
 if(window.Android?.shareDukaanBillToWhatsApp) Android.shareDukaanBillToWhatsApp(payload);
 else showNotice("Thermal Share is available in the Android APK.","Thermal Share");
});

window.openIncomingThermalBill=function(json){
 try{
   const incoming=typeof json==='string'?JSON.parse(json):json;
   if(!incoming || incoming.dukaanBillType!=="THERMAL_PRINT") throw new Error("Invalid SiddhiBill print file");
   const localSettings=Object.assign({},state.settings);
   incoming.settings=Object.assign({},incoming.settings||{}, {logoData:localSettings.logoData||"", bluetoothPrinter:localSettings.bluetoothPrinter||"auto", paperSize:(incoming.settings&&incoming.settings.paperSize)||localSettings.paperSize||"80mm"});
   window.__incomingThermalBill=incoming;
   $("incomingThermalBillNo").textContent=incoming.billNo||"";
   $("incomingThermalCustomer").textContent=incoming.customer||"Walk-in Customer";
   $("incomingThermalTotal").textContent=money(Number(incoming.total||0));
   $("incomingThermalPaper").textContent=incoming.settings.paperSize||"80mm";
   $("incomingThermalModal").classList.remove("hidden");
 }catch(e){showNotice("Could not open this SiddhiBill file: "+e.message,"SiddhiBill");}
};
$("incomingThermalCancel")?.addEventListener("click",()=>$("incomingThermalModal").classList.add("hidden"));
$("incomingThermalPrint")?.addEventListener("click",()=>{
 const b=window.__incomingThermalBill; if(!b)return;
 $("incomingThermalModal").classList.add("hidden");
 const payload=JSON.stringify(b);
 if(String(b.settings?.paperSize||"80mm").toLowerCase()==="80mm" && window.Android?.directThermalPrint80) Android.directThermalPrint80(payload);
 else if(window.Android?.printBill) Android.printBill(payload);
});
function applyExistingCustomerToCurrentBill(existing){
 if(!existing||!window.currentBill)return;
 const phone=normalizePhone(existing.phone||"");
 window.currentBill.customer=String(existing.name||window.currentBill.customer||"");
 window.currentBill.customerPhone=phone;
 window.currentBill.customerGstin=String(existing.gstin||"").trim().toUpperCase();
 window.currentBill.customerFssai=String(existing.fssai||"").trim();
 window.currentBill.customerAddress=String(existing.address||"").trim();
 window.currentBill.customerState=String(existing.state||"").trim();
 if($("customer")){$("customer").value=window.currentBill.customer;$("customer").dataset.phone=phone;}
 if($("printCustomerName"))$("printCustomerName").value=window.currentBill.customer;
 if($("printCustomerPhone"))$("printCustomerPhone").value=phone;
}
function handleCustomerConflict(name,phone,onDecision,extra={}){
 const existing=findCustomerByNameOrPhone(name,phone);
 if(!existing){ onDecision("none",null); return; }
 if(String(existing.name||"").trim().toLowerCase()===name.trim().toLowerCase() && normalizePhone(existing.phone)===phone){ onDecision("same",existing); return; }
 pendingCustomerSave={name,phone,existing,onDecision,extra};
 const sameName=String(existing.name||"").trim().toLowerCase()===name.trim().toLowerCase();
 const samePhone=normalizePhone(existing.phone)===phone;
 $("customerConflictText").textContent=sameName?`This customer name already exists with a different mobile number. Update the existing customer's mobile/details, or create a separate customer? Existing mobile: ${existing.phone||"Not set"}; entered mobile: ${phone||"Not set"}.`:`This mobile number is already linked to ${String(existing.name||"a customer")}. You can use the existing customer, update their name, or create a separate customer.`;
 const useExistingButton=$("customerConflictUseExisting");if(useExistingButton)useExistingButton.classList.toggle("hidden",!(samePhone&&!sameName));
 $("customerConflictModal").classList.remove("hidden");
}
$("customerConflictCancel").onclick=()=>{pendingCustomerSave=null;$("customerConflictModal").classList.add("hidden");};
$("customerConflictUseExisting").onclick=()=>{const p=pendingCustomerSave;if(!p)return;pendingCustomerSave=null;$("customerConflictModal").classList.add("hidden");p.onDecision("existing",p.existing);};
$("customerConflictUpdate").onclick=()=>{const p=pendingCustomerSave;if(!p)return;p.existing.name=p.name;p.existing.phone=p.phone;Object.assign(p.existing,p.extra||{});save();pendingCustomerSave=null;$("customerConflictModal").classList.add("hidden");p.onDecision("update",p.existing);};
$("customerConflictCreate").onclick=()=>{const p=pendingCustomerSave;if(!p)return;state.customers.unshift({name:p.name,phone:p.phone,openingBalance:0,...(p.extra||{})});state.customers=state.customers.slice(0,500);save();renderCustomerDatalist();renderCustomers();pendingCustomerSave=null;$("customerConflictModal").classList.add("hidden");p.onDecision("create",null);};
$("printCustomerContinue").onclick=()=>{
 const name=$("printCustomerName").value.trim()||"Walk-in Customer";
 let phoneRaw=$("printCustomerPhone").value.trim();
 let phone=phoneRaw?normalizePhone(phoneRaw):"";
 const exact=findCustomer(name);
 if(!phone && exact) phone=normalizePhone(exact.phone??exact.mobile??exact.mobileNumber??exact.phoneNumber??"");
 if(phoneRaw && !isValidMobile(phone)){alert("Enter a valid 10 digit mobile number or leave it blank.");return}
 window.currentBill.customer=name;
 window.currentBill.paymentFollowUpDate=String(!$("billPaymentFollowUpWrap")?.classList.contains("hidden")?($("billPaymentFollowUpDate")?.value||""):"");
 window.currentBill.customerPhone=phone;
 updateBillPaymentFollowUpVisibility();const pc=findCustomer(name);window.currentBill.customerGstin=pc?String(pc.gstin||"").trim().toUpperCase():String(window.currentBill.customerGstin||""); window.currentBill.customerFssai=pc?String(pc.fssai||"").trim():String(window.currentBill.customerFssai||""); window.currentBill.customerAddress=pc?String(pc.address||"").trim():String(window.currentBill.customerAddress||""); window.currentBill.customerState=pc?String(pc.state||"").trim():String(window.currentBill.customerState||"");
 $("printCustomerPhone").value=phone;
 if($('customer')) { $('customer').value=name; $('customer').dataset.phone=phone; }
 const finish=()=>{save();renderBill(window.currentBill);renderPaymentFollowUpReport();continueBillAfterCustomerSave();};
 if(name!=="Walk-in Customer" && phone){
   handleCustomerConflict(name,phone,(decision,existing)=>{if(decision==="existing")applyExistingCustomerToCurrentBill(existing);finish();});
 } else finish();
};

function renderPrintCustomerSuggestions(){
 const box=$("printCustomerSuggestions"),input=$("printCustomerName"); if(!box||!input)return;
 const q=String(input.value||"").trim().toLowerCase();
 const nq=normalizePhone(q);
 // Use the same unified customer source as Billing/Customers so customers created
 // from bills are also searchable from the Print and PDF dialogs.
 const matches=getCustomerRecords().filter(c=>{
   const name=String(c.name??c.customerName??"");
   const phone=normalizePhone(c.phone??c.mobile??c.mobileNumber??c.phoneNumber??"");
   const notes=String(c.notes??c.note??c.additionalDetails??"");
   return !q||name.toLowerCase().includes(q)||(nq.length>0&&phone.includes(nq))||notes.toLowerCase().includes(q);
 }).slice(0,20);
 if(!matches.length){box.classList.add("hidden");box.innerHTML="";return;}
 box.innerHTML=matches.map(c=>{
   const phone=c.phone??c.mobile??c.mobileNumber??c.phoneNumber??"";
   return `<div class="customer-suggestion" data-name="${esc(c.name)}" data-phone="${esc(phone)}" tabindex="0"><b>${esc(c.name)}</b>${phone?`<div class="muted">${esc(phone)}</div>`:""}</div>`;
 }).join("");
 box.classList.remove("hidden");
 box.querySelectorAll(".customer-suggestion").forEach(el=>{
   const choose=e=>{
     e?.preventDefault?.();e?.stopPropagation?.();
     $("printCustomerName").value=el.dataset.name||"";
     $("printCustomerPhone").value=normalizePhone(el.dataset.phone||"");
     box.classList.add("hidden");box.innerHTML="";
     setTimeout(()=>$("printCustomerName")?.focus(),0);
   };
   el.addEventListener("pointerdown",choose,{passive:false});
   el.addEventListener("touchstart",choose,{passive:false});
   el.addEventListener("mousedown",choose,{passive:false});
   el.addEventListener("click",choose);
   el.addEventListener("keydown",e=>{if(e.key==="Enter"){choose(e);}});
 });
}
// Suggestions appear only after the user changes the search text, not just
// because the print dialog opened or the field received focus.
$("printCustomerName")?.addEventListener("input",()=>{
 const q=String($("printCustomerName")?.value||"").trim();
 if(!q){$("printCustomerSuggestions")?.classList.add("hidden");if($("printCustomerSuggestions"))$("printCustomerSuggestions").innerHTML="";return;}
 renderPrintCustomerSuggestions();
});
$("printCustomerName")?.addEventListener("blur",()=>setTimeout(()=>{$("printCustomerSuggestions")?.classList.add("hidden")},180));
$("printCustomerPhone")?.addEventListener("input",e=>{e.target.value=normalizePhone(e.target.value).slice(0,10);});
$("printCustomerName")?.addEventListener("input",()=>{updateBillPaymentFollowUpVisibility();const d=customerReminderDate($("printCustomerName").value);if($("billPaymentFollowUpDate"))$("billPaymentFollowUpDate").value=d;});$("customer")?.addEventListener("input",()=>{updateBillPaymentFollowUpVisibility();const d=customerReminderDate($("customer").value);});$("paymentMode")?.addEventListener("change",updateBillPaymentFollowUpVisibility);
function persistFollowUpDate(value){const b=window.currentBill;if(!b)return;const date=String(value||"");b.paymentFollowUpDate=date;b.shopKey=moduleShopKey();b.shopName=moduleCurrentShop();if($("billPaymentFollowUpDate"))$("billPaymentFollowUpDate").value=date;saveCustomerReminderDate(b.customer,date);if(nativeBridgePresent&&window.Android?.saveTransactionRecord){try{Android.saveTransactionRecord("pksBills",JSON.stringify(b));}catch(e){console.warn("Bill follow-up date could not be persisted",e);}}else{const i=state.bills.findIndex(x=>String(x.billNo)===String(b.billNo));if(i>=0)state.bills[i].paymentFollowUpDate=date;save();}renderPaymentFollowUpReport();}
$("billingPaymentFollowUpDate")?.addEventListener("change",e=>{persistFollowUpDate(e.target.value);if($("billPaymentFollowUpDate"))$("billPaymentFollowUpDate").value=e.target.value;});
$("billPaymentFollowUpDate")?.addEventListener("change",e=>{persistFollowUpDate(e.target.value);});
document.addEventListener("click",e=>{if(!e.target.closest("#printCustomerModal .customer-search-wrap"))$("printCustomerSuggestions")?.classList.add("hidden")});
function buildCustomerBillMessage(b){
 const shop=state.settings?.shopName||"SiddhiBill";
 const mobile=shopMobileText();
 const lines=[`*${shop}*`,""];
 if(b.customer && b.customer!=="Walk-in Customer") lines.push(`Dear ${b.customer},`,"");
 lines.push(`Bill No: ${b.billNo||""}`);
 const dt=b.date||b.createdAt||"";
 if(dt) lines.push(`Date: ${dt}`);
 lines.push("", "Bill Summary");
 const items=Array.isArray(b.items)?b.items:[];
 items.forEach((it,i)=>{
   const qty=String(it.qty??"").trim(), unit=String(it.unit??"").trim();
   const rate=Number(it.rate||0), amount=Number(it.amount||0) || quantityValue(qty,unit||"piece")*rate;
   const qtyText=[qty,unit].filter(Boolean).join(" ");
   const itemTaxRate=Number(it.taxRate??it.tax??0)||0;
   const taxLabel=billTaxEnabled(b)?` (GST ${itemTaxRate}%)`:"";
   lines.push(`${i+1}. ${it.name||"Item"}${taxLabel} - ${qtyText} x ₹${rate.toFixed(2)} = ₹${amount.toFixed(2)}`);
 });
 const subtotal=Number(b.subtotal||0), discount=Number(b.discount||0), total=Number(b.total||0);
 lines.push("",`Subtotal: ₹${subtotal.toFixed(2)}`);
 if(discount>0) lines.push(`Discount: -₹${discount.toFixed(2)}`);
 if(b.taxationEnabled){
   const tax=calculateBillTax(b);
   lines.push(`Taxable Amount: ₹${Number(tax.taxable||0).toFixed(2)}`);
   if(tax.inter) lines.push(`IGST: ₹${Number(tax.igst||0).toFixed(2)}`);
   else { lines.push(`CGST: ₹${Number(tax.cgst||0).toFixed(2)}`); lines.push(`SGST: ₹${Number(tax.sgst||0).toFixed(2)}`); }
 }
 lines.push(`*Total Amount: ₹${total.toFixed(2)}*`,`Payment: ${b.paymentMode||"Cash"}`);
 // Share the customer's overall outstanding balance for credit bills or when
 // the bill is configured to include last-five transaction details. Do not
 // append the transaction history itself to the message.
 if((String(b.paymentMode||"Cash").toLowerCase()==="credit" || b.includeLast5Transactions) && b.customer && b.customer!=="Walk-in Customer"){
   let totalBalance=Number(b.customerTotalBalance);
   if(typeof customerDue==="function") totalBalance=Number(customerDue(b.customer)||0);
   if(!Number.isFinite(totalBalance)||totalBalance<0) totalBalance=0;
   lines.push(`Total Balance: ₹${totalBalance.toFixed(2)}`);
 }
 lines.push("", "Thank you for shopping with us!");
 if(mobile) lines.push(shop, mobile); else lines.push(shop);
 return lines.join("\n");
}
$("printMessage")?.addEventListener("click",()=>{
 console.info("SHARE_DIAG: Message click reached");
 try {
 const phone=normalizePhone($("printCustomerPhone")?.value||"");
 if(!isValidMobile(phone)){showNotice("Select an existing customer or enter a valid 10 digit mobile number first.","Message");return;}
 const name=$("printCustomerName")?.value.trim()||"Walk-in Customer";
 window.currentBill.customer=name; window.currentBill.customerPhone=phone;
 const pc=findCustomer(name);
 window.currentBill.customerGstin=pc?String(pc.gstin||"").trim().toUpperCase():String(window.currentBill.customerGstin||""); window.currentBill.customerFssai=pc?String(pc.fssai||"").trim():String(window.currentBill.customerFssai||""); window.currentBill.customerAddress=pc?String(pc.address||"").trim():String(window.currentBill.customerAddress||""); window.currentBill.customerState=pc?String(pc.state||"").trim():String(window.currentBill.customerState||"");
 if($('customer')) { $('customer').value=name; $('customer').dataset.phone=phone; }
 const send=()=>{
   save();
   const msg=buildCustomerBillMessage(window.currentBill);
   if(window.Android?.sendBillMessage) Android.sendBillMessage(phone,msg);
   else window.location.href=`sms:${phone}?body=${encodeURIComponent(msg)}`;
 };
 if(name!=="Walk-in Customer" && phone) handleCustomerConflict(name,phone,(decision,existing)=>{if(decision==="existing")applyExistingCustomerToCurrentBill(existing);send();}); else send();
 } catch(e) { console.error("SHARE_DIAG: Message handler failed",e); showNotice("Message failed before opening SMS: "+String(e?.message||e),"Sharing diagnostics"); }
});

$("printWhatsApp")?.addEventListener("click",()=>{
 console.info("SHARE_DIAG: WhatsApp click reached");
 try {
 const phone=normalizePhone($("printCustomerPhone")?.value||"");
 if(!isValidMobile(phone)){showNotice("Select an existing customer or enter a valid 10 digit mobile number first.","WhatsApp");return;}
 const name=$("printCustomerName")?.value.trim()||"Walk-in Customer";
 window.currentBill.customer=name;window.currentBill.customerPhone=phone;
 const pc=findCustomer(name);
 window.currentBill.customerGstin=pc?String(pc.gstin||"").trim().toUpperCase():String(window.currentBill.customerGstin||""); window.currentBill.customerFssai=pc?String(pc.fssai||"").trim():String(window.currentBill.customerFssai||""); window.currentBill.customerAddress=pc?String(pc.address||"").trim():String(window.currentBill.customerAddress||""); window.currentBill.customerState=pc?String(pc.state||"").trim():String(window.currentBill.customerState||"");
 if($('customer')) { $('customer').value=name; $('customer').dataset.phone=phone; }
 const share=()=>{
   // WhatsApp must persist the same customer details as Print / PDF.
   // Do this before launching WhatsApp so the bill is already saved.
   save();
   // Inside the Print flow, WhatsApp follows the currently selected paper size.
   // The standalone PDF button remains A4. The logo is included in normal PDF sharing,
   // but the special .dukaanbill thermal-share file intentionally excludes it.
   const shareSettings=selectedPrintSettings();
   const billForShare=Object.assign({},window.currentBill,{settings:shareSettings});
   const payload=JSON.stringify(billForShare);
   const message=buildCustomerBillMessage(billForShare);
   if(window.Android?.shareBillPdfToWhatsApp) Android.shareBillPdfToWhatsApp(payload,phone); else showNotice("WhatsApp direct sharing is available in the Android APK.","WhatsApp");
 };
 if(name!=="Walk-in Customer" && phone) handleCustomerConflict(name,phone,(decision,existing)=>{if(decision==="existing")applyExistingCustomerToCurrentBill(existing);share();}); else share();
 } catch(e) { console.error("SHARE_DIAG: WhatsApp handler failed",e); showNotice("WhatsApp failed before opening: "+String(e?.message||e),"Sharing diagnostics"); }
});

$("backToBilling").onclick=()=>showPage("billing");
// ---------------- Purchasing / Vendor Accounts ----------------
function purchaseId(prefix="PUR"){return prefix+"-"+Date.now()+"-"+Math.random().toString(36).slice(2,7).toUpperCase()}
function renderVendorsSelects(){
 const pv=$("purchaseVendor"), pay=$("paymentVendor");
 const selectedPurchase=pv?.value||"",selectedPayment=pay?.value||"";
 if(pv){pv.innerHTML='<option value="">Select vendor</option>'+state.vendors.map(v=>`<option value="${esc(v.id)}">${esc(v.name)}</option>`).join("");if(state.vendors.some(v=>String(v.id)===String(selectedPurchase)))pv.value=selectedPurchase;}
 if(pay){pay.innerHTML='<option value="">Select vendor</option>'+state.vendors.map(v=>`<option value="${esc(v.id)}">${esc(v.name)}</option>`).join("");if(state.vendors.some(v=>String(v.id)===String(selectedPayment)))pay.value=selectedPayment;}
}
function vendorById(id){const key=String(id??"").trim();return (state.vendors||[]).find(v=>String(v?.id??"").trim()===key)||null}
function populatePurchaseVendorFields(){const v=vendorById($("purchaseVendor")?.value);if(!v)return; if(!$("purchaseSupplierState").value)$("purchaseSupplierState").value=v.state||'';if(!$("purchaseSupplierStateCode").value)$("purchaseSupplierStateCode").value=v.stateCode||'';if(!$("purchaseSupplierPan").value)$("purchaseSupplierPan").value=v.pan||'';}
function vendorBalance(v){
 const vendorPurchases=state.purchases.filter(p=>p.vendorId===v.id);
 const purchases=vendorPurchases.reduce((s,p)=>s+Number(p.total||0),0);
 const purchasePayments=vendorPurchases.reduce((s,p)=>s+Number(p.paid||0),0);
 const accountPayments=state.vendorPayments.filter(p=>p.vendorId===v.id).reduce((s,p)=>s+Number(p.amount||0),0);
 const paid=purchasePayments+accountPayments;
 return {purchases,paid,pending:Number(v.openingBalance||0)+purchases-paid};
}
// Vendor invoice schema v2. Derived totals are calculated from source line values;
// supplier-declared totals are retained separately for reconciliation.
function vendorNum(v){const n=Number(String(v??'').replace(/,/g,'').trim());return Number.isFinite(n)?n:0;}
function roundMoney(v){return Math.round((vendorNum(v)+Number.EPSILON)*100)/100;}
function normalizeVendorLine(line,index=0){
 const qty=vendorNum(line.qty??line.quantity),freeQty=vendorNum(line.freeQty??line.freeQuantity),packSize=vendorNum(line.packSize??line.unitsPerPack??1)||1,baseQty=vendorNum(line.baseQty??(qty*packSize)),rate=vendorNum(line.rate??line.unitRate),discount=vendorNum(line.discountAmount??line.discount),scheme=vendorNum(line.schemeDiscount??line.schemeAmount),taxRate=vendorNum(line.taxRate??line.gstRate);
 const grossInclusive=line.lineTotalInclusive!=null?roundMoney(line.lineTotalInclusive):(line.priceIncludesTax?roundMoney(qty*rate):null);
 const effectiveRate=vendorNum(line.taxRate??line.gstRate);
 const inclusiveTaxable=(grossInclusive!=null&&effectiveRate>0)?roundMoney(grossInclusive/(1+effectiveRate/100)):null;
 const taxable=roundMoney(Math.max(0,inclusiveTaxable!=null?inclusiveTaxable:baseQty*rate-discount-scheme));
 const cgstRate=vendorNum(line.cgstRate)||(line.taxType==='intra'?taxRate/2:0),sgstRate=vendorNum(line.sgstRate)||(line.taxType==='intra'?taxRate/2:0),igstRate=vendorNum(line.igstRate)||(line.taxType==='inter'?taxRate:0);
 const cgstAmount=line.cgstAmount!=null?roundMoney(line.cgstAmount):roundMoney(taxable*cgstRate/100),sgstAmount=line.sgstAmount!=null?roundMoney(line.sgstAmount):roundMoney(taxable*sgstRate/100),igstAmount=line.igstAmount!=null?roundMoney(line.igstAmount):roundMoney(taxable*igstRate/100),cessRate=vendorNum(line.cessRate),cessAmount=line.cessAmount!=null?roundMoney(line.cessAmount):roundMoney(taxable*cessRate/100);
 const inclusiveTax=roundMoney(cgstAmount+sgstAmount+igstAmount+cessAmount);const storedRate=baseQty>0?roundMoney(taxable/baseQty):rate;const inclusiveTotal=grossInclusive!=null?grossInclusive:roundMoney(taxable+inclusiveTax);return {...line,lineNo:Number(line.lineNo)||index+1,packSize,baseQty,itemCode:String(line.itemCode??line.supplierItemCode??'').trim(),barcode:String(line.barcode??line.ean??line.upc??'').trim(),productId:line.productId||null,name:String(line.name??line.description??line.itemName??'').trim(),supplierDescription:String(line.supplierDescription??line.description??line.name??'').trim(),hsn:String(line.hsn??line.hsnCode??'').trim(),mrp:vendorNum(line.mrp),qty,freeQty,unit:String(line.unit??line.uom??'').trim(),rate:storedRate,costPerUnitInclusive:baseQty>0?roundMoney(inclusiveTotal/baseQty):roundMoney(rate),lineTotalInclusive:inclusiveTotal,priceIncludesTax:false,discountAmount:roundMoney(discount),schemeDiscount:roundMoney(scheme),taxableAmount:taxable,invoiceTaxableAmount:line.invoiceTaxableAmount!=null?roundMoney(line.invoiceTaxableAmount):null,invoiceLineTotal:line.invoiceLineTotal!=null?roundMoney(line.invoiceLineTotal):null,taxRate,cgstRate,sgstRate,igstRate,cgstAmount,sgstAmount,igstAmount,cessRate,cessAmount,totalTaxAmount:roundMoney(cgstAmount+sgstAmount+igstAmount+cessAmount),lineTotal:inclusiveTotal,batchNo:String(line.batchNo||'').trim(),expiryDate:String(line.expiryDate||'').trim(),serialNo:String(line.serialNo||'').trim(),rawExtractedText:String(line.rawExtractedText||'').trim(),reviewRequired:!!line.reviewRequired};
}
function deriveVendorInvoice(p){
 const items=(Array.isArray(p.items)?p.items:[]).map(normalizeVendorLine),taxableDerived=roundMoney(items.reduce((a,x)=>a+x.taxableAmount,0));
 const cgst=roundMoney(items.reduce((a,x)=>a+x.cgstAmount,0)),sgst=roundMoney(items.reduce((a,x)=>a+x.sgstAmount,0)),igst=roundMoney(items.reduce((a,x)=>a+x.igstAmount,0)),cess=roundMoney(items.reduce((a,x)=>a+x.cessAmount,0)),lineTax=roundMoney(cgst+sgst+igst+cess);
 const charges=roundMoney(p.otherCharges),discount=roundMoney(p.invoiceDiscount),tcs=roundMoney(p.tcsAmount),roundOff=roundMoney(p.roundOff);
 const hasLineTax=items.some(x=>x.taxRate||x.cgstRate||x.sgstRate||x.igstRate||x.cgstAmount||x.sgstAmount||x.igstAmount||x.cessAmount);
 const declaredTaxable=p.declaredTaxableAmount!=null?roundMoney(p.declaredTaxableAmount):null,declaredTax=p.declaredTaxAmount!=null?roundMoney(p.declaredTaxAmount):null;
 const taxableAmount=declaredTaxable!=null?declaredTaxable:taxableDerived,taxAmount=declaredTax!=null?declaredTax:(hasLineTax?lineTax:roundMoney(p.taxAmount));
 const computedTotal=roundMoney(taxableAmount+taxAmount+charges-discount+tcs+roundOff),declaredTotal=p.declaredTotalAmount!=null?roundMoney(p.declaredTotalAmount):(vendorNum(p.total)>0?roundMoney(p.total):null),total=declaredTotal!=null?declaredTotal:computedTotal;
 const gstMap={};items.forEach(x=>{const rate=roundMoney(x.cgstRate+x.sgstRate+x.igstRate+x.cessRate);if(!rate&&!x.totalTaxAmount)return;const key=String(rate);if(!gstMap[key])gstMap[key]={rate,taxableAmount:0,cgstRate:x.cgstRate,cgstAmount:0,sgstRate:x.sgstRate,sgstAmount:0,igstRate:x.igstRate,igstAmount:0,cessRate:x.cessRate,cessAmount:0,totalTaxAmount:0};const g=gstMap[key];g.taxableAmount=roundMoney(g.taxableAmount+x.taxableAmount);g.cgstAmount=roundMoney(g.cgstAmount+x.cgstAmount);g.sgstAmount=roundMoney(g.sgstAmount+x.sgstAmount);g.igstAmount=roundMoney(g.igstAmount+x.igstAmount);g.cessAmount=roundMoney(g.cessAmount+x.cessAmount);g.totalTaxAmount=roundMoney(g.totalTaxAmount+x.totalTaxAmount);});
 return {...p,schemaVersion:2,items,declaredTaxableAmount:declaredTaxable,declaredTaxAmount:declaredTax,declaredTotalAmount:declaredTotal,subtotal:taxableAmount,taxAmount,total,otherCharges:charges,invoiceDiscount:discount,tcsAmount:tcs,roundOff,paid:roundMoney(p.paid),pending:roundMoney(Math.max(0,total-vendorNum(p.paid))),derived:{lineCount:items.length,taxableAmount:taxableDerived,cgstAmount:cgst,sgstAmount:sgst,igstAmount:igst,cessAmount:cess,lineTaxAmount:lineTax,gstSummary:Object.values(gstMap),computedInvoiceTotal:computedTotal},reconciliation:{taxableDifference:declaredTaxable==null?null:roundMoney(declaredTaxable-taxableDerived),taxDifference:declaredTax==null?null:roundMoney(declaredTax-lineTax),totalDifference:declaredTotal==null?null:roundMoney(declaredTotal-computedTotal)}};
}
function normalizeVendorSchema(){
 // Vendor master and vendor payments are firm-owned masters, not shared group data.
 // Keep explicitly tagged records only in their owning firm; legacy untagged rows
 // already stored in this firm's namespace are safely assigned to the active firm.
 const firm=__sbActiveFirm(),shopKey=String(firm?.shopKey||firm?.id||'').toLowerCase(),shopName=String(firm?.name||state.settings?.shopName||'').trim();
 let changed=false;
 state.vendors=(Array.isArray(state.vendors)?state.vendors:[]).filter(v=>{
  const owner=String(v?.shopKey||'').trim().toLowerCase();
  if(owner&&owner!==shopKey){changed=true;return false;}
  return true;
 }).map(v=>{
  const next={...v,shopKey,shopName,pan:String(v.pan||'').trim().toUpperCase(),email:String(v.email||'').trim(),state:String(v.state||'').trim(),stateCode:String(v.stateCode||'').trim(),gstin:String(v.gstin||'').trim().toUpperCase(),address:String(v.address||'').trim()};
  if(!v.shopKey||v.shopKey!==shopKey||v.shopName!==shopName)changed=true;
  return next;
 });
 state.vendorPayments=(Array.isArray(state.vendorPayments)?state.vendorPayments:[]).filter(p=>{
  const owner=String(p?.shopKey||'').trim().toLowerCase();
  if(owner&&owner!==shopKey){changed=true;return false;}
  return true;
 }).map(p=>{const next={...p,shopKey,shopName};if(!p.shopKey||p.shopKey!==shopKey||p.shopName!==shopName)changed=true;return next;});
 if(changed)save();
}
let purchaseHistorySchemaNormalized=false;
function normalizePurchaseRecord(p){
 if(!p)return p;
 const normalized=deriveVendorInvoice({...p,supplierSnapshot:p.supplierSnapshot||{name:p.vendorName||'',gstin:'',pan:'',address:'',state:'',stateCode:'',phone:'',email:''},invoiceType:p.invoiceType||'tax_invoice',deliveryDate:p.deliveryDate||'',poNumber:p.poNumber||'',supplierReference:p.supplierReference||'',paymentTerms:p.paymentTerms||'',reverseCharge:!!p.reverseCharge,invoiceDiscount:p.invoiceDiscount||0,tcsAmount:p.tcsAmount||0,roundOff:p.roundOff||0,declaredTaxableAmount:p.declaredTaxableAmount??(p.subtotal!=null?p.subtotal:null),declaredTaxAmount:p.declaredTaxAmount??(p.taxAmount!=null?p.taxAmount:null),declaredTotalAmount:p.declaredTotalAmount??(p.total!=null?p.total:null)});
 // Editing one purchase must stay record-scoped on Android. Accessing state.purchases
 // here invokes the lazy getter and materializes all 10k+ purchase records.
 if(window.__siddhiLazyState?.purchases?.()){
   const history=state.purchases,index=history.findIndex(x=>String(x.id)===String(p.id));
   if(index>=0)history[index]=normalized;
 }
 return normalized;
}
function normalizePurchaseHistorySchema(){
 // Retained only for workflows that genuinely need to inspect the complete
 // history (for example, a vendor-wide transaction ledger). Do not normalize
 // every purchase merely to edit one invoice.
 if(purchaseHistorySchemaNormalized)return;
 const __sbPurchaseNormalizeStart=__sbTraceClock();
 state.purchases=(Array.isArray(state.purchases)?state.purchases:[]).map(normalizePurchaseRecord);
 purchaseHistorySchemaNormalized=true;
 __sbTraceProfile("on-demand purchase schema normalization",__sbPurchaseNormalizeStart,{purchases:state.purchases.length});
}


// Large transaction lists are rendered in fixed pages to keep the WebView DOM small.
const TRANSACTION_PAGE_SIZE = 50;
let salesHistoryPage = 1;
let purchaseHistoryPage = 1;
function renderTransactionPager(anchor, pagerId, total, page, onPageChange) {
  let pager = document.getElementById(pagerId);
  if (!pager) {
    pager = document.createElement("div");
    pager.id = pagerId;
    pager.className = "transaction-pagination";
    anchor.insertAdjacentElement("afterend", pager);
  }
  const pages = Math.max(1, Math.ceil(total / TRANSACTION_PAGE_SIZE));
  page = Math.min(Math.max(1, page), pages);
  pager.innerHTML = "";
  const info = document.createElement("span");
  info.className = "transaction-pagination-info";
  info.textContent = total
    ? `Showing ${(page - 1) * TRANSACTION_PAGE_SIZE + 1}-${Math.min(page * TRANSACTION_PAGE_SIZE, total)} of ${total} • Page ${page} of ${pages}`
    : "No records";
  const controls = document.createElement("div");
  controls.className = "transaction-pagination-controls";
  const addButton = (label, target, disabled) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "secondary";
    button.textContent = label;
    button.disabled = disabled;
    button.addEventListener("click", () => onPageChange(target));
    controls.appendChild(button);
  };
  addButton("First", 1, page <= 1);
  addButton("Previous", page - 1, page <= 1);
  addButton("Next", page + 1, page >= pages);
  addButton("Last", pages, page >= pages);
  pager.append(info, controls);
  return page;
}
function readNativeVendorSummary(){
 try{const raw=window.Android?.loadVendorSummary?.();if(!raw)return null;const data=JSON.parse(raw);return data?.supported?data:null;}catch(e){console.warn("Native vendor summary unavailable",e);return null;}
}
function readNativePurchasePage(offset,limit,query){
 try{const raw=window.Android?.loadPurchaseHistoryPage?.(offset,limit,query||"");if(!raw)return null;const data=JSON.parse(raw);return data?.supported?data:null;}catch(e){console.warn("Native purchase page unavailable",e);return null;}
}
function readNativeSalesPage(offset,limit,query,from="",to=""){
 try{const raw=window.Android?.loadSalesHistoryPage?.(offset,limit,query||"",from||"",to||"",moduleShopKey());if(!raw)return null;const data=JSON.parse(raw);return data?.supported?data:null;}catch(e){console.warn("Native sales history page unavailable",e);return null;}
}
function renderVendorEntryScreen(){
 // Landing page stays fast; summary values are populated from compact native aggregates.
 renderVendorsSelects();
 const summary=readNativeVendorSummary();
 if(summary){
  const byVendor=new Map((summary.vendors||[]).map(x=>[String(x.vendorId||""),x]));
  const payments=new Map((summary.paymentsByVendor||[]).map(x=>[String(x.vendorId||""),Number(x.paid||0)]));
  const total=(summary.vendors||[]).reduce((a,x)=>a+Number(x.purchases||0),0);
  const purchasePaid=(summary.vendors||[]).reduce((a,x)=>a+Number(x.purchasePaid||0),0);
  const paid=purchasePaid+Number(summary.vendorPaymentTotal||0);
  const pending=state.vendors.reduce((a,v)=>a+Number(v.openingBalance||0)+Number(byVendor.get(String(v.id))?.purchases||0)-Number(byVendor.get(String(v.id))?.purchasePaid||0)-Number(payments.get(String(v.id))||0),0);
  $("purchaseTotal").textContent=money(total);$("purchasePaid").textContent=money(paid);$("purchasePending").textContent=money(pending);
 }else ["purchaseTotal","purchasePaid","purchasePending"].forEach(id=>{const el=$(id);if(el)el.textContent="Summary unavailable";});
}
let vendorAccountsPage=1;
const VENDOR_PAGE_SIZE=25;
function renderVendorAccountsFromSummary(summary){
 const byVendor=new Map((summary.vendors||[]).map(x=>[String(x.vendorId||""),x]));
 const payments=new Map((summary.paymentsByVendor||[]).map(x=>[String(x.vendorId||""),Number(x.paid||0)]));
 const va=$("vendorAccounts");va.innerHTML="";
 const pages=Math.max(1,Math.ceil(state.vendors.length/VENDOR_PAGE_SIZE));vendorAccountsPage=Math.min(Math.max(1,vendorAccountsPage),pages);
 if(!state.vendors.length)va.innerHTML='<div class="muted">No vendors added yet.</div>';
 state.vendors.slice((vendorAccountsPage-1)*VENDOR_PAGE_SIZE,vendorAccountsPage*VENDOR_PAGE_SIZE).forEach(v=>{
  const data=byVendor.get(String(v.id))||{},purchases=Number(data.purchases||0),paid=Number(data.purchasePaid||0)+Number(payments.get(String(v.id))||0),pending=Number(v.openingBalance||0)+purchases-paid;
  const r=document.createElement("div");r.className="vendor-account";
  r.innerHTML=`<div class="vendor-account-head"><div><div class="history-title">${esc(v.name)}</div><div class="muted">${esc(v.phone||"")} ${v.gstin?"• "+esc(v.gstin):""}</div></div><div class="row-actions"><button class="secondary edit-vendor">Edit</button><button class="secondary pay">Pay</button><button class="secondary vendor-transactions">Transactions</button></div></div><div class="purchase-summary"><div class="sales-box"><span>Purchases</span><strong>${money(purchases)}</strong></div><div class="sales-box"><span>Paid</span><strong class="paid">${money(paid)}</strong></div><div class="sales-box"><span>Pending</span><strong class="${pending>0?"payable":"paid"}">${money(pending)}</strong></div></div>`;
  r.querySelector(".edit-vendor").onclick=()=>openVendorModal(v.id);
  r.querySelector(".pay").onclick=()=>{$("paymentVendor").value=v.id;$("paymentDate").value=today();$("paymentModal").classList.remove("hidden");};
  r.querySelector(".vendor-transactions").onclick=()=>openTransactionHistory("vendor",v.id);
  va.appendChild(r);
 });
 renderTransactionPager(va,"vendorAccountsPagination",state.vendors.length,vendorAccountsPage,next=>{vendorAccountsPage=next;renderPurchasing();});
}
function renderVendorPaymentsOnly(){
 const vp=$("vendorPayments");vp.innerHTML="";
 const payments=[...state.vendorPayments].sort((a,b)=>String(b.date).localeCompare(String(a.date)));
 if(!payments.length)vp.innerHTML='<div class="muted">No vendor payments recorded.</div>';
 payments.slice(0,50).forEach(p=>{const v=vendorById(p.vendorId);const r=document.createElement("div");r.className="history-row";r.innerHTML=`<div><div class="history-title">${esc(v?.name||"Unknown Vendor")} • ${money(p.amount)}</div><div class="muted">${esc(p.date)} • ${esc(p.mode||"")} ${p.note?"• "+esc(p.note):""}</div></div>`;vp.appendChild(r)});
}
function renderPurchaseHistoryPage(){
 const q=String($("purchaseSearch")?.value||"").trim(),ph=$("purchaseHistory");
 const offset=(purchaseHistoryPage-1)*TRANSACTION_PAGE_SIZE;
 const nativePage=readNativePurchasePage(offset,TRANSACTION_PAGE_SIZE,q);
 if(!nativePage)return false;
 const records=nativePage.records||[],total=Number(nativePage.total||0),pages=Math.max(1,Math.ceil(total/TRANSACTION_PAGE_SIZE));
 purchaseHistoryPage=Math.min(Math.max(1,purchaseHistoryPage),pages);ph.innerHTML="";
 if(!records.length)ph.innerHTML='<div class="muted">No purchase bills found.</div>';
 records.forEach(p=>{const v=vendorById(p.vendorId);const r=document.createElement("div");r.className="history-row";r.innerHTML=`<div><div class="history-title">${esc(v?.name||p.vendorName||"Vendor")} • ${esc(p.invoiceNo||"No invoice")}</div><div class="muted">${esc(p.date||"")} • Total ${money(p.total)} • Paid ${money(p.paid)} • Pending ${money(Number(p.total)-Number(p.paid))}</div></div><div class="row-actions"><button class="secondary viewPurchase" type="button">View</button><button class="secondary editPurchase" type="button">Edit</button><button class="primary purchasePdf" type="button">PDF</button></div>`;
  r.querySelector(".viewPurchase").onclick=()=>{const fresh=resolvePurchaseRecord(p);if(fresh)showPurchaseDetail(fresh);};
  r.querySelector(".editPurchase").onclick=()=>editPurchase(p);
  r.querySelector(".purchasePdf").onclick=()=>{const fresh=resolvePurchaseRecord(p);if(fresh)exportPurchasePdf(fresh);};ph.appendChild(r);
 });
 purchaseHistoryPage=renderTransactionPager(ph,"purchaseHistoryPagination",total,purchaseHistoryPage,next=>{purchaseHistoryPage=next;renderPurchaseHistoryPage();});
 return true;
}
function renderPurchasing(){
 renderVendorsSelects();
 const summary=readNativeVendorSummary();
 if(summary){
  const total=(summary.vendors||[]).reduce((a,x)=>a+Number(x.purchases||0),0),purchasePaid=(summary.vendors||[]).reduce((a,x)=>a+Number(x.purchasePaid||0),0),paid=purchasePaid+Number(summary.vendorPaymentTotal||0);
  const byVendor=new Map((summary.vendors||[]).map(x=>[String(x.vendorId||""),x])),payments=new Map((summary.paymentsByVendor||[]).map(x=>[String(x.vendorId||""),Number(x.paid||0)]));
  const pending=state.vendors.reduce((a,v)=>a+Number(v.openingBalance||0)+Number(byVendor.get(String(v.id))?.purchases||0)-Number(byVendor.get(String(v.id))?.purchasePaid||0)-Number(payments.get(String(v.id))||0),0);
  $("purchaseTotal").textContent=money(total);$("purchasePaid").textContent=money(paid);$("purchasePending").textContent=money(pending);
  if($("vendorAccountsCard")&&!$("vendorAccountsCard").classList.contains("hidden"))renderVendorAccountsFromSummary(summary);
  if($("vendorPaymentsCard")&&!$("vendorPaymentsCard").classList.contains("hidden"))renderVendorPaymentsOnly();
  if($("purchaseHistoryCard")&&!$("purchaseHistoryCard").classList.contains("hidden")&&!renderPurchaseHistoryPage()){
   normalizePurchaseHistorySchema();return renderPurchasingFallback();
  }
  return;
 }
 // On Android, a native query failure must not fall back to parsing every purchase
 // invoice in the WebView. Keep vendor master navigation usable and show an explicit
 // local-database warning instead of triggering a potentially app-blocking full read.
 if(nativeBridgePresent){
  ["purchaseTotal","purchasePaid","purchasePending"].forEach(id=>{const el=$(id);if(el)el.textContent="Summary unavailable";});
  if($("vendorAccountsCard")&&!$("vendorAccountsCard").classList.contains("hidden")){
   const va=$("vendorAccounts");va.innerHTML="";
   (state.vendors||[]).slice((vendorAccountsPage-1)*VENDOR_PAGE_SIZE,vendorAccountsPage*VENDOR_PAGE_SIZE).forEach(v=>{const r=document.createElement("div");r.className="vendor-account";r.innerHTML=`<div class="vendor-account-head"><div><div class="history-title">${esc(v.name)}</div><div class="muted">${esc(v.phone||"")}</div></div><div class="row-actions"><button class="secondary edit-vendor">Edit</button><button class="secondary pay">Pay</button><button class="secondary vendor-transactions">Transactions</button></div></div><div class="muted">Purchase balance summary temporarily unavailable.</div>`;r.querySelector(".edit-vendor").onclick=()=>openVendorModal(v.id);r.querySelector(".pay").onclick=()=>{$("paymentVendor").value=v.id;$("paymentDate").value=today();$("paymentModal").classList.remove("hidden");};r.querySelector(".vendor-transactions").onclick=()=>openTransactionHistory("vendor",v.id);va.appendChild(r);});
  }
  if($("purchaseHistoryCard")&&!$("purchaseHistoryCard").classList.contains("hidden")){if(!renderPurchaseHistoryPage())$("purchaseHistory").innerHTML='<div class="muted">Purchase history is temporarily unavailable. Your saved records are unchanged; please reopen this section or share diagnostics.</div>';}
  if($("vendorPaymentsCard")&&!$("vendorPaymentsCard").classList.contains("hidden"))renderVendorPaymentsOnly();
  return;
 }
 normalizePurchaseHistorySchema();renderPurchasingFallback();
}
function renderPurchasingFallback(){
 renderVendorsSelects();
 const total=state.purchases.reduce((s,p)=>s+Number(p.total||0),0),paid=state.purchases.reduce((s,p)=>s+Number(p.paid||0),0)+state.vendorPayments.reduce((s,p)=>s+Number(p.amount||0),0),pending=state.vendors.reduce((s,v)=>s+vendorBalance(v).pending,0);
 $("purchaseTotal").textContent=money(total);$("purchasePaid").textContent=money(paid);$("purchasePending").textContent=money(pending);
 if(!$("vendorAccountsCard").classList.contains("hidden")){const va=$("vendorAccounts");va.innerHTML="";if(!state.vendors.length)va.innerHTML='<div class="muted">No vendors added yet.</div>';state.vendors.forEach(v=>{const b=vendorBalance(v),r=document.createElement("div");r.className="vendor-account";r.innerHTML=`<div class="vendor-account-head"><div><div class="history-title">${esc(v.name)}</div><div class="muted">${esc(v.phone||"")} ${v.gstin?"• "+esc(v.gstin):""}</div></div><div class="row-actions"><button class="secondary edit-vendor">Edit</button><button class="secondary pay">Pay</button><button class="secondary vendor-transactions">Transactions</button></div></div><div class="purchase-summary"><div class="sales-box"><span>Purchases</span><strong>${money(b.purchases)}</strong></div><div class="sales-box"><span>Paid</span><strong class="paid">${money(b.paid)}</strong></div><div class="sales-box"><span>Pending</span><strong class="${b.pending>0?"payable":"paid"}">${money(b.pending)}</strong></div></div>`;r.querySelector(".edit-vendor").onclick=()=>openVendorModal(v.id);r.querySelector(".pay").onclick=()=>{$("paymentVendor").value=v.id;$("paymentDate").value=today();$("paymentModal").classList.remove("hidden");};r.querySelector(".vendor-transactions").onclick=()=>openTransactionHistory("vendor",v.id);va.appendChild(r);});}
 if(!$("vendorPaymentsCard").classList.contains("hidden"))renderVendorPaymentsOnly();
 if(!$("purchaseHistoryCard").classList.contains("hidden")){const ph=$("purchaseHistory"),q=String($("purchaseSearch")?.value||"").trim().toLowerCase(),list=state.purchases.filter(p=>{if(!q)return true;const vendor=vendorById(p.vendorId)?.name||p.vendorName||"";return [p.invoiceNo,p.date,vendor,p.vendorName,p.total,p.paid,p.id,...(Array.isArray(p.items)?p.items.flatMap(i=>[i.name,i.hsn,i.barcode]):[])].some(v=>String(v??"").toLowerCase().includes(q));}).sort((a,b)=>String(b.date||"").localeCompare(String(a.date||"")));const pages=Math.max(1,Math.ceil(list.length/TRANSACTION_PAGE_SIZE));purchaseHistoryPage=Math.min(Math.max(1,purchaseHistoryPage),pages);const rows=list.slice((purchaseHistoryPage-1)*TRANSACTION_PAGE_SIZE,purchaseHistoryPage*TRANSACTION_PAGE_SIZE);ph.innerHTML="";if(!list.length)ph.innerHTML='<div class="muted">No purchase bills found.</div>';rows.forEach(p=>{const v=vendorById(p.vendorId),r=document.createElement("div");r.className="history-row";r.innerHTML=`<div><div class="history-title">${esc(v?.name||p.vendorName||"Vendor")} • ${esc(p.invoiceNo||"No invoice")}</div><div class="muted">${esc(p.date||"")} • Total ${money(p.total)} • Paid ${money(p.paid)} • Pending ${money(Number(p.total)-Number(p.paid))}</div></div><div class="row-actions"><button class="secondary viewPurchase" type="button">View</button><button class="secondary editPurchase" type="button">Edit</button><button class="primary purchasePdf" type="button">PDF</button></div>`;r.querySelector(".viewPurchase").onclick=()=>{const fresh=resolvePurchaseRecord(p);if(fresh)showPurchaseDetail(fresh);};r.querySelector(".editPurchase").onclick=()=>editPurchase(p);r.querySelector(".purchasePdf").onclick=()=>{const fresh=resolvePurchaseRecord(p);if(fresh)exportPurchasePdf(fresh);};ph.appendChild(r);});purchaseHistoryPage=renderTransactionPager(ph,"purchaseHistoryPagination",list.length,purchaseHistoryPage,next=>{purchaseHistoryPage=next;renderPurchasingFallback();});}
}

function exportPurchasePdf(p){
 const payload=JSON.stringify({...p,settings:state.settings||{},vendorSnapshot:p.supplierSnapshot||{name:vendorById(p.vendorId)?.name||p.vendorName||"Vendor"}});
 // Build one canonical HTML document for both browser preview and Android printing.
 // The native raster/PDF path previously bypassed the HTML invoice layout and could
 // fail on supplier records whose optional line fields were absent.
 // Browser fallback for desktop/source testing: open a print-ready purchase invoice.
 const v=vendorById(p.vendorId)||p.supplierSnapshot||{};
 const vendorFssai=String(v.fssai||p.supplierSnapshot?.fssai||state.purchaseImportMeta?.fssai||"").trim();
 const rows=(p.items||[]).map((x,i)=>{const m=purchaseLineMath(x,p.taxableBill!==false);const rate=Number(x.taxRate??(Number(x.cgstRate||0)+Number(x.sgstRate||0)+Number(x.igstRate||0)));return `<tr><td>${i+1}</td><td>${esc(x.name||"")}</td><td>${esc(x.hsn||"")}</td><td class="num">${esc(x.qty??"")}</td><td>${esc(x.unit||"")}</td><td class="num">${money(m.buyingRate)}</td><td class="num">${money(m.taxable)}</td><td class="num">${rate.toFixed(2)}%</td><td class="num">${money(x.cgstAmount||0)}</td><td class="num">${money(x.sgstAmount||0)}</td><td class="num">${money(x.igstAmount||0)}</td><td class="num">${money(m.gross)}</td></tr>`}).join("");
 const gstByRate={};(p.items||[]).forEach(x=>{const r=Number(x.taxRate??(Number(x.cgstRate||0)+Number(x.sgstRate||0)+Number(x.igstRate||0)));const k=r.toFixed(2);if(!gstByRate[k])gstByRate[k]={taxable:0,cgst:0,sgst:0,igst:0,gst:0};const m=purchaseLineMath(x,p.taxableBill!==false);gstByRate[k].taxable+=m.taxable;gstByRate[k].cgst+=Number(x.cgstAmount||0);gstByRate[k].sgst+=Number(x.sgstAmount||0);gstByRate[k].igst+=Number(x.igstAmount||0);gstByRate[k].gst+=m.tax;});const gstRows=Object.entries(gstByRate).map(([r,g])=>`<tr><td>${r}%</td><td class="num">${money(g.taxable)}</td><td class="num">${money(g.cgst)}</td><td class="num">${money(g.sgst)}</td><td class="num">${money(g.igst)}</td><td class="num">${money(g.gst)}</td></tr>`).join("");
 const row=(label,value,bold=false)=>`<tr class="${bold?"bold":""}"><td>${label}</td><td class="num">${money(value)}</td></tr>`;
 const gross=(p.items||[]).reduce((a,x)=>a+purchaseLineMath(x,p.taxableBill!==false).gross,0),taxable=(p.items||[]).reduce((a,x)=>a+purchaseLineMath(x,p.taxableBill!==false).taxable,0),tax=(p.items||[]).reduce((a,x)=>a+purchaseLineMath(x,p.taxableBill!==false).tax,0),total=Number(p.total||0),paid=Number(p.paid||0);
 const html=`<!doctype html><html><head><meta charset="utf-8"><title>Purchase ${esc(p.invoiceNo||"")}</title><style>body{font:12px Arial,sans-serif;color:#222;margin:24px}h1{font-size:22px;margin:0 0 4px}.muted{color:#555}.meta{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:20px 0}table{border-collapse:collapse;width:100%;font-size:8px;table-layout:fixed;word-break:break-word;border:1px solid #222;margin:8px 0}th,td{border:1px solid #333;padding:4px 3px;text-align:left;vertical-align:top}th{background:#eee}.num{text-align:right;white-space:nowrap}.purchase-line-table th:last-child,.purchase-line-table td:last-child{padding-right:9px}small{display:block;color:#555;margin-top:3px}.summary{width:100%;margin:10px 0 0 auto}.summary table{width:100%;font-size:9px}.summary td:first-child{width:72%}.bold{font-weight:bold;font-size:12px;border-top:2px solid #333;background:#eee}.footer{margin-top:18px;color:#555}@page{size:A4 landscape;margin:8mm}@media print{body{margin:0}}</style></head><body><h2>Purchase Bill</h2><div class="meta"><div><b>BUYER (YOUR SHOP)</b><br><b>${esc(state.settings.shopName||"")}</b><br>${esc(state.settings.address||"")}<br>GSTIN: ${esc(state.settings.gstin||"-")}<br>State: ${esc(state.settings.businessState||"-")}<br>Phone: ${esc(state.settings.shopMobile||"-")}${p.taxableBill!==false&&state.settings.fssai?`<br>FSSAI: ${esc(state.settings.fssai)}`:""}</div><div><b>SELLER (VENDOR)</b><br><b>${esc(v.name||p.vendorName||"")}</b><br>${esc(v.address||"")}<br>GSTIN: ${esc(v.gstin||"-")} &nbsp; PAN: ${esc(v.pan||"-")}${p.taxableBill!==false&&vendorFssai?`<br>FSSAI: ${esc(vendorFssai)}`:""}<br>State: ${esc(v.state||p.supplierState||"-")}<hr><b>Invoice No:</b> ${esc(p.invoiceNo||"-")}<br><b>Date:</b> ${esc(p.date||"-")}<br><b>PO:</b> ${esc(p.poNumber||"-")}<br><b>Payment Terms:</b> ${esc(p.paymentTerms||"-")}</div></div><table class="purchase-line-table"><thead><tr><th>#</th><th>Item</th><th>HSN/SAC</th><th>Qty</th><th>Unit</th><th class="num">Buy rate</th><th class="num">Taxable</th><th class="num">Tax %</th><th class="num">CGST</th><th class="num">SGST</th><th class="num">IGST</th><th class="num">Total</th></tr></thead><tbody>${rows}</tbody></table>${p.taxableBill===false?'<h3>Non-taxable purchase — GST not applied</h3>':`<h3>GST breakdown by rate</h3><table><thead><tr><th>Tax %</th><th>Taxable</th><th>CGST</th><th>SGST</th><th>IGST</th><th>Total GST</th></tr></thead><tbody>${gstRows}</tbody></table>`}<div class="summary"><table><thead><tr><th>Bill Summary</th><th class="num">Amount (₹)</th></tr></thead><tbody>${row("Items total ("+(p.amountsIncludeTax===false?"before GST":"incl. tax")+")",gross)}${row("Taxable amount",taxable)}${p.taxableBill===false?row("GST (not applicable)",0):row("GST included",tax)}${row("Other charges",p.otherCharges||0)}${row("Discount",-(p.invoiceDiscount||0))}${row("TCS",p.tcsAmount||0)}${row("Round off",p.roundOff||0)}${row("Invoice total",total,true)}${row("Paid",paid)}${row("Balance pending",Math.max(0,total-paid),true)}</tbody></table></div><div class="footer">Generated by SiddhiBill. Amounts shown are from the saved purchase record.</div><script>window.onload=()=>setTimeout(()=>window.print(),250)</script></body></html>`;
 if(window.Android?.printHtmlDocument){
  const safeInvoice=String(p.invoiceNo||"Purchase").replace(/[^A-Za-z0-9_-]/g,"_");
  window.Android.printHtmlDocument(html,"Purchase_"+safeInvoice+".pdf");
  return;
 }
 const w=window.open("","_blank");if(!w){showNotice("Allow pop-ups to print this purchase PDF.","Purchase PDF");return;}w.document.open();w.document.write(html);w.document.close();
}
function showPurchaseDetail(p){
 const v=vendorById(p.vendorId),items=Array.isArray(p.items)?p.items:[];
 let modal=$("purchasePreviewModal");
 if(!modal){modal=document.createElement("div");modal.id="purchasePreviewModal";modal.style.cssText="position:fixed;inset:0;z-index:9999;background:#0008;display:none;align-items:center;justify-content:center;padding:12px;";modal.innerHTML=`<div style="background:#fff;border-radius:16px;width:min(96vw,760px);max-height:90vh;overflow:auto;padding:16px;box-shadow:0 12px 40px #0003"><div style="display:flex;justify-content:space-between;align-items:center;gap:12px"><h2 style="margin:0">Purchase Bill</h2><button id="purchasePreviewClose" class="secondary" type="button">Close</button></div><div id="purchasePreviewContent" style="margin-top:12px"></div><div style="display:flex;gap:8px;justify-content:flex-end;margin-top:14px"><button id="purchasePreviewPdf" class="primary" type="button">PDF / Print</button></div></div>`;document.body.appendChild(modal);$("purchasePreviewClose").onclick=()=>modal.style.display="none";$("purchasePreviewPdf").onclick=()=>{if(modal.__purchaseRecord)exportPurchasePdf(modal.__purchaseRecord);};}
 modal.__purchaseRecord=p;
 const rows=items.map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x.name||"")}</td><td>${esc(x.hsn||x.hsnCode||"")}</td><td style="text-align:right">${esc(x.qty??"")}</td><td>${esc(x.unit||"")}</td><td style="text-align:right">${money(x.rate||x.costPerUnitInclusive||0)}</td><td style="text-align:right">${money(x.lineTotal??x.lineTotalInclusive??(Number(x.qty||0)*Number(x.rate||0)))}</td></tr>`).join("");
 $("purchasePreviewContent").innerHTML=`<div><b>Vendor:</b> ${esc(v?.name||p.vendorName||"Vendor")}<br><b>Invoice:</b> ${esc(p.invoiceNo||"-")}<br><b>Date:</b> ${esc(displayDate(p.date||""))}</div><div style="overflow:auto;margin-top:12px"><table style="width:100%;border-collapse:collapse;font-size:13px"><thead><tr>${["#","Item","HSN","Qty","Unit","Rate","Amount"].map(x=>`<th style="border:1px solid #ccd5df;padding:6px;text-align:left">${x}</th>`).join("")}</tr></thead><tbody>${rows||`<tr><td colspan="7" style="padding:10px">No item details available.</td></tr>`}</tbody></table></div><div style="margin-top:12px;text-align:right;line-height:1.8"><div>Subtotal: <b>${money(p.subtotal||0)}</b></div><div>Tax / GST: <b>${money(p.taxAmount||0)}</b></div><div>Other charges: <b>${money(p.otherCharges||0)}</b></div><div>Discount: <b>${money(p.invoiceDiscount||0)}</b></div><div>Total: <b>${money(p.total||0)}</b></div><div>Paid: <b>${money(p.paid||0)}</b></div><div>Pending: <b>${money(Number(p.total||0)-Number(p.paid||0))}</b></div><div>Payment mode: <b>${esc(p.paymentMode||"-")}</b></div></div>`;
 modal.style.display="flex";
 if(p.attachment?.id&&window.Android?.openPurchaseAttachment){const open=document.createElement("button");open.className="secondary";open.type="button";open.textContent="Open Attachment";open.style.marginTop="10px";open.onclick=()=>window.Android.openPurchaseAttachment(p.attachment.id,p.attachment.mime||"application/pdf");$("purchasePreviewContent").appendChild(open);}
}
function purchaseCanonicalLine(item){return `${String(item.name||"").trim()} ${String(item.qty||"1").trim()} ${String(item.unit||"piece").trim()} ${Number(item.rate||0)}`.trim()}
function parsePurchaseOcrMetadata(text){
 const raw=String(text||"");
 const invoiceNo=(raw.match(/(?:Invoice\s*(?:No|Number)|Inv\.?\s*No\.?|Bill\s*(?:No|Number))\s*[:#-]?\s*([A-Z0-9][A-Z0-9\/-]+)/i)||[])[1]||"";
 const dateText=(raw.match(/(?:Invoice\s*Date|Bill\s*Date|Dated|Date)\s*[:#-]?\s*(\d{1,2}[\/-][A-Za-z]{3,9}[\/-]\d{2,4}|\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4}|\d{4}-\d{2}-\d{2})/i)||[])[1]||"";
 const amount=v=>Number(String(v||"").replace(/,/g,""));
 const firstAmount=(patterns)=>{for(const re of patterns){const m=raw.match(re);if(m)return amount(m[1]);}return 0;};
 // Prefer invoice-level labels and avoid accidentally capturing per-line tax values.
 const collectableLine=(raw.split(/\r?\n/).find(line=>/Collectable\s+Amount|Collectible\s+Amount/i.test(line))||"");
 const collectableValues=collectableLine.match(/[0-9,]+(?:\.\d{1,2})?/g)||[];
 const total=collectableValues.length?amount(collectableValues[collectableValues.length-1]):firstAmount([
  /(?:Grand\s*Total|Invoice\s*Total|Net\s*Payable|Total\s*Amount|Bill\s*Amount)\s*[:\-]?\s*(?:₹|Rs\.?\s*)?([0-9,]+(?:\.\d{1,2})?)/i
 ]);
 const gstSummary=raw.match(/GST\s+Summary([\s\S]{0,2200})/i);
 const gstSummaryText=gstSummary?gstSummary[1]:"";
 // Summary rows may be extracted on one line or across multiple lines. Prefer the final Total row.
 const summaryLines=gstSummaryText.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 let totalRow=null;
 for(let i=0;i<summaryLines.length;i++){
   if(/^Total\b/i.test(summaryLines[i])){
     let nums=(summaryLines[i].match(/[0-9,]+(?:\.\d{1,2})?/g)||[]).map(amount);
     if(nums.length<5 && summaryLines[i+1]) nums=nums.concat((summaryLines[i+1].match(/[0-9,]+(?:\.\d{1,2})?/g)||[]).map(amount));
     if(nums.length>=5){totalRow=nums;break;}
   }
 }
 const taxable=totalRow?totalRow[0]:firstAmount([/\bTaxable\s+Amount\s*[: ]+([0-9,]+(?:\.\d{1,2})?)/i]);
 const taxSection=(raw.match(/Total\s+Tax\s+Amount([\s\S]{0,180})/i)||[])[1]||"";
 const taxValues=taxSection.match(/[0-9,]+(?:\.\d{1,2})?/g)||[];
 const tax=totalRow?totalRow[4]:(taxValues.length?amount(taxValues[taxValues.length-1]):firstAmount([/(?:Total\s+(?:GST|Tax)|GST\s+Amount|Tax\s+Amount)\s*[:\-]?\s*(?:₹|Rs\.?\s*)?([0-9,]+(?:\.\d{1,2})?)/i]));
 const gstin=(raw.match(/GSTIN(?:\s*\/\s*UIN)?\s*[: ]\s*([0-9A-Z]{15})/i)||[])[1]||"";
 const supplierMatch=raw.match(/^\s*([^\n]{3,100}\bPRIVATE LIMITED(?:\s*\([^\n)]*\))?)/im)||raw.match(/^\s*([^\n]{3,80}\b(?:DISTRIBUTOR|TRADERS|ENTERPRISES|AGENCY|INDUSTRIES)\b[^\n]*)/im);
 const supplierName=supplierMatch?supplierMatch[1]:"";
 const pan=(raw.match(/(?:Company.?s\s+)?PAN\s*[: ]\s*([A-Z]{5}[0-9]{4}[A-Z])/i)||[])[1]||"";
 const poNumber=(raw.match(/\bPO[ \t]*Number[ \t]*:[ \t]*(?!Dated\b)([A-Z0-9][A-Z0-9/-]+)/i)||[])[1]||"";
 const supplierReference=(raw.match(/\bSO\s*No\s*[: ]\s*([A-Z0-9/-]+)/i)||[])[1]||"";
 const deliveryText=(raw.match(/Delivery\s*Date\s*[: ]\s*(\d{1,2}[/-][A-Za-z]{3,9}[/-]\d{2,4}|\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2})/i)||[])[1]||"";
 const stateName=(raw.match(/State\s*Name\s*[: ]\s*([A-Za-z ]+?)(?:\s*,?\s*State\s+Code|$)/im)||[])[1]||"";
 const stateCode=(raw.match(/State\s*Code\s*[: ]\s*(\d{2})/i)||[])[1]||"";
 const email=(raw.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)||[])[0]||"";
 let address=(raw.match(/(?:Registered\s+Office|Address|Bill\s+From|Supplier\s+Address)\s*[:\n]+([^\n]{8,180})/i)||[])[1]||"";if(!address&&supplierName){const allLines=raw.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);const si=allLines.findIndex(x=>x.toLowerCase().includes(supplierName.toLowerCase()));if(si>=0){const addrLines=[];for(const ln of allLines.slice(si+1,si+9)){if(/^(?:GSTIN|GSTIN\s*\/\s*UIN)/i.test(ln))break;if(/authorized|distributor|e-mail|email|phone|state name|\bPAN\b/i.test(ln))continue;if(/[A-Za-z]/.test(ln)&&ln.length>5)addrLines.push(ln);}address=addrLines.slice(0,3).join(', ');}}
 const phone=(raw.match(/(?:Phone|Telephone)\s*[: ]\s*([+()0-9 -]{8,18})/i)||[])[1]||"";
 const paymentTerms=(raw.match(/Terms\s+of\s+Payment\s*:\s*([^\n]*?)(?=\s{2,}|\s+Beat\s+Name|$)/i)||[])[1]||"";
 const paymentType=(raw.match(/Payment\s+Type\s*:\s*([^\n]*?)(?=\s{2,}|\s+Terms\s+of\s+Payment|$)/i)||[])[1]||"";
 let roundOff=firstAmount([/Round\s*Off[ \t]*[: ]?[ \t]*(-?[0-9,]+(?:\.[0-9]{1,2})?)/i]);if(!roundOff&&total>0&&(taxable>0||tax>0))roundOff=roundMoney(total-(taxable+tax));
 const tcs=firstAmount([/TCS\s*:?\s*[0-9.]*%?\s*([0-9,]+(?:\.[0-9]{1,2})?)/i]);
 const discount=firstAmount([/Bill\s+Discount\s*:?\s*[0-9.]*%?\s*([0-9,]+(?:\.[0-9]{1,2})?)/i]);
 return {invoiceNo,date:toInputDate(dateText)||(/\d{4}-\d{2}-\d{2}/.test(dateText)?dateText:""),address:address.trim(),deliveryDate:toInputDate(deliveryText)||(/\d{4}-\d{2}-\d{2}/.test(deliveryText)?deliveryText:""),total,tax,taxable,gstin,supplierName:supplierName.trim(),pan,poNumber,supplierReference,stateName:stateName.trim(),stateCode,email,phone:phone.trim(),paymentTerms:paymentTerms.trim(),paymentType:paymentType.trim(),roundOff,discount,tcs};
}
function parsePurchaseInvoiceTable(text){
 const raw=String(text||"");
 if(!/(?:Item\s+Code\s*-\s*Item\s+Description|Sr\s+Item\s+Code)/i.test(raw)||!/(?:HSN|Taxable\s+Amt)/i.test(raw))return [];
 const lines=raw.split(/\r?\n/).map(x=>x.trim()).filter(Boolean), anchors=[];
 // Supplier invoice rows start with a numeric SKU followed by a dash and description.
 for(let i=0;i<lines.length;i++){
   const m=lines[i].match(/^(?:\d{1,3}\s+)?(\d{5,12})\s*[-–]\s*(.+)$/);
   if(m){
     let desc=m[2].trim();
     desc=desc.replace(/\s+\d{8}\s+.*$/," ").replace(/\s+\d+(?:\.\d{1,2})?%.*$/," ").replace(/\s+\d+(?:\.\d+)?\s*(?:CA|EA)\s*$/i,"").replace(/,\s*IN\s*,?/gi," ").replace(/\s*,\s*/g," ").replace(/\s+/g," ").trim();
     // Normalize common supplier abbreviations/noise without changing item identity.
     desc=desc.replace(/^DETOL\b/i,"Dettol").replace(/^DETTOL\b/i,"Dettol").replace(/^HARPC\b/i,"Harpic");
     desc=desc.replace(/^Dettol\s*,\s*IN\s*,\s*(?:ORG|SAN|SOAP|SOP)\s*/i,"Dettol ");
     desc=desc.replace(/\bORG\b/gi,'Original').replace(/\bWHT\b/gi,'White').replace(/\bSHIN\b/gi,'Shine').replace(/\bFLO\b/gi,'Floor').replace(/\bSQUEZY\b/gi,'Squeezy').replace(/\bSAN\b/gi,'Sanitizer').replace(/\bSOP\b/gi,'Soap');
     desc=desc.replace(/\s+(?:SRP|PRCOF)$/i,"").replace(/\s+/g," ").trim();
     anchors.push({index:i,code:m[1],description:desc});
   }
 }
 const out=[];
 for(let n=0;n<anchors.length;n++){
   const a=anchors[n],block=lines.slice(a.index, n+1<anchors.length?anchors[n+1].index:lines.length);
   let description=a.description;
   // Wraparound description continuations occur on their own line (e.g. 100MLX96).
   for(const line of block.slice(1)){
     if(/^(?:Taxable Amount|CGST|UT\/SGST|IGST|Bill Discount|Round Off|TCS|Collectable Amount|GST Summary|TotalAmount|Terms and Condition|Total\s)/i.test(line))break;
     // Capture wrapped product-description suffixes before the numeric columns,
     // e.g. "-16PK 0EA 54.91 ..." or "100MLX96 2.43 ...".
     const prefixMatch=line.match(/^(-?[A-Z0-9@+&()/._%+-][A-Z0-9@+&()/._%+ -]{0,44}?)\s+(?=\d+(?:\.\d{1,2})?%|\d+(?:\.\d+)?\s*(?:CA|CASE|CS|EA|EACH)\b|\d+\.\d{1,2}\b)/i);
     if(prefixMatch && /[A-Z]/i.test(prefixMatch[1]) && !/\d{8}/.test(prefixMatch[1]) && !/^\d+(?:\.\d+)?\s*(?:CA|CASE|CS|EA|EACH)$/i.test(prefixMatch[1])){
       const suffix=prefixMatch[1].replace(/^-\s*/,"").trim();
       if(suffix && !description.toLowerCase().includes(suffix.toLowerCase()))description=(description+" "+suffix).trim();
       continue;
     }
     if(/^(?:\d{1,3}\s+)?\d{8}\s+/.test(line))continue;
     if(/^(?:Taxable Amount|CGST|UT\/SGST|IGST|Bill Discount|Round Off|TCS|Collectable Amount|GST Summary|TotalAmount|Terms and Condition)/i.test(line))break;
     if(/^(?:\d{1,3}\s+)?\d{5,12}\s*[-–]\s*/.test(line))continue;
     const looksLikeContinuation=/^[A-Z0-9@+&()/._ -]{2,35}$/i.test(line)
       && !/\d{8}/.test(line) && !/\d+\.\d{1,2}/.test(line)
       && !/\d+\s*(?:CA|CASE|CS|EA|EACH)\b/i.test(line) && !/\d+%/.test(line)
       && !/^(?:Taxable Amount|CGST|UT\/SGST|IGST|Bill Discount|Round Off|TCS|Collectable Amount|GST Summary|TotalAmount|Terms and Condition)/i.test(line);
     if(looksLikeContinuation){
       const candidate=line.replace(/^-\s*/,"").trim();
       if(candidate&&!description.toLowerCase().includes(candidate.toLowerCase()))description=(description+" "+candidate).trim();
     }
   }
   let qty=null,unit="each",rate=null,hsn="",mrp=null,itemCode=a.code,sourceDetailLine="",packSize=1,invoiceTaxableAmount=null,invoiceLineTotal=null,cgstAmount=null,sgstAmount=null,igstAmount=null,schemeDiscount=0,cgstRate=0,sgstRate=0,igstRate=0,sourceUomNumericOnly=false,sourceQty=null;
   // Quantity may be printed in a separate visual row (case/each). Prefer the first positive quantity.
   for(const line of block){
     const qm=[...line.matchAll(/\b(\d+(?:\.\d+)?)\s*(CA|CASE|CS|EA|EACH)\b/ig)].map(m=>({qty:Number(m[1]),unit:/^(?:CA|CASE|CS)$/i.test(m[2])?"case":"each"}));
     const positive=qm.find(x=>x.qty>0);if(positive&&qty===null){qty=positive.qty;unit=positive.unit;}
   }
   // The numeric detail line is anchored by the 8-digit HSN. Following columns are UOM, MRP, Qty, Rate.
   for(const line of block){
     const hm=line.match(/\b(\d{8})\s+(.+)$/);if(!hm)continue;
     hsn=hm[1];sourceDetailLine=line;
     const tokens=hm[2].match(/\d+(?:\.\d+)?\s*(?:CA|EA)|\d+(?:,\d{3})*(?:\.\d{1,2})?/ig)||[];
     const clean=tokens.map(x=>x.replace(/,/g,"").trim());
     // Expected columns: pack size, MRP, optional qty token, rate. If qty is blank, rate is token 3.
     if(clean.length>=3){
       // Invoice columns after HSN: pack count, MRP, optional billed qty, rate,
       // discount, taxable value, line total. Keep invoice values as source facts.
       if(clean[0]&&/^\d+$/.test(clean[0]))packSize=Number(clean[0])||1;
       if(clean[1]&&/^\d+(?:\.\d{1,2})?$/.test(clean[1]))mrp=Number(clean[1]);
       if(clean.length>=5){invoiceTaxableAmount=Number(clean[clean.length-2]);invoiceLineTotal=Number(clean[clean.length-1]);}
       const qtyAt=clean.findIndex(x=>/\d+(?:\.\d+)?\s*(?:CA|EA)$/i.test(x));
       const rateToken=qtyAt>=0?clean[qtyAt+1]:clean[2];
       if(rateToken&&/^\d+(?:\.\d{1,2})?$/.test(rateToken)){rate=Number(rateToken);}
     }
     break;
   }
   // IMPORTANT: Android PDFTextStripper / ML Kit may split a visual invoice row
   // across several text lines. The HSN detail line can therefore contain only
   // UOM, MRP and rate; its last two numbers are NOT necessarily taxable/total.
   // Resolve the taxable + GST-inclusive Total pair from the entire item block.
   // Ignore percentages (scheme discount and tax rates) and select the highest
   // plausible adjacent amount pair whose total reconciles at a standard GST rate.
   {
     const summaryStart=block.findIndex(line=>/^(?:Taxable Amount|CGST|UT\/SGST|IGST|Bill Discount|Round Off|TCS|Collectable Amount|GST Summary|TotalAmount|Terms and Condition)/i.test(line));
     const amountLines=summaryStart>=0?block.slice(0,summaryStart):block;
     const blockWithoutPercents=amountLines.join(" ").replace(/\d+(?:\.\d+)?\s*%/g," ");
     const moneyTokens=[...blockWithoutPercents.matchAll(/(?<![\d.])\d+(?:,\d{3})*\.\d{2}(?!\d)/g)].map(m=>Number(m[0].replace(/,/g,"")));
     let best=null;
     for(let k=0;k<moneyTokens.length-1;k++){
       const taxableCandidate=moneyTokens[k],totalCandidate=moneyTokens[k+1];
       if(!(taxableCandidate>0)||!(totalCandidate>=taxableCandidate))continue;
       const inferredRate=Math.round((totalCandidate/taxableCandidate-1)*100);
       if(![0,5,12,18,28].includes(inferredRate))continue;
       const expected=roundMoney(taxableCandidate*inferredRate/100);
       if(Math.abs((totalCandidate-taxableCandidate)-expected)>0.03)continue;
       const score=totalCandidate; // largest reconciled pair is the line's taxable/total pair, not unit rate/discount/tax amounts
       if(!best||score>best.score)best={taxable:taxableCandidate,total:totalCandidate,rate:inferredRate,score};
     }
     if(best){invoiceTaxableAmount=best.taxable;invoiceLineTotal=best.total;}
   }
   if(qty===null){
     const qline=block.find(x=>/\b\d+(?:\.\d+)?\s*(?:CA|CASE|CS|EA|EACH)\b/i.test(x));
     const qm=qline&&qline.match(/\b(\d+(?:\.\d+)?)\s*(CA|CASE|CS|EA|EACH)\b/i);if(qm&&Number(qm[1])>0){qty=Number(qm[1]);unit=/^(?:CA|CASE|CS)$/i.test(qm[2])?"case":"each";}
   }
   // Keep the raw supplier UOM/Qty column candidates for bill-level resolution below.
   // Do not decide row-by-row: these invoices can swap the two columns consistently
   // for the entire bill. A bill-level pass after all rows are parsed selects one column.
   if(sourceDetailLine){
     const detailMatch=sourceDetailLine.match(/\b(\d{8})\s+(.+)$/);
     if(detailMatch){
       const detailTokens=detailMatch[2].match(/\d+(?:\.\d+)?\s*(?:CA|CASE|CS|EA|EACH)|\d+(?:,\d{3})*(?:\.\d{1,2})?/ig)||[];
       const numericTokens=detailTokens.map(t=>t.replace(/,/g,'').trim());
       const uomToken=numericTokens[0]||'';
       const uomCount=/^\d+(?:\.\d+)?$/.test(uomToken)?Number(uomToken):NaN;
       let qtyToken=numericTokens.find(t=>/\d+(?:\.\d+)?\s*(?:CA|CASE|CS|EA|EACH)$/i.test(t));
       if(!qtyToken){
         const detailPos=block.indexOf(sourceDetailLine);
         const nextLine=detailPos>=0?block.slice(detailPos+1,detailPos+3).find(x=>/\b\d+(?:\.\d+)?\s*(?:CA|CASE|CS|EA|EACH)\b/i.test(x)):null;
         const qm=nextLine&&nextLine.match(/\b(\d+(?:\.\d+)?)\s*(CA|CASE|CS|EA|EACH)\b/i);
         if(qm)qtyToken=qm[1]+qm[2];
       }
       const qm=qtyToken&&qtyToken.match(/(\d+(?:\.\d+)?)\s*(CA|CASE|CS|EA|EACH)$/i);
       const columnQty=qm?Number(qm[1]):NaN;
       // Keep explicit candidates; the whole bill's column pattern determines which wins.
       if(Number.isFinite(uomCount)&&uomCount>0)packSize=uomCount;
       if(Number.isFinite(columnQty)&&columnQty>0){qty=columnQty;sourceQty=columnQty;unit=qm&&/^(?:CA|CASE|CS)$/i.test(qm[2])?'case':'each';}
       sourceUomNumericOnly=Number.isFinite(uomCount)&&uomCount>0;
       // A supplier row showing exactly 1 Case means the Quantity is a pack marker;
       // use the numeric UOM/EA count for the actual item quantity when available.
       if(unit==='case'&&Number(qty)===1&&sourceUomNumericOnly&&Number(packSize)>0){qty=Number(packSize);sourceQty=Number(packSize);unit='each';}
     }
   }
   // Some distributor templates print case/each quantity in the aligned column
   // immediately before the description/serial line. Only inspect the few lines
   // between the previous item and this row, and prefer the nearest positive value.
   if(qty===null && sourceUomNumericOnly && Number(packSize)>0){qty=Number(packSize);unit='each';}
   if(qty===null){
     const previousStart=n>0?anchors[n-1].index+1:Math.max(0,a.index-4);
     const priorLines=lines.slice(Math.max(previousStart,a.index-4),a.index).reverse();
     for(const priorLine of priorLines){
       const matches=[...priorLine.matchAll(/\b(\d+(?:\.\d+)?)\s*(CA|CASE|CS|EA|EACH)\b/ig)];
       const positive=matches.map(m=>({q:Number(m[1]),u:m[2]})).find(m=>m.q>0);
       if(positive){qty=positive.q;unit=/^(?:CA|CASE|CS)$/i.test(positive.u)?"case":"each";break;}
     }
   }
   if(!description||qty===null||!Number.isFinite(rate)||rate<0)continue;
   // Keep supplier code as an item-code prefix so repeated invoices can be mapped later.
   const blockText=block.join(" ");
   // Read only GST rate columns. Scheme discount is a separate column and must never
   // be added to GST. Typical layouts have [Scheme Disc, CGST, SGST, IGST]; some
   // layouts omit Scheme Disc or label the tax column simply GST.
   const percentRows=block.map(line=>[...line.matchAll(/(\d+(?:\.\d+)?)\s*%/g)].map(m=>Number(m[1]))).filter(a=>a.length>0);
   // Some suppliers print the rate row immediately before the item description.
   if(!percentRows.length){for(const prior of lines.slice(Math.max(0,a.index-3),a.index)){const values=[...prior.matchAll(/(\d+(?:\.\d+)?)\s*%/g)].map(m=>Number(m[1]));if(values.length)percentRows.push(values);}}
   const pct=percentRows.length?percentRows[0]:[];
   if(pct.length>=4){
     // First percentage is Scheme Discount; ignore it. GST columns are the final 3.
     cgstRate=pct[pct.length-3]||0;sgstRate=pct[pct.length-2]||0;igstRate=pct[pct.length-1]||0;
   }else if(pct.length===3){
     // Three tax columns without a scheme-discount column: CGST, SGST, IGST.
     cgstRate=pct[0]||0;sgstRate=pct[1]||0;igstRate=pct[2]||0;
   }else if(pct.length===2){
     // Two columns are CGST and SGST (or a single GST split into its two components).
     cgstRate=pct[0]||0;sgstRate=pct[1]||0;igstRate=0;
   }else if(pct.length===1){
     // Supplier uses a single GST column instead of CGST/SGST/IGST.
     cgstRate=pct[0]||0;sgstRate=0;igstRate=0;
   }
   // Combined GST rate: positive IGST takes precedence; otherwise add CGST + SGST.
   // Zero-valued tax columns are ignored.
   let sourceGstRate=igstRate>0?igstRate:((cgstRate>0?cgstRate:0)+(sgstRate>0?sgstRate:0));
   // The line following the HSN detail carries scheme/discount and tax amounts.
   const detailIndex=block.findIndex(x=>/\b\d{8}\s+/.test(x));
   const taxLine=detailIndex>=0?block.slice(detailIndex+1,detailIndex+3).find(x=>/\d+\.\d{2}/.test(x)&&!/^\s*(?:\d{1,3}\s+)?\d{8}/.test(x)):"";
   if(taxLine){const vals=(taxLine.match(/-?[0-9,]+\.\d{2}/g)||[]).map(x=>Number(x.replace(/,/g,"")));if(vals.length>=4){schemeDiscount=vals[0];cgstAmount=vals[1];sgstAmount=vals[2];igstAmount=vals[3];}}
   let totalTaxRate=sourceGstRate;
   // OCR sometimes associates the preceding item's discount/tax row with the final item.
   // The invoice's own taxable value and tax-inclusive line total are the stronger per-line source.
   if(invoiceTaxableAmount>0&&invoiceLineTotal>=invoiceTaxableAmount){
     const inferred=Math.round(((invoiceLineTotal/invoiceTaxableAmount)-1)*100);
     if([0,5,12,18,28].includes(inferred)&&Math.abs((invoiceLineTotal-invoiceTaxableAmount)-roundMoney(invoiceTaxableAmount*inferred/100))<=0.03){
       totalTaxRate=inferred;
       if(inferred>0&&cgstRate+sgstRate+igstRate!==inferred){cgstRate=inferred/2;sgstRate=inferred/2;igstRate=0;}
     }
   }
   out.push({name:description.replace(/\s+/g," ").trim(),itemCode,hsn,mrp,qty:String(qty),freeQty:0,unit,packSize,baseQty:Number(qty)*(unit==="case"?packSize:1),rate,schemeDiscount,discountAmount:0,taxRate:totalTaxRate,cgstRate,sgstRate,igstRate,cgstAmount,sgstAmount,igstAmount,invoiceTaxableAmount,invoiceLineTotal,sourceDetailLine,sourceUomNumericOnly,sourceQty,rawExtractedText:blockText,reviewRequired:!hsn||mrp==null||invoiceTaxableAmount==null});
 }
 if(out.length){
   // Quantity is authoritative when present. Only a single Case marker uses the
   // row's numeric UOM/EA count; if Quantity was absent, the parser already fell
   // back to that row's numeric UOM. Never switch every row based on bill-wide data.
   for(const item of out){delete item.sourceUomNumericOnly;delete item.sourceQty;}
 }
 if(!out.length){
   // Column-oriented PDF text often lists all descriptions first and the HSN/quantity columns afterwards.
   // Pair those sections by row order; keep one billed unit as one unit and never apply pack conversions.
   const descriptionAnchors=[];
   for(let i=0;i<lines.length;i++){const m=lines[i].match(/^(?:\d{1,3}\s+)?(\d{5,12})\s*[-–]\s*(.+)$/);if(m){let description=m[2].trim();for(let j=i+1;j<lines.length&&!/^(?:\d{1,3}\s+)?\d{5,12}\s*[-–]\s*/.test(lines[j])&&!/^\d{8}$/.test(lines[j]);j++){const cont=lines[j].trim();if(/^(?:HSN|U|O|M|MRP|Qty|Rate|Taxable Amount|CGST|IGST|GST Summary)/i.test(cont))break;if(cont.length<40&&!/\d+\.\d{2}/.test(cont)&&/[A-Z]/i.test(cont))description+=' '+cont.replace(/^-\s*/, '');}descriptionAnchors.push({code:m[1],name:description.replace(/\s+/g,' ').trim()});}}
   const hsnIndices=[];for(let i=0;i<lines.length;i++)if(/^\d{8}$/.test(lines[i]))hsnIndices.push(i);
   const totalAmtMatches=[...raw.matchAll(/Total\s*\n\s*Amt/ig)];let lineTotals=[];if(totalAmtMatches.length){const pos=totalAmtMatches[totalAmtMatches.length-1].index;const endPos=raw.search(/Total\s+Tax\s+Amount/i);const section=raw.slice(pos,endPos>pos?endPos:pos+700);lineTotals=(section.match(/[0-9,]+(?:\.\d{1,2})?/g)||[]).map(v=>Number(String(v).replace(/,/g,''))).filter(v=>v>0).slice(0,descriptionAnchors.length);}
   for(let i=0;i<Math.min(descriptionAnchors.length,hsnIndices.length);i++){
     const a=descriptionAnchors[i],startAt=hsnIndices[i],endAt=i+1<hsnIndices.length?hsnIndices[i+1]:lines.length,part=lines.slice(startAt+1,endAt);
     const qTokens=[];part.forEach((ln,idx)=>{for(const m of ln.matchAll(/\b(\d+(?:\.\d+)?)\s*(CA|CASE|CS|EA|EACH|BOX|BOXES)\b/ig))if(Number(m[1])>0)qTokens.push({qty:Number(m[1]),idx});});
     const q=qTokens[0]||{qty:1,idx:-1};let rate=0;for(let j=Math.max(0,q.idx+1);j<part.length;j++){const n=part[j].match(/^([0-9,]+\.\d{1,2})$/);if(n){rate=Number(String(n[1]).replace(/,/g,''));break;}}if(!rate){const nums=part.map(x=>x.match(/^([0-9,]+\.\d{1,2})$/)).filter(Boolean).map(m=>Number(String(m[1]).replace(/,/g,'')));rate=nums.length?nums[nums.length-1]:0;}
     if(!a.name||!(q.qty>0))continue;const gross=lineTotals[i]!=null?lineTotals[i]:roundMoney(q.qty*rate);
     out.push({name:a.name,itemCode:a.code,hsn:lines[startAt],qty:String(q.qty),freeQty:0,unit:'Unit',packSize:1,baseQty:q.qty,rate:rate||gross/q.qty,taxRate:0,cgstRate:0,sgstRate:0,igstRate:0,cgstAmount:null,sgstAmount:null,igstAmount:null,invoiceTaxableAmount:null,invoiceLineTotal:gross,rawExtractedText:part.join(' '),reviewRequired:true});
   }
 }
 return out;
}
function purchaseOcrEntryLine(item){
 // Emit only the requested purchase columns: item, bill-level resolved UOM/Qty,
 // tax-inclusive line Total, combined GST rate, HSN/SAC and optional barcode.
 // Scheme discount and other supplier columns are deliberately excluded.
 const rawName=String(item.name||item.description||item.itemName||'').trim();
 const correctedName=typeof canonicalizeOcrProductName==='function'?canonicalizeOcrProductName(rawName):rawName;
 item=enrichPurchaseItemFromMaster({...item,name:correctedName,originalOcrName:rawName,unitWasDefault:item.unitWasDefault===true||item.unitMissing===true,taxRateWasProvided:item.taxRateWasProvided===undefined?(Number(item.taxRate||0)>0):item.taxRateWasProvided});
 const name=String(item.name||item.description||item.itemName||'').trim();
 const total=item.invoiceLineTotal!=null?Number(item.invoiceLineTotal):(item.lineTotalInclusive!=null?Number(item.lineTotalInclusive):Number(item.rate||0));
 const qtyValue=Number(item.qty);
 const qty=Number.isFinite(qtyValue)&&qtyValue>0?qtyValue:1;
 const unitRaw=String(item.unit||'').trim().toLowerCase();
 const unit=unitRaw==='case'||unitRaw==='carton'?'Case':(unitRaw==='packet'||unitRaw==='pk'||unitRaw==='pkt'?'Packet':(unitRaw==='each'||unitRaw==='ea'?'Piece':'Piece'));
 const tax=item.taxRate??item.gstRate??null,hsn=String(item.hsn||item.hsnCode||'').trim(),barcode=String(item.barcode||item.ean||item.upc||'').trim();
 return [name,String(qty),unit,String(roundMoney(total)),tax==null?'':String(Number(tax)),hsn,barcode].join(',');
}
function parsePurchaseGenericColumnTable(text){
 const lines=String(text||"").split(/\r?\n/).map(x=>x.replace(/\t/g,"    ").replace(/\s+$/,""));
 const findHeading=(line,patterns)=>{for(const re of patterns){const m=re.exec(line);if(m)return {start:m.index,end:m.index+m[0].length,text:m[0]};}return null;};
 let headerIndex=-1,header="",heads={};
 const patterns={item:[/item\s*(?:name|description)?/i,/product\s*(?:name|description)?/i,/description/i],qty:[/quantity/i,/\bqty\b/i],ea:[/\bea\b/i],uom:[/\buom\b/i],unit:[/\bunit\b/i,/\bpack(?:ing)?\b/i],total:[/grand\s*total/i,/net\s*amt\.?/i,/line\s*total/i,/total\s*amt\.?/i,/gross\s*amt\.?/i,/\btotal\b/i,/amount/i],cgst:[/\bCGST\s*%?/i],sgst:[/\bSGST\s*%?/i],igst:[/\bIGST\s*%?/i],gst:[/(?<![A-Z])GST\s*%?/i,/\bTAX\s*%?/i],hsn:[/hsn(?:\/sac)?/i]};
 for(let i=0;i<Math.min(lines.length,120);i++){
   const line=lines[i];const found={};for(const [key,res] of Object.entries(patterns)){for(const re of res){const m=re.exec(line);if(m){found[key]={start:m.index,end:m.index+m[0].length,text:m[0]};break;}}}
   if(found.item&&found.total&&(found.qty||found.ea||found.uom||found.unit)&&Object.keys(found).length>=3){headerIndex=i;header=line;heads=found;break;}
 }
 if(headerIndex<0)return [];
 // Use column positions from the header. Item is the first/second column after Sr. No.;
 // Total is the rightmost total/amount heading, never the invoice summary outside this table.
 const starts=Object.entries(heads).map(([key,v])=>({key,start:v.start,end:v.end})).sort((a,b)=>a.start-b.start);
 if(!starts.some(x=>x.key==="item")||!starts.some(x=>x.key==="total"))return [];
 const col=(line,key)=>{const h=starts.find(x=>x.key===key);if(!h)return "";const next=starts.find(x=>x.start>h.start);return line.slice(h.start,next?next.start:line.length).trim();};
 const numeric=(v)=>{const m=String(v||"").replace(/,/g,"").match(/-?\d+(?:\.\d+)?/);return m?Number(m[0]):null;};
 const rows=[];let started=false;
 const candidateLines=lines.slice(headerIndex+1).filter(line=>line.trim()&&!/^(?:subtotal|grand\s*total|invoice\s*total|tax\s*summary|gst\s*summary|total\s+tax|round\s*off|terms\b)/i.test(line.trim()));
 for(let i=headerIndex+1;i<lines.length;i++){
   const line=lines[i];if(!line.trim())continue;
   if(/^(?:subtotal|grand\s*total|invoice\s*total|tax\s*summary|gst\s*summary|total\s+tax|round\s*off|terms\b)/i.test(line.trim()))break;
   const name=col(line,"item").replace(/^\s*\d{1,3}\s+/,"").replace(/\s+/g," ").trim();
   if(!name||!/\p{L}/u.test(name))continue;
   const total=numeric(col(line,"total"));if(total==null||total<0)continue;
   let qty=null;
   const qtyCell=heads.qty?col(line,"qty"):"";
   const qtyIsCaseOrBox=/^\s*1(?:\.0+)?\s*(?:case|cases|box|boxes)\s*$/i.test(qtyCell);
   const eaQty=heads.ea?numeric(col(line,"ea")):null;
   const uomQty=heads.uom?numeric(col(line,"uom")):null;
   if(qtyIsCaseOrBox){
     // Supplier invoices sometimes put the pack quantity (e.g. 1 Case) in Quantity
     // and the actual each count in EA/UoM. Prefer the numeric EA field, then UoM.
     qty=eaQty>0?eaQty:(uomQty>0?uomQty:null);
   }else if(heads.qty){
     qty=numeric(qtyCell);
   }else{
     // If Quantity/Qty is absent, select the first EA or UoM column containing a number.
     qty=eaQty>0?eaQty:(uomQty>0?uomQty:(heads.unit?numeric(col(line,"unit")):null));
   }
   if(!(qty>0))continue;
   let unitText=col(line,"unit").replace(/[^A-Za-z]/g,"").trim();
   if(!unitText||unitText.length<3){const afterQty=line.slice((starts.find(x=>x.key==="qty")||starts.find(x=>x.key==="unit")||{start:0}).start);const um=afterQty.match(/^\s*\d+(?:\.\d+)?\s+([A-Za-z]{2,12})\b/);if(um)unitText=um[1];}
   let taxRate=null;const ig=numeric(col(line,"igst")),cg=numeric(col(line,"cgst")),sg=numeric(col(line,"sgst")),gst=numeric(col(line,"gst"));
   if(ig!=null&&ig>0)taxRate=ig;else if(cg!=null||sg!=null){const sum=(cg>0?cg:0)+(sg>0?sg:0);if(sum>0)taxRate=sum;}else if(gst!=null&&gst>0)taxRate=gst;
   const hsn=col(line,"hsn").match(/\b[0-9]{4,8}\b/);const master=findPurchaseMasterMatch(name);
   const unitAliases={ea:"Piece",each:"Piece",pcs:"Piece",pc:"Piece",piece:"Piece",pk:"Packet",pkt:"Packet",packet:"Packet",box:"Box",case:"Case",kg:"Kg",g:"Gram",ltr:"Litre",litre:"Litre"};
   const recognizedUnit=unitAliases[unitText.toLowerCase()]||null;
   const unit=recognizedUnit||(master&&master.unit)||"Piece";
   if(taxRate==null&&master&&master.taxRate!=null)taxRate=Number(master.taxRate);
   const resolvedHsn=hsn?hsn[0]:String(master?.hsn||master?.hsnCode||"");
   rows.push(purchaseOcrEntryLine({name,qty:String(qty),unit,unitWasDefault:!recognizedUnit,invoiceLineTotal:total,taxRate,taxRateWasProvided:taxRate!=null,hsn:resolvedHsn,priceIncludesTax:true}));started=true;
 }
 return started?rows:[];
}
function parsePurchaseOcrRows(text){
 const tableRows=parsePurchaseInvoiceTable(text);
 if(tableRows.length){
   return tableRows.map(item=>purchaseOcrEntryLine(item));
 }
 const genericRows=parsePurchaseGenericColumnTable(text);
 if(genericRows.length)return genericRows;
 const rows=[];const seen=new Set();
 for(const rawLine of String(text||"").split(/\r?\n/)){
   let line=rawLine.trim();if(!line)continue;
   line=line.replace(/^\s*(?:\d{1,3}[.)]|[-•*])\s*/,"").replace(/\s+-\s+/g," ").replace(/\bRs\.?\s*/ig," ").replace(/₹\s*/g," ").replace(/\s+/g," ").trim();
   if(!line||/^(?:tax invoice|invoice|bill of supply|item\s+(?:name|description)|description\s+qty|subtotal|grand total|total amount|amount|hsn|gstin|phone|address|terms and conditions)/i.test(line))continue;
   const item=parseQuickListLine(line);
   if(item&&!item.error){const canonical=purchaseCanonicalLine(item);const k=canonical.toLowerCase();if(!seen.has(k)){seen.add(k);rows.push(canonical);}}
 }
 return rows;
}

function purchaseNameKey(value){return String(value||"").toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g," ").trim().replace(/\s+/g," ");}
function findPurchaseMasterMatch(name){
 const originalName=String(name||'').trim();
 if(typeof canonicalizeOcrProductName==='function')name=canonicalizeOcrProductName(name);
 const key=purchaseNameKey(name);if(!key)return null;
 const products=(Array.isArray(state.products)?state.products:[]).filter(p=>String(p.name||p.productName||p.itemName||"").trim());
 const exact=products.find(p=>purchaseNameKey(p.name||p.productName||p.itemName)===key);if(exact)return exact;
 // Confirmed aliases can be followed by promotional/pack text (e.g. +20% EXTRA).
 // Match the canonical product prefix only when a saved alias explicitly maps to
 // that product. This avoids turning arbitrary partial descriptions into matches.
 const savedAliases=(state.settings&&state.settings.ocrProductAliases&&typeof state.settings.ocrProductAliases==='object'&&!Array.isArray(state.settings.ocrProductAliases))?state.settings.ocrProductAliases:{};
 const aliasEntries=Object.entries(savedAliases).filter(([a,target])=>state.products.some(p=>purchaseNameKey(p.name||p.productName||p.itemName)===purchaseNameKey(target)));
 const aliasPrefix=aliasEntries.find(([alias])=>{
   const escaped=String(alias).trim().replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp('^'+escaped+'(?=$|[^a-z0-9])','i').test(originalName);
 });
 if(aliasPrefix){const targetKey=purchaseNameKey(savedAliases[aliasPrefix[0]]);const matches=products.filter(p=>purchaseNameKey(p.name||p.productName||p.itemName)===targetKey);if(matches.length===1)return matches[0];}
 const tokens=key.split(" ").filter(t=>t.length>1);if(!tokens.length)return null;
 const ranked=products.map(p=>{const pk=purchaseNameKey(p.name||p.productName||p.itemName),pt=pk.split(" ").filter(t=>t.length>1);const common=tokens.filter(t=>pt.includes(t)).length;const score=common/Math.max(tokens.length,pt.length,1);return {p,score,common,pk};}).filter(x=>x.common>=2&&x.score>=0.78).sort((a,b)=>b.score-a.score);
 if(!ranked.length)return null;if(ranked.length>1&&Math.abs(ranked[0].score-ranked[1].score)<0.08)return null;return ranked[0].p;
}
function enrichPurchaseItemFromMaster(item){
 if(!item||!String(item.name||"").trim())return item;
 const master=findPurchaseMasterMatch(item.originalOcrName||item.name);if(!master)return {...item,unit:String(item.unit||"Piece")};
 const unitMissing=!String(item.unit||"").trim()||item.unitWasDefault===true;
 const taxMissing=item.taxRate==null||item.taxRate===""||!Number.isFinite(Number(item.taxRate))||item.taxRateWasProvided===false;
 const hsnMissing=!String(item.hsn||item.hsnCode||"").trim();
 return {...item,unit:unitMissing?(master.unit||item.unit||"Piece"):item.unit,taxRate:taxMissing&&master.taxRate!=null?Number(master.taxRate):item.taxRate,hsn:hsnMissing?String(master.hsn||master.hsnCode||""):String(item.hsn||item.hsnCode||"") ,matchedProductName:master.name||master.productName||master.itemName};
}
function isPurchaseTaxableBill(){const el=typeof $==="function"?$("purchaseTaxableBill"):null;return !!(el&&el.checked===true);}
function parsePurchaseEntryLine(line){
 const original=String(line||'').trim();if(!original)return null;
 // Preferred structured format supports TAB, comma, and legacy pipe delimiters.
 // Commas are supported when the row has the expected 6/7 fields; product names
 // containing commas should be entered with tabs to avoid ambiguous splitting.
 const delimiter=original.includes('\t')?'\t':(original.includes('|')?'|':(original.split(',').length>=4?',':null));
 if(delimiter){
   const cols=original.split(delimiter).map(x=>x.trim());
   if(cols.length>=4){
     const rawName=cols[0],name=typeof canonicalizeOcrProductName==='function'?canonicalizeOcrProductName(rawName):rawName,qty=Number(String(cols[1]||'').replace(/,/g,'')),unitProvided=String(cols[2]||'').trim(),unitRaw=unitProvided||'Piece',fourthValue=Number(String(cols[3]||'').replace(/[₹, ]/g,'')),total=($('purchaseQuickListUnitPrice')?.checked===true)?roundMoney(fourthValue*qty):fourthValue;
     const taxText=String(cols[4]||'').replace(/%|GST/ig,'').trim(),taxRate=taxText===''?null:Number(taxText),hsn=String(cols[5]||'').trim(),barcode=String(cols[6]||'').trim(),sellingText=String(cols[7]||'').replace(/[₹, ]/g,'').trim(),sellingRate=sellingText===''?null:Number(sellingText);
     const unitAliases={pk:'Packet',pkt:'Packet',packet:'Packet',packets:'Packet',pc:'Piece',pcs:'Piece',piece:'Piece',pieces:'Piece',ea:'Piece',each:'Piece',box:'Box',boxes:'Box',case:'Case',carton:'Carton',bottle:'Bottle',bottles:'Bottle',kg:'Kg',g:'Gram',gram:'Gram',grams:'Gram',ltr:'Litre',litre:'Litre',liter:'Litre',ml:'ml',unit:'Unit',units:'Unit',dozen:'Dozen',job:'Job'};
     const unit=unitAliases[unitRaw.toLowerCase()]||unitRaw;
     if(!name||!(qty>0)||!Number.isFinite(total)||total<0||(!Number.isFinite(taxRate)&&taxText!=='' )||(taxRate!=null&&(taxRate<0||taxRate>100))||(!Number.isFinite(sellingRate)&&sellingText!=='' )||(sellingRate!=null&&sellingRate<0))return {error:`${original} — invalid Item, Qty, Unit, Total, Tax or SP/MRP. Use Item, Qty, Unit, Purchase Total, Tax, HSN, Barcode, SP/MRP per Unit.`};
     return enrichPurchaseItemFromMaster({name,qty:String(qty),unit,unitWasDefault:!unitProvided,taxRateWasProvided:taxText!=='',rate:roundMoney(total/qty),sellingRate:sellingRate==null?undefined:roundMoney(sellingRate),taxRate,priceIncludesTax:true,lineTotalInclusive:roundMoney(total),costPerUnitInclusive:roundMoney(total/qty),hsn,barcode});
   }
 }
 // Backward-compatible compact format, with optional tax percentage, HSN and barcode.
 let raw=original.replace(/[;]+/g,' ').replace(/\s+/g,' ');let taxRate=null,hsn='',barcode='';
 const tx=raw.match(/\s+(?:GST\s*)?(0|5|12|18|28)\s*%\s*/i);
 if(tx){taxRate=Number(tx[1]);raw=raw.slice(0,tx.index)+' '+raw.slice(tx.index+tx[0].length);raw=raw.trim();}
 const totalMatch=raw.match(/(?:₹\s*|Rs\.?\s*|INR\s*)?([0-9,]+(?:\.\d{1,2})?)\s*$/i);if(!totalMatch)return {error:`${original} — missing line TOTAL. Use Item, Qty, Unit, Total; Tax, HSN/SAC and Barcode are optional extra columns.`};
 const fourthValue=Number(totalMatch[1].replace(/,/g,''));const before=raw.slice(0,totalMatch.index).trim();
 const qm=before.match(/\s+(\d+(?:\.\d+)?)\s*(pk|pkt|packet|packets|pcs?|pieces?|ea|each|box|boxes|case|carton|bottle|bottles|kg|g|gram|grams|ltr|litre|liter|ml|unit|units|dozen|job)\s*$/i);
 if(!qm)return {error:`${original} — quantity/unit not found before TOTAL. Use Item, Qty, Unit, Total; Tax, HSN/SAC and Barcode are optional extra columns.`};
 const qty=Number(qm[1]);let unit=qm[2].toLowerCase();const aliases={pk:'Packet',pkt:'Packet',packet:'Packet',packets:'Packet',pc:'Piece',pcs:'Piece',piece:'Piece',pieces:'Piece',ea:'Piece',each:'Piece',box:'Box',boxes:'Box',case:'Case',carton:'Carton',bottle:'Bottle',bottles:'Bottle',kg:'Kg',g:'Gram',gram:'Gram',grams:'Gram',ltr:'Litre',litre:'Litre',liter:'Litre',ml:'ml',unit:'Unit',units:'Unit',dozen:'Dozen',job:'Job'};unit=aliases[unit]||unit;
 const name=before.slice(0,qm.index).trim().replace(/[,:;\-]+$/,'').trim();const total=$('purchaseQuickListUnitPrice')?.checked===true?roundMoney(fourthValue*qty):fourthValue;if(!name||!(qty>0)||!Number.isFinite(total)||total<0)return {error:`${original} — invalid item, quantity or amount.`};
 return enrichPurchaseItemFromMaster({name,qty:String(qty),unit,unitWasDefault:false,rate:roundMoney(total/qty),taxRate,priceIncludesTax:true,lineTotalInclusive:roundMoney(total),costPerUnitInclusive:roundMoney(total/qty),hsn,barcode});
}
function vendorTaxContext(supplierState){
 const buyer=String(state.settings.businessState||'').trim().toLowerCase(),seller=String(supplierState||'').trim().toLowerCase();
 const normalize=x=>x.replace(/\b(state|india)\b/g,'').replace(/[^a-z]/g,'');
 return buyer&&seller? (normalize(buyer)===normalize(seller)?'intra':'inter') : 'unknown';
}
function findExistingVendorFromOcr(meta){
 if(!meta)return null;const gstin=String(meta.gstin||'').replace(/\s/g,'').toUpperCase(),name=String(meta.supplierName||'').trim();
 return (gstin&&state.vendors.find(x=>String(x.gstin||'').replace(/\s/g,'').toUpperCase()===gstin))||(name&&state.vendors.find(x=>String(x.name||'').trim().toLowerCase()===name.toLowerCase()))||null;
}
let vendorModalFromOcr=false;
let pendingOcrVendorMeta=null;

function applyPurchaseImport(data){
 const raw=String(data.text||"");const meta=parsePurchaseOcrMetadata(raw);const tableRows=parsePurchaseInvoiceTable(raw);const rows=tableRows.length?tableRows.map(item=>purchaseOcrEntryLine(item)):parsePurchaseOcrRows(raw);state.purchaseImportRows=tableRows;state.purchaseImportMeta=meta;
 // The original document is retained as an attachment. We deliberately do not use the
 // former supplier-specific invoice layout parser; OCR rows use the same Quick List parser
 // as customer billing and remain editable before saving.
 renderPurchasing();
 if(meta.invoiceNo)$("purchaseInvoice").value=meta.invoiceNo;
 if(meta.date)$("purchaseDate").value=meta.date;
 
 if(meta.taxable>0)$("purchaseSubtotalInput").value=String(meta.taxable);
 if(meta.tax>0){$("purchaseTaxInput").value=String(meta.tax);$("purchaseTaxableBill").checked=true;}
 else if(tableRows.some(item=>Number(item.taxRate||0)>0))$("purchaseTaxableBill").checked=true;
 updatePurchaseTaxFieldVisibility();
 if(meta.deliveryDate&&$("purchaseDeliveryDate"))$("purchaseDeliveryDate").value=meta.deliveryDate;
 if(meta.poNumber&&$("purchasePoNumber"))$("purchasePoNumber").value=meta.poNumber;
 if(meta.supplierReference&&$("purchaseSupplierRef"))$("purchaseSupplierRef").value=meta.supplierReference;
 if(meta.paymentTerms&&$("purchasePaymentTerms"))$("purchasePaymentTerms").value=meta.paymentTerms;
 if(meta.stateName&&$("purchaseSupplierState"))$("purchaseSupplierState").value=meta.stateName;
 if(meta.stateCode&&$("purchaseSupplierStateCode"))$("purchaseSupplierStateCode").value=meta.stateCode;
 if(meta.pan&&$("purchaseSupplierPan"))$("purchaseSupplierPan").value=meta.pan;
 if(meta.roundOff&&$("purchaseRoundOffInput"))$("purchaseRoundOffInput").value=String(meta.roundOff);
 if(meta.discount&&$("purchaseDiscountInput"))$("purchaseDiscountInput").value=String(meta.discount);
 if(meta.tcs&&$("purchaseTcsInput"))$("purchaseTcsInput").value=String(meta.tcs);
 if(meta.paymentType&&$("purchasePaymentMode")){const pt=meta.paymentType.toLowerCase();if(/cash/.test(pt))$("purchasePaymentMode").value="Cash";else if(/upi/.test(pt))$("purchasePaymentMode").value="UPI";else if(/bank|transfer/.test(pt))$("purchasePaymentMode").value="Bank Transfer";}
 const vendorFromOcr=findExistingVendorFromOcr(meta);
 if(vendorFromOcr){renderVendorsSelects();$("purchaseVendor").value=vendorFromOcr.id;populatePurchaseVendorFields();}
 else if(meta.supplierName||meta.gstin){
   // Do not silently create OCR-derived vendor data. Let the shopkeeper verify and edit it first.
   vendorModalFromOcr=true;pendingOcrVendorMeta=meta;
   openVendorModal(null,{name:meta.supplierName||"",gstin:meta.gstin||"",pan:meta.pan||"",phone:meta.phone||"",email:meta.email||"",state:meta.stateName||"",stateCode:meta.stateCode||"",address:meta.address||""});
   $("vendorModalTitle").textContent="Verify New Vendor from OCR";
   const hint=document.getElementById("vendorOcrReviewHint");if(hint)hint.textContent="Review the details extracted from the invoice. Correct any errors and tap Save Vendor.";
 }
 if(rows.length){$("purchaseItemsText").value=rows.join("\n");$("purchaseQuickListStatus").textContent=`Found ${rows.length} possible item row(s). Review and tap Add List before saving.`;}
 else {$("purchaseItemsText").value=raw;$("purchaseQuickListStatus").textContent="OCR text is ready for review, but no standard item rows were confidently recognized. Edit it into Item Qty Unit Total lines (TOTAL includes tax), then tap Add List.";}
 state.purchaseAttachment={id:data.attachmentId,name:data.fileName,mime:data.mime,rawText:raw};
 $("purchaseAttachmentBox").innerHTML=`Attached: <b>${esc(data.fileName)}</b> • Original vendor bill saved with this purchase.`;
 $("purchaseImportStatus").textContent="OCR completed. Review the extracted details and item rows; nothing is saved until you tap Save Purchase.";
 updatePurchasePending();save();
}
// Vendor Quick List draft rows are separate from customer sales rows and from the catalogue.
let purchaseDraftItems=[];
let editingPurchaseId=null;
function renderPurchaseDraftItems(){
 const host=$("purchaseParsedItems");if(!host)return;
 if(!purchaseDraftItems.length){host.innerHTML="";return;}
 // Existing catalogue products supply their current selling price; brand-new items start at zero.
 purchaseDraftItems.forEach(x=>{if(x.sellingRate==null){const p=state.products.find(p=>String(p.name||p.productName||p.itemName||"").trim().toLowerCase()===String(x.name||"").trim().toLowerCase());x.sellingRate=Math.max(0,Number(p?.rate??p?.sellingPrice??0)||0);if(p)x._sellingRateLoadedFor=String(p.id||p.productId||p.name);}});
 host.innerHTML=`<div class="purchase-draft-head"><strong>Purchase items (${purchaseDraftItems.length})</strong><span class="muted">Edit fields before saving</span></div>`+
 purchaseDraftItems.map((x,i)=>`<div class="purchase-draft-row" data-purchase-index="${i}">
   <label>Item<input class="pd-name" value="${esc(x.name||"")}" list="productNames" autocomplete="off" placeholder="Search or enter product"></label>
   <div class="purchase-draft-grid">
    <label>Qty<input class="pd-qty" type="number" min="0.001" step="0.001" value="${esc(x.qty??1)}"></label>
    <label>Unit<input class="pd-unit" value="${esc(x.unit||"piece")}" list="unitNames"></label>
    <label>Buying Rate / Unit (before GST)<input class="pd-buy-rate" type="number" min="0" step="0.01" value="${esc(purchaseLineMath(x).buyingRate)}"></label>
    <label>SP / MRP per Unit<input class="pd-selling-rate" type="number" min="0" step="0.01" value="${esc(x.sellingRate??x.masterSellingRate??0)}" placeholder="0.00"></label>
    <div class="pd-amount"><span>${inclusivePurchaseAmounts()?"Line total (incl. tax)":"Line total (with GST)"}</span><strong class="pd-line-total">${money(purchaseLineMath(x).gross)}</strong></div>
    <label class="purchase-tax-field">GST % (optional)<input class="pd-tax" type="number" min="0" max="100" step="0.01" value="${x.taxRate==null?"":esc(x.taxRate)}" placeholder="No tax"></label>
    <label class="purchase-tax-field">HSN (optional)<input class="pd-hsn" value="${esc(x.hsn||"")}" placeholder="HSN code"></label>
    <label>Barcode (optional)<input class="pd-barcode" value="${esc(x.barcode||"")}" inputmode="numeric" placeholder="Barcode"></label>
    <div class="pd-amount purchase-tax-field"><span>Taxable amount</span><strong class="pd-taxable">${money(purchaseLineMath(x).taxable)}</strong></div>
    <div class="pd-amount purchase-tax-field"><span>${inclusivePurchaseAmounts()?"GST included":"GST added"}</span><strong class="pd-tax-amount">${money(purchaseLineMath(x).tax)}</strong></div>
    <button class="remove pd-remove" type="button" aria-label="Remove purchase item">×</button>
   </div>
  </div>`).join("");
 host.querySelectorAll('.purchase-draft-row').forEach(row=>{
   const i=Number(row.dataset.purchaseIndex);
   row.querySelectorAll('input').forEach(input=>input.addEventListener('input',()=>{
     const item=purchaseDraftItems[i];
     if(input.classList.contains('pd-name')){
       const found=state.products.find(p=>String(p.name||p.productName||p.itemName||'').trim().toLowerCase()===String(input.value||'').trim().toLowerCase());
       if(found){if(!row.querySelector('.pd-unit').value||row.querySelector('.pd-unit').value==='piece')row.querySelector('.pd-unit').value=found.unit||found.unitName||found.uom||'piece';if(!row.querySelector('.pd-hsn').value)row.querySelector('.pd-hsn').value=found.hsn||found.hsnCode||'';if(!row.querySelector('.pd-tax').value&&Number(found.taxRate||0)>0)row.querySelector('.pd-tax').value=String(found.taxRate);item.productId=found.id||found.productId||'';item.hsn=row.querySelector('.pd-hsn').value;item.taxRate=row.querySelector('.pd-tax').value===''?item.taxRate:Number(row.querySelector('.pd-tax').value);if(item.sellingRate==null||item._sellingRateLoadedFor!==String(found.id||found.productId||found.name)){item.sellingRate=Math.max(0,Number(found.rate??found.sellingPrice??0)||0);item._sellingRateLoadedFor=String(found.id||found.productId||found.name);row.querySelector('.pd-selling-rate').value=String(item.sellingRate);}}
     }
     item.name=row.querySelector('.pd-name').value.trim();
     item.qty=row.querySelector('.pd-qty').value;
     item.unit=row.querySelector('.pd-unit').value.trim()||'piece';
     const taxText=row.querySelector('.pd-tax')?.value.trim()||'';item.taxRate=taxText===''?null:Number(taxText);
     const qty=Math.max(0,Number(item.qty||0)),buyRate=Math.max(0,Number(row.querySelector('.pd-buy-rate')?.value||0)),effectiveTax=isPurchaseTaxableBill()?Math.max(0,Number(item.taxRate||0)):0;
     item.rate=roundMoney(buyRate);item.sellingRate=roundMoney(Math.max(0,Number(row.querySelector('.pd-selling-rate')?.value||0)));item.priceIncludesTax=inclusivePurchaseAmounts();
     const baseTotal=roundMoney(qty*buyRate);item.lineTotalInclusive=inclusivePurchaseAmounts()?roundMoney(baseTotal*(1+effectiveTax/100)):baseTotal;
     item.costPerUnitInclusive=qty>0?roundMoney(item.lineTotalInclusive/qty):0;
     if(input.classList.contains('pd-tax')){item.cgstRate=0;item.sgstRate=0;item.igstRate=0;item.cgstAmount=null;item.sgstAmount=null;item.igstAmount=null;}
     if(input.classList.contains('pd-qty')||input.classList.contains('pd-buy-rate')||input.classList.contains('pd-tax')){item.invoiceTaxableAmount=null;item.invoiceLineTotal=null;}
     item.hsn=row.querySelector('.pd-hsn')?.value.trim()||'';item.barcode=row.querySelector('.pd-barcode')?.value.trim()||'';
     updatePurchaseDraftSummary();
   }));
   row.querySelector('.pd-remove').onclick=()=>{purchaseDraftItems.splice(i,1);renderPurchaseDraftItems();updatePurchaseDraftSummary();};
 });
 updatePurchaseTaxFieldVisibility();
 updatePurchaseDraftSummary();
}
function addBlankPurchaseItem(){
 purchaseDraftItems.push({name:"",qty:1,unit:"piece",rate:0,sellingRate:0,lineTotalInclusive:0,taxRate:null,hsn:"",barcode:"",priceIncludesTax:true});
 renderPurchaseDraftItems();updatePurchaseDraftSummary();
 const rows=document.querySelectorAll('.purchase-draft-row');rows[rows.length-1]?.querySelector('.pd-name')?.focus();
}
function resolvePurchaseRecord(candidate){
 const id=String(candidate&&typeof candidate==="object"?candidate.id:candidate||"").trim();
 if(id&&nativeBridgePresent&&window.Android?.loadTransactionRecord){
  try{const raw=Android.loadTransactionRecord("pksPurchases",id);if(raw){const fresh=JSON.parse(raw);if(fresh&&String(fresh.id)===id)return fresh;}}catch(e){console.warn("Selected purchase lookup failed; using history row",e);}
 }
 if(candidate&&typeof candidate==="object"&&Array.isArray(candidate.items))return candidate;
 if(!nativeBridgePresent)return window.__siddhiLazyState?.purchases?.()?state.purchases.find(x=>String(x.id)===id):null;
 // A compact vendor-history row is not a complete invoice. Never open it as an
 // editable purchase if the authoritative SQLite record could not be fetched.
 return null;
}
function editPurchase(id){
 const rawPurchase=resolvePurchaseRecord(id);if(!rawPurchase){showNotice("The complete purchase record could not be loaded. Please refresh Purchase History and try again; no changes were made.","Purchase not opened");return;}
 window.editingPurchaseRecord=rawPurchase;
 const p=normalizePurchaseRecord(rawPurchase);
 window.purchaseSavedInEditor=false;editingPurchaseId=p.id;purchaseDraftItems=(p.items||[]).map(x=>({...x}));
 renderVendorsSelects();
 const matchedVendor=vendorById(p.vendorId||p.supplierId||p.partyId)||state.vendors.find(v=>String(v.name||"").trim().toLowerCase()===String(p.vendorName||p.supplierSnapshot?.name||"").trim().toLowerCase());
 const values={purchaseAmountsIncludeTax:p.amountsIncludeTax===false?"exclusive":"inclusive",purchaseTaxableBill:p.taxableBill!==false,purchaseVendor:matchedVendor?.id||p.vendorId||p.supplierId||p.partyId||"",purchaseInvoice:p.invoiceNo||"",purchaseDate:p.date||today(),purchaseDeliveryDate:p.deliveryDate||"",purchasePoNumber:p.poNumber||"",purchaseSupplierRef:p.supplierReference||"",purchasePaymentTerms:p.paymentTerms||"",purchaseInvoiceType:p.invoiceType||"tax_invoice",purchaseSupplierState:p.supplierState||p.supplierSnapshot?.state||"",purchaseSupplierStateCode:p.supplierStateCode||p.supplierSnapshot?.stateCode||"",purchaseSupplierPan:p.supplierPan||p.supplierSnapshot?.pan||"",purchaseReverseCharge:String(!!p.reverseCharge),purchaseSubtotalInput:p.declaredTaxableAmount??p.subtotal??"",purchaseTaxInput:p.declaredTaxAmount??p.taxAmount??"",purchaseChargesInput:p.otherCharges||0,purchaseDiscountInput:p.invoiceDiscount||0,purchaseTcsInput:p.tcsAmount||0,purchaseRoundOffInput:p.roundOff||0,purchaseTotalInput:p.total??0,purchasePaidInput:p.paid||0,purchasePaymentMode:p.paymentMode||"Credit",purchaseNotes:p.notes||""};
 Object.entries(values).forEach(([k,v])=>{if($(k)){if(k==="purchaseTaxableBill")$(k).checked=!!v;else $(k).value=v;}});
 $('savePurchaseBtn').textContent='Update Purchase';$('purchaseImportStatus').textContent='Editing saved purchase. Make corrections and tap Update Purchase.';
 $('purchaseItemsText').value='';updatePurchaseTaxFieldVisibility();renderPurchaseDraftItems();updatePurchaseDraftSummary();showVendorSection('purchaseEntryCard');
}
function resetPurchaseEditor(){editingPurchaseId=null;window.editingPurchaseRecord=null;$('savePurchaseBtn').textContent='Save Purchase';}
function inclusivePurchaseAmounts(){return ((typeof $==="function"?$("purchaseAmountsIncludeTax")?.value:null)||"inclusive")==="inclusive";}
function updatePurchaseTaxFieldVisibility(){
 const taxable=isPurchaseTaxableBill();
 document.querySelectorAll('.purchase-tax-field').forEach(el=>el.classList.toggle('hidden',!taxable));
 document.querySelectorAll('.purchase-tax-section-title').forEach(el=>el.classList.toggle('hidden',!taxable));
 document.querySelectorAll('#purchaseParsedItems .purchase-tax-field').forEach(el=>el.classList.toggle('hidden',!taxable));
 const help=$("purchaseQuickListHelp");if(help)help.textContent=taxable?"One item per line: ITEM, QTY, UNIT, TOTAL, TAX %, HSN/SAC, BARCODE. TAX %, HSN/SAC and BARCODE are optional. Total is tax-inclusive unless you select exclusive GST above. You can also paste invoice/OCR text.":"Non-taxable bill: enter ITEM, QTY, UNIT, TOTAL (e.g. Button,100,pc,500). TAX %, HSN/SAC and BARCODE are optional and not required. One item per line; you can also paste invoice/OCR text.";
 const label=document.querySelector('label[for="purchaseTaxableBill"]');
}
function purchaseLineMath(item,taxableOverride){
 const qty=Math.max(0,vendorNum(item.qty)),entered=roundMoney(Math.max(0,item.lineTotalInclusive!=null?vendorNum(item.lineTotalInclusive):qty*vendorNum(item.rate))),rate=((typeof taxableOverride==="boolean")?taxableOverride:isPurchaseTaxableBill())?Math.max(0,vendorNum(item.taxRate)):0,inclusive=(((typeof $==="function"?$("purchaseAmountsIncludeTax")?.value:null)||"inclusive")==="inclusive");
 const sourceTaxable=inclusive&&item.invoiceTaxableAmount!=null&&item.invoiceLineTotal!=null&&Math.abs(vendorNum(item.invoiceLineTotal)-entered)<0.005?roundMoney(Math.max(0,vendorNum(item.invoiceTaxableAmount))):null;
 const taxable=sourceTaxable!=null?sourceTaxable:(inclusive?(rate>0?roundMoney(entered/(1+rate/100)):entered):entered);
 const tax=roundMoney(rate>0?(inclusive?entered-taxable:taxable*rate/100):0),gross=inclusive?entered:roundMoney(taxable+tax);
 return {qty,gross,taxable,tax,buyingRate:qty>0?roundMoney(taxable/qty):0,entered,inclusive};
}
function updatePurchaseDraftSummary(){
 const status=$("purchaseQuickListStatus"),summary=$("purchaseCalculationSummary");if(!status)return;
 if(!purchaseDraftItems.length){status.textContent="";if(summary)summary.innerHTML="";return;}
 const lines=purchaseDraftItems.map(purchaseLineMath),gross=roundMoney(lines.reduce((sum,x)=>sum+x.gross,0)),taxable=roundMoney(lines.reduce((sum,x)=>sum+x.taxable,0)),tax=roundMoney(lines.reduce((sum,x)=>sum+x.tax,0));
 const charges=roundMoney($("purchaseChargesInput")?.value),discount=roundMoney($("purchaseDiscountInput")?.value),tcs=roundMoney($("purchaseTcsInput")?.value),roundOff=roundMoney($("purchaseRoundOffInput")?.value),calculated=roundMoney(gross+charges-discount+tcs+roundOff),finalTotal=calculated,mode=$("purchasePaymentMode")?.value||"Credit";if($("purchaseTotalInput"))$("purchaseTotalInput").value=calculated.toFixed(2);if(mode!=="Credit"&&$("purchasePaidInput"))$("purchasePaidInput").value=calculated.toFixed(2);const paid=mode==="Credit"?Math.min(calculated,roundMoney($("purchasePaidInput")?.value)):calculated,pending=roundMoney(Math.max(0,finalTotal-paid));
 const moneyRow=(label,value,klass="")=>`<div class="purchase-calc-row ${klass}"><span>${label}</span><strong>${money(value)}</strong></div>`;
 if(summary)summary.innerHTML=`<h4>Purchase Bill Calculation</h4><div class="purchase-calc-lines">${moneyRow(inclusivePurchaseAmounts()?"Items total (tax-inclusive)":"Items total (before GST)",gross)}${isPurchaseTaxableBill()?moneyRow("Taxable amount",taxable)+moneyRow("GST included in item totals",tax):""}${moneyRow("Other charges",charges)}${moneyRow("Invoice discount",-discount)}${isPurchaseTaxableBill()?moneyRow("TCS",tcs):""}${moneyRow("Round off",roundOff)}${moneyRow("Bill total",calculated,"purchase-calc-total")}${moneyRow("Paid",paid)}${moneyRow("Balance pending",pending,"purchase-calc-total")}</div>`;
 purchaseDraftItems.forEach((item,i)=>{const row=document.querySelector(`.purchase-draft-row[data-purchase-index="${i}"]`);if(!row)return;const m=lines[i];const br=row.querySelector('.pd-buying-rate'),tx=row.querySelector('.pd-taxable'),ta=row.querySelector('.pd-tax-amount'),lt=row.querySelector('.pd-line-total');if(br)br.textContent=money(m.buyingRate);if(tx)tx.textContent=money(m.taxable);if(ta)ta.textContent=money(m.tax);if(lt)lt.textContent=money(m.gross);});
 status.textContent=`${purchaseDraftItems.length} item row(s) • ${isPurchaseTaxableBill()?`Taxable ${money(taxable)} • GST ${money(tax)} • ${inclusivePurchaseAmounts()?"Entered amounts include GST":"GST added to entered amounts"} • `:"Non-taxable • GST not applied • "}Total ${money(gross)}.`;
}
function initPurchaseQuickListSearch(){
 const $q=id=>document.getElementById(id),search=$q("purchaseQuickSearch"),list=$q("purchaseQuickSuggestions"),qty=$q("purchaseQuickQty"),unit=$q("purchaseQuickUnit"),rate=$q("purchaseQuickRate"),mrp=$q("purchaseQuickMrp"),tax=$q("purchaseQuickTax"),hsn=$q("purchaseQuickHsn"),barcode=$q("purchaseQuickBarcode"),add=$q("purchaseQuickAddSelected");
 if(!search||!list||!qty||!unit||!rate||!mrp||!tax||!hsn||!barcode||!add)return;
 const hide=()=>{list.classList.add("hidden");list.innerHTML="";};
 const render=()=>{const q=search.value.trim().toLowerCase(),products=(state.products||[]).filter(p=>p&&String(p.name||p.productName||p.itemName||"").trim()).filter(p=>{const name=String(p.name||p.productName||p.itemName||"");return !q||name.toLowerCase().includes(q)||String(p.itemCode||p.code||p.barcode||p.ean||"").toLowerCase().includes(q);}).slice(0,15);if(!products.length){hide();return;}list.innerHTML=products.map((p,i)=>`<div class="product-suggestion" data-index="${i}" tabindex="0"><b>${esc(p.name||p.productName||p.itemName||"")}</b><div class="muted">${esc(p.unit||p.unitName||p.uom||"piece")}${Number(p.lastPurchaseCost??p.purchaseRate??p.costPrice??0)>0?` · Buy ₹${Number(p.lastPurchaseCost??p.purchaseRate??p.costPrice).toFixed(2)}`:""}${Number(p.rate??p.sellingPrice??p.mrp??0)>0?` · SP/MRP ₹${Number(p.rate??p.sellingPrice??p.mrp).toFixed(2)}`:""}</div></div>`).join("");list.classList.remove("hidden");list.querySelectorAll(".product-suggestion").forEach(el=>{const choose=()=>{const p=products[Number(el.dataset.index)];search.value=String(p.name||p.productName||p.itemName||"");unit.value=normalizeUnitName(p.unit||p.unitName||p.uom||"piece");rate.value=Number(p.lastPurchaseCost??p.purchaseRate??p.costPrice??0)||"";mrp.value=Number(p.rate??p.sellingPrice??p.mrp??0)||"";tax.value=Number(p.taxRate??p.tax??0)||"";hsn.value=String(p.hsn??p.hsnCode??p.hsnSac??"");barcode.value=String(p.barcode??p.ean??p.upc??"");qty.value="1";hide();qty.focus();qty.select();};el.addEventListener("mousedown",e=>{e.preventDefault();choose();});el.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();choose();}});});};
 search.addEventListener("input",()=>search.value.trim()?render():hide());search.addEventListener("focus",()=>search.value.trim()?render():hide());search.addEventListener("blur",()=>setTimeout(hide,150));
 add.addEventListener("click",()=>{const name=search.value.trim(),n=Number(qty.value||1),buy=String(rate.value||"").trim(),sp=String(mrp.value||"").trim();if(!name){search.focus();return;}if(!(n>0)){qty.focus();qty.select();return;}if(buy===""||!Number.isFinite(Number(buy))||Number(buy)<0){rate.focus();return;}const enteredPurchaseValue=$q("purchaseQuickListUnitPrice")?.checked===true?Number(buy):roundMoney(Number(buy)*n);const fields=[name,String(n),unit.value||"piece",String(enteredPurchaseValue),tax.value.trim(),hsn.value.trim(),barcode.value.trim(),sp];const line=fields.join("|");const box=$q("purchaseItemsText");box.value=box.value.trim()?box.value.trimEnd()+"\n"+line:line;box.dispatchEvent(new Event("input",{bubbles:true}));addPurchaseQuickList();search.value="";qty.value="1";rate.value="";mrp.value="";tax.value="";hsn.value="";barcode.value="";hide();const sx=window.scrollX,sy=window.scrollY;requestAnimationFrame(()=>{try{search.focus({preventScroll:true});}catch(e){search.focus();}window.scrollTo(sx,sy);});});
}

function normalizePurchaseQuickListLines(text){
 const sourceLines=String(text||"").split(/\r?\n/).map(x=>x.trim()).filter(Boolean),normalizedLines=[];
 for(let i=0;i<sourceLines.length;i++){
   let line=sourceLines[i];
   if(/^(?:quick list|item\s*(?:\/|\|)?\s*qty|description\s+qty|item\s*,\s*qty\s*,|please keep each item)/i.test(line))continue;
   // OCR engines often put the item name on one line and the comma-separated
   // Qty/Unit/Total/GST/HSN fields on the next line. Join them before parsing.
   if(!/[\t|]/.test(line)&&line.split(',').length<4&&i+1<sourceLines.length&&sourceLines[i+1].split(',').length>=5){line=line+' '+sourceLines[++i];}
   normalizedLines.push(line);
 }
 return normalizedLines;
}
function addPurchaseQuickList(){
 const box=$("purchaseItemsText"),text=String(box.value||"").trim();if(!text){box.focus();return;}
 const parsed=[],errors=[];
 const normalizedLines=normalizePurchaseQuickListLines(text);
 for(const line of normalizedLines){const item=parsePurchaseEntryLine(line);if(item?.error)errors.push(item.error);else if(item)parsed.push(item); }
 if(errors.length||!parsed.length){$("purchaseQuickListStatus").textContent=errors.length?`Please correct these rows: ${errors.join(" | ")}`:"No valid item rows found. Use Item Qty Unit Total (tax-inclusive), one item per line. Example: Dettol Handwash 16 pk 1600. Add GST only when known, e.g. Item 2 piece 236 18%.";box.classList.add("quicklist-invalid");return;}
 box.classList.remove("quicklist-invalid");
 const imported=Array.isArray(state.purchaseImportRows)?state.purchaseImportRows:[];
 const useImportedRows=parsed.length===imported.length && imported.length>0;
 // Add List is a sync operation: the textarea is the source of truth. Rebuild the
 // draft list so correcting an existing row updates it instead of appending duplicates.
 const nextItems=parsed.map((p,i)=>{
   const src=useImportedRows?(imported[i]||{}):{};
   return {...src,...p,name:p.name,qty:p.qty,unit:p.unit,rate:p.rate,sellingRate:p.sellingRate!=null?Number(p.sellingRate):(src.sellingRate??src.masterSellingRate??null),taxRate:p.taxRate!=null?p.taxRate:(src.taxRate!=null?src.taxRate:null),priceIncludesTax:!!p.priceIncludesTax,lineTotalInclusive:p.lineTotalInclusive??src.invoiceLineTotal??null,costPerUnitInclusive:p.costPerUnitInclusive??null,hsn:p.hsn||src.hsn||src.hsnCode||"",barcode:p.barcode||src.barcode||src.ean||src.upc||"",itemCode:src.itemCode||src.supplierItemCode||"",packSize:1,freeQty:Number(src.freeQty||0),discountAmount:Number(src.discountAmount||0),schemeDiscount:Number(src.schemeDiscount||0),cgstRate:Number(src.cgstRate||0),sgstRate:Number(src.sgstRate||0),igstRate:Number(src.igstRate||0),cgstAmount:src.cgstAmount??null,sgstAmount:src.sgstAmount??null,igstAmount:src.igstAmount??null,invoiceTaxableAmount:src.invoiceTaxableAmount??null,invoiceLineTotal:src.invoiceLineTotal??null,rawExtractedText:src.rawExtractedText||"",reviewRequired:!!src.reviewRequired};
 });
 purchaseDraftItems=nextItems;
 box.classList.remove("quicklist-invalid");
 renderPurchaseDraftItems();
 $("purchaseQuickListStatus").textContent=`${purchaseDraftItems.length} purchase item row(s) synchronized below. Corrections replace prior rows; HSN and GST are optional.`;
}

window.onPurchaseImportProgress=function(message){
 const el=$("purchaseImportStatus"); if(el) el.textContent=String(message||"Reading vendor bill...");
};
window.onPurchaseImportError=function(message){
 const el=$("purchaseImportStatus"); if(el) el.textContent="Could not read the vendor bill: "+String(message||"Unknown error");
 alert("Purchase bill import failed.\n\n"+String(message||"Please try another PDF/photo."));
};
window.onPurchaseImportResultBase64=function(encoded){
 try{
   const bin=atob(encoded); let s=""; for(let i=0;i<bin.length;i++)s+=String.fromCharCode(bin.charCodeAt(i));
   const json=decodeURIComponent(Array.prototype.map.call(s,c=>"%"+("00"+c.charCodeAt(0).toString(16)).slice(-2)).join(""));
   applyPurchaseImport(JSON.parse(json));
 }catch(e){ window.onPurchaseImportError(e.message); }
};
function toInputDate(s){
 if(!s)return "";
 const m=String(s).match(/(\d{1,2})[\/-]([A-Za-z]{3}|\d{1,2})[\/-](\d{2,4})/);
 if(!m)return "";
 let mon=isNaN(Number(m[2]))?({jan:1,feb:2,mar:3,apr:4,may:5,jun:6,jul:7,aug:8,sep:9,oct:10,nov:11,dec:12}[m[2].slice(0,3).toLowerCase()]||0):Number(m[2]);
 let y=Number(m[3]);if(y<100)y+=2000;
 return mon?`${y}-${String(mon).padStart(2,"0")}-${String(m[1]).padStart(2,"0")}`:"";
}
function updatePurchasePending(){const t=Number($("purchaseTotalInput")?.value||0),mode=$("purchasePaymentMode")?.value||"Credit";if(mode!=="Credit"&&$("purchasePaidInput"))$("purchasePaidInput").value=t.toFixed(2);const p=mode==="Credit"?Number($("purchasePaidInput")?.value||0):t;if($("purchasePendingInput"))$("purchasePendingInput").value=Math.max(0,t-p).toFixed(2);const credit=mode==="Credit";const lab=$("purchasePaidLabel");if(lab)lab.classList.toggle("hidden",!credit);const extra=$("purchasePaymentExtraFields");if(extra)extra.classList.toggle("hidden",!["UPI","Bank Transfer","Cheque","Card"].includes(mode));const cheque=["Cheque"].includes(mode);$("purchaseChequeNoWrap")?.classList.toggle("hidden",!cheque);$("purchaseChequeDateWrap")?.classList.toggle("hidden",!cheque);}
function savePurchase(){
 // After the first save, keep editing the same purchase record until New Bill is pressed.

 const vendorId=$("purchaseVendor").value, vendor=vendorById(vendorId);
 if(!vendor){alert("Select a vendor.");return}
 const paymentMode=$("purchasePaymentMode").value||"Credit";updatePurchasePending();const paidInput=Number($("purchasePaidInput").value||0);
 const items=purchaseDraftItems.map(x=>({...x}));
 if(!items.length){alert("Add purchase items using Add List before saving the purchase.");$("purchaseItemsText").focus();return;}
 const itemErrors=[];
 items.forEach((x,i)=>{if(!String(x.name||"").trim()||!(Number(x.qty)>0)||!Number.isFinite(Number(x.rate))||Number(x.rate)<0)itemErrors.push(`Row ${i+1}: enter item, quantity greater than zero and a valid rate.`);if(x.taxRate!=null&&(!Number.isFinite(Number(x.taxRate))||Number(x.taxRate)<0||Number(x.taxRate)>100))itemErrors.push(`Row ${i+1}: GST rate must be between 0 and 100.`);});
 if(isPurchaseTaxableBill()){
   const missingHsn=items.map((x,i)=>({x,i})).filter(v=>!String(v.x.hsn||v.x.hsnCode||"").trim());
   if(missingHsn.length&&confirm(`${missingHsn.map(v=>`Row ${v.i+1}: ${v.x.name}`).join("\n")}\n\nHSN/SAC was not found in OCR or Product Master. Choose OK to enter HSN/SAC now, or Cancel to save without HSN.`)){
     renderPurchaseDraftItems();const first=document.querySelector(`.purchase-draft-row[data-purchase-index="${missingHsn[0].i}"] .pd-hsn`);first?.focus();first?.scrollIntoView({behavior:"smooth",block:"center"});return;
   }
 }
 if(itemErrors.length){alert("Please correct these vendor purchase rows before saving:\n\n"+itemErrors.join("\n"));return;}
 const subtotalInput=isPurchaseTaxableBill()?Number($("purchaseSubtotalInput").value||0):0,taxInput=isPurchaseTaxableBill()?Number($("purchaseTaxInput").value||0):0,otherCharges=Number($("purchaseChargesInput").value||0),invoiceDiscount=Number($("purchaseDiscountInput").value||0),tcsAmount=isPurchaseTaxableBill()?Number($("purchaseTcsInput").value||0):0,roundOff=Number($("purchaseRoundOffInput").value||0);
 const taxableBill=isPurchaseTaxableBill();
 const taxApplied=taxableBill&&(taxInput>0||items.some(x=>Number(x.taxRate||0)>0||Number(x.cgstAmount||0)>0||Number(x.sgstAmount||0)>0||Number(x.igstAmount||0)>0));
 const supplierGstin=String(vendor.gstin||state.purchaseImportMeta?.gstin||'').trim().toUpperCase();const supplierPan=String(vendor.pan||$("purchaseSupplierPan").value||state.purchaseImportMeta?.pan||'').trim().toUpperCase();
 if(taxApplied&&!supplierGstin&&!supplierPan){openVendorModal(vendor.id);alert("Tax is applied to this purchase. Please complete the vendor PAN or GSTIN before saving.");return;}
 if(taxApplied&&supplierGstin&&!/^[0-9A-Z]{15}$/.test(supplierGstin)){openVendorModal(vendor.id);alert("The vendor GSTIN is incomplete or invalid. Please correct it in the vendor profile before saving.");return;}
 if(taxApplied&&supplierPan&&!/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(supplierPan)){openVendorModal(vendor.id);alert("The vendor PAN is incomplete or invalid. Please correct it in the vendor profile before saving.");return;}
 const sellerStateForTax=String($("purchaseSupplierState").value||vendor.state||state.purchaseImportMeta?.stateName||'').trim();
 if(taxApplied&&!sellerStateForTax){openVendorModal(vendor.id);alert("Tax is applied. Please complete the supplier state in the vendor profile before saving.");return;}if(taxApplied&&!state.settings.businessState){showPage("settings");alert("Tax is applied. Please complete your shop's business state in Settings before saving, so CGST/SGST versus IGST is not guessed.");return;}
 vendor.gstin=supplierGstin;vendor.pan=supplierPan;vendor.state=sellerStateForTax;vendor.stateCode=String($("purchaseSupplierStateCode").value||vendor.stateCode||state.purchaseImportMeta?.stateCode||'').trim();
 const businessState=String(state.settings.businessState||"").trim().toLowerCase();
 const supplierState=String($("purchaseSupplierState").value||state.purchaseImportMeta?.stateName||"").trim().toLowerCase();
 const sameState=!!businessState&&!!supplierState&&businessState===supplierState;
 const normalizedItems=items.map((x,i)=>{
   let cgstRate=taxableBill?Number(x.cgstRate||0):0,sgstRate=taxableBill?Number(x.sgstRate||0):0,igstRate=taxableBill?Number(x.igstRate||0):0;
   const taxContext=vendorTaxContext($("purchaseSupplierState").value||vendor.state);
   if(Number(x.taxRate||0)>0&&!cgstRate&&!sgstRate&&!igstRate){if(taxContext==='intra'){cgstRate=Number(x.taxRate)/2;sgstRate=Number(x.taxRate)/2;}else if(taxContext==='inter'){igstRate=Number(x.taxRate);}else{itemErrors.push(`Row ${i+1}: seller and buyer state are needed to determine CGST/SGST versus IGST.`);}}
   const enteredLine=x.lineTotalInclusive!=null?Number(x.lineTotalInclusive):Number(x.qty||0)*Number(x.rate||0);
   const lineRate=taxableBill?Number(x.taxRate||0):0,taxableBase=inclusivePurchaseAmounts()?(lineRate>0?enteredLine/(1+lineRate/100):enteredLine):enteredLine;
   const grossLine=inclusivePurchaseAmounts()?enteredLine:roundMoney(taxableBase+taxableBase*lineRate/100);
   const exRate=Number(x.qty||0)>0?taxableBase/Number(x.qty):Number(x.rate||0);
   return normalizeVendorLine({...x,lineNo:i+1,name:x.name,qty:x.qty,unit:x.unit,rate:exRate,sellingRate:Math.max(0,Number(x.sellingRate??0)),baseQty:Number(x.qty||0),packSize:1,lineTotalInclusive:grossLine,cgstRate,sgstRate,igstRate,taxRate:lineRate,hsn:x.hsn||"",reviewRequired:!!x.reviewRequired});
 });
 if(itemErrors.length){alert("Please complete the required tax details before saving:\n\n"+itemErrors.join("\n"));return;}
 const lineTaxable=roundMoney(normalizedItems.reduce((sum,x)=>sum+x.taxableAmount,0)),lineTax=roundMoney(normalizedItems.reduce((sum,x)=>sum+x.totalTaxAmount,0));
 const invoiceTaxBreakdown=taxInput>0?(vendorTaxContext(sellerStateForTax)==='intra'?{cgst:roundMoney(taxInput/2),sgst:roundMoney(taxInput-taxInput/2),igst:0}:{cgst:0,sgst:0,igst:roundMoney(taxInput)}):{cgst:roundMoney(normalizedItems.reduce((sum,x)=>sum+x.cgstAmount,0)),sgst:roundMoney(normalizedItems.reduce((sum,x)=>sum+x.sgstAmount,0)),igst:roundMoney(normalizedItems.reduce((sum,x)=>sum+x.igstAmount,0))};
 const subtotal=subtotalInput>0?subtotalInput:lineTaxable,taxAmount=taxInput>0?taxInput:lineTax;
 const total=roundMoney(normalizedItems.reduce((sum,x)=>sum+Number(x.lineTotalInclusive||0),0)+otherCharges-invoiceDiscount+tcsAmount+roundOff);
 if(total<=0){alert("Enter an invoice total or add item rows with valid quantities and rates.");return}
 const previous=editingPurchaseId?(window.editingPurchaseRecord||null):null;
 const rec=deriveVendorInvoice({...(previous||{}),id:editingPurchaseId||purchaseId(),shopKey:moduleShopKey(),shopName:moduleCurrentShop(),schemaVersion:2,vendorId,vendorName:vendor.name,supplierSnapshot:{name:state.purchaseImportMeta?.supplierName||vendor.name,gstin:supplierGstin,pan:supplierPan,address:vendor.address||state.purchaseImportMeta?.address||"",state:sellerStateForTax,stateCode:vendor.stateCode||state.purchaseImportMeta?.stateCode||"",phone:vendor.phone||state.purchaseImportMeta?.phone||"",email:vendor.email||state.purchaseImportMeta?.email||"",fssai:vendor.fssai||state.purchaseImportMeta?.fssai||""},invoiceNo:$("purchaseInvoice").value.trim(),date:$("purchaseDate").value||today(),deliveryDate:$("purchaseDeliveryDate").value||"",poNumber:$("purchasePoNumber").value.trim(),supplierReference:$("purchaseSupplierRef").value.trim(),paymentTerms:$("purchasePaymentTerms").value.trim(),invoiceType:$("purchaseInvoiceType").value||"tax_invoice",taxableBill,amountsIncludeTax:inclusivePurchaseAmounts(),supplierState:sellerStateForTax,supplierStateCode:vendor.stateCode,supplierPan:supplierPan,reverseCharge:$("purchaseReverseCharge").value==="true",declaredTaxableAmount:subtotalInput>0?subtotalInput:null,declaredTaxAmount:taxInput>0?taxInput:null,declaredTotalAmount:null,subtotal,taxAmount,invoiceTaxBreakdown,otherCharges,invoiceDiscount,tcsAmount,roundOff,total,paid:paymentMode==="Credit"?Math.min(paidInput,total):total,paymentMode,paymentTransactionNo:String($("purchasePaymentRef")?.value||"").trim(),paymentChequeNo:String($("purchaseChequeNo")?.value||"").trim(),paymentChequeDate:String($("purchaseChequeDate")?.value||"").trim(),paymentDate:today(),items:normalizedItems,notes:$("purchaseNotes").value.trim(),attachment:state.purchaseAttachment||previous?.attachment||null,rawExtractedText:state.purchaseAttachment?.rawText||"",reviewStatus:state.purchaseImportRows?.length?"review_required":"reviewed"});
 if(window.__siddhiLazyState?.purchases?.()){
   const history=state.purchases;
   if(editingPurchaseId){const ix=history.findIndex(x=>String(x.id)===String(editingPurchaseId));if(ix>=0)history[ix]=rec;else history.unshift(rec);}else history.unshift(rec);
 }
 // Purchase save also creates missing catalog products and refreshes supplier-derived
 // product metadata. Existing selling rates and stock are not overwritten/incremented.
 normalizedItems.forEach(x=>{const name=String(x.name||'').trim();if(!name)return;let product=state.products.find(p=>String(p.name||p.productName||p.itemName||'').trim().toLowerCase()===name.toLowerCase());const unit=normalizeUnitName(String(x.unit||'piece')),hsn=String(x.hsn||'').trim(),barcode=String(x.barcode||x.ean||x.upc||'').trim(),taxRate=Number(x.taxRate||0),cost=Number(x.rate||0);if(!product){product={name,rate:Math.max(0,Number(x.sellingRate??0)),unit,hsn,barcode,taxRate,lastPurchaseCost:cost,createdFromPurchase:true,trackInventory:true,stockQty:0,minimumStock:0,baseStockUnit:unit,packSize:1};state.products.unshift(product);}else{product.lastPurchaseCost=cost;product.rate=Math.max(0,Number(x.sellingRate??product.rate??0));product.trackInventory=true;if(!product.baseStockUnit)product.baseStockUnit=product.unit||unit;if(!Number(product.packSize))product.packSize=1;if(unit)product.unit=unit;if(hsn)product.hsn=hsn;if(barcode&&!String(product.barcode||product.ean||product.upc||'').trim())product.barcode=barcode;if(taxableBill&&taxRate>=0)product.taxRate=taxRate;}});
 if(state.settings.inventoryManagement===true)postPurchaseInventoryMovement(rec,editingPurchaseId);
 save();
 if(nativeBridgePresent && window.Android?.saveTransactionRecord){
   try{if(Android.saveTransactionRecord("pksPurchases",JSON.stringify(rec))===false)throw new Error("Native purchase record save returned false");}
   catch(e){console.error("Purchase record persistence failed",e);showNotice("Purchase was updated on screen but its database record could not be confirmed. Do not close the app; please retry and share diagnostics.","Purchase save warning");}
 }
 renderDatalist();renderProducts();
 // Keep the saved bill on screen for verification. Do not clear the form or jump away.
 // The user explicitly starts a new bill using the New Purchase button.
 window.purchaseSavedInEditor=true;editingPurchaseId=rec.id;window.editingPurchaseRecord=rec;
 $("savePurchaseBtn").textContent="Update Purchase";
 $("savePurchaseBtn").classList.remove("secondary");$("savePurchaseBtn").classList.add("primary");
 $("purchaseImportStatus").textContent=`Purchase saved successfully (${rec.invoiceNo||"no invoice number"}). You can continue editing and tap Update Purchase. Use New Bill at the top to start another bill.`;
 renderPurchasing();
}
// Inventory module: isolated behind the Inventory Management setting.
function inventoryShopKey(){return typeof moduleShopKey==="function"?moduleShopKey():String(state.settings.shopName||"default-shop").trim().toLowerCase();}
function inventoryProductByName(name){const n=String(name||"").trim().toLowerCase();return state.products.find(p=>String(p.name||p.productName||p.itemName||"").trim().toLowerCase()===n);}
function inventoryQty(qty,unit,product){let q=Number(typeof quantityValue==="function"?quantityValue(qty,unit):qty)||0;const unitNorm=String(unit||product?.unit||"").trim().toLowerCase(),base=String(product?.unit||"").trim().toLowerCase();if(product?.packSize>1&&unitNorm!==base)q*=Number(product.packSize);return q;}
function inventoryReverseSource(sourceType,sourceId){state.inventoryMovements.forEach(m=>{if(m.shopKey===inventoryShopKey()&&m.sourceType===sourceType&&String(m.sourceId)===String(sourceId)&&!m.reversed){m.reversed=true;m.reversedAt=new Date().toISOString();}});}
function inventoryAddMovement({product,qty,unitCost=0,type,sourceType="manual",sourceId="",date=today(),reason="",deferRebuild=false}){if(!product||product.trackInventory!==true)return;const q=Number(qty)||0;if(!q)return;const movement={id:"im-"+Date.now()+"-"+Math.random().toString(36).slice(2,8),shopKey:inventoryShopKey(),productName:product.name,productId:product.itemCode||product.barcode||product.name,qty:q,unitCost:Math.max(0,Number(unitCost)||0),type,sourceType,sourceId:String(sourceId||""),date,reason,reversed:false,createdAt:new Date().toISOString()};
 const nativeFast=!deferRebuild&&nativeBridgePresent&&window.Android?.saveTransactionRecord;
 if(window.__siddhiLazyState?.inventoryMovements?.()||!nativeFast)state.inventoryMovements.push(movement);
 if(nativeFast){try{if(Android.saveTransactionRecord("pksInventoryMovements",JSON.stringify(movement))===false)throw new Error("Movement save returned false");const oldQty=Number(product.stockQty)||0,oldAvg=Math.max(0,Number(product.averageCost||product.lastPurchaseCost)||0),nextQty=oldQty+q;if(q>0&&nextQty>0)product.averageCost=Number(((Math.max(0,oldQty)*oldAvg+q*movement.unitCost)/nextQty).toFixed(6));product.stockQty=Number(nextQty.toFixed(6));}catch(e){console.error("Inventory movement persistence failed",e);showNotice("Stock movement could not be confirmed in the local database. Please retry before leaving Inventory.","Inventory save warning");}return;}
 if(!deferRebuild)rebuildInventoryBalances();}
function rebuildInventoryBalances(affectedProductNames=null){
 const __sbInvStart=__sbTraceClock(),shop=inventoryShopKey(),byProduct=new Map();
 const affected=Array.isArray(affectedProductNames)?new Set(affectedProductNames.map(x=>String(x||"").trim().toLowerCase()).filter(Boolean)):null;
 // Sort once globally, then calculate weighted-average stock in one pass.
 // The old implementation sorted a separate array for every product, which
 // multiplied sorting overhead on large restored movement histories.
 const movements=state.inventoryMovements.filter(m=>m.shopKey===shop&&!m.reversed&&(!affected||affected.has(String(m.productName||"").toLowerCase()))).slice().sort((a,b)=>String(a.date||"").localeCompare(String(b.date||""))||String(a.createdAt||"").localeCompare(String(b.createdAt||"")));
 movements.forEach(m=>{const key=String(m.productName||"").toLowerCase();if(!key)return;let v=byProduct.get(key);if(!v){v={qty:0,value:0};byProduct.set(key,v);}const q=Number(m.qty)||0,cost=Math.max(0,Number(m.unitCost)||0);if(q>0){v.value+=q*cost;v.qty+=q;}else if(q<0){const avg=v.qty>0?v.value/v.qty:(cost||0);v.qty+=q;v.value=Math.max(0,v.value+q*avg);}});
 state.products.forEach(p=>{if(p.trackInventory!==true)return;const productKey=String(p.name||"").toLowerCase();if(affected&&!affected.has(productKey))return;const v=byProduct.get(productKey)||{qty:0,value:0};p.stockQty=Number(v.qty.toFixed(6));p.averageCost=v.qty>0?Number((v.value/v.qty).toFixed(6)):Number(p.averageCost||p.lastPurchaseCost||0);});
 __sbTraceProfile("inventory balance rebuild",__sbInvStart,{movementCount:movements.length,productCount:affected?affected.size:state.products.length,shop});
}
function applyInventorySourceChange(sourceType,reverseId,sourceId,date,items,qtySign,reason){
 const rows=[];
 (items||[]).forEach(it=>{const p=inventoryProductByName(it.name);if(!p||p.trackInventory!==true)return;const rawQty=inventoryQty(it.qty??it.baseQty,it.unit,p),qty=qtySign*rawQty;if(!qty)return;const cost=sourceType==="purchase"?Number(it.rate||it.unitCost||p.lastPurchaseCost||0):Number(p.averageCost||p.lastPurchaseCost||0);rows.push({id:"im-"+Date.now()+"-"+Math.random().toString(36).slice(2,10),shopKey:inventoryShopKey(),productName:p.name,productId:p.itemCode||p.barcode||p.name,qty,unitCost:Math.max(0,cost),type:sourceType,sourceType,sourceId:String(sourceId||""),date:date||today(),reason,reversed:false,createdAt:new Date().toISOString()});});
 if(nativeBridgePresent&&window.Android?.replaceInventorySource){
   try{
     const wasLoaded=!!window.__siddhiLazyState?.inventoryMovements?.();
     if(wasLoaded){const history=state.inventoryMovements;history.forEach(m=>{if(m.shopKey===inventoryShopKey()&&m.sourceType===sourceType&&String(m.sourceId)===String(reverseId)&&!m.reversed){m.reversed=true;m.reversedAt=new Date().toISOString();}});history.push(...rows);}
     const summary=JSON.parse(Android.replaceInventorySource(sourceType,String(reverseId),inventoryShopKey(),JSON.stringify(rows))||"[]");
     if(!Array.isArray(summary))throw new Error(summary.error||"Inventory database update failed");
     summary.forEach(x=>{const p=inventoryProductByName(x.productName);if(p){p.stockQty=Number(x.stockQty||0);if(Number(x.averageCost)>0)p.averageCost=Number(x.averageCost);}});
   }catch(e){console.error("Inventory source persistence failed",e);showNotice("Bill was saved, but stock movement persistence could not be confirmed. Please check Inventory before closing the app.","Inventory save warning");}
   return;
 }
 // Browser-only fallback retains the legacy in-memory movement behavior.
 inventoryReverseSource(sourceType,reverseId);
 rows.forEach(m=>state.inventoryMovements.push(m));
 rebuildInventoryBalances(rows.map(x=>x.productName));
}
function postBillInventoryMovement(bill,oldBillNo){applyInventorySourceChange("sale",oldBillNo||bill.billNo,bill.billNo,bill.date,bill.items,-1,"Customer bill");}
function postPurchaseInventoryMovement(purchase,oldId){applyInventorySourceChange("purchase",oldId||purchase.id,purchase.id,purchase.date,purchase.items,1,"Purchase invoice "+(purchase.invoiceNo||""));}
// SiddhiBillPlus Group Inventory: group metadata is global to the local installation;
// firm product/inventory records remain in their own firm namespaces.
const SBP_GROUP_KEY='siddhibillplus_business_groups_v1';
function sbpLoadGroups(){try{return JSON.parse(nativeStore[SBP_GROUP_KEY]||localStorage.getItem(SBP_GROUP_KEY)||'{"groups":[],"mappings":[],"transfers":[]}')}catch(_){return {groups:[],mappings:[],transfers:[]}}}
let sbpGroupData=sbpLoadGroups();
function sbpSaveGroups(){const raw=JSON.stringify(sbpGroupData);try{window.Android?.saveAppStateValue?.(SBP_GROUP_KEY,raw);localStorage.setItem(SBP_GROUP_KEY,raw);nativeStore[SBP_GROUP_KEY]=raw;}catch(e){console.error('Group inventory metadata save failed',e);throw e;}}
function sbpFirmProducts(f){try{const k='sbp_'+f.id+'__pksProducts';let raw=f.id===__sbActiveFirmId?JSON.stringify(state.products||[]):(localStorage.getItem(k)||nativeStore[k]);const rows=JSON.parse(raw||'[]');return Array.isArray(rows)?rows.filter(p=>p&&p.trackInventory===true):[];}catch(e){console.warn('Group inventory could not read firm products',f?.name,e);return [];}}
function sbpGroup(){return (sbpGroupData.groups||[]).find(g=>g.id===sbpGroupData.activeGroupId)||sbpGroupData.groups?.[0]||null;}
function sbpMappedProduct(f,p){const key=String(p.itemCode||p.barcode||p.name);const map=(sbpGroupData.mappings||[]).find(m=>m.firmId===f.id&&String(m.localProductKey)===key);return map?.groupProductId||('AUTO-'+String(p.barcode||p.itemCode||p.name||'').trim().toLowerCase().replace(/[^a-z0-9]+/g,'-'));}
function sbpGroupFirms(){const g=sbpGroup();return __sbFirmRegistry.firms.filter(f=>g?.firmIds?.includes(f.id)&&f.status!=='inactive');}
function sbpProductLocalKey(p){return String(p.itemCode||p.barcode||p.name||'');}
function sbpManualMapping(f,p){return (sbpGroupData.mappings||[]).find(m=>m.firmId===f.id&&String(m.localProductKey)===sbpProductLocalKey(p));}
function sbpMappingDiagnostics(){const firms=sbpGroupFirms(),byName=new Map(),norm=v=>String(v||'').trim().toLowerCase().replace(/[^a-z0-9]+/g,'');firms.forEach(f=>sbpFirmProducts(f).forEach(p=>{const m=sbpManualMapping(f,p),name=m?.groupProductName||m?.localProductName||p.name,key=norm(m?.localProductName||p.name)||norm(p.itemCode||p.barcode)||String(p.name);let r=byName.get(key);if(!r){r={id:m?.groupProductId||sbpMappedProduct(f,p),name,perFirm:new Map()};byName.set(key,r);}if(m){r.id=m.groupProductId;r.name=m.groupProductName||r.name;}r.perFirm.set(f.id,{product:p,mapped:!!m,groupProductId:m?.groupProductId||''});}));return [...byName.values()].map(r=>({...r,perFirm:firms.map(f=>({firm:f,...(r.perFirm.get(f.id)||{}),mapped:!!r.perFirm.get(f.id)?.mapped}))})).sort((a,b)=>a.name.localeCompare(b.name));}
function sbpTransferProductRows(){const g=sbpGroup();if(!g||!g.firmIds?.includes(__sbActiveFirmId))return [];const destId=$('groupTransferDestination')?.value||'',src=__sbFirmRegistry.firms.find(f=>f.id===__sbActiveFirmId),dst=__sbFirmRegistry.firms.find(f=>f.id===destId);if(!src||!dst||src.id===dst.id||!g.firmIds.includes(dst.id))return [];const srcProducts=sbpFirmProducts(src),dstProducts=sbpFirmProducts(dst),destById=new Map();dstProducts.forEach(p=>{const id=sbpMappedProduct(dst,p);if(!destById.has(id))destById.set(id,p);});return srcProducts.filter(p=>destById.has(sbpMappedProduct(src,p))).map(p=>{const id=sbpMappedProduct(src,p),m=sbpManualMapping(src,p),other=destById.get(id);return {id,name:m?.groupProductName||sbpManualMapping(dst,other)?.groupProductName||p.name,unit:p.unit||'',qty:Number(p.stockQty)||0};}).sort((a,b)=>a.name.localeCompare(b.name));}
function sbpRenderTransferDiagnostics(){const el=$('groupTransferDiagnostics');if(!el)return;const g=sbpGroup(),src=__sbFirmRegistry.firms.find(f=>f.id===__sbActiveFirmId),dst=__sbFirmRegistry.firms.find(f=>f.id===($('groupTransferDestination')?.value||''));if(!g||!src||!dst){el.innerHTML='<div class="muted">Select a destination firm in the same business group.</div>';return;}const rows=sbpMappingDiagnostics(),issues=rows.map(r=>({r,source:r.perFirm.find(x=>x.firm.id===src.id),destination:r.perFirm.find(x=>x.firm.id===dst.id)})).filter(x=>x.source?.product||x.destination?.product).filter(x=>!x.source?.product||!x.destination?.product||!x.source?.mapped||!x.destination?.mapped);el.innerHTML=issues.length?issues.map(({r,source,destination})=>{let message='';if(!source?.product)message=`Product is missing from ${src.name}.`;else if(!destination?.product)message=`Product is missing from ${dst.name}.`;else if(!source.mapped)message=`${r.name} is mapped in ${dst.name} but missing a mapping in ${src.name}.`;else message=`${r.name} is mapped in ${src.name} but missing a mapping in ${dst.name}.`;return `<div class="module-record"><b>${esc(r.name)}</b><div class="module-meta">${esc(message)}</div><div class="status">${esc(!source?.mapped?src.name:dst.name)}: mapping required</div></div>`;}).join(''):`<div class="muted">${rows.length?'All matching products are mapped in both selected firms.':'No tracked inventory products found in the selected firms.'}</div>`;}
function sbpRenderTransferProductOptions(){const t=$('groupTransferProduct');if(!t)return;const prior=t.value,rows=sbpTransferProductRows();t.innerHTML=rows.map(r=>`<option value="${esc(r.id)}">${esc(r.name)} (${Number(r.qty.toFixed(3))} ${esc(r.unit)})</option>`).join('')||'<option value="">No products mapped in both selected firms</option>';if(rows.some(r=>r.id===prior))t.value=prior;sbpRenderTransferDiagnostics();}
function sbpRenderMappingDiagnostics(){const el=$('groupMappingDiagnostics');if(!el)return;const firms=sbpGroupFirms(),rows=sbpMappingDiagnostics();if(!firms.length){el.innerHTML='<div class="muted">Add at least two active firms to the business group to see mapping status.</div>';return;}el.innerHTML=rows.map(r=>{const missing=r.perFirm.filter(x=>!x.mapped);return `<article class="module-record"><div class="module-record-head"><div><b>${esc(r.name)}</b><div class="module-meta">${esc(r.id)}</div></div><span class="status">${missing.length?'Incomplete':'Mapped'}</span></div>${r.perFirm.map(x=>`<div class="module-meta">${esc(x.firm.name)} — ${x.product?esc(x.product.name):'Product not found'} · ${x.mapped?'<span class="inventory-instock">Mapped</span>':'<span class="inventory-low">Missing mapping</span>'}</div>`).join('')}${missing.length?`<div class="muted">${esc(r.name)} is not mapped in: ${missing.map(x=>esc(x.firm.name)).join(', ')}.</div>`:'<div class="muted">Mapped in all active firms in this group.</div>'}</article>`;}).join('')||'<div class="muted">No tracked inventory products found in the selected firms.</div>';}
function sbpGroupRows(){const g=sbpGroup();if(!g)return [];const firms=__sbFirmRegistry.firms.filter(f=>g.firmIds.includes(f.id)&&f.status!=='inactive'),out=new Map();firms.forEach(f=>sbpFirmProducts(f).forEach(p=>{const id=sbpMappedProduct(f,p);let r=out.get(id);if(!r){r={id,name:(sbpGroupData.mappings||[]).find(m=>m.groupProductId===id)?.groupProductName||p.name,unit:p.unit||'',qty:0,inTransit:0,value:0,firms:[]};out.set(id,r);}const qty=Number(p.stockQty)||0,cost=Number(p.averageCost||p.lastPurchaseCost)||0;r.qty+=qty;r.value+=qty*cost;r.firms.push({firm:f,product:p,qty,cost});}));(sbpGroupData.transfers||[]).filter(t=>['dispatched','partially_received'].includes(t.status)).forEach(t=>{const r=out.get(t.groupProductId);if(r)r.inTransit+=Math.max(0,Number(t.qty||0)-Number(t.receivedQty||0));});return [...out.values()].sort((a,b)=>a.name.localeCompare(b.name));}
function sbpRenderGroupInventory(){const fs=$('groupInventoryFirms'),g=sbpGroup();if(fs){fs.innerHTML=__sbFirmRegistry.firms.filter(f=>f.status!=='inactive').map(f=>`<option value="${esc(f.id)}" ${g?.firmIds?.includes(f.id)?'selected':''}>${esc(f.name)}</option>`).join('');}const dest=$('groupTransferDestination');if(dest){const eligible=__sbFirmRegistry.firms.filter(f=>f.status!=='inactive'&&f.id!==__sbActiveFirmId&&g?.firmIds?.includes(f.id));const prior=dest.value;dest.innerHTML=eligible.map(f=>`<option value="${esc(f.id)}">${esc(f.name)}</option>`).join('')||'<option value="">No other active firm in this group</option>';if(eligible.some(f=>f.id===prior))dest.value=prior;else if(eligible.length)dest.value=eligible[0].id;}const prod=$('groupMapProduct');if(prod)prod.innerHTML=state.products.filter(p=>p.trackInventory===true).map(p=>`<option value="${esc(p.itemCode||p.barcode||p.name)}">${esc(p.name)}</option>`).join('');const maps=$('groupProductMappings');if(maps)maps.innerHTML=(sbpGroupData.mappings||[]).filter(m=>g?.firmIds?.includes(m.firmId)).map(m=>`<div class="module-record"><b>${esc(m.groupProductName)}</b><div class="module-meta">${esc(m.groupProductId)} · ${esc(__sbFirmRegistry.firms.find(f=>f.id===m.firmId)?.name||m.firmId)} · ${esc(m.localProductName)}</div></div>`).join('')||'<div class="muted">No manual product mappings yet. Barcode/SKU/name fallback is used until products are mapped.</div>';sbpRenderMappingDiagnostics();const summary=$('groupInventorySummary');if(!summary)return;if(!g){summary.innerHTML='<div class="module-empty">Create a business group and select at least two firms to view consolidated inventory.</div>';return;}const rows=sbpGroupRows(),total=rows.reduce((a,r)=>a+r.value,0);summary.innerHTML=`<div class="module-kpis"><div class="module-kpi"><span>Firms included</span><strong>${g.firmIds.length}</strong></div><div class="module-kpi"><span>Group products</span><strong>${rows.length}</strong></div><div class="module-kpi"><span>Stock valuation</span><strong>${money(total)}</strong></div></div><div class="muted">${esc(g.name)}</div><div style="overflow-x:auto"><table class="data-table"><thead><tr><th>Product</th><th>Firm stock</th><th>In transit</th><th>Firm breakdown</th><th>Value</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.name)}</td><td>${Number(r.qty.toFixed(4))} ${esc(r.unit)}</td><td>${Number(r.inTransit.toFixed(4))} ${esc(r.unit)}</td><td>${r.firms.map(x=>`${esc(x.firm.name)}: ${Number(x.qty.toFixed(4))}`).join('<br>')}</td><td>${money(r.value)}</td></tr>`).join('')||'<tr><td colspan="5">No tracked products found in selected firms.</td></tr>'}</tbody></table></div>`;sbpRenderTransferProductOptions();sbpRenderTransfers();}
function sbpRenderTransfers(){const el=$('groupTransferList');if(!el)return;const rows=(sbpGroupData.transfers||[]).filter(t=>sbpGroup()?.firmIds?.includes(t.sourceFirmId)||sbpGroup()?.firmIds?.includes(t.destinationFirmId)).slice().reverse();el.innerHTML=rows.map(t=>{const src=__sbFirmRegistry.firms.find(f=>f.id===t.sourceFirmId)?.name||t.sourceFirmId,dst=__sbFirmRegistry.firms.find(f=>f.id===t.destinationFirmId)?.name||t.destinationFirmId;let actions='';if(t.status==='pending_approval'&&t.destinationFirmId===__sbActiveFirmId)actions=`<button class="secondary" data-gtransfer="approve" data-id="${esc(t.id)}">Approve</button> <button class="secondary" data-gtransfer="reject" data-id="${esc(t.id)}">Reject</button>`;if(t.status==='approved'&&t.sourceFirmId===__sbActiveFirmId)actions=`<button class="primary" data-gtransfer="dispatch" data-id="${esc(t.id)}">Dispatch</button>`;if((t.status==='dispatched'||t.status==='partially_received')&&t.destinationFirmId===__sbActiveFirmId)actions=`<button class="primary" data-gtransfer="receive" data-id="${esc(t.id)}">Confirm Receipt</button>`;return `<article class="module-record"><div class="module-record-head"><div><b>${esc(t.productName)}</b><div class="module-meta">${esc(src)} → ${esc(dst)} · ${t.qty} ${esc(t.unit)} · ${esc(t.createdAt)}</div></div><span class="status">${esc(t.status.replaceAll('_',' ').toUpperCase())}</span></div>${actions}</article>`;}).join('')||'<div class="muted">No group stock transfers yet.</div>';}
function sbpApplyTransferMovement(t,firmId,qty,type){const f=__sbFirmRegistry.firms.find(x=>x.id===firmId);if(!f)throw Error('Firm not found');const key='sbp_'+f.id+'__pksProducts';let products=JSON.parse(f.id===__sbActiveFirmId?JSON.stringify(state.products||[]):(localStorage.getItem(key)||nativeStore[key]||'[]'));if(!Array.isArray(products))throw Error('Product data is unavailable for '+f.name);const fProducts=products.filter(x=>x&&x.trackInventory===true);const map=(sbpGroupData.mappings||[]).find(m=>m.groupProductId===t.groupProductId&&m.firmId===firmId);let p=fProducts.find(x=>String(x.itemCode||x.barcode||x.name)===String(map?.localProductKey))||fProducts.find(x=>sbpMappedProduct(f,x)===t.groupProductId);if(!p)throw Error('Mapped product is missing in '+f.name);if(type==='transfer_out'&&(Number(p.stockQty)||0)<qty)throw Error('Insufficient available stock in '+f.name);const movement={id:'im-'+Date.now()+'-'+Math.random().toString(36).slice(2,8),shopKey:String(f.shopKey||f.id).toLowerCase(),productName:p.name,productId:p.itemCode||p.barcode||p.name,qty:type==='transfer_out'?-qty:qty,unitCost:Number(p.averageCost||p.lastPurchaseCost)||0,type,sourceType:'inter_firm_transfer',sourceId:t.id,date:today(),reason:'Group transfer '+t.transferNo,reversed:false,createdAt:new Date().toISOString()};if(!window.Android?.saveTransactionRecord||window.Android.saveTransactionRecord('pksInventoryMovements',JSON.stringify(movement))===false)throw Error('Could not save inventory movement for '+f.name);p.stockQty=Number(((Number(p.stockQty)||0)+movement.qty).toFixed(6));products[products.indexOf(p)]=p;window.Android.saveAppStateValue(key,JSON.stringify(products));nativeStore[key]=JSON.stringify(products);if(f.id===__sbActiveFirmId){state.products=products;save();}}
function sbpHandleTransferAction(action,id){const t=sbpGroupData.transfers.find(x=>x.id===id);if(!t)return;try{if(action==='approve'){t.status='approved';t.approvedAt=new Date().toISOString();}else if(action==='reject'){t.status='rejected';t.rejectedAt=new Date().toISOString();}else if(action==='dispatch'){sbpApplyTransferMovement(t,t.sourceFirmId,t.qty,'transfer_out');t.status='dispatched';t.dispatchedAt=new Date().toISOString();}else if(action==='receive'){const remaining=Number(t.qty)-Number(t.receivedQty||0);const qty=Number(prompt('Quantity received (remaining '+remaining+' '+t.unit+')',String(remaining)));if(!Number.isFinite(qty)||qty<=0||qty>remaining)throw Error('Enter a valid received quantity not exceeding dispatched quantity.');sbpApplyTransferMovement(t,t.destinationFirmId,qty,'transfer_in');t.receivedQty=Number(t.receivedQty||0)+qty;t.status=t.receivedQty>=t.qty?'completed':'partially_received';t.receivedAt=new Date().toISOString();}(sbpGroupData.audit||(sbpGroupData.audit=[])).push({id:'ga-'+Date.now(),transferId:t.id,action,firmId:__sbActiveFirmId,at:new Date().toISOString(),status:t.status});sbpSaveGroups();sbpRenderGroupInventory();}catch(e){showNotice(e.message||String(e),'Stock transfer not completed');}}
function sbpInitGroupInventory(){const saveGroup=$('groupInventorySaveGroup');if(saveGroup)saveGroup.onclick=()=>{const name=$('groupInventoryName').value.trim(),ids=[...$('groupInventoryFirms').selectedOptions].map(o=>o.value);if(!name||ids.length<2){showNotice('Enter a group name and select at least two firms.','Business group');return;}let g=sbpGroup();if(!g){g={id:'grp-'+Date.now(),name,firmIds:[],createdAt:new Date().toISOString()};sbpGroupData.groups.push(g);}g.name=name;g.firmIds=ids;sbpGroupData.activeGroupId=g.id;sbpSaveGroups();sbpRenderGroupInventory();};$('groupInventoryRefresh')&&($('groupInventoryRefresh').onclick=sbpRenderGroupInventory);$('groupTransferDestination')?.addEventListener('change',()=>{if($('groupTransferQty'))$('groupTransferQty').value='';sbpRenderTransferProductOptions();});$('groupMapSave')?.addEventListener('click',()=>{const key=$('groupMapProduct').value,p=state.products.find(x=>String(x.itemCode||x.barcode||x.name)===key),g=sbpGroup();if(!g||!p)return;const name=$('groupMapName').value.trim()||p.name,id=$('groupMapId').value.trim()||('GP-'+String(p.barcode||p.itemCode||p.name).toLowerCase().replace(/[^a-z0-9]+/g,'-'));const f=__sbActiveFirm();sbpGroupData.mappings=sbpGroupData.mappings.filter(m=>!(m.firmId===f.id&&m.localProductKey===key));sbpGroupData.mappings.push({groupProductId:id,groupProductName:name,firmId:f.id,localProductKey:key,localProductName:p.name,unit:p.unit,createdAt:new Date().toISOString()});sbpSaveGroups();sbpRenderGroupInventory();});$('groupTransferCreate')?.addEventListener('click',()=>{const g=sbpGroup(),dest=$('groupTransferDestination').value,pid=$('groupTransferProduct').value,r=sbpGroupRows().find(x=>x.id===pid),qty=Number($('groupTransferQty').value);if(!g||!dest||!r||!Number.isFinite(qty)||qty<=0){showNotice('Select a destination, mapped product and valid quantity.','Stock transfer');return;}const sourceFirm=__sbActiveFirm();if(!g.firmIds.includes(sourceFirm.id)||!g.firmIds.includes(dest)){showNotice('Both firms must belong to the same business group.','Stock transfer');return;}const sourceRow=r.firms.find(x=>x.firm.id===sourceFirm.id);if(!sourceRow||sourceRow.qty<qty){showNotice('Insufficient stock in the source firm.','Stock transfer');return;}const t={id:'tr-'+Date.now(),transferNo:'TR-'+Date.now().toString().slice(-8),groupProductId:pid,productName:r.name,unit:r.unit,qty,sourceFirmId:sourceFirm.id,destinationFirmId:dest,status:'pending_approval',createdAt:new Date().toISOString(),createdByFirm:sourceFirm.id,reason:$('groupTransferReason').value.trim()};sbpGroupData.transfers.push(t);(sbpGroupData.audit||(sbpGroupData.audit=[])).push({id:'ga-'+Date.now(),transferId:t.id,action:'requested',firmId:sourceFirm.id,at:new Date().toISOString(),status:t.status});sbpSaveGroups();$('groupTransferQty').value='';sbpRenderGroupInventory();});$('groupTransferList')&&($('groupTransferList').onclick=e=>{const b=e.target.closest('[data-gtransfer]');if(b)sbpHandleTransferAction(b.dataset.gtransfer,b.dataset.id);});sbpRenderGroupInventory();}
function renderInventory(){if(state.settings.inventoryManagement!==true)return;inventoryReportShopOptions();const list=$("inventoryStockList"),search=String($("inventorySearch")?.value||"").trim().toLowerCase(),tracked=state.products.filter(p=>p.trackInventory===true),shown=tracked.filter(p=>!search||[p.name,p.itemCode,p.barcode].join(" ").toLowerCase().includes(search)).sort((a,b)=>{const low=p=>Number(p.stockQty||0)<=0||Number(p.stockQty||0)<Number(p.minStock||0);return Number(low(b))-Number(low(a))||String(a.name||"").localeCompare(String(b.name||""));}),stockPage=window.inventoryStockPage||1,stockRows=shown.slice((stockPage-1)*25,stockPage*25);$("inventoryTrackedCount").textContent=String(tracked.length);$("inventoryLowCount").textContent=String(tracked.filter(p=>Number(p.stockQty||0)<Number(p.minStock||0)||Number(p.stockQty||0)<0).length);$("inventoryValue").textContent=money(tracked.reduce((a,p)=>a+Math.max(0,Number(p.stockQty)||0)*Math.max(0,Number(p.averageCost||0)),0));if(list)list.innerHTML=(stockRows.length?stockRows.map(p=>`<div class="product-row"><div><div class="product-name">${esc(p.name)}</div><div class="muted">${esc(p.itemCode||p.barcode||"")} • ${Number(p.stockQty||0)} ${esc(p.unit||"")} • Avg cost ${money(p.averageCost||0)} • Value ${money((Number(p.stockQty)||0)*(Number(p.averageCost)||0))}</div></div><div><span class="${Number(p.stockQty||0)<0||Number(p.stockQty||0)<Number(p.minStock||0)?"inventory-low":"inventory-instock"}">${Number(p.stockQty||0)<0?"Negative stock":Number(p.stockQty||0)<Number(p.minStock||0)?"Low stock":"In Stock"}</span></div></div>`).join(""):'<div class="muted">No tracked products match your search. Enable tracking in Product → Edit.</div>')+`<div class="pagination"><button type="button" class="secondary" onclick="window.inventoryStockPage=Math.max(1,(window.inventoryStockPage||1)-1);renderInventory()">Previous</button><span>Page ${stockPage} of ${Math.max(1,Math.ceil(shown.length/25))}</span><button type="button" class="secondary" onclick="window.inventoryStockPage=Math.min(${Math.max(1,Math.ceil(shown.length/25))},(window.inventoryStockPage||1)+1);renderInventory()">Next</button></div>`;
 const sel=$("inventoryAdjustProduct");if(sel){const prev=sel.value;sel.innerHTML=tracked.map(p=>`<option value="${esc(p.name)}">${esc(p.name)} (${Number(p.stockQty||0)} ${esc(p.unit||"")})</option>`).join("");if(tracked.some(p=>p.name===prev))sel.value=prev;}
 const hist=$("inventoryMovementList");if(hist){let rows=[];try{if(nativeBridgePresent&&window.Android?.loadRecentInventoryMovements)rows=JSON.parse(Android.loadRecentInventoryMovements(inventoryShopKey(),5000)||"[]");else rows=state.inventoryMovements.filter(m=>m.shopKey===inventoryShopKey()&&!m.reversed).slice().reverse();}catch(e){console.warn("Recent inventory movement query failed",e);}const movementPage=window.inventoryMovementPage||1,movementRows=rows.slice((movementPage-1)*25,movementPage*25);hist.innerHTML=(movementRows.length?movementRows.map(m=>`<div class="history-row"><div><b>${esc(m.productName)}</b><div class="muted">${esc(m.date||"")} • ${esc(m.type)} • ${esc(m.sourceId||m.reason||"")}</div></div><div>${Number(m.qty)>0?"+":""}${Number(m.qty)}<div class="muted">${money(Number(m.qty||0)*Number(m.unitCost||0))}</div></div></div>`).join(""):'<div class="muted">No stock movements recorded yet.</div>')+`<div class="pagination"><button type="button" class="secondary" onclick="window.inventoryMovementPage=Math.max(1,(window.inventoryMovementPage||1)-1);renderInventory()">Previous</button><span>Page ${movementPage} of ${Math.max(1,Math.ceil(rows.length/25))}</span><button type="button" class="secondary" onclick="window.inventoryMovementPage=Math.min(${Math.max(1,Math.ceil(rows.length/25))},(window.inventoryMovementPage||1)+1);renderInventory()">Next</button></div>`;}}
function inventoryReportShopOptions(){const prod=$("inventoryReportProduct");if(prod){const prev=prod.value;prod.innerHTML=`<option value="">All Products</option>${state.products.filter(p=>p.trackInventory===true).map(p=>`<option value="${esc(p.name)}">${esc(p.name)}</option>`).join("")}`;if([...prod.options].some(o=>o.value===prev))prod.value=prev;}const el=$("inventoryReportShop");if(!el)return;const prior=el.value||"current",keys=[inventoryShopKey()];el.innerHTML='<option value="current">Current Shop</option><option value="all">All Shops</option>'+keys.filter(k=>k!==inventoryShopKey()).map(k=>`<option value="${esc(k)}">${esc(k)}</option>`).join("");if([...el.options].some(o=>o.value===prior))el.value=prior;}
function inventoryReportData(){let type=$("inventoryReportType")?.value||"summary";if(type==="valuation")type="summary";const shopChoice=$("inventoryReportShop")?.value||"current",from=$("inventoryReportFrom")?.value||"",to=$("inventoryReportTo")?.value||"";if(from&&to&&from>to)throw new Error("From date must be on or before To date.");let allMov=[];if(!(nativeBridgePresent&&window.Android?.loadInventoryReportMovements))allMov=(state.inventoryMovements||[]).filter(m=>!m.reversed&&m.shopKey);let shops=shopChoice==="all"?[...new Set([inventoryShopKey(),...allMov.map(m=>String(m.shopKey))])]:[shopChoice==="current"?inventoryShopKey():shopChoice];const fmtShop=k=>k===inventoryShopKey()?(state.settings.shopName||k):k;const selectedProduct=String($("inventoryReportProduct")?.value||"");const tracked=state.products.filter(p=>p.trackInventory===true);let rows=[];
 if(type==="ledger"){
  if(nativeBridgePresent&&window.Android?.loadInventoryReportMovements){try{const payload=JSON.parse(Android.loadInventoryReportMovements(from||"0000-01-01",to||"9999-12-31",shopChoice==="all"?"*":shops[0],selectedProduct)||"[]");allMov=Array.isArray(payload)?payload:[];if(shopChoice==="all")shops=[...new Set(allMov.map(m=>String(m.shopKey||"")).filter(Boolean))];}catch(e){console.warn("Native inventory ledger query failed",e);}}
  rows=allMov.filter(m=>(!selectedProduct||String(m.productName||"")===selectedProduct)&&shops.includes(String(m.shopKey))&&(!from||String(m.date||"")>=from)&&(!to||String(m.date||"")<=to)).sort((a,b)=>String(a.date||"").localeCompare(String(b.date||""))||String(a.createdAt||"").localeCompare(String(b.createdAt||""))).map(m=>({shop:fmtShop(m.shopKey),date:m.date||"",product:m.productName||"",code:m.productId||"",type:m.type||"",reference:m.sourceId||m.reason||"",qty:Number(m.qty)||0,unitCost:Number(m.unitCost)||0,value:(Number(m.qty)||0)*(Number(m.unitCost)||0),balance:""}));
 } else {
  const names=[...new Set([...tracked.map(p=>String(p.name||"")),...allMov.filter(m=>shops.includes(String(m.shopKey))).map(m=>String(m.productName||""))].filter(Boolean))];
  for(const shop of shops){for(const name of names){const product=tracked.find(p=>String(p.name||"").toLowerCase()===name.toLowerCase());if(!product)continue;let qty=0,avg=Number(product.averageCost||product.lastPurchaseCost||0);
    if(nativeBridgePresent&&window.Android?.loadInventoryReportMovements){qty=Number(product.stockQty)||0;}
    else {const mov=allMov.filter(m=>String(m.shopKey)===shop&&String(m.productName||"").toLowerCase()===name.toLowerCase()).sort((a,b)=>String(a.date||"").localeCompare(String(b.date||""))||String(a.createdAt||"").localeCompare(String(b.createdAt||"")));let value=0;mov.forEach(m=>{const q=Number(m.qty)||0,c=Math.max(0,Number(m.unitCost)||0);if(q>0){qty+=q;value+=q*c;}else if(q<0){const weighted=qty>0?value/qty:(c||avg);qty+=q;value=Math.max(0,value+q*weighted);}});avg=qty>0?value/qty:avg;}
    const min=Number(product.minStock||0),row={shop:fmtShop(shop),date:"",product:name,code:product.itemCode||product.barcode||"",unit:product.unit||"",qty:Number(qty.toFixed(6)),unitCost:Number(avg.toFixed(6)),value:Number((qty*avg).toFixed(2)),minStock:min,status:qty<0?"Negative stock":qty<=0?"Out of stock":qty<min?"Low stock":"In stock"};if(type!=="low"||qty<=0||qty<min||qty<0)rows.push(row);}}
 }
 if(type==="low")rows.sort((a,b)=>Number(a.qty)-Number(b.qty));return {type,shopChoice,shops,from,to,rows,shopLabel:shopChoice==="all"?"All Shops":fmtShop(shops[0]||inventoryShopKey())};}
function inventoryReportTitle(type){return ({summary:"Stock Summary",valuation:"Stock Valuation",low:"Low Stock & Reorder",ledger:"Stock Movement Ledger"})[type]||"Inventory Report";}
function inventoryReportHtml(data){const title=inventoryReportTitle(data.type),fmt=n=>money(Number(n)||0),cols=data.type==="ledger"?["Shop","Date","Product","Code","Movement","Reference","Qty Change","Unit Cost","Movement Value"]:["Shop","Product","Code","Unit","Quantity","Average Cost","Stock Value",...(data.type==="low"?["Minimum Stock","Status"]:[])];const keys=data.type==="ledger"?["shop","date","product","code","type","reference","qty","unitCost","value"]:["shop","product","code","unit","qty","unitCost","value",...(data.type==="low"?["minStock","status"]:[])];const moneyKeys=new Set(["unitCost","value"]);const rows=data.rows.map(r=>`<tr>${keys.map(k=>`<td class="${moneyKeys.has(k)?"num":""}">${esc(moneyKeys.has(k)?fmt(r[k]):(r[k]??""))}</td>`).join("")}</tr>`).join("");return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>@page{size:A4 landscape;margin:10mm}body{font:11px Arial,sans-serif;color:#172b45}h1{font-size:20px;margin:0 0 6px}p{margin:5px 0;color:#555}table{border-collapse:collapse;width:100%;table-layout:fixed;margin-top:12px;font-size:7.5px}thead{display:table-header-group}tr{break-inside:avoid;page-break-inside:avoid}th,td{border:1px solid #cbd5e1;padding:3px;text-align:left;overflow-wrap:anywhere}th{background:#edf3fa}.num{text-align:right;white-space:nowrap}.total{margin-top:12px;font-weight:bold}</style></head><body><h1>${esc(state.settings.shopName||"SiddhiBill")} — ${esc(title)}</h1><p>Shop: ${esc(data.shopLabel)} · Generated: ${esc(today())}${data.type==="ledger"?` · Period: ${esc(data.from||"All dates")} to ${esc(data.to||"Today")}`:" · Current stock position"}</p><table><thead><tr>${cols.map(c=>`<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${rows||`<tr><td colspan="${cols.length}">No records for this report.</td></tr>`}</tbody></table><p class="total">Rows: ${data.rows.length} · Total stock value: ${fmt(data.rows.reduce((a,r)=>a+(data.type==="ledger"?0:Number(r.value)||0),0))}</p><script>window.onload=()=>setTimeout(()=>window.print(),250)<\/script></body></html>`;}
function renderInventoryReport(){try{const d=inventoryReportData(),title=inventoryReportTitle(d.type),container=$("inventoryReportResults"),sum=d.rows.reduce((a,r)=>a+(d.type==="ledger"?0:Number(r.value)||0),0),page=window.inventoryReportPage||1,all=d.rows,shown=all.slice((page-1)*25,page*25);window.inventoryReportLastData=d;const cols=d.type==="ledger"?["shop","date","product","type","reference","qty","unitCost","value"]:["shop","product","code","unit","qty","unitCost","value",...(d.type==="low"?["minStock","status"]:[])],labels={shop:"Shop",date:"Date",product:"Product",code:"Code",unit:"Unit",type:"Movement",reference:"Reference",qty:d.type==="ledger"?"Qty Change":"Quantity",unitCost:"Unit Cost",value:d.type==="ledger"?"Movement Value":"Stock Value",minStock:"Minimum",status:"Status"};container.innerHTML=`<div class="muted">${esc(title)} · ${all.length} row(s) · ${d.type==="ledger"?"Movement values are signed quantities × recorded unit cost.":"Current stock value: "+money(sum)}</div><div style="overflow-x:auto;margin-top:8px"><table class="data-table inventory-report-table"><colgroup>${cols.map(()=>'<col>').join("")}</colgroup><thead><tr>${cols.map(k=>`<th>${labels[k]}</th>`).join("")}</tr></thead><tbody>${shown.length?shown.map(r=>`<tr>${cols.map(k=>`<td>${esc(["unitCost","value"].includes(k)?money(r[k]):(r[k]??""))}</td>`).join("")}</tr>`).join(""):`<tr><td colspan="${cols.length}">No records found.</td></tr>`}</tbody></table></div><div class="pagination"><button type="button" class="secondary" onclick="window.inventoryReportPage=Math.max(1,(window.inventoryReportPage||1)-1);renderInventoryReport()">Previous</button><span>Page ${page} of ${Math.max(1,Math.ceil(all.length/25))} · ${all.length} rows</span><button type="button" class="secondary" onclick="window.inventoryReportPage=Math.min(${Math.max(1,Math.ceil(all.length/25))},(window.inventoryReportPage||1)+1);renderInventoryReport()">Next</button></div>`;$ ("inventoryReportStatus").textContent="Report ready. PDF and CSV use the complete selected report.";}catch(e){$("inventoryReportStatus").textContent=e.message;}}
function exportInventoryReportCsv(){try{const d=window.inventoryReportLastData||inventoryReportData(),title=inventoryReportTitle(d.type),keys=d.type==="ledger"?["shop","date","product","code","type","reference","qty","unitCost","value"]:["shop","product","code","unit","qty","unitCost","value",...(d.type==="low"?["minStock","status"]:[])],headers={shop:"Shop",date:"Date",product:"Product",code:"Code",unit:"Unit",type:"Movement Type",reference:"Reference",qty:d.type==="ledger"?"Quantity Change":"Quantity",unitCost:"Unit Cost",value:d.type==="ledger"?"Movement Value":"Stock Value",minStock:"Minimum Stock",status:"Status"};const csv=[keys.map(k=>headers[k]),...d.rows.map(r=>keys.map(k=>r[k]??""))].map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(",")).join("\r\n"),filename="SiddhiBill_"+title.replace(/[^a-z0-9]+/gi,"_")+".csv";if(window.Android?.saveExportFile){Android.saveExportFile(btoa(unescape(encodeURIComponent(csv))),filename);}else{a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"}));a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}}catch(e){showNotice(e.message,"Inventory Report");}}
function exportInventoryReportPdf(){try{const d=window.inventoryReportLastData||inventoryReportData(),html=inventoryReportHtml(d);if(window.Android?.printHtmlDocument){Android.printHtmlDocument(html,"SiddhiBill_"+inventoryReportTitle(d.type).replace(/\s+/g,"_"));$("inventoryReportStatus").textContent="Report opened in Android Print. Choose Save as PDF to download.";return;}const w=window.open("","_blank");if(!w){showNotice("Allow pop-ups to open the PDF report.","Inventory Report");return;}w.document.open();w.document.write(html);w.document.close();}catch(e){showNotice(e.message,"Inventory Report");}}
$("inventoryReportViewBtn")?.addEventListener("click",()=>{window.inventoryReportPage=1;renderInventoryReport();});$("inventoryReportCsvBtn")?.addEventListener("click",()=>{window.inventoryReportLastData=null;renderInventoryReport();if(window.inventoryReportLastData)exportInventoryReportCsv();});$("inventoryReportPdfBtn")?.addEventListener("click",()=>{window.inventoryReportLastData=null;renderInventoryReport();if(window.inventoryReportLastData)exportInventoryReportPdf();});$("inventoryReportType")?.addEventListener("change",()=>{window.inventoryReportPage=1;window.inventoryReportLastData=null;$("inventoryReportResults").innerHTML="";$("inventoryReportStatus").textContent="Click View Report to generate the selected report.";});
$("inventoryRefreshBtn")?.addEventListener("click",()=>{renderInventory();inventoryReportShopOptions();window.inventoryReportLastData=null;$("inventoryReportResults").innerHTML="";$("inventoryReportStatus").textContent="Inventory refreshed. Click View Report to generate a report.";});$("inventorySearch")?.addEventListener("input",renderInventory);
$("inventoryAdjustSaveBtn")?.addEventListener("click",()=>{if(state.settings.inventoryManagement!==true)return;const p=inventoryProductByName($("inventoryAdjustProduct")?.value),type=$("inventoryAdjustType").value,q=Math.abs(Number($("inventoryAdjustQty").value)||0),cost=Number($("inventoryAdjustCost").value||0),reason=$("inventoryAdjustReason").value.trim();if(!p||p.trackInventory!==true){showNotice("Select a product with inventory tracking enabled.","Inventory");return;}if(!(q>0)){showNotice("Enter a quantity greater than zero.","Inventory");return;}const entered=Number($("inventoryAdjustQty").value)||0;const signed=type==="adjustment"?entered:((type==="damage"||type==="purchase_return")?-q:q);if(type==="adjustment"&&Math.abs(entered)<0.000001){showNotice("Enter a non-zero adjustment quantity.","Inventory");return;}if(type==="opening"&&state.inventoryMovements.some(m=>m.shopKey===inventoryShopKey()&&m.productName===p.name&&m.type==="opening"&&!m.reversed)){showNotice("Opening stock has already been entered for this product. Use Physical count adjustment to correct it.","Inventory");return;}inventoryAddMovement({product:p,qty:signed,unitCost:cost||Number(p.averageCost||p.lastPurchaseCost||0),type,sourceType:"manual",sourceId:"",date:today(),reason:reason||type});save();$("inventoryAdjustQty").value="";$("inventoryAdjustCost").value="";$("inventoryAdjustReason").value="";$("inventoryAdjustStatus").textContent="Stock movement saved.";renderInventory();});
$("inventoryExportBtn")?.addEventListener("click",()=>{const rows=state.inventoryMovements.filter(m=>m.shopKey===inventoryShopKey()&&!m.reversed);const csv=["Date,Product,Type,Quantity,Unit Cost,Source,Reason",...rows.map(m=>[m.date,m.productName,m.type,m.qty,m.unitCost,m.sourceId,m.reason].map(v=>'"'+String(v??"").replace(/"/g,'""')+'"').join(","))].join("\n");const filename="SiddhiBill_Inventory_Movements.csv";if(window.Android?.saveExportFile){Android.saveExportFile(btoa(unescape(encodeURIComponent(csv))),filename);}else{const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"}));a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}});

$("inventoryOpeningImportBtn")?.addEventListener("click",()=>$("inventoryOpeningImportFile")?.click());
$("inventoryOpeningImportFile")?.addEventListener("change",async e=>{const file=e.target.files?.[0];if(!file)return;try{const text=await file.text();const lines=text.split(/\r?\n/).filter(x=>x.trim());if(lines.length<2)throw new Error("CSV needs a header and at least one row.");const parseLine=line=>{const out=[];let cur="",quoted=false;for(let i=0;i<line.length;i++){const ch=line[i];if(ch==='"'&&line[i+1]==='"'&&quoted){cur+='"';i++;}else if(ch==='"')quoted=!quoted;else if(ch===','&&!quoted){out.push(cur.trim());cur="";}else cur+=ch;}out.push(cur.trim());return out;};const headers=parseLine(lines[0]).map(x=>x.toLowerCase());const ixName=headers.findIndex(x=>["product","product name","name"].includes(x)),ixQty=headers.findIndex(x=>["quantity","opening quantity","qty"].includes(x)),ixCost=headers.findIndex(x=>["unit cost","cost","average cost"].includes(x));if(ixName<0||ixQty<0)throw new Error("CSV columns required: Product, Quantity; optional Unit Cost.");let added=0;for(let i=1;i<lines.length;i++){const row=parseLine(lines[i]),p=inventoryProductByName(row[ixName]);const qty=Number(row[ixQty]||0),cost=ixCost>=0?Number(row[ixCost]||0):0;if(!p||p.trackInventory!==true||!(qty>=0)||!Number.isFinite(qty))continue;if(state.inventoryMovements.some(m=>m.shopKey===inventoryShopKey()&&m.productName===p.name&&m.type==="opening"&&!m.reversed))continue;inventoryAddMovement({product:p,qty,unitCost:cost||Number(p.lastPurchaseCost||0),type:"opening",sourceType:"manual",date:today(),reason:"Opening stock CSV import"});added++;}save();renderInventory();showNotice(`Opening stock import completed. ${added} product rows imported. Rows for unknown or untracked products and products with existing opening stock were skipped.`,"Inventory CSV Import");}catch(err){showNotice("Opening stock CSV import failed: "+err.message,"Inventory CSV Import");}finally{e.target.value="";}});

let editingVendorId=null;
function openVendorModal(vendorId=null, prefill={}){editingVendorId=vendorId;const v=vendorId?vendorById(vendorId):null;$("vendorModalTitle").textContent=v?"Edit Vendor":"Add Vendor";const values={vendorName:v?.name||prefill.name||"",vendorPhone:v?.phone||prefill.phone||"",vendorGstin:v?.gstin||prefill.gstin||"",vendorFssai:v?.fssai||prefill.fssai||"",vendorPan:v?.pan||prefill.pan||"",vendorEmail:v?.email||prefill.email||"",vendorState:v?.state||prefill.state||"",vendorStateCode:v?.stateCode||prefill.stateCode||"",vendorAddress:v?.address||prefill.address||""};Object.entries(values).forEach(([id,value])=>{if($(id))$(id).value=value});let hint=document.getElementById("vendorOcrReviewHint");if(!hint){hint=document.createElement("div");hint.id="vendorOcrReviewHint";hint.className="status";const title=$("vendorModalTitle");title?.insertAdjacentElement("afterend",hint);}hint.textContent="";$("vendorModal").classList.remove("hidden");}
function saveVendor(){
 const name=$("vendorName").value.trim();if(!name){alert("Enter vendor name.");return}
 const gstin=$("vendorGstin").value.trim().toUpperCase(),pan=$("vendorPan").value.trim().toUpperCase();
 if(gstin&&!/^[0-9A-Z]{15}$/.test(gstin)){alert("GSTIN should contain 15 letters/numbers.");return}if(pan&&!/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(pan)){alert("PAN format is invalid.");return}
 const data={name,phone:$("vendorPhone").value.trim(),gstin,fssai:$("vendorFssai").value.trim(),pan,email:$("vendorEmail").value.trim(),state:$("vendorState").value.trim(),stateCode:$("vendorStateCode").value.trim(),address:$("vendorAddress").value.trim(),shopKey:String(__sbActiveFirm().shopKey||__sbActiveFirm().id).toLowerCase(),shopName:__sbActiveFirm().name};
 const duplicate=state.vendors.find(v=>v.id!==editingVendorId&&((gstin&&String(v.gstin||'').toUpperCase()===gstin)||(v.name||'').trim().toLowerCase()===name.toLowerCase()));if(duplicate){alert("A vendor with the same name or GSTIN already exists. Select that vendor instead of creating a duplicate.");if(vendorModalFromOcr){renderVendorsSelects();$("purchaseVendor").value=duplicate.id;populatePurchaseVendorFields();$("vendorModal").classList.add("hidden");vendorModalFromOcr=false;pendingOcrVendorMeta=null;}return}
 let savedVendorId=editingVendorId;
 if(editingVendorId){const v=vendorById(editingVendorId);if(v)Object.assign(v,data);}else{const created={id:purchaseId("VEN"),...data,openingBalance:0};state.vendors.unshift(created);savedVendorId=created.id;}
 save();$("vendorModal").classList.add("hidden");editingVendorId=null;renderPurchasing();
 if(vendorModalFromOcr&&savedVendorId){renderVendorsSelects();$("purchaseVendor").value=savedVendorId;populatePurchaseVendorFields();vendorModalFromOcr=false;pendingOcrVendorMeta=null;save();}
}

function savePayment(){
 const vendorId=$("paymentVendor").value,amount=Number($("paymentAmount").value||0);
 if(!vendorId||amount<=0){alert("Select vendor and enter amount.");return}
 state.vendorPayments.unshift({id:purchaseId("PAY"),vendorId,shopKey:String(__sbActiveFirm().shopKey||__sbActiveFirm().id).toLowerCase(),shopName:__sbActiveFirm().name,date:$("paymentDate").value||today(),amount,mode:$("vendorPaymentMode").value,note:$("paymentNote").value.trim()});
 save();$("paymentModal").classList.add("hidden");$("paymentAmount").value="";$("paymentNote").value="";renderPurchasing();
}
$("purchaseImportBtn").onclick=()=>{if(window.Android?.pickPurchaseDocument)Android.pickPurchaseDocument();else alert("Vendor bill upload is available in the Android app.");};
$("purchaseCameraBtn").onclick=()=>{if(window.Android?.capturePurchaseBill)Android.capturePurchaseBill();else alert("Vendor bill camera capture is available in the Android app.");};
$("purchaseQuickListBtn").onclick=addPurchaseQuickList;initPurchaseQuickListSearch();$("purchaseAddItemBtn").onclick=addBlankPurchaseItem;
$("purchaseQuickListClearBtn").onclick=()=>{if($("purchaseItemsText"))$("purchaseItemsText").value="";purchaseDraftItems=[];$("purchaseQuickListStatus").textContent="";$("purchaseParsedItems").innerHTML="";updatePurchaseDraftSummary();};
$("savePurchaseBtn").onclick=savePurchase;
updatePurchaseTaxFieldVisibility();
$("purchaseTaxableBill")?.addEventListener("change",()=>{if(!isPurchaseTaxableBill()){$("purchaseTaxInput").value="0";$("purchaseTcsInput").value="0";}updatePurchaseTaxFieldVisibility();renderPurchaseDraftItems();updatePurchaseDraftSummary();});
$("purchaseInvoiceType")?.addEventListener("change",()=>{if($("purchaseInvoiceType").value==="bill_of_supply"&&$("purchaseTaxableBill")){$("purchaseTaxableBill").checked=false;$("purchaseTaxInput").value="0";$("purchaseTcsInput").value="0";$("purchaseSubtotalInput").value="";}updatePurchaseTaxFieldVisibility();renderPurchaseDraftItems();updatePurchaseDraftSummary();});
$("purchaseAmountsIncludeTax")?.addEventListener("change",()=>{purchaseDraftItems.forEach(x=>{x.invoiceTaxableAmount=null;x.invoiceLineTotal=null;});renderPurchaseDraftItems();updatePurchaseDraftSummary();});
$("purchaseTotalInput").oninput=()=>{updatePurchasePending();updatePurchaseDraftSummary();};$("purchasePaidInput").oninput=()=>{updatePurchasePending();updatePurchaseDraftSummary();};$("purchasePaymentMode")?.addEventListener("change",()=>{updatePurchasePending();updatePurchaseDraftSummary();});
function startNewPurchaseBill(){window.purchaseSavedInEditor=false;editingPurchaseId=null;state.purchaseAttachment=null;state.purchaseImportRows=[];state.purchaseImportMeta=null;purchaseDraftItems=[];resetPurchaseEditor();["purchaseInvoice","purchasePoNumber","purchaseSupplierRef","purchasePaymentTerms","purchaseSubtotalInput","purchaseTaxInput","purchaseChargesInput","purchaseDiscountInput","purchaseTcsInput","purchaseRoundOffInput","purchaseTotalInput","purchasePaidInput","purchaseNotes","purchaseItemsText","purchaseSupplierPan","purchaseSupplierState","purchaseSupplierStateCode","purchasePaymentRef","purchaseChequeNo","purchaseChequeDate"].forEach(id=>{const el=$(id);if(el)el.value="";});$("purchaseDate").value=today();$("purchaseDeliveryDate").value="";$("purchaseInvoiceType").value="tax_invoice";$("purchaseAmountsIncludeTax").value="inclusive";$("purchaseTaxableBill").checked=false;$("purchasePaymentMode").value="Credit";$("purchasePaidInput").value="0";$("purchasePendingInput").value="0.00";$("savePurchaseBtn").textContent="Save Purchase";$("savePurchaseBtn").classList.remove("secondary");$("savePurchaseBtn").classList.add("primary");$("purchaseImportStatus").textContent="Ready for a new purchase.";updatePurchaseTaxFieldVisibility();updatePurchasePending();updatePurchaseDraftSummary();renderPurchaseDraftItems();showVendorSection("purchaseEntryCard");}
$("newPurchaseTopBtn")?.addEventListener("click",startNewPurchaseBill);["purchaseChargesInput","purchaseDiscountInput","purchaseTcsInput","purchaseRoundOffInput","purchaseSubtotalInput","purchaseTaxInput"].forEach(id=>{const el=$(id);if(el)el.addEventListener("input",updatePurchaseDraftSummary);});
$("addVendorBtn").onclick=()=>openVendorModal();$("purchaseVendor").addEventListener("change",populatePurchaseVendorFields);$("vendorCancel").onclick=()=>{$("vendorModal").classList.add("hidden");if(vendorModalFromOcr){vendorModalFromOcr=false;pendingOcrVendorMeta=null;}};$("vendorSave").onclick=saveVendor;
$("addPaymentBtn").onclick=()=>{$("paymentDate").value=today();$("paymentModal").classList.remove("hidden")};$("paymentCancel").onclick=()=>$("paymentModal").classList.add("hidden");$("paymentSave").onclick=savePayment;
$("vendorRefreshBtn").onclick=renderPurchasing;let purchaseHistorySearchTimer=null;
$("purchaseSearch").oninput=()=>{purchaseHistoryPage=1;clearTimeout(purchaseHistorySearchTimer);purchaseHistorySearchTimer=setTimeout(renderPurchasing,140);};

// Vendor Management navigation behaves as real sections instead of a long page of stacked lists.
function showVendorSection(sectionId){
 const entry=$("purchaseEntryCard"), panels=[...document.querySelectorAll("[data-vendor-panel]")];
 if(entry)entry.classList.toggle("hidden",sectionId!=="purchaseEntryCard");
 panels.forEach(panel=>panel.classList.toggle("hidden",panel.id!==sectionId));
 document.querySelectorAll("[data-vendor-section]").forEach(btn=>btn.classList.toggle("active",btn.dataset.vendorSection===sectionId));
 if(sectionId==="vendorAccountsCard")renderPurchasing();
 if(sectionId==="vendorPaymentsCard")renderPurchasing();
 if(sectionId==="purchaseHistoryCard")renderPurchasing();
 window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll("[data-vendor-section]").forEach(btn=>{btn.type="button";btn.addEventListener("click",event=>{event.preventDefault();const target=btn.dataset.vendorSection;if($(target)||target==="purchaseEntryCard")showVendorSection(target);});});
$("newPurchaseBillBtn")?.addEventListener("click",()=>{
 resetPurchaseEditor();purchaseDraftItems=[];["purchaseInvoice","purchasePoNumber","purchaseSupplierRef","purchasePaymentTerms","purchaseSubtotalInput","purchaseTaxInput","purchaseChargesInput","purchaseDiscountInput","purchaseTcsInput","purchaseRoundOffInput","purchaseTotalInput","purchasePaidInput","purchaseNotes","purchaseItemsText","purchaseSupplierPan","purchaseSupplierState","purchaseSupplierStateCode"].forEach(id=>{const el=$(id);if(el)el.value="";});
 $("purchaseDate").value=today();$("purchaseDeliveryDate").value="";$("purchaseInvoiceType").value="tax_invoice";$("purchaseAmountsIncludeTax").value="inclusive";$("purchaseTaxableBill").checked=false;updatePurchaseTaxFieldVisibility();$("purchaseReverseCharge").value="false";$("purchasePaymentMode").value="Credit";$("purchaseQuickListStatus").textContent="";$("purchaseParsedItems").innerHTML="";$("purchaseCalculationSummary").innerHTML="";$("purchaseAttachmentBox").innerHTML="";$("purchaseTotalInput").value="";$("purchasePaidInput").value="0";$("purchasePendingInput").value="0";showVendorSection("purchaseEntryCard");
});
$("purchaseDate").value=today();
let productPage=1, productPageSize=20, productQuery="";
function renderProducts(){
 const list=$("productList"); if(!list)return;
 const q=String(productQuery||"").trim().toLowerCase();
 const all=state.products.filter(p=>{const name=String(p.name??p.productName??p.itemName??"");const unit=String(p.unit??p.unitName??p.uom??"");const rate=String(p.rate??p.price??p.sellingPrice??"");const hay=[name,unit,rate,p.itemCode||p.code||"",p.barcode||p.ean||p.upc||""].join(" ").toLowerCase();return !q||hay.includes(q);});
 const pages=Math.max(1,Math.ceil(all.length/productPageSize)); productPage=Math.min(Math.max(1,productPage),pages);
 const slice=all.slice((productPage-1)*productPageSize,productPage*productPageSize);
 list.innerHTML="";
 if(!all.length){list.innerHTML='<div class="muted">No products found.</div>';}
 slice.forEach(p=>{
   const i=state.products.indexOf(p); const r=document.createElement("div"); r.className="product-row";
   r.innerHTML=`<div><div class="product-name">${esc(p.name)}</div><div class="muted">${p.itemCode?`Code: ${esc(p.itemCode)} • `:""}${money(p.rate)} / ${esc(p.unit||"piece")} ${state.settings.taxationEnabled?`• GST ${Number(p.taxRate||0)}%`:""}${p.hsn?` • HSN ${esc(p.hsn)}`:""}${p.barcode?` • Barcode ${esc(p.barcode)}`:""}</div></div><div><button type="button" class="secondary edit">Edit</button> <button type="button" class="danger del">Delete</button></div>`;
   r.querySelector(".edit").onclick=()=>openProduct(i);
   r.querySelector(".del").onclick=()=>showConfirm("Delete "+p.name+" from the product master?",()=>{state.products.splice(i,1);save();renderProducts();renderDatalist();renderOcrVocabulary();},"Delete Product");
   list.appendChild(r);
 });
 const pager=$("productPagination"); if(pager){pager.innerHTML=`<button type="button" class="secondary" ${productPage<=1?"disabled":""}>‹ Previous</button><span>Page ${productPage} of ${pages} • ${all.length} products</span><button type="button" class="secondary" ${productPage>=pages?"disabled":""}>Next ›</button>`;const bs=pager.querySelectorAll("button");bs[0].onclick=()=>{if(productPage>1){productPage--;renderProducts()}};bs[1].onclick=()=>{if(productPage<pages){productPage++;renderProducts()}};}
}
function openProduct(i){editingProduct=i;$("modalTitle").textContent=i<0?"Add Product":"Edit Product";$("modalName").value=i<0?"":state.products[i].name;$("modalTrackInventory").checked=i>=0&&state.products[i].trackInventory===true;$("modalMinStock").value=i<0?"0":Number(state.products[i].minStock||0);$("modalPackSize").value=i<0?"1":Number(state.products[i].packSize||1);$("modalItemCode").value=i<0?"":(state.products[i].itemCode||state.products[i].code||"");$("modalRate").value=i<0?"":state.products[i].rate;$("modalUnit").value=i<0?"piece":(state.products[i].unit||"piece");$("modalHsn").value=i<0?"":(state.products[i].hsn||"");$("modalBarcode").value=i<0?"":(state.products[i].barcode||state.products[i].ean||state.products[i].upc||"");$("modalTax").value=i<0?"0":String(state.products[i].taxRate??0);$("modal").classList.remove("hidden");setTimeout(()=>$("modalName")?.focus(),50);}
$("addProductBtn")?.addEventListener("click",()=>openProduct(-1));
function handleProductPageSearch(e){productQuery=String(e.target.value||"");productPage=1;renderProducts();}
$("productPageSearch")?.addEventListener("input",handleProductPageSearch);
$("productPageSearch")?.addEventListener("keyup",handleProductPageSearch);
$("productPageSearch")?.addEventListener("change",handleProductPageSearch);
$("modalCancel").onclick=()=>$("modal").classList.add("hidden");$("modalSave").onclick=()=>{const name=$("modalName").value.trim(),rate=+$("modalRate").value,itemCode=$("modalItemCode").value.trim();if(!name||!Number.isFinite(rate)||rate<0){showNotice("Enter a product name and a valid rate.","Product");return}const unit=normalizeUnitName($("modalUnit").value||"piece");const hsn=$("modalHsn").value.trim();const taxRate=Math.max(0,Number($("modalTax").value)||0);const barcode=$("modalBarcode").value.trim();const duplicate=state.products.find((p,i)=>i!==editingProduct&&String(p.name||"").trim().toLowerCase()===name.toLowerCase());const duplicateCode=itemCode&&state.products.find((p,i)=>i!==editingProduct&&String(p.itemCode||p.code||"").trim().toLowerCase()===itemCode.toLowerCase());if(duplicateCode){showNotice("This item code is already assigned to another product.","Duplicate Item Code");return}if(duplicate){showNotice("A product with this name already exists.","Product");return}if(editingProduct<0)state.products.unshift({name,itemCode,rate,unit,hsn,barcode,taxRate,trackInventory:$("modalTrackInventory").checked,minStock:Math.max(0,Number($("modalMinStock").value)||0),packSize:Math.max(0.000001,Number($("modalPackSize").value)||1),stockQty:0,averageCost:0});else state.products[editingProduct]={...state.products[editingProduct],name,itemCode,rate,unit,hsn,barcode,taxRate,trackInventory:$("modalTrackInventory").checked,minStock:Math.max(0,Number($("modalMinStock").value)||0),packSize:Math.max(0.000001,Number($("modalPackSize").value)||1)};save();$("modal").classList.add("hidden");renderProducts();renderDatalist();renderOcrVocabulary();};
function renderDatalist(){let dl=document.getElementById("productNames");if(dl)dl.remove();dl=document.createElement("datalist");dl.id="productNames";state.products.forEach(p=>{let o=document.createElement("option");o.value=p.name;dl.appendChild(o)});document.body.appendChild(dl)}
renderDatalist();renderCustomerDatalist();renderCustomUnits();refreshUnitControls();renderOcrVocabulary();document.body.classList.toggle("taxation-on",!!state.settings.taxationEnabled);document.querySelectorAll(".tax-field").forEach(x=>x.classList.toggle("hidden",!state.settings.taxationEnabled));if($("placeOfSupply"))$("placeOfSupply").value=state.settings.businessState||"";
let salesHistoryPhoneMigrationDone=false;

function deleteBillEligibility(bill){
 const items=Array.isArray(bill?.items)?bill.items:[];
 const tracked=items.filter(it=>{const p=inventoryProductByName(it.name);return p?.trackInventory===true;});
 if(state.settings.inventoryManagement===true&&tracked.length){
  return {allowed:false,reason:"Inventory management is enabled and this bill contains inventory-tracked item(s): "+tracked.map(x=>String(x.name||"Item")).join(", ")+". Delete is blocked to protect stock balances and inventory history."};
 }
 return {allowed:true,tracked};
}

function removeDeletedBillInventorySource(bill){
 const no=String(bill?.billNo||"");if(!no)return;
 if(nativeBridgePresent&&window.Android?.replaceInventorySource){
  const raw=Android.replaceInventorySource("sale",no,inventoryShopKey(),"[]");
  const summary=JSON.parse(raw||"[]");
  if(!Array.isArray(summary))throw new Error(summary.error||"Inventory movement cleanup was not confirmed");
  summary.forEach(x=>{const p=inventoryProductByName(x.productName);if(p){p.stockQty=Number(x.stockQty||0);if(Number(x.averageCost)>0)p.averageCost=Number(x.averageCost);}});
 }else{
  inventoryReverseSource("sale",no);
  rebuildInventoryBalances((bill.items||[]).map(x=>x.name));
 }
}
function deleteBillFromHistory(bill){
 if(!bill||!bill.billNo){showNotice("The selected bill could not be identified. Refresh Bill History and try again.","Bill not deleted");return;}
 const gate=deleteBillEligibility(bill);
 if(!gate.allowed){showNotice(gate.reason,"Bill not deleted");return;}
 const trackedNames=(gate.tracked||[]).map(x=>String(x.name||"Item"));
 const warning=`You are about to permanently delete bill ${bill.billNo} for ${bill.customer||"Walk-in Customer"} (Total: ${money(bill.total)}).\n\nThis cannot be undone. The bill will be removed from Bill History and customer sales records.${trackedNames.length?"\n\nInventory is currently disabled. The bill contains tracked items; linked inventory movement entries will be removed so they do not affect stock if inventory is enabled again.":""}\n\nContinue?`;
 if(!window.confirm(warning))return;
 try{
  if(nativeBridgePresent&&window.Android?.deleteTransactionRecord){
   const shop=moduleShopKey(),no=String(bill.billNo);
   const a=Android.deleteTransactionRecord("pksBills",shop+"|"+no)===true;
   if(!a){showNotice("The local database did not confirm deletion. The bill may already be deleted, or its record key could not be matched. Refresh Bill History and retry; no success was reported.","Bill not deleted");return;}
   if(trackedNames.length&&state.settings.inventoryManagement!==true){
    try{removeDeletedBillInventorySource(bill);}
    catch(stockError){showNotice("The bill record was deleted, but its stock reversal could not be confirmed. Open Inventory and verify stock before continuing. Details: "+String(stockError.message||stockError),"Inventory warning");}
   }
  }else{
   const index=state.bills.findIndex(x=>String(x.billNo)===String(bill.billNo));
   if(index<0){showNotice("The bill was not found in the local bill list. Refresh Bill History and try again.","Bill not deleted");return;}
   state.bills.splice(index,1);
   if(trackedNames.length&&state.settings.inventoryManagement!==true){
    try{removeDeletedBillInventorySource(bill);}catch(e){console.warn("Stock reversal warning",e);}
   }
   save();
  }
  salesHistoryPage=1;__customerBillSummaryCache=null;renderHistory();renderCustomers();
  showNotice("Bill "+bill.billNo+" was deleted from the local database.","Bill deleted");
 }catch(e){console.error("Bill deletion failed",e);showNotice("Bill could not be deleted because the local database operation failed: "+String(e.message||e),"Bill not deleted");}
}

function renderHistory(){
 const q=String($("billSearch")?.value||"").trim().toLowerCase(),from=String($("billHistoryFrom")?.value||""),to=String($("billHistoryTo")?.value||""),list=$("historyList");
 list.innerHTML="";
 const offset=(salesHistoryPage-1)*TRANSACTION_PAGE_SIZE;
 const nativePage=readNativeSalesPage(offset,TRANSACTION_PAGE_SIZE,q,from,to);
 let bills,total,pageRows;
 if(nativePage){
   bills=nativePage.records||[];total=Number(nativePage.total||0);pageRows=bills;
 }else{
   const all=state.bills;
   if(!salesHistoryPhoneMigrationDone){
     const __sbPhoneMigrationStart=__sbTraceClock();
     all.forEach(b=>{const n=normalizePhone(b.customerPhone);if(/^\d{10}$/.test(n))b.customerPhone=n;});
     salesHistoryPhoneMigrationDone=true;
     __sbTraceProfile("on-demand sales phone normalization",__sbPhoneMigrationStart,{bills:all.length});
   }
   bills=all.filter(b=>{
     if(from&&String(b.date||"")<from)return false;if(to&&String(b.date||"")>to)return false;
     if(!q)return true;
     return [b.billNo,b.customer,b.customerPhone,b.date,b.total,b.paymentMode,...(Array.isArray(b.items)?b.items.flatMap(i=>[i.name,i.hsn,i.barcode]):[])].some(v=>String(v??"").toLowerCase().includes(q));
   }).sort((a,b)=>String(b.date||"").localeCompare(String(a.date||"")));
   total=bills.length;pageRows=bills.slice(offset,offset+TRANSACTION_PAGE_SIZE);
 }
 const pages=Math.max(1,Math.ceil(total/TRANSACTION_PAGE_SIZE));
 salesHistoryPage=Math.min(Math.max(1,salesHistoryPage),pages);
 if(!pageRows.length)list.innerHTML='<div class="muted">No bills found.</div>';
 pageRows=pageRows.filter(b=>moduleRecordBelongsToCurrentShop(b));
 pageRows.forEach(b=>{
   const r=document.createElement("div");r.className="history-row bill-history-modern";
   r.innerHTML=`<div class="bill-history-content"><div class="bill-history-number">${esc(b.billNo||"Bill")}</div><div class="bill-history-customer-line"><div class="bill-history-customer">${esc(b.customer||"Walk-in Customer")}</div><div class="bill-history-total">${money(b.total)}</div></div><div class="bill-history-meta">${String(b.date||"").split("-").reverse().join("/")} <span aria-hidden="true">·</span> ${(b.items||[]).length} items</div></div><div class="row-actions bill-history-actions"><button class="secondary view-bill" type="button">View</button><button class="secondary edit-bill" type="button">Edit</button><button class="secondary delete-bill" type="button">Delete</button><button class="secondary bill-pdf-direct" type="button" title="Open bill PDF" aria-label="Open bill PDF">📄</button></div>`;
   r.querySelector(".bill-pdf-direct").onclick=()=>{const payload=JSON.stringify({...b,settings:{...state.settings}});if(window.Android?.openBillPdf)window.Android.openBillPdf(payload);else{renderBill(b);showPage("preview");showNotice("Direct PDF opening is available in the SiddhiBill Android app.","Bill PDF");}};
   r.querySelector(".view-bill").onclick=()=>{if(!moduleRecordBelongsToCurrentShop(b)){showNotice("This bill belongs to another firm and cannot be opened here.","Firm data protection");return;}renderBill(b);showPage("preview")};
   r.querySelector(".edit-bill").onclick=()=>{if(!moduleRecordBelongsToCurrentShop(b)){showNotice("This bill belongs to another firm and cannot be edited here.","Firm data protection");return;}loadBillForEdit(b);};
   r.querySelector(".delete-bill").onclick=()=>{if(!moduleRecordBelongsToCurrentShop(b)){showNotice("This bill belongs to another firm and cannot be deleted here.","Firm data protection");return;}deleteBillFromHistory(b);};
   list.appendChild(r);
 });
 salesHistoryPage=renderTransactionPager(list,"historyPagination",total,salesHistoryPage,next=>{salesHistoryPage=next;renderHistory();});
}

let salesHistorySearchTimer=null;
$("billSearch").oninput=()=>{salesHistoryPage=1;clearTimeout(salesHistorySearchTimer);salesHistorySearchTimer=setTimeout(renderHistory,140);};
$("billHistoryFrom")?.addEventListener("change",()=>{salesHistoryPage=1;renderHistory()});$("billHistoryTo")?.addEventListener("change",()=>{salesHistoryPage=1;renderHistory()});
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;$("installBtn").classList.remove("hidden")});$("installBtn").onclick=async()=>{if(deferredInstall){deferredInstall.prompt();deferredInstall=null;$("installBtn").classList.add("hidden")}};
// Android WebView uses the APK-bundled assets directly. Remove any stale service-worker
// registrations/caches left by older releases so updated button handlers cannot be shadowed.
if("serviceWorker" in navigator){
  try{navigator.serviceWorker.getRegistrations().then(rs=>Promise.all(rs.map(r=>r.unregister()))).catch(()=>{});
  try{caches.keys().then(keys=>Promise.all(keys.map(k=>caches.delete(k)))).catch(()=>{});}catch(e){}}catch(e){}
  try{caches?.keys?.().then(keys=>keys.forEach(k=>caches.delete(k))).catch(()=>{});}catch(e){}
}

let transactionHistoryPage=1, transactionHistoryPageSize=20, transactionHistoryKind="customer", transactionHistoryKey="";
function customerTransactions(name){
 const rows=[],linkedPaymentsByBill=new Map();
 (state.customerPayments||[]).forEach(p=>{const source=String(p.sourceBillNo||"");if(!source||String(p.customer||"").trim().toLowerCase()!==String(name||"").trim().toLowerCase())return;linkedPaymentsByBill.set(source,(linkedPaymentsByBill.get(source)||0)+Number(p.amount||0));});
 if(nativeBridgePresent&&window.Android?.loadCustomerBills){try{const raw=Android.loadCustomerBills(String(name||""),"","",moduleShopKey());const list=JSON.parse(raw||"[]");if(Array.isArray(list)){list.forEach(b=>{const paid=Math.max(Number(b.partialPaymentAmount||0),Number(linkedPaymentsByBill.get(String(b.billNo||""))||0));rows.push({date:b.date||"",transactionDateTime:b.transactionDateTime||b.dateTime||b.createdAt||b.timestamp||b.time||b.date||"",type:"Sale",label:(b.paymentMode||"Cash")==="Credit"?"Credit":"Bill",reference:b.billNo||"",debit:(b.paymentMode||"Cash")==="Credit"?Math.max(0,Number(b.total||0)-paid):0,credit:0,amount:Number(b.total||0),paymentAmount:paid,balanceDue:Math.max(0,Number(b.total||0)-paid),balance:Math.max(0,Number(b.total||0)-paid)});});} }catch(e){console.warn("Customer transaction query failed",e);}}
 const stamp=r=>{const raw=String(r.transactionDateTime||r.dateTime||r.createdAt||r.timestamp||r.time||r.date||"");const parsed=Date.parse(raw);return Number.isFinite(parsed)?parsed:0;};
 if(!nativeBridgePresent){
 state.bills.filter(b=>b.customer===name).forEach(b=>{const paid=Math.max(Number(b.partialPaymentAmount||0),Number(linkedPaymentsByBill.get(String(b.billNo||""))||0));rows.push({date:b.date||"",transactionDateTime:b.transactionDateTime||b.dateTime||b.createdAt||b.timestamp||b.time||b.date||"",type:"Sale",label:(b.paymentMode||"Cash")==="Credit"?"Credit":"Bill",reference:b.billNo||"",debit:(b.paymentMode||"Cash")==="Credit"?Math.max(0,Number(b.total||0)-paid):0,credit:0,amount:Number(b.total||0),paymentAmount:paid,balanceDue:Math.max(0,Number(b.total||0)-paid),balance:Math.max(0,Number(b.total||0)-paid)});});}
 state.customerPayments.filter(p=>String(p.customer||"").trim().toLowerCase()===String(name||"").trim().toLowerCase()&&!p.sourceBillNo).forEach(p=>rows.push({date:p.date||"",transactionDateTime:p.transactionDateTime||p.dateTime||p.createdAt||p.timestamp||p.time||p.date||"",type:"Payment",reference:p.note||p.id||"",paymentId:p.id,followUpDate:p.followUpDate||"",mode:p.mode||p.paymentMode||"",transactionNo:p.transactionNo||p.utr||"",chequeNo:p.chequeNo||"",chequeDate:p.chequeDate||"",debit:0,credit:Number(p.amount||0),amount:Number(p.amount||0)}));
 // Build running balances in true chronological order, using time/timestamp where stored.
 const chronological=rows.slice().sort((a,b)=>stamp(a)-stamp(b)||String(a.date).localeCompare(String(b.date))||String(a.reference).localeCompare(String(b.reference)));
 let balance=Number(state.customers.find(c=>c.name===name)?.openingBalance||0);
 chronological.forEach(r=>{r.previousBalance=balance;balance+=Number(r.debit||0)-Number(r.credit||0);r.balance=balance;});
 return chronological.slice().sort((a,b)=>stamp(b)-stamp(a)||String(b.date).localeCompare(String(a.date))||String(b.reference).localeCompare(String(a.reference)));
}
function customerRecentTransactions(name){
 const key=String(name||"").trim().toLowerCase();if(!key)return [];
 let bills=[];try{if(nativeBridgePresent&&window.Android?.loadCustomerRecentBills){bills=JSON.parse(Android.loadCustomerRecentBills(String(name||""),moduleShopKey(),5)||"[]");}else bills=(state.bills||[]).filter(b=>String(b.customer||"").trim().toLowerCase()===key).sort((a,b)=>String(b.date||"").localeCompare(String(a.date||""))).slice(0,5);}catch(e){console.warn("Recent customer bills unavailable",e);}
 const linked=new Map();(state.customerPayments||[]).forEach(p=>{if(String(p.customer||"").trim().toLowerCase()!==key||!p.sourceBillNo)return;const id=String(p.sourceBillNo);linked.set(id,(linked.get(id)||0)+Number(p.amount||0));});
 const rows=bills.map(b=>{const paid=Math.max(Number(b.partialPaymentAmount||0),Number(linked.get(String(b.billNo||""))||0));return {date:b.date||"",type:"Sale",label:(b.paymentMode||"Cash")==="Credit"?"Credit":"Bill",reference:b.billNo||"",debit:(b.paymentMode||"Cash")==="Credit"?Math.max(0,Number(b.total||0)-paid):0,credit:0,amount:Number(b.total||0),paymentAmount:paid};});
 (state.customerPayments||[]).filter(p=>String(p.customer||"").trim().toLowerCase()===key&&!p.sourceBillNo).forEach(p=>rows.push({date:p.date||"",type:"Payment",reference:p.note||p.id||"",paymentId:p.id,mode:p.mode||p.paymentMode||"",debit:0,credit:Number(p.amount||0),amount:Number(p.amount||0)}));
 rows.sort((a,b)=>String(b.date||"").localeCompare(String(a.date||""))||String(b.reference||"").localeCompare(String(a.reference||"")));const recent=rows.slice(0,5);
 let balance=Number(customerDue(name)||0)-recent.reduce((sum,r)=>sum+Number(r.debit||0)-Number(r.credit||0),0);
 recent.slice().sort((a,b)=>String(a.date||"").localeCompare(String(b.date||""))||String(a.reference||"").localeCompare(String(b.reference||""))).forEach(r=>{r.previousBalance=balance;balance+=Number(r.debit||0)-Number(r.credit||0);r.balance=balance;});
 return recent.sort((a,b)=>String(b.date||"").localeCompare(String(a.date||""))||String(b.reference||"").localeCompare(String(a.reference||"")));
}
let transactionHistoryVendorPurchases=null;
function vendorTransactions(id){
 const rows=[],vendor=vendorById(id),vendorName=String(vendor?.name||"").trim().toLowerCase();
 const purchaseRows=Array.isArray(transactionHistoryVendorPurchases)?transactionHistoryVendorPurchases:(window.__siddhiLazyState?.purchases?.()?state.purchases:[]).filter(p=>String(p.vendorId??p.supplierId??p.partyId)===String(id)||String(p.vendorName||p.supplierSnapshot?.name||"").trim().toLowerCase()===vendorName);
 purchaseRows.forEach(p=>{const match=String(p.vendorId??p.supplierId??p.partyId)===String(id)||String(p.vendorName||p.supplierSnapshot?.name||"").trim().toLowerCase()===vendorName;if(!match)return;const total=Number(p.total??p.grandTotal??0),paid=Number(p.paid||0);rows.push({date:p.date||p.invoiceDate||"",type:"Purchase",reference:p.invoiceNo||p.billNo||"",purchaseId:p.id||"",debit:Math.max(0,total-paid),credit:0,amount:total});});
 (Array.isArray(state.vendorPayments)?state.vendorPayments:[]).filter(p=>String(p.vendorId??p.supplierId??p.partyId)===String(id)||String(p.vendorName||"").trim().toLowerCase()===vendorName).forEach(p=>rows.push({date:p.date||"",type:"Payment made",reference:p.note||p.reference||p.id||"",debit:0,credit:Number(p.amount||0),amount:Number(p.amount||0),mode:p.mode||p.paymentMode||"",transactionNo:p.transactionNo||p.referenceNo||"",chequeNo:p.chequeNo||"",chequeDate:p.chequeDate||""}));
 rows.sort((a,b)=>String(b.date).localeCompare(String(a.date)));
 let balance=Number(vendor?.openingBalance||0);rows.slice().sort((a,b)=>String(a.date).localeCompare(String(b.date))).forEach(r=>{balance+=r.debit-r.credit;r.balance=balance;});return rows;
}
function openTransactionHistory(kind,key){transactionHistoryKind=kind;transactionHistoryKey=key;transactionHistoryPage=1;transactionHistoryVendorPurchases=null;if(kind==="vendor"){const vendor=vendorById(key);try{const raw=window.Android?.loadVendorPurchases?.(String(key),String(vendor?.name||""),moduleShopKey());if(raw){const data=JSON.parse(raw);if(Array.isArray(data))transactionHistoryVendorPurchases=data;}}catch(e){console.warn("Vendor transaction page query failed",e);}}const title=kind==="customer"?key:(vendorById(key)?.name||"Vendor");$("transactionHistoryTitle").textContent=title+" — Transaction History";$("transactionHistoryFrom").value="";$("transactionHistoryTo").value="";renderTransactionHistory();$("transactionHistoryModal").classList.remove("hidden");}
function renderTransactionHistory(){const all=transactionHistoryKind==="customer"?customerTransactions(transactionHistoryKey):vendorTransactions(transactionHistoryKey);const from=$("transactionHistoryFrom").value,to=$("transactionHistoryTo").value;const rows=all.filter(r=>(!from||r.date>=from)&&(!to||r.date<=to));const pages=Math.max(1,Math.ceil(rows.length/transactionHistoryPageSize));transactionHistoryPage=Math.min(transactionHistoryPage,pages);const list=$("transactionHistoryList");list.innerHTML=rows.length?rows.slice((transactionHistoryPage-1)*transactionHistoryPageSize,transactionHistoryPage*transactionHistoryPageSize).map(r=>{return `<div class="history-row"><div><b>${esc(r.label||r.type)} • ${esc(r.reference)}</b><div class="muted">${esc(displayDate(r.date))} • Debit ${money(r.debit)} • Credit ${money(r.credit)} • Balance ${money(r.balance)}${r.mode?" • Mode "+esc(r.mode):""}${r.transactionNo?" • Ref "+esc(r.transactionNo):""}${r.chequeNo?" • Cheque "+esc(r.chequeNo)+(r.chequeDate?" ("+esc(displayDate(r.chequeDate))+")":""):""}${r.followUpDate?" • Follow-up "+esc(r.followUpDate):""}</div></div><div class="customer-row-actions">${r.type==="Purchase"?`<button class="secondary view-transaction-purchase" data-purchase-id="${esc(r.purchaseId||"")}" type="button">View Purchase</button>`:r.type==="Sale"?`<button class="secondary view-transaction-bill" data-bill-no="${esc(r.reference)}" type="button">View Bill</button>`:""}${r.paymentId!=null&&!state.customerPayments.find(p=>String(p.id)===String(r.paymentId))?.sourceBillNo?`<button class="secondary edit-customer-payment" data-payment-id="${esc(r.paymentId)}" type="button">Edit Payment</button>`:""}</div></div>`}).join(""):'<div class="muted">No transactions in this date range.</div>';list.querySelectorAll(".view-transaction-purchase").forEach(btn=>btn.addEventListener("click",()=>{const id=String(btn.dataset.purchaseId||"").trim();if(!id)return;const p=resolvePurchaseRecord(id);if(!p){showNotice("The selected purchase record could not be found.","Vendor Transactions");return;}showPurchaseDetail(p);}));
list.querySelectorAll(".view-transaction-bill").forEach(btn=>btn.addEventListener("click",()=>{let b=null;if(nativeBridgePresent&&window.Android?.loadTransactionRecord){try{b=JSON.parse(Android.loadTransactionRecord("pksBills",moduleShopKey()+"|"+String(btn.dataset.billNo||""))||"null");}catch(e){}}else b=state.bills.find(x=>String(x.billNo||"")===String(btn.dataset.billNo||"")&&moduleRecordBelongsToCurrentShop(x));if(!b||!moduleRecordBelongsToCurrentShop(b)){showNotice("This bill does not belong to the currently selected firm. It was not opened.","Firm data protection");return;}$("transactionHistoryModal").classList.add("hidden");window.editingBillNo=null;renderBill(b);showPage("preview");}));
list.querySelectorAll(".edit-customer-payment").forEach(btn=>btn.addEventListener("click",()=>{const p=state.customerPayments.find(x=>String(x.id)===String(btn.dataset.paymentId));if(!p)return;customerPaymentTarget={name:p.customer};editingCustomerPaymentId=p.id;$("customerPaymentLabel").textContent="Edit payment received from "+p.customer;$("customerPaymentAmount").value=Number(p.amount||0);$("customerPaymentDate").value=p.date||today();$("customerPaymentMode").value=p.mode||p.paymentMode||"Cash";$("customerPaymentTransactionNo").value=p.transactionNo||p.utr||p.transactionReference||"";$("customerPaymentChequeNo").value=p.chequeNo||"";$("customerPaymentChequeDate").value=p.chequeDate||p.date||today();$("customerPaymentNote").value=p.note||"";$("customerPaymentFollowUpDate").value=p.followUpDate||"";updateCustomerPaymentModeFields();$("customerPaymentModal").classList.remove("hidden");}));$("transactionHistoryPager").innerHTML=`<button class="secondary" id="txPrev" ${transactionHistoryPage<=1?"disabled":""}>‹ Previous</button><span>Page ${transactionHistoryPage} of ${pages} • ${rows.length} transactions</span><button class="secondary" id="txNext" ${transactionHistoryPage>=pages?"disabled":""}>Next ›</button>`;$("txPrev").onclick=()=>{transactionHistoryPage--;renderTransactionHistory()};$("txNext").onclick=()=>{transactionHistoryPage++;renderTransactionHistory()};}
$("transactionHistoryClose")?.addEventListener("click",()=>$("transactionHistoryModal").classList.add("hidden"));$("transactionHistoryFrom")?.addEventListener("change",()=>{transactionHistoryPage=1;renderTransactionHistory()});$("transactionHistoryTo")?.addEventListener("change",()=>{transactionHistoryPage=1;renderTransactionHistory()});
function paymentReportRows(){
 const {from,to}=reportRange();
 const normDate=v=>{const x=String(v||"").trim();if(!x)return "";const iso=x.match(/^(\d{4})-(\d{2})-(\d{2})/);if(iso)return `${iso[1]}-${iso[2]}-${iso[3]}`;const dmy=x.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);if(dmy)return `${dmy[3]}-${String(dmy[2]).padStart(2,"0")}-${String(dmy[1]).padStart(2,"0")}`;return x.slice(0,10);};
 const inRange=v=>{const d=normDate(v);return !!d&&d>=from&&d<=to;};
 const isCash=v=>String(v||"").trim().toLowerCase()==="cash";
 const shopMatches=v=>!v||moduleRecordShopKey(v)===moduleShopKey();
 const rows=[];
 const seenCustomerSources=new Set(),seenVendorSources=new Set();
 (state.customerPayments||[]).forEach(p=>{
   if(inRange(p.date)){
     rows.push({date:normDate(p.date),party:p.customer||"Customer",type:"Customer receipt",credit:Number(p.amount||0),debit:0,reference:p.note||p.sourceBillNo||p.billNo||p.id||"",paymentId:p.id});
     if(p.sourceBillNo)seenCustomerSources.add(String(p.sourceBillNo));
   }
 });
 (state.vendorPayments||[]).forEach(p=>{
   if(inRange(p.date)){
     rows.push({date:normDate(p.date),party:vendorById(p.vendorId)?.name||p.vendorName||"Vendor",type:"Vendor payment",credit:0,debit:Number(p.amount||0),reference:p.note||p.sourceBillNo||p.invoiceNo||p.id||"",paymentId:p.id});
     const source=String(p.sourceBillNo||p.invoiceNo||p.reference||"");
     if(source)seenVendorSources.add(source);
   }
 });
 // Cash sales and purchases are fetched from date-scoped SQLite queries on Android.
 if(nativeBridgePresent&&window.Android?.loadCashPaymentReportRows){
   try{const nativeRows=JSON.parse(Android.loadCashPaymentReportRows(from,to,moduleShopKey())||"[]");if(Array.isArray(nativeRows))nativeRows.forEach(r=>{if(r.type==="Cash sale"&&seenCustomerSources.has(String(r.reference||"")))return;if(r.type==="Cash purchase"&&seenVendorSources.has(String(r.reference||"")))return;rows.push({...r,date:normDate(r.date),credit:Number(r.credit||0),debit:Number(r.debit||0)});});}
   catch(e){console.warn("Native cash payment report query unavailable",e);}
 }else{
   (state.bills||[]).forEach(b=>{const billNo=String(b.billNo||"");if(!isCash(b.paymentMode)||!inRange(b.date)||!shopMatches(b)||seenCustomerSources.has(billNo))return;const amount=Number(b.total||0);if(amount>0)rows.push({date:normDate(b.date),party:b.customer||"Walk-in Customer",type:"Cash sale",credit:amount,debit:0,reference:billNo,paymentId:"cash-sale-"+billNo});});
   (state.purchases||[]).forEach(p=>{const invoice=String(p.invoiceNo||p.billNo||p.id||"");if(!isCash(p.paymentMode)||!inRange(p.paymentDate||p.date||p.invoiceDate)||!shopMatches(p)||seenVendorSources.has(invoice))return;const amount=Number(p.paid??p.total??p.grandTotal??0);if(amount>0)rows.push({date:normDate(p.paymentDate||p.date||p.invoiceDate),party:p.vendorName||vendorById(p.vendorId)?.name||"Vendor",type:"Cash purchase",credit:0,debit:amount,reference:invoice,paymentId:"cash-purchase-"+invoice});});
 }
 // Cash expenses are cash outflows and belong in the same movement report.
 (state.expenses||[]).forEach(e=>{
   if(!isCash(e.paymentMode)||!inRange(e.date)||!shopMatches(e))return;
   const amount=Number(e.amount||0);
   if(amount<=0)return;
   rows.push({date:normDate(e.date),party:e.payee||e.category||"Expense",type:"Cash expense",credit:0,debit:amount,reference:e.reference||e.description||e.id||"",paymentId:"cash-expense-"+String(e.id||e.date)});
 });
 return rows.sort((a,b)=>String(a.date).localeCompare(String(b.date))||String(a.paymentId||"").localeCompare(String(b.paymentId||"")));
}
function renderPaymentTransactionsReport(){
 const rows=paymentReportRows();
 const credits=rows.reduce((s,r)=>s+r.credit,0),debits=rows.reduce((s,r)=>s+r.debit,0);
 $("paymentReportCredits").textContent=money(credits);$("paymentReportDebits").textContent=money(debits);$("paymentReportNet").textContent=money(credits-debits);
 $("paymentTransactionsList").innerHTML=rows.length?`<div class="payment-report-table"><div class="payment-report-head"><span>Date</span><span>Party / Transaction</span><span>Type</span><span>Debit</span><span>Credit</span></div>${rows.slice(-100).reverse().map(r=>`<div class="payment-report-line"><span>${esc(displayDate(r.date))}</span><span class="payment-report-ref">${esc(r.party)}${r.reference?" • "+esc(r.reference):""}</span><span>${esc(r.type.replace("Customer receipt","Receipt").replace("Vendor payment","Payment"))}</span><span class="amount">${r.debit?money(r.debit):"—"}</span><span class="amount">${r.credit?money(r.credit):"—"}</span></div>`).join("")}</div>`:'<div class="muted">No customer/vendor payments in this date range.</div>';
}
function exportPaymentReport(format){const rows=paymentReportRows();const header=["Date","Party","Type","Reference","Credit","Debit"];const csv=[header,...rows.map(r=>[r.date,r.party,r.type,r.reference,r.credit.toFixed(2),r.debit.toFixed(2)])].map(row=>row.map(v=>'"'+String(v??"").replace(/"/g,'""')+'"').join(",")).join("\r\n");if(format==="excel"){const filename=`SiddhiBill_Payment_Report_${reportRange().from}_${reportRange().to}.csv`;if(window.Android?.saveExportFile){Android.saveExportFile(btoa(unescape(encodeURIComponent(csv))),filename);}else{const blob=new Blob([csv],{type:"text/csv;charset=utf-8;"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}}else{const html=`<!doctype html><html><head><meta charset="utf-8"><title>Payment Transactions Report</title><style>@page{size:A4 portrait;margin:14mm}body{font:12px Arial;padding:24px;color:#222}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccc;padding:7px;text-align:left}th{background:#edf3f8}.num{text-align:right;white-space:nowrap}</style></head><body><h2>Payment Transactions Report</h2><p>${reportRange().from} to ${reportRange().to}</p><table><thead><tr>${header.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(displayDate(r.date))}</td><td>${esc(r.party)}</td><td>${esc(r.type)}</td><td>${esc(r.reference)}</td><td class="num">${money(r.credit)}</td><td class="num">${money(r.debit)}</td></tr>`).join("")}</tbody><tfoot><tr><th colspan="4">Totals</th><th>${money(rows.reduce((s,r)=>s+r.credit,0))}</th><th>${money(rows.reduce((s,r)=>s+r.debit,0))}</th></tr></tfoot></table></body></html>`;if(window.Android?.printHtmlDocument){Android.printHtmlDocument(html,`SiddhiBill_Payment_Transactions_${reportRange().from}_${reportRange().to}`);}else{const win=window.open("","_blank");if(!win){alert("Allow pop-ups to export the PDF report.");return;}win.document.open();win.document.write(html);win.document.close();}}}
$("loadPaymentTransactionsBtn")?.addEventListener("click",()=>{const b=$("loadPaymentTransactionsBtn");if(b){b.disabled=true;b.textContent="Loading transactions…";}try{renderPaymentTransactionsReport();if(b)b.classList.add("hidden");}catch(e){if(b){b.disabled=false;b.textContent="Load Payment Transactions";}showNotice("Could not load payment transactions: "+(e?.message||e),"Payment Transactions");}});
$("paymentReportExcel")?.addEventListener("click",()=>exportPaymentReport("excel"));$("paymentReportPdf")?.addEventListener("click",()=>exportPaymentReport("pdf"));

function reportRange(){
 const from=String($("reportFrom")?.value||today());
 const to=String($("reportTo")?.value||today());
 return from<=to?{from,to}:{from:to,to:from};
}
function serviceDueReportRows(now=new Date()){
 const defs=customBillFieldDefinitions();
 const dateDef=defs.find(d=>d.key==="field3");
 if(!dateDef||!dateDef.label)return [];
 const start=new Date(now.getFullYear(),now.getMonth(),now.getDate());
 const end=new Date(start);end.setDate(end.getDate()+7);
 const startKey=`${start.getFullYear()}-${String(start.getMonth()+1).padStart(2,"0")}-${String(start.getDate()).padStart(2,"0")}`;
 const endKey=`${end.getFullYear()}-${String(end.getMonth()+1).padStart(2,"0")}-${String(end.getDate()).padStart(2,"0")}`;
 let dueBills=[];try{if(typeof nativeBridgePresent!=="undefined"&&nativeBridgePresent&&typeof window!=="undefined"&&window.Android?.loadServiceDueBills)dueBills=JSON.parse(Android.loadServiceDueBills(startKey,endKey,moduleShopKey())||"[]");else dueBills=state.bills;}catch(e){dueBills=state.bills||[];}
 const customers=(typeof nativeBridgePresent!=="undefined"&&nativeBridgePresent&&window.Android?.loadServiceDueBills)?(state.customers||[]):getCustomerRecords();
 return dueBills.filter(b=>{
   const due=String(b?.customFields?.field3||"").slice(0,10);
   return due>=startKey&&due<=endKey&&String(b.customer||"").trim()&&b.customer!=="Walk-in Customer";
 }).map(b=>{
   const c=customers.find(x=>String(x.name||"").trim().toLowerCase()===String(b.customer||"").trim().toLowerCase());
   const phone=normalizePhone(b.customerPhone||c?.phone||c?.mobile||c?.mobileNumber||c?.phoneNumber||"");
   return {billNo:String(b.billNo||""),customer:String(b.customer||""),phone:/^\d{10}$/.test(phone)?phone:"",dueDate:String(b.customFields.field3).slice(0,10),dueLabel:dateDef.label,vehicle:String(b.customFields.field1||""),vehicle2:String(b.customFields.field2||""),date:String(b.date||"")};
 }).sort((a,b)=>a.dueDate.localeCompare(b.dueDate)||a.customer.localeCompare(b.customer));
}
function serviceDueWhatsAppUrl(row){
 const phone=normalizePhone(row?.phone||"");if(!/^\d{10}$/.test(phone))return "";
 const followUpLabel=String(row.dueLabel||state.settings.customBillField3Label||"Follow-up date").trim()||"Follow-up date";
 const message=`Hello ${row.customer}, this is a reminder from ${state.settings.shopName||"our shop"}. ${followUpLabel}: ${row.dueDate}${row.vehicle?`. ${customBillFieldDefinitions().find(d=>d.key==="field1")?.label||"Details"}: ${row.vehicle}`:""}${row.vehicle2?`. ${customBillFieldDefinitions().find(d=>d.key==="field2")?.label||"Details"}: ${row.vehicle2}`:""}. Please contact us if you need any assistance.`;
 return `https://wa.me/91${phone}?text=${encodeURIComponent(message)}`;
}
function renderServiceDueReport(){
 const rows=serviceDueReportRows();
 const count=$("serviceDueCount"),noPhone=$("serviceDueNoPhone"),list=$("serviceDueReportList"),hint=$("serviceDueReportHint");
 const label=String(state.settings.customBillField3Label||"Next Service Due Date").trim()||"Next Service Due Date";
 const reportTitleBase=label.replace(/\s*date\s*$/i,"").trim()||label;
 const reportTitle=$("serviceDueReportTitle");if(reportTitle)reportTitle.textContent=`📅 ${reportTitleBase} (Next 7 Days)`;
 if(hint)hint.textContent=`${label}: today through the next 7 days. WhatsApp opens a pre-filled reminder; review and send it yourself.`;
 if(count)count.textContent=String(rows.length);if(noPhone)noPhone.textContent=String(rows.filter(r=>!r.phone).length);
 if(!list)return;
 list.innerHTML=rows.length?rows.map(r=>`<div class="report-row service-due-row"><div><b>${esc(r.customer)}</b><div class="muted">Due: ${esc(displayDate(r.dueDate))} • Bill: ${esc(r.billNo||"—")}</div>${r.vehicle?`<div class="muted">${esc(customBillFieldDefinitions().find(d=>d.key==="field1")?.label||"Details")}: ${esc(r.vehicle)}</div>`:""}${r.vehicle2?`<div class="muted">${esc(customBillFieldDefinitions().find(d=>d.key==="field2")?.label||"Details")}: ${esc(r.vehicle2)}</div>`:""}<div class="muted">${r.phone?esc(r.phone):"No valid customer mobile number"}</div></div><div>${followUpActions(r,"custom")}</div></div>`).join(""):'<div class="muted">No service due dates found in the next 7 days. Confirm the date field is configured and filled in on bills.</div>';
 bindFollowUpActions(list);list.querySelectorAll(".service-due-whatsapp").forEach(btn=>btn.addEventListener("click",()=>{
   const row=rows.find(r=>r.billNo===btn.dataset.dueBill&&r.customer===btn.dataset.dueCustomer&&r.dueDate===btn.dataset.dueDate&&r.phone===btn.dataset.duePhone);if(!row)return;
   const url=serviceDueWhatsAppUrl(row);if(url)window.open(url,"_blank","noopener,noreferrer");
 }));
}
function applyDateFollowUpReportVisibility(){
 const card=$("serviceDueReportCard");if(card)card.classList.toggle("hidden",state.settings.showDateFollowUpReport===false);
}

function paymentFollowUpRows(){
 const byCustomer=new Map(),norm=n=>String(n||"").trim().toLowerCase();
 let nativeSummary=null;try{if(nativeBridgePresent&&window.Android?.loadCustomerCreditSummary)nativeSummary=JSON.parse(Android.loadCustomerCreditSummary(moduleShopKey())||"[]");}catch(e){console.warn("Customer credit summary unavailable",e);}
 const records=nativeSummary?(state.customers||[]):getCustomerRecords();
 const summaryMap=new Map((Array.isArray(nativeSummary)?nativeSummary:[]).map(x=>[norm(x.customer),x]));
 records.forEach(c=>{const customer=String(c.name||"").trim();if(!customer||customer==="Walk-in Customer")return;const key=norm(customer),summary=summaryMap.get(key);
   const relatedPayments=state.customerPayments.filter(p=>norm(p.customer)===key),latestPaymentReminder=relatedPayments.filter(p=>String(p.followUpDate||"").trim()).sort((a,b)=>String(b.date||"").localeCompare(String(a.date||"")))[0];
   const relatedBills=nativeSummary?[]:state.bills.filter(b=>norm(b.customer)===key);
   const due=nativeSummary?Math.max(0,Number(c.openingBalance||0)+Number(summary?.creditSales||0)-relatedPayments.reduce((a,p)=>a+Number(p.amount||0),0)):Math.max(0,Number(customerDue(customer)||0));
   const date=String(c.paymentFollowUpDate||c.nextPaymentReminderDate||latestPaymentReminder?.followUpDate||relatedBills.find(b=>b.paymentFollowUpDate)?.paymentFollowUpDate||summary?.followUpDate||"").trim();
   const phone=c.phone||c.mobile||c.mobileNumber||relatedPayments.find(p=>p.customerPhone)?.customerPhone||relatedBills.find(b=>b.customerPhone)?.customerPhone||summary?.customerPhone||"";
   if(due>0&&date)byCustomer.set(key,{customer,phone,followUpDate:date,source:"Customer",amount:due,reference:relatedBills[0]?.billNo||summary?.billNo||""});
 });
 return [...byCustomer.values()].map(r=>({...r,phone:normalizePhone(r.phone||findCustomer(r.customer)?.phone||"")})).sort((a,b)=>String(a.followUpDate).localeCompare(String(b.followUpDate))||a.customer.localeCompare(b.customer));
}
function fillFollowUpTemplate(template,row){return String(template||"").replace(/\{(customer|shop|date|amount|bill|phone|fieldLabel|details)\}/gi,(_,k)=>({customer:row.customer||"",shop:state.settings.shopName||"our shop",date:displayDate(row.followUpDate||row.dueDate||""),amount:money(row.amount||0),bill:row.reference||row.billNo||"",phone:row.phone||"",fieldLabel:row.dueLabel||state.settings.customBillField3Label||"Follow-up",details:[row.vehicle,row.vehicle2].filter(Boolean).join(" / ")})[k.toLowerCase()]||"")}
function followUpActions(row,kind="payment"){return `<div class="row-actions followup-actions"><button type="button" class="secondary followup-whatsapp" data-followup="${encodeURIComponent(JSON.stringify(row))}" data-kind="${kind}">WhatsApp</button><button type="button" class="secondary followup-message" data-followup="${encodeURIComponent(JSON.stringify(row))}" data-kind="${kind}">Message</button>${row.phone?`<a class="secondary" href="tel:${esc(row.phone)}">Call</a>`:""}</div>`}
function bindFollowUpActions(root){root.querySelectorAll(".followup-whatsapp,.followup-message").forEach(btn=>btn.addEventListener("click",()=>{let row;try{row=JSON.parse(decodeURIComponent(btn.dataset.followup))}catch(e){return}const custom=btn.dataset.kind==="custom",template=custom?state.settings.customFollowUpTemplate:state.settings.paymentFollowUpTemplate,fallback=custom?"Hello {customer}, reminder from {shop}: {fieldLabel} is {date}. Details: {details}":"Hello {customer}, payment of {amount} is pending with {shop}. Please follow up on {date}. Reference: {bill}",message=fillFollowUpTemplate(template||fallback,row);if(btn.classList.contains("followup-whatsapp")){const phone=normalizePhone(row.phone||"");if(!/^\d{10}$/.test(phone)){showNotice("No valid mobile number is available.","Follow-up");return}window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(message)}`,"_blank","noopener,noreferrer")}else{window.location.href=`sms:${normalizePhone(row.phone||"")}?body=${encodeURIComponent(message)}`}}))}
function renderPaymentFollowUpReport(){const rows=paymentFollowUpRows();const el=$("paymentFollowUpReportList");if(!el)return;const todayDate=String(today()||"");el.innerHTML=rows.length?rows.map(r=>{const overdue=String(r.followUpDate||"")<todayDate;return `<article class="payment-followup-card ${overdue?"is-overdue":"is-upcoming"}"><div class="payment-followup-main"><div class="payment-followup-person"><h4>${esc(r.customer)}</h4>${r.phone?`<div class="payment-followup-phone"><span aria-hidden="true">☎</span> ${esc(r.phone)}</div>`:""}</div><div class="payment-followup-balance"><span>Outstanding</span><strong>${money(r.amount)}</strong></div></div><div class="payment-followup-date-row"><span class="payment-followup-calendar" aria-hidden="true">▦</span><label>Reminder date<input type="date" class="customer-reminder-date" aria-label="Reminder date for ${esc(r.customer)}" data-customer="${esc(r.customer)}" value="${esc(r.followUpDate)}"></label><span class="payment-followup-status ${overdue?"overdue":"upcoming"}">${overdue?"⚠ OVERDUE":"◷ UPCOMING"}</span></div><div class="payment-followup-actions">${followUpActions(r,"payment")}</div></article>`}).join(""):'<div class="payment-followup-empty">No customers with both an outstanding balance and a reminder date.</div>';bindFollowUpActions(el);el.querySelectorAll(".customer-reminder-date").forEach(input=>input.addEventListener("change",()=>saveCustomerReminderDate(input.dataset.customer,input.value)));}

function ledgerPagedTable(headerHtml,rowHtml,footerHtml=""){
 const rows=Array.isArray(rowHtml)?rowHtml:[];
 // Do not split by an arbitrary row count. A single semantic table lets Android
 // WebView's print engine paginate by physical page height and repeat <thead>
 // only when that same table continues onto the next printed page.
 return `<table class="ledger-page-table"><thead><tr>${headerHtml}</tr></thead><tbody>${rows.join("")}</tbody>${footerHtml?`<tfoot>${footerHtml}</tfoot>`:""}</table>`;
}
function bindLedgerSearch(inputId,optionsId,getOptions){
 const input=$(inputId),panel=$(optionsId);if(!input||!panel||input.dataset.ledgerSearchBound==="1")return;
 input.dataset.ledgerSearchBound="1";panel.setAttribute("role","listbox");
 const hide=()=>panel.classList.add("hidden");
 const draw=()=>{
  const q=String(input.value||"").trim().toLowerCase(),all=getOptions(),matches=all.filter(x=>x.label.toLowerCase().includes(q)).slice(0,25);
  panel.innerHTML=matches.map((x,i)=>`<button type="button" class="ledger-search-option" role="option" data-value="${esc(x.value)}" data-index="${i}">${esc(x.label)}</button>`).join("");
  panel.classList.toggle("hidden",matches.length===0);
 };
 input.addEventListener("focus",draw);input.addEventListener("input",draw);
 input.addEventListener("keydown",e=>{
  if(e.key==="Escape"){hide();return;}
  if(e.key==="Enter"&&!panel.classList.contains("hidden")){const first=panel.querySelector(".ledger-search-option");if(first){e.preventDefault();input.value=first.dataset.value;hide();}}
 });
 panel.addEventListener("click",e=>{const option=e.target.closest(".ledger-search-option");if(!option)return;input.value=option.dataset.value;hide();input.dispatchEvent(new Event("change",{bubbles:true}));});
 document.addEventListener("click",e=>{if(!panel.contains(e.target)&&e.target!==input)hide();});
}
function renderCustomerLedgerCustomerOptions(){
 bindLedgerSearch("customerLedgerCustomer","customerLedgerCustomerOptions",()=>[...new Set(getCustomerRecords().map(c=>String(c.name||"").trim()).filter(n=>n&&n!=="Walk-in Customer"))].sort((a,b)=>a.localeCompare(b)).map(n=>({label:n,value:n})));
}
function openCustomerLedgerPdf(){
 const customer=String($("customerLedgerCustomer")?.value||"").trim(),from=String($("customerLedgerFrom")?.value||""),to=String($("customerLedgerTo")?.value||"");const status=$("customerLedgerPdfStatus");
 if(!customer){showNotice("Please select a customer.","Customer Ledger");return;}const selectedCustomer=getCustomerRecords().find(c=>String(c.name||"").trim().toLowerCase()===customer.toLowerCase());if(!selectedCustomer){showNotice("Choose a customer from the search suggestions.","Customer Ledger");return;}if(!from||!to||from>to){showNotice("Please select a valid date range.","Customer Ledger");return;}
 let bills=[];try{if(nativeBridgePresent&&window.Android?.loadCustomerBills){bills=JSON.parse(Android.loadCustomerBills(customer,from,to,moduleShopKey())||"[]");}else bills=(state.bills||[]).filter(b=>String(b.customer||"").trim()===customer&&String(b.date||"")>=from&&String(b.date||"")<=to);}catch(e){console.error("Customer ledger bill query failed",e);showNotice("Customer bills could not be loaded for this ledger. Please retry.","Customer Ledger");return;}bills.sort((a,b)=>String(a.date||"").localeCompare(String(b.date||""))||String(a.billNo||"").localeCompare(String(b.billNo||"")));
 const payments=(state.customerPayments||[]).filter(p=>String(p.customer||"").trim().toLowerCase()===customer.toLowerCase()&&String(p.date||"")>=from&&String(p.date||"")<=to).sort((a,b)=>String(a.date||"").localeCompare(String(b.date||"")));
 const items=bills.flatMap(b=>(b.items||[]).map(it=>({date:b.date||"",billNo:b.billNo||"",name:it.name||it.description||"",comment:String(it.comment||it.itemComment||"").trim(),qty:it.qty??it.quantity??"",unit:it.unit||"",rate:Number(it.rate||it.price||0),amount:Number(it.amount??it.total??(Number(it.qty??it.quantity??0)*Number(it.rate||it.price||0)))})));
 const salesTotal=bills.reduce((s,b)=>s+Number(b.total||0),0),discountTotal=bills.reduce((s,b)=>s+Math.max(0,Number(b.discount||0)),0),paidAtBill=bills.reduce((s,b)=>s+Number(b.partialPaymentAmount||0)+((b.paymentMode||"Cash")==="Credit"?0:Number(b.total||0)),0),received=payments.reduce((s,p)=>s+Number(p.amount||0),0);
 const cust=selectedCustomer||{};const fmt=n=>money(Number(n||0));const totalBalance=customerDue(customer);const rows=bills.map(b=>`<tr><td>${esc(displayDate(b.date||""))}</td><td>${esc(b.billNo||"")}</td><td>${esc(({Credit:"Cr",Cash:"Cash",UPI:"UPI",Cheque:"Chq",Card:"Card",Bank:"Bank"})[b.paymentMode||"Cash"]||b.paymentMode||"Cash")}</td><td class="num">${fmt(b.discount||0)}</td><td class="num">${fmt(b.total)}</td><td class="num">${fmt(b.partialPaymentAmount||((b.paymentMode||"Cash")==="Credit"?0:b.total))}</td><td class="num">${fmt(Math.max(0,Number(b.total||0)-Number(b.partialPaymentAmount||((b.paymentMode||"Cash")==="Credit"?0:b.total))))}</td></tr>`);
 const itemRows=items.map(i=>`<tr><td>${esc(displayDate(i.date))}</td><td>${esc(i.billNo)}</td><td><div>${esc(i.name)}</div>${i.comment?`<div class="item-comment">Comment: ${esc(i.comment)}</div>`:""}</td><td>${esc(String(i.qty))} ${esc(i.unit)}</td><td class="num">${fmt(i.rate)}</td><td class="num">${fmt(i.amount)}</td></tr>`);
 const payRows=payments.map(p=>{const mode=p.mode||p.paymentMode||"—",ref=p.transactionNo||p.utr||p.transactionReference||p.reference||"",cheque=p.chequeNo?`Cheque ${p.chequeNo}${p.chequeDate?" • "+displayDate(p.chequeDate):""}`:"";return `<tr><td>${esc(displayDate(p.date||""))}</td><td>${esc(p.sourceBillNo||p.billNo||ref||"Payment")}</td><td>${esc(mode)}</td><td>${esc([ref,cheque,p.note||""].filter(Boolean).join(" • ")||"Customer payment")}</td><td class="num">${fmt(p.amount)}</td></tr>`});
 
 const html=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Customer Ledger - ${esc(customer)}</title><style>@page{size:A4 portrait;margin:12mm}body{font:11px Arial,sans-serif;color:#222;margin:12px}h1{font-size:19px;margin:0 0 5px}h2{font-size:13px;margin:18px 0 6px}.muted{color:#555}table{border-collapse:collapse;width:100%;font-size:9px;margin-bottom:10px}th,td{border:1px solid #bbb;padding:5px;text-align:left;vertical-align:top}th{background:#edf3f8}.item-comment{margin-top:3px;font-size:8.5px;color:#555;white-space:pre-wrap;overflow-wrap:anywhere}.num{text-align:right;white-space:nowrap}.summary{display:flex;gap:12px;margin:12px 0}.box{border:1px solid #bbb;padding:8px;flex:1}.empty{color:#666;font-style:italic}.ledger-next-page{break-before:page;page-break-before:always}.ledger-page-table{break-inside:auto;page-break-inside:auto}.ledger-page-table thead{display:table-header-group!important}.ledger-page-table tr{break-inside:avoid!important;page-break-inside:avoid!important}.ledger-toolbar{position:fixed;left:0;right:0;bottom:calc(16px + env(safe-area-inset-bottom,0px));z-index:9999;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;width:100%;margin:0;padding:10px max(10px,env(safe-area-inset-right)) 10px max(10px,env(safe-area-inset-left));background:#fff;border-top:1px solid #bbb;box-shadow:0 -2px 8px rgba(0,0,0,.08);box-sizing:border-box}.ledger-toolbar button{display:block;width:100%;min-width:0;box-sizing:border-box;padding:10px 8px;min-height:46px;white-space:normal;overflow-wrap:anywhere;border:1px solid #777;border-radius:8px;background:#f4f4f4;font-weight:600;font-size:14px;color:#111;touch-action:manipulation}.ledger-toolbar button:first-child{grid-column:1/-1}body{padding:0 0 calc(112px + env(safe-area-inset-bottom));margin:0;overflow-x:hidden;box-sizing:border-box}.ledger-content{padding:0 12px 40px;box-sizing:border-box;overflow-wrap:anywhere}.summary{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.box{min-width:0;overflow-wrap:anywhere}table{display:block;max-width:100%;overflow-x:auto;white-space:normal}th.date-col,td:first-child{min-width:76px;white-space:nowrap}th.bill-col{min-width:92px}td:nth-child(2){min-width:92px;overflow-wrap:anywhere}th,td{padding:4px 5px}td.num,th.num{white-space:nowrap} @media(min-width:700px){.ledger-toolbar{position:sticky;left:auto;right:auto;bottom:auto;grid-template-columns:2fr 1fr 1.5fr;padding:10px;box-shadow:none;border-top:0;border-bottom:1px solid #bbb}.ledger-toolbar button:first-child{grid-column:auto}.ledger-content{padding:0 16px 24px}table{display:table;overflow:visible}}@media(max-width:360px){.summary{grid-template-columns:1fr}.ledger-toolbar{grid-template-columns:1fr}.ledger-toolbar button:first-child{grid-column:auto}}@media print{.ledger-toolbar{display:none!important}.ledger-next-page{break-before:page;page-break-before:always}.ledger-page-table{break-inside:auto;page-break-inside:auto}.ledger-page-table thead{display:table-header-group!important}.ledger-page-table tr{break-inside:avoid!important;page-break-inside:avoid!important}body{margin:0;padding:0}.ledger-content{padding:0}table{display:table!important;overflow:visible!important;width:100%;table-layout:auto;white-space:normal}thead{display:table-header-group!important}tfoot{display:table-footer-group!important}tr{break-inside:avoid!important;page-break-inside:avoid!important}th,td{break-inside:avoid!important;page-break-inside:avoid!important}.ledger-content{break-inside:auto}h2{break-after:avoid!important;page-break-after:avoid!important}}</style></head><body><div class="ledger-toolbar"><button type="button" onclick="ledgerPrint()">Print / Download</button><button type="button" onclick="ledgerBack()">Back</button></div><div class="ledger-content"><h1>${esc(state.settings.shopName||"Customer Ledger")}</h1><div class="muted">Customer Ledger Statement</div><p><b>Customer:</b> ${esc(customer)} &nbsp; <b>Mobile:</b> ${esc(cust.phone||cust.mobile||bills.find(b=>b.customerPhone)?.customerPhone||"—")}<br><b>Period:</b> ${esc(displayDate(from))} to ${esc(displayDate(to))}<br><b>Generated:</b> ${esc(displayDate(today()))}</p><div class="summary"><div class="box"><b>Total Balance Due</b><br>${fmt(totalBalance)}</div><div class="box"><b>Sales in Period</b><br>${fmt(salesTotal)}</div><div class="box"><b>Payments in Period</b><br>${fmt(received)}</div><div class="box"><b>Number of Bills</b><br>${bills.length}</div></div><h2>Sales Bills</h2>${bills.length?ledgerPagedTable('<th class="date-col">Date</th><th class="bill-col">Bill No.</th><th>Mode</th><th>Disc.</th><th>Total</th><th>Paid</th><th>Bal.</th>',rows,`<tr><th colspan="3">Total</th><th class="num">${fmt(discountTotal)}</th><th class="num">${fmt(salesTotal)}</th><th class="num">${fmt(paidAtBill)}</th><th class="num">${fmt(Math.max(0,salesTotal-paidAtBill))}</th></tr>`):'<p class="empty">No sales bills for this period.</p>'}<h2>Items Purchased</h2>${items.length?ledgerPagedTable('<th class="date-col">Date</th><th class="bill-col">Bill No.</th><th>Item</th><th>Qty/Unit</th><th>Rate</th><th>Amt.</th>',itemRows):'<p class="empty">No item details found for this period.</p>'}<h2>Customer Payments</h2>${payments.length?ledgerPagedTable('<th class="date-col">Date</th><th>Ref.</th><th>Mode</th><th>Notes</th><th>Amt.</th>',payRows,`<tr><th colspan="4">Total payments</th><th class="num">${fmt(received)}</th></tr>`):'<p class="empty">No separate customer payment records for this period.</p>'}<p class="muted">This statement includes bills and payment records dated within the selected period. Bill totals and payment records are shown separately.</p></div></body></html>`;
 const filename="Customer_Ledger_"+customer.replace(/[^A-Za-z0-9_-]+/g,"_")+"_"+from+"_"+to;
 if(window.Android?.printHtmlDocument){Android.printHtmlDocument(html,filename);if(status)status.textContent="PDF saved to Downloads/SiddhiBill/Customer-Ledger. Choose an app to open it.";return;}
 const win=window.open("","_blank");if(win){win.document.open();win.document.write(html);win.document.close();}else showNotice("Could not open the ledger report. Allow pop-ups and try again.","Customer Ledger");if(status)status.textContent="Customer ledger opened for printing/download.";
}
$("customerLedgerPdfBtn")?.addEventListener("click",openCustomerLedgerPdf);
$("customerLedgerFrom")&&( $("customerLedgerFrom").value=new Date(new Date().getFullYear(),new Date().getMonth(),1).toISOString().slice(0,10));
$("customerLedgerTo")&&( $("customerLedgerTo").value=today());

function renderVendorLedgerVendorOptions(){
 bindLedgerSearch("vendorLedgerVendor","vendorLedgerVendorOptions",()=>(state.vendors||[]).filter(v=>v?.name).slice().sort((a,b)=>String(a.name||"").localeCompare(String(b.name||""))).map(v=>({label:String(v.name||""),value:String(v.name||"")})));
}
function openVendorLedgerPdf(){
 const vendorInput=String($("vendorLedgerVendor")?.value||"").trim(),vendor=(state.vendors||[]).find(v=>String(v.name||"").trim().toLowerCase()===vendorInput.toLowerCase()||String(v.id)===vendorInput),vendorId=String(vendor?.id||"").trim(),from=String($("vendorLedgerFrom")?.value||""),to=String($("vendorLedgerTo")?.value||"");
 const status=$("vendorLedgerPdfStatus");
 if(!vendor){showNotice("Please select a vendor.","Vendor Ledger");return;}
 if(!from||!to||from>to){showNotice("Please select a valid date range.","Vendor Ledger");return;}
 const normalizeLedgerDate=value=>{const raw=String(value||"").trim();if(!raw)return "";const iso=raw.match(/^(\d{4}-\d{2}-\d{2})/);if(iso)return iso[1];const dmy=raw.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})$/);return dmy?`${dmy[3]}-${String(dmy[2]).padStart(2,"0")}-${String(dmy[1]).padStart(2,"0")}`:raw.slice(0,10);};
 const sameShop=r=>!r?.shopKey||String(r.shopKey).trim().toLowerCase()===moduleShopKey();
 const normVendorName=v=>String(v||"").trim().replace(/\s+/g," ").toLowerCase();
 const selectedVendorName=normVendorName(vendor.name);
 const belongsToVendor=p=>{
   const idMatch=String(p.vendorId??p.supplierId??p.partyId??"").trim()===vendorId;
   const nameMatch=selectedVendorName && [p.vendorName,p.supplierName,p.supplierSnapshot?.name,p.vendor?.name].some(n=>normVendorName(n)===selectedVendorName);
   return idMatch||nameMatch;
 };
 let nativeLedger=null;
 try{const raw=window.Android?.loadVendorLedgerData?.(vendorId,String(vendor.name||""),from,to,moduleShopKey());if(raw){const parsed=JSON.parse(raw);if(parsed?.supported)nativeLedger=parsed;}}catch(e){console.warn("Native vendor ledger query unavailable",e);}
 const purchases=(nativeLedger?nativeLedger.purchases:(state.purchases||[]).filter(p=>belongsToVendor(p)&&sameShop(p)&&normalizeLedgerDate(p.date||p.invoiceDate)>=from&&normalizeLedgerDate(p.date||p.invoiceDate)<=to))
  .sort((a,b)=>normalizeLedgerDate(a.date||a.invoiceDate).localeCompare(normalizeLedgerDate(b.date||b.invoiceDate))||String(a.invoiceNo||a.billNo||"").localeCompare(String(b.invoiceNo||b.billNo||"")));
 const payments=(nativeLedger?nativeLedger.payments:(state.vendorPayments||[]).filter(p=>belongsToVendor(p)&&sameShop(p)&&normalizeLedgerDate(p.date)>=from&&normalizeLedgerDate(p.date)<=to))
  .sort((a,b)=>normalizeLedgerDate(a.date).localeCompare(normalizeLedgerDate(b.date)));
 const totalPurchases=purchases.reduce((sum,p)=>sum+Number(p.total||p.grandTotal||0),0);
 const paidOnInvoices=purchases.reduce((sum,p)=>sum+Number(p.paid||0),0);
 const totalPayments=payments.reduce((sum,p)=>sum+Number(p.amount||0),0);
 const pending=purchases.reduce((sum,p)=>sum+Math.max(0,Number(p.total||p.grandTotal||0)-Number(p.paid||0)),0);
 // Vendor opening balance is the brought-forward balance from the vendor master.
 // Period movement increases the payable for purchases and reduces it for payments.
 const openingBalance=Number(vendor.openingBalance||0);
 const netMovement=totalPurchases-paidOnInvoices-totalPayments;
 const closingBalance=openingBalance+netMovement;
 const fmt=n=>money(Number(n||0));
 const purchaseRows=purchases.map(p=>`<tr><td>${esc(displayDate(p.date||p.invoiceDate||""))}</td><td>${esc(p.invoiceNo||p.billNo||"")}</td><td>${esc(p.paymentMode||"Credit")}</td><td class="num">${fmt(p.total||p.grandTotal||0)}</td><td class="num">${fmt(p.paid||0)}</td><td class="num">${fmt(Math.max(0,Number(p.total||p.grandTotal||0)-Number(p.paid||0)))}</td></tr>`);
 const itemRows=purchases.flatMap(p=>(p.items||[]).map(it=>({date:p.date||p.invoiceDate||"",invoice:p.invoiceNo||p.billNo||"",name:it.name||it.description||it.itemName||"",qty:it.qty??it.quantity??"",unit:it.unit||it.uom||"",rate:Number(it.rate||it.unitRate||0),amount:Number(it.lineTotalInclusive??it.invoiceLineTotal??it.lineTotal??it.amount??((Number(it.qty??it.quantity??0)*Number(it.rate||it.unitRate||0))))})))
  .map(i=>`<tr><td>${esc(displayDate(i.date))}</td><td>${esc(i.invoice)}</td><td>${esc(i.name)}</td><td>${esc(String(i.qty))} ${esc(i.unit)}</td><td class="num">${fmt(i.rate)}</td><td class="num">${fmt(i.amount)}</td></tr>`);
 const paymentRows=payments.map(p=>`<tr><td>${esc(displayDate(p.date||""))}</td><td>${esc(p.note||p.reference||p.id||"Payment")}</td><td>${esc(p.mode||p.paymentMode||"—")}</td><td class="num">${fmt(p.amount)}</td></tr>`);
 const html=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Vendor Ledger - ${esc(vendor.name||"Vendor")}</title><style>@page{size:A4 portrait;margin:12mm}body{font:11px Arial,sans-serif;color:#222;margin:12px}h1{font-size:19px;margin:0 0 5px}h2{font-size:13px;margin:18px 0 6px}.muted{color:#555}table{border-collapse:collapse;width:100%;font-size:9px;margin-bottom:10px}th,td{border:1px solid #bbb;padding:5px;text-align:left;vertical-align:top}th{background:#edf3f8}.num{text-align:right;white-space:nowrap}.summary{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:12px 0}.box{border:1px solid #bbb;padding:8px;min-width:0}.empty{color:#666;font-style:italic}.ledger-toolbar{display:none!important}.ledger-next-page{break-before:page;page-break-before:always}.ledger-page-table{break-inside:auto;page-break-inside:auto}.ledger-page-table thead{display:table-header-group!important}.ledger-page-table tr{break-inside:avoid!important;page-break-inside:avoid!important}</style></head><body><h1>${esc(state.settings.shopName||"SiddhiBill")}</h1><div class="muted">Vendor Ledger Statement</div><p><b>Vendor:</b> ${esc(vendor.name||"")} &nbsp; <b>Mobile:</b> ${esc(vendor.phone||vendor.mobile||"—")}<br><b>Period:</b> ${esc(displayDate(from))} to ${esc(displayDate(to))}<br><b>Generated:</b> ${esc(displayDate(today()))}</p><div class="summary"><div class="box"><b>Purchase total</b><br>${fmt(totalPurchases)}</div><div class="box"><b>Paid on invoices</b><br>${fmt(paidOnInvoices)}</div><div class="box"><b>Pending on invoices</b><br>${fmt(pending)}</div><div class="box"><b>Separate payments</b><br>${fmt(totalPayments)}</div><div class="box"><b>Opening balance</b><br>${fmt(openingBalance)}</div><div class="box"><b>Net movement</b><br>${fmt(netMovement)}</div><div class="box"><b>Closing balance</b><br>${fmt(closingBalance)}</div></div><h2>Purchase Invoices</h2>${purchases.length?ledgerPagedTable('<th>Date</th><th>Invoice No.</th><th>Mode</th><th>Total</th><th>Paid</th><th>Bal.</th>',purchaseRows,`<tr><th colspan="3">Total</th><th class="num">${fmt(totalPurchases)}</th><th class="num">${fmt(paidOnInvoices)}</th><th class="num">${fmt(pending)}</th></tr>`):'<p class="empty">No purchase invoices for this period.</p>'}<h2>Items Purchased</h2>${itemRows.length?ledgerPagedTable('<th>Date</th><th>Invoice</th><th>Item</th><th>Qty/Unit</th><th>Rate</th><th>Amt.</th>',itemRows):'<p class="empty">No item details found for this period.</p>'}<h2>Vendor Payments</h2>${payments.length?ledgerPagedTable('<th>Date</th><th>Reference</th><th>Mode</th><th>Amount</th>',paymentRows,`<tr><th colspan="3">Total payments</th><th class="num">${fmt(totalPayments)}</th></tr>`):'<p class="empty">No separate vendor payment records for this period.</p>'}<p class="muted">This statement includes purchase invoices and separate vendor payment records dated within the selected period. Invoice-paid amounts and separate account payments are shown separately.</p></body></html>`;
 const filename="Vendor_Ledger_"+String(vendor.name||"Vendor").replace(/[^A-Za-z0-9_-]+/g,"_")+"_"+from+"_"+to;
 if(window.Android?.printHtmlDocument){Android.printHtmlDocument(html,filename);if(status)status.textContent="Vendor ledger PDF saved to Downloads/SiddhiBill/Vendor-Reports.";return;}
 const win=window.open("","_blank");if(win){win.document.open();win.document.write(html);win.document.close();}else showNotice("Could not open the vendor ledger report. Allow pop-ups and try again.","Vendor Ledger");
}
$("vendorLedgerPdfBtn")?.addEventListener("click",openVendorLedgerPdf);
$("vendorLedgerFrom")&&($("vendorLedgerFrom").value=new Date(new Date().getFullYear(),new Date().getMonth(),1).toISOString().slice(0,10));
$("vendorLedgerTo")&&($("vendorLedgerTo").value=today());
function renderReports(){
 const __rp0=__sbTraceClock();let __rpMark=__rp0;
 const __rpPhase=(name,details={})=>{__sbTraceProfile("renderReports / "+name,__rpMark,details);__rpMark=__sbTraceClock();};
 renderCustomerLedgerCustomerOptions();renderVendorLedgerVendorOptions();applyDateFollowUpReportVisibility();renderPaymentFollowUpReport();
 __rpPhase("ledger options and follow-up summary");
 const {from,to}=reportRange();
 const bills=reportRowsForPeriod("pksBills",from,to);
 __rpPhase("load and filter sales bills",{filtered:bills.length});
 const sales=bills.reduce((s,b)=>s+Number(b.total||0),0);
 const day=$('reportSalesDate')?.value||today();
 const dayBills=reportRowsForPeriod("pksBills",day,day);
 const daySales=dayBills.reduce((s,b)=>s+Number(b.total||0),0);
 $("reportDaySales")&&( $("reportDaySales").textContent=money(daySales) );
 $("reportDayBills")&&( $("reportDayBills").textContent=String(dayBills.length) );
 $("reportDayAverage")&&( $("reportDayAverage").textContent=money(dayBills.length?daySales/dayBills.length:0) );
 if($("reportDayList")){ $("reportDayList").innerHTML=dayBills.length?dayBills.slice().sort((a,b)=>String(a.billNo).localeCompare(String(b.billNo))).map(b=>`<div class="report-row"><span>${esc(b.billNo)} • ${esc(b.customer||"Walk-in Customer")}</span><b>${money(b.total)}</b></div>`).join(""): '<div class="muted">No bills for this date.</div>'; }
 __rpPhase("daily sales summary");
 const discount=bills.reduce((s,b)=>s+Number(b.discount||0),0);
 const credit=bills.filter(b=>(b.paymentMode||"Cash")==="Credit").reduce((sum,b)=>{const linked=state.customerPayments.filter(p=>String(p.sourceBillNo||"")===String(b.billNo||"")).reduce((ps,p)=>ps+Number(p.amount||0),0);const paid=Math.max(Number(b.partialPaymentAmount||0),linked);return sum+Math.max(0,Number(b.total||0)-paid);},0);
 const nonCredit=bills.filter(b=>(b.paymentMode||"Cash")!=="Credit").reduce((sum,b)=>sum+Number(b.total||0),0);
 $("reportSales").textContent=money(sales);$("reportBills").textContent=String(bills.length);$("reportAverage").textContent=money(bills.length?sales/bills.length:0);$("reportDiscount").textContent=money(discount);$("reportCredit").textContent=money(credit);$("reportNonCredit").textContent=money(nonCredit);
 __rpPhase("sales totals and payment balances");
 const custMap={}; bills.forEach(b=>{const n=b.customer&&b.customer!=="Walk-in Customer"?b.customer:"Walk-in Customer";custMap[n]=(custMap[n]||0)+Number(b.total||0)});
 const topCust=Object.entries(custMap).sort((a,b)=>b[1]-a[1]).slice(0,10);
 $("reportCustomers").innerHTML=topCust.length?topCust.map((x,i)=>`<div class="report-row"><span>${i+1}. ${esc(x[0])}</span><b>${money(x[1])}</b></div>`).join(""):'<div class="muted">No sales in this period.</div>';
 __rpPhase("customer ranking");
 const prod={}; bills.forEach(b=>(b.items||[]).forEach(it=>{const key=String(it.name||"").trim();if(!key)return;const qty=quantityValue(it.qty,it.unit||"piece");prod[key]=(prod[key]||0)+qty;}));
 const topProd=Object.entries(prod).sort((a,b)=>b[1]-a[1]).slice(0,10);
 $("reportProducts").innerHTML=topProd.length?topProd.map((x,i)=>`<div class="report-row"><span>${i+1}. ${esc(x[0])}</span><b>${Number(x[1]).toFixed(2)}</b></div>`).join(""):'<div class="muted">No products sold in this period.</div>';
 __rpPhase("product ranking");
 const pm={};
 bills.forEach(b=>{if((b.paymentMode||"Cash")==="Credit"){
   const linked=state.customerPayments.filter(p=>String(p.sourceBillNo||"")===String(b.billNo||""));
   const linkedTotal=linked.reduce((sum,p)=>sum+Number(p.amount||0),0);
   const legacyPaid=Math.max(0,Number(b.partialPaymentAmount||0)-linkedTotal);
   if(legacyPaid>0){const k=b.partialPaymentMode||"Cash";pm[k]=(pm[k]||0)+legacyPaid;}
   linked.forEach(p=>{const k=p.mode||p.paymentMode||"Cash";pm[k]=(pm[k]||0)+Number(p.amount||0);});
 }else{const k=b.paymentMode||"Cash";pm[k]=(pm[k]||0)+Number(b.total||0);}});
 $("reportPayments").innerHTML=Object.entries(pm).sort((a,b)=>b[1]-a[1]).map(x=>`<div class="report-row"><span>Received by ${esc(x[0])}</span><b>${money(x[1])}</b></div>`).join("")||'<div class="muted">No payments received in this period.</div>';
 __rpPhase("payment mode summary");
 let __customerRecords=getCustomerRecords(),due=[];
 try{let summary=[];if(nativeBridgePresent&&window.Android?.loadCustomerCreditSummary)summary=JSON.parse(Android.loadCustomerCreditSummary(moduleShopKey())||"[]");const sm=new Map(summary.map(x=>[String(x.customer||"").trim().toLowerCase(),x]));due=__customerRecords.map(c=>({name:c.name,due:Number(customerDue(c.name)||0)})).filter(x=>Math.abs(x.due)>0.00001).sort((a,b)=>Math.abs(b.due)-Math.abs(a.due));}catch(e){console.warn("Outstanding credit report calculation failed",e);due=__customerRecords.map(c=>({name:c.name,due:Number(customerDue(c.name)||0)})).filter(x=>Math.abs(x.due)>0.00001).sort((a,b)=>Math.abs(b.due)-Math.abs(a.due));}
 const outstandingTotal=due.reduce((sum,x)=>sum+x.due,0);let outstandingPage=1;const outstandingPageSize=20;
 const outstandingEl=$("reportOutstanding");if(outstandingEl){const drawOutstanding=()=>{const pages=Math.max(1,Math.ceil(due.length/outstandingPageSize));outstandingPage=Math.min(outstandingPage,pages);const pageRows=due.slice((outstandingPage-1)*outstandingPageSize,outstandingPage*outstandingPageSize);outstandingEl.innerHTML=`<div class="report-row"><b>Total Outstanding</b><b>${money(outstandingTotal)}</b></div><div class="report-row muted">${due.length} customers with non-zero balances</div>${pageRows.map(x=>`<div class="report-row"><span>${esc(x.name)}</span><b>${money(x.due)}</b></div>`).join("")||'<div class="muted">No outstanding credit.</div>'}<div class="pagination"><button type="button" class="secondary" id="outstandingPrev" ${outstandingPage<=1?"disabled":""}>Previous</button><span>Page ${outstandingPage} of ${pages}</span><button type="button" class="secondary" id="outstandingNext" ${outstandingPage>=pages?"disabled":""}>Next</button><button type="button" class="secondary" id="outstandingPdf">Download PDF</button></div>`;$("outstandingPrev")?.addEventListener("click",()=>{outstandingPage--;drawOutstanding()});$("outstandingNext")?.addEventListener("click",()=>{outstandingPage++;drawOutstanding()});$("outstandingPdf")?.addEventListener("click",()=>{const body=due.map(x=>`<tr><td>${esc(x.name)}</td><td style="text-align:right">${money(x.due)}</td></tr>`).join("");const html=`<!doctype html><html><head><meta charset="utf-8"><title>Outstanding Credit</title><style>@page{size:A4;margin:14mm}body{font:11px Arial;color:#222}table{width:100%;border-collapse:collapse}th,td{border:1px solid #bbb;padding:7px}th{background:#edf3f8}thead{display:table-header-group}tr{break-inside:avoid;page-break-inside:avoid}</style></head><body><h2>${esc(state.settings.shopName||"SiddhiBill")} — Outstanding Credit</h2><p>Generated: ${displayDate(today())}</p><h3>Total Outstanding: ${money(outstandingTotal)}</h3><table><thead><tr><th>Customer</th><th>Outstanding</th></tr></thead><tbody>${body}</tbody></table></body></html>`;if(window.Android?.printHtmlDocument)Android.printHtmlDocument(html,"Outstanding_Credit");else{const w=window.open("","_blank");if(w){w.document.write(html);w.document.close();}}});};drawOutstanding();}
 __rpPhase("customer outstanding balances",{records:__customerRecords.length});
 const productRevenue={};bills.forEach(b=>(b.items||[]).forEach(it=>{const name=String(it.name||"").trim();if(!name)return;const qty=quantityValue(it.qty,it.unit||"piece");const amount=qty*(Number(it.rate)||0);productRevenue[name]=(productRevenue[name]||0)+amount;}));
 const revenueRows=Object.entries(productRevenue).sort((a,b)=>b[1]-a[1]).slice(0,15);
 if($("reportProductRevenueList"))$("reportProductRevenueList").innerHTML=revenueRows.length?revenueRows.map(([name,value],i)=>`<div class="report-row"><span>${i+1}. ${esc(name)}</span><b>${money(value)}</b></div>`).join(""):'<div class="muted">No product sales in this period.</div>';
 __rpPhase("product revenue summary");
 const taxSummary=bills.filter(b=>billTaxEnabled(b)).reduce((a,b)=>{a.taxable+=Number(b.taxableValue??b.taxable??0)||0;a.gst+=Number(b.taxTotal??b.taxTotalAmount??b.gstAmount??0)||0;a.bills++;return a;},{taxable:0,gst:0,bills:0});
 if($("reportTaxSummaryList"))$("reportTaxSummaryList").innerHTML=taxSummary.bills?`<div class="report-row"><span>Tax invoices</span><b>${taxSummary.bills}</b></div><div class="report-row"><span>Taxable value</span><b>${money(taxSummary.taxable)}</b></div><div class="report-row"><span>Total GST</span><b>${money(taxSummary.gst)}</b></div>`:'<div class="muted">No tax invoices in this period.</div>';
 renderServiceDueReport();
 __rpPhase("service due report");
 // Payment Transactions is intentionally user-triggered; it can require loading the full purchase history.
 __rpPhase("payment transactions report deferred");
 __sbTraceProfile("renderReports TOTAL",__rp0,{records:bills.length});
}

// Expense Management: simple shop-wise expense register, persisted with app data.
function renderExpenses(){
 const list=$("expenseList");if(!list)return;
 const from=$("expenseFrom")?.value||"",to=$("expenseTo")?.value||"";
 const shop=moduleShopKey();const rows=(state.expenses||[]).filter(e=>(e.shopKey||moduleShopKey())===shop&&(!from||String(e.date||"")>=from)&&(!to||String(e.date||"")<=to)).sort((a,b)=>String(b.date||"").localeCompare(String(a.date||""))||Number(b.id)-Number(a.id));
 const total=rows.reduce((sum,e)=>sum+Number(e.amount||0),0);if($("expenseTotal"))$("expenseTotal").textContent=money(total);if($("expenseCount"))$("expenseCount").textContent=String(rows.length);
 list.innerHTML=rows.length?rows.map(e=>`<div class="report-row expense-row"><span><b>${esc(e.category||"Other")}</b> · ${esc(e.description||"—")}<small>${esc(displayDate(e.date||""))} · ${esc(e.paymentMode||"Cash")}${e.payee?" · "+esc(e.payee):""}</small></span><b>${money(e.amount)} <button type="button" class="secondary expense-edit" data-id="${esc(e.id)}">Edit</button> <button type="button" class="secondary expense-delete" data-id="${esc(e.id)}">Delete</button></b></div>`).join(""):'<div class="muted">No expenses in this date range.</div>';
 list.querySelectorAll(".expense-edit").forEach(b=>b.onclick=()=>{const e=state.expenses.find(x=>String(x.id)===String(b.dataset.id));if(!e)return;$("expenseId").value=e.id;$("expenseDate").value=e.date||today();$("expenseCategory").value=e.category||"Other";$("expenseDescription").value=e.description||"";$("expenseAmount").value=e.amount||"";$("expensePaymentMode").value=e.paymentMode||"Cash";$("expensePayee").value=e.payee||"";$("expenseReference").value=e.reference||"";$("expenseNotes").value=e.notes||"";$("saveExpenseBtn").textContent="Update Expense";window.scrollTo(0,0);});
 list.querySelectorAll(".expense-delete").forEach(b=>b.onclick=()=>{const e=state.expenses.find(x=>String(x.id)===String(b.dataset.id));if(!e||!confirm("Delete this expense entry?"))return;state.expenses=state.expenses.filter(x=>String(x.id)!==String(e.id));save();renderExpenses();});
}

// Native, bounded report reads keep large transaction histories off the WebView thread.
function reportRowsForPeriod(collection,from,to){
 try{if(nativeBridgePresent&&window.Android?.loadReportRecords){const data=JSON.parse(Android.loadReportRecords(collection,from||"0000-01-01",to||"9999-12-31",moduleShopKey())||"{}");if(data?.supported&&Array.isArray(data.records))return data.records;}}catch(e){console.warn("Scoped report query unavailable; using offline fallback",e);}
 const source=collection==="pksBills"?state.bills:state.inventoryMovements;
 return (source||[]).filter(r=>{const d=String(r?.date||"").slice(0,10);return (!from||d>=from)&&(!to||d<=to)&&moduleRecordShopKey(r)===moduleShopKey();});
}
// Profit & Loss report. COGS uses recorded sale inventory movements at their stored weighted-average cost.
function profitLossRange(){return {from:$('plFrom')?.value||new Date(new Date().getFullYear(),new Date().getMonth(),1).toISOString().slice(0,10),to:$('plTo')?.value||today()};}
function profitLossData(){
 const {from,to}=profitLossRange(),shop=moduleShopKey();
 const normDate=v=>{const raw=String(v||'').trim();const iso=raw.match(/^(\d{4}-\d{2}-\d{2})/);if(iso)return iso[1];const dmy=raw.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})$/);return dmy?`${dmy[3]}-${String(dmy[2]).padStart(2,'0')}-${String(dmy[1]).padStart(2,'0')}`:raw.slice(0,10);};
 const inRange=(r)=>{const d=normDate(r?.date);return !!d&&d>=from&&d<=to&&moduleRecordShopKey(r)===shop;};
 const bills=reportRowsForPeriod("pksBills",from,to).filter(inRange);
 const sales=bills.reduce((sum,b)=>sum+Math.max(0,(Number(b.total)||0)-(Number(b.taxTotal??b.taxTotalAmount??b.gstAmount??b.taxAmount)||0)),0);
 const tax=bills.reduce((sum,b)=>sum+(Number(b.taxTotal??b.taxTotalAmount??b.gstAmount??b.taxAmount)||0),0);
 const cogsMovements=reportRowsForPeriod("pksInventoryMovements",from,to).filter(m=>m.reversed!==true&&String(m.sourceType||'').trim().toLowerCase()==='sale'&&inRange(m)&&Number(m.qty)<0&&Number.isFinite(Number(m.unitCost))); // m.sourceType==='sale' retained as source type guard
 const cogs=cogsMovements.reduce((sum,m)=>sum+Math.abs(Number(m.qty)||0)*Math.max(0,Number(m.unitCost)||0),0);
 const expenses=(state.expenses||[]).filter(inRange);
 const expenseTotal=expenses.reduce((sum,e)=>sum+Math.max(0,Number(e.amount)||0),0);
 const categories={};expenses.forEach(e=>{const k=String(e.category||'Other');categories[k]=(categories[k]||0)+Math.max(0,Number(e.amount)||0);});
 const gross=sales-cogs,net=gross-expenseTotal,margin=sales>0?(net/sales)*100:0;
 const soldTrackedNames=new Set(cogsMovements.map(m=>String(m.productName||'').trim().toLowerCase()));
 const soldItems=new Set();bills.forEach(b=>(b.items||[]).forEach(it=>{const name=String(it.name||'').trim().toLowerCase();if(name)soldItems.add(name);}));
 const missingCostNames=[...soldItems].filter(n=>!soldTrackedNames.has(n));
 return {from,to,shopName:moduleCurrentShop(),bills,sales,tax,cogs,cogsMovements,expenses,expenseTotal,categories,gross,net,margin,missingCostNames};
}
function renderProfitLoss(){
 const d=profitLossData();
 if($('plShopTitle'))$('plShopTitle').textContent='Profit & Loss — '+d.shopName;
 if($('plPeriodLabel'))$('plPeriodLabel').textContent=displayDate(d.from)+' to '+displayDate(d.to);
 [['plRevenue',d.sales],['plCogs',d.cogs],['plGross',d.gross],['plExpenses',d.expenseTotal],['plNet',d.net]].forEach(([id,v])=>{if($(id))$(id).textContent=money(v);});
 if($('plMargin'))$('plMargin').textContent=d.margin.toFixed(1)+'%';
 if($('plNet'))$('plNet').style.color=d.net<0?'#b42318':'#157347';
 const cats=Object.entries(d.categories).sort((a,b)=>b[1]-a[1]);
 if($('plBreakdown'))$('plBreakdown').innerHTML=`<div class="report-row"><span>Sales bills</span><b>${d.bills.length}</b></div><div class="report-row"><span>GST excluded from sales revenue</span><b>${money(d.tax)}</b></div><div class="report-row"><span>Inventory cost movements included</span><b>${d.cogsMovements.length}</b></div><h3 style="margin-top:14px">Expense Breakdown</h3>${cats.length?cats.map(([name,value])=>`<div class="report-row"><span>${esc(name)}</span><b>${money(value)}</b></div>`).join(''):'<div class="muted">No expenses recorded in this period.</div>'}`;
 if($('plCaveat'))$('plCaveat').textContent=d.missingCostNames.length?`Important: cost coverage may be incomplete. No sale cost movement was found for ${d.missingCostNames.length} sold item name(s) in this period. Ensure Inventory Management and product tracking/costs were enabled; opening stock should have a unit cost. This report does not invent costs for untracked items.`:'COGS uses recorded inventory sale movements and their stored unit costs. If inventory tracking or costs were not recorded for some sales, profit may be understated; verify historical data before accounting/tax use.';
 if($('plStatus'))$('plStatus').textContent='Updated from this shop’s saved bills, inventory movements and expense entries.';
}
function profitLossPdfHtml(){
 const d=profitLossData(), rows=Object.entries(d.categories).sort((a,b)=>b[1]-a[1]);
 return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Profit and Loss</title><style>@page{size:A4 portrait;margin:14mm}body{font:12px Arial,sans-serif;color:#222}h1{margin:0 0 5px;font-size:22px}p{color:#555}table{border-collapse:collapse;width:100%;margin:16px 0}td,th{border:1px solid #ccc;padding:9px;text-align:left}th{background:#edf3f8}.num{text-align:right;white-space:nowrap}.total{font-weight:bold;background:#f3f5f7}.note{font-size:10px;color:#666;margin-top:20px}.toolbar{margin-bottom:14px}@media print{.toolbar{display:none}}</style></head><body><div class="toolbar"><button onclick="window.print()">Print / Save as PDF</button></div><h1>Profit &amp; Loss Statement</h1><b>${esc(d.shopName)}</b><p>Period: ${esc(displayDate(d.from))} to ${esc(displayDate(d.to))}</p><table><tbody><tr><td>Net Sales (excluding GST)</td><td class="num">${money(d.sales)}</td></tr><tr><td>Less: Cost of Goods Sold</td><td class="num">${money(d.cogs)}</td></tr><tr class="total"><td>Gross Profit / (Loss)</td><td class="num">${money(d.gross)}</td></tr><tr><td>Less: Operating Expenses</td><td class="num">${money(d.expenseTotal)}</td></tr><tr class="total"><td>Net Profit / (Loss)</td><td class="num">${money(d.net)}</td></tr><tr><td>Net Profit Margin</td><td class="num">${d.margin.toFixed(1)}%</td></tr></tbody></table><h3>Expense Breakdown</h3><table><thead><tr><th>Category</th><th class="num">Amount</th></tr></thead><tbody>${rows.length?rows.map(([n,v])=>`<tr><td>${esc(n)}</td><td class="num">${money(v)}</td></tr>`).join(''):'<tr><td colspan="2">No expenses recorded.</td></tr>'}</tbody></table><p class="note">COGS includes only recorded inventory sale movements at stored unit costs. ${d.missingCostNames.length?`Cost movements were not found for ${d.missingCostNames.length} sold item name(s); the result may be incomplete.`:'Check that inventory movements and costs were recorded for all sold items.'} This management report is based on SiddhiBill records and is not a substitute for reviewed financial statements or tax advice.</p><script>window.onload=()=>setTimeout(()=>window.print(),250)<\/script></body></html>`;
}
function exportProfitLossPdf(){const d=profitLossData(),html=profitLossPdfHtml(),filename=`SiddhiBill_Profit_Loss_${d.from}_${d.to}`;if(window.Android?.printHtmlDocument){Android.printHtmlDocument(html,filename);return;}const win=window.open('','_blank');if(!win){showNotice('Allow pop-ups to view or download the P&L PDF.','Profit & Loss');return;}win.document.open();win.document.write(html);win.document.close();}
function exportProfitLossCsv(){const d=profitLossData(),rows=[['Profit & Loss',d.shopName],['From',d.from],['To',d.to],['Net Sales (excluding GST)',d.sales.toFixed(2)],['Cost of Goods Sold',d.cogs.toFixed(2)],['Gross Profit / (Loss)',d.gross.toFixed(2)],['Operating Expenses',d.expenseTotal.toFixed(2)],['Net Profit / (Loss)',d.net.toFixed(2)],['Net Profit Margin (%)',d.margin.toFixed(2)],[],['Expense Category','Amount'],...Object.entries(d.categories).sort((a,b)=>b[1]-a[1])];const csv=rows.map(r=>r.map(v=>`"${String(v??'').replace(/"/g,'""')}"`).join(',')).join('\r\n');const filename=`SiddhiBill_Profit_Loss_${d.from}_${d.to}.csv`;if(window.Android?.saveExportFile){Android.saveExportFile(btoa(unescape(encodeURIComponent(csv))),filename);}else{const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'}));const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}}
$('plRefreshBtn')?.addEventListener('click',renderProfitLoss);
$('plThisMonthBtn')?.addEventListener('click',()=>{const d=new Date(),m=String(d.getMonth()+1).padStart(2,'0'),y=d.getFullYear();$('plFrom').value=`${y}-${m}-01`;$('plTo').value=today();renderProfitLoss();});
$('plPdfBtn')?.addEventListener('click',exportProfitLossPdf);$('plCsvBtn')?.addEventListener('click',exportProfitLossCsv);
document.querySelectorAll('[data-back-home]').forEach(b=>b.addEventListener('click',()=>showPage('home')));

function clearExpenseForm(){["expenseId","expenseDescription","expenseAmount","expensePayee","expenseReference","expenseNotes"].forEach(id=>{if($(id))$(id).value="";});if($("expenseDate"))$("expenseDate").value=today();if($("expenseCategory"))$("expenseCategory").value="Rent";if($("expensePaymentMode"))$("expensePaymentMode").value="Cash";if($("saveExpenseBtn"))$("saveExpenseBtn").textContent="Save Expense";}
$("saveExpenseBtn")?.addEventListener("click",()=>{const amount=Number($("expenseAmount")?.value||0),description=String($("expenseDescription")?.value||"").trim();if(!(amount>0)){showNotice("Enter an expense amount greater than zero.","Expense Management");return;}if(!description){showNotice("Enter a short expense description.","Expense Management");return;}const id=$("expenseId")?.value||("exp-"+Date.now());const existing=(state.expenses||[]).find(e=>String(e.id)===String(id));const row={...(existing||{}),id,date:$("expenseDate")?.value||today(),category:$("expenseCategory")?.value||"Other",description,amount:roundMoney(amount),paymentMode:$("expensePaymentMode")?.value||"Cash",payee:String($("expensePayee")?.value||"").trim(),reference:String($("expenseReference")?.value||"").trim(),notes:String($("expenseNotes")?.value||"").trim(),shopKey:moduleShopKey(),updatedAt:new Date().toISOString()};if(existing){const ix=state.expenses.findIndex(e=>String(e.id)===String(id));state.expenses[ix]=row;}else state.expenses.unshift(row);save();clearExpenseForm();renderExpenses();showNotice("Expense saved.","Expense Management");});
$("clearExpenseBtn")?.addEventListener("click",clearExpenseForm);$("expenseFrom")?.addEventListener("change",renderExpenses);$("expenseTo")?.addEventListener("change",renderExpenses);$("expenseRefreshBtn")?.addEventListener("click",renderExpenses);

function initializeProfitLossDates(){if(!$('plFrom')||!$('plTo'))return;const d=new Date(),m=String(d.getMonth()+1).padStart(2,'0'),y=d.getFullYear();if(!$('plFrom').value)$('plFrom').value=`${y}-${m}-01`;if(!$('plTo').value)$('plTo').value=today();}
initializeProfitLossDates();
function setReportThisMonth(){const d=new Date();const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,"0");$("reportFrom").value=`${y}-${m}-01`;$("reportTo").value=today();renderReports();}
function initializeReportDates(){const d=new Date();const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,"0");if($("reportFrom")&&!$("reportFrom").value)$("reportFrom").value=`${y}-${m}-01`;if($("reportTo")&&!$("reportTo").value)$("reportTo").value=today();}
$("serviceDueRefreshBtn")?.addEventListener("click",renderServiceDueReport);$("paymentFollowUpRefreshBtn")?.addEventListener("click",renderPaymentFollowUpReport);
$("paymentFollowUpTemplateBtn")?.addEventListener("click",()=>{$("setPaymentFollowUpTemplate").value=state.settings.paymentFollowUpTemplate||"Hello {customer}, payment of {amount} is pending with {shop}. Please follow up on {date}. Reference: {bill}";$("setCustomFollowUpTemplate").value=state.settings.customFollowUpTemplate||"Hello {customer}, reminder from {shop}: {fieldLabel} is {date}. Details: {details}";$("followUpTemplateModal").classList.remove("hidden")});
$("closeFollowUpTemplateBtn")?.addEventListener("click",()=>$("followUpTemplateModal").classList.add("hidden"));
$("saveFollowUpTemplatesBtn")?.addEventListener("click",()=>{state.settings.paymentFollowUpTemplate=$("setPaymentFollowUpTemplate").value.trim();state.settings.customFollowUpTemplate=$("setCustomFollowUpTemplate").value.trim();save();$("followUpTemplateModal").classList.add("hidden");showNotice("Follow-up templates saved.","Settings");});
const resetPaymentTransactionsLoad=()=>{const b=$("loadPaymentTransactionsBtn");if(b){b.disabled=false;b.textContent="Load Payment Transactions";b.classList.remove("hidden");}};
$("reportSalesDate")?.addEventListener("change",renderReports);$("reportFrom")?.addEventListener("change",()=>{resetPaymentTransactionsLoad();renderReports();});$("reportTo")?.addEventListener("change",()=>{resetPaymentTransactionsLoad();renderReports();});$("reportRefreshBtn")?.addEventListener("click",renderReports);$("reportClearBtn")?.addEventListener("click",setReportThisMonth);
window.__sbTraceMark("startup report initialization begin");
const __sbStartupReportStart=__sbTraceClock();
initializeReportDates();
__sbTraceProfile("startup report initialization (render deferred)",__sbStartupReportStart,{records:"not loaded"});
window.__sbTraceMark("startup report initialization complete");
if($("reportSalesDate"))$("reportSalesDate").value=today();
syncNavigation("billing");
// A standalone ledger window may return through a fresh WebView navigation on Android.
try{const returnTo=new URLSearchParams(window.location.search).get("returnTo");if(returnTo==="reports"){showPage("reports",false);history.replaceState(null,"",window.location.pathname);}}catch(e){}

let __customerBillSummaryCache=null,__customerBillSummaryShop="";
function customerBillSummaries(force=false){
 const shop=moduleShopKey();
 if(!force&&__customerBillSummaryCache&&__customerBillSummaryShop===shop)return __customerBillSummaryCache;
 try{if(nativeBridgePresent&&window.Android?.loadCustomerCreditSummary){const rows=JSON.parse(Android.loadCustomerCreditSummary(shop)||"[]");if(Array.isArray(rows)){__customerBillSummaryCache=new Map(rows.map(x=>[String(x.customer||"").trim().toLowerCase(),x]));__customerBillSummaryShop=shop;return __customerBillSummaryCache;}}}catch(e){console.warn("Customer bill summary unavailable",e);}
 const map=new Map();if(!nativeBridgePresent){(state.bills||[]).forEach(b=>{const k=String(b.customer||"").trim().toLowerCase();if(!k)return;const x=map.get(k)||{customer:b.customer,creditSales:0,totalSales:0,billCount:0,latestBillDate:""};x.totalSales+=Number(b.total||0);x.billCount++;if((b.paymentMode||"Cash")==="Credit")x.creditSales+=Math.max(0,Number(b.total||0)-Number(b.partialPaymentAmount||0));if(String(b.date||"")>x.latestBillDate)x.latestBillDate=String(b.date||"");map.set(k,x);});}
 __customerBillSummaryCache=map;__customerBillSummaryShop=shop;return map;
}
let __customerPaymentBalanceCache=null,__customerPaymentBalanceSource=null;
function customerPaymentBalanceByName(){
 const source=state.customerPayments||[];if(__customerPaymentBalanceSource===source&&__customerPaymentBalanceCache)return __customerPaymentBalanceCache;
 const map=new Map();source.forEach(p=>{if(p?.sourceBillNo)return;const key=String(p.customer||"").trim().toLowerCase();if(key)map.set(key,(map.get(key)||0)+Number(p.amount||0));});
 __customerPaymentBalanceSource=source;__customerPaymentBalanceCache=map;return map;
}
function customerDue(name){
 if(!name||name==="Cash Sale")return 0;
 const key=String(name).trim().toLowerCase(),c=state.customers.find(x=>String(x.name||"").trim().toLowerCase()===key);
 if(nativeBridgePresent&&window.Android?.loadCustomerDue){try{const summary=customerBillSummaries().get(key);if(summary&&summary.standalonePayments!==undefined)return Number(c?.openingBalance||0)+Number(summary.creditSales||0)-Number(summary.standalonePayments||0);const d=JSON.parse(Android.loadCustomerDue(String(name),moduleShopKey())||"null");if(d&&d.supported)return Number(c?.openingBalance||0)+Number(d.creditSales||0)-Number(d.standalonePayments||0);console.warn("Native customer due summary unavailable; avoiding full payment-history load.");return Number(c?.openingBalance||0)+Number(summary?.creditSales||0);}catch(e){console.warn("Native customer due lookup failed",e);return Number(c?.openingBalance||0);}}
 const summary=customerBillSummaries().get(key),paid=Number(customerPaymentBalanceByName().get(key)||0);
 return Number(c?.openingBalance||0)+Number(summary?.creditSales||0)-paid;
}
let customerPage=1, customerPageSize=20, customerQuery="", customerSortBy="name_asc";
function getCustomerRecords(){
 const map=new Map();
 state.customers.forEach(c=>{if(c?.name)map.set(c.name.trim().toLowerCase(),c);});
 const summaries=customerBillSummaries();summaries.forEach((summary,key)=>{const n=String(summary.customer||"").trim();if(n&&n!=="Walk-in Customer"&&!map.has(key))map.set(key,{name:n,phone:summary.customerPhone||"",openingBalance:0,notes:""});});
 return [...map.values()];
}
function renderCustomers(){
 const box=$("customerBalances"); if(!box)return;
 const all=getCustomerRecords(); const q=String($("customerPageSearch")?.value??customerQuery??"").trim().toLowerCase(); customerQuery=q;
 const filtered=all.filter(c=>{const name=String(c.name??c.customerName??"");const phone=normalizePhone(c.phone??c.mobile??c.mobileNumber??c.phoneNumber??"");const notes=String(c.notes??c.note??c.additionalDetails??"");const hay=[name,phone,notes].join(" ").toLowerCase();const phoneQ=normalizePhone(q); return !q||hay.includes(q)|| (phoneQ && phone.includes(phoneQ));});
 const summaries=customerBillSummaries();
 const salesFor=c=>Number(summaries.get(String(c.name||"").trim().toLowerCase())?.totalSales||0);
 const latestBillFor=c=>String(summaries.get(String(c.name||"").trim().toLowerCase())?.latestBillDate||"");
 const sortKey=$("customerSortBy")?.value||customerSortBy;customerSortBy=sortKey;
 filtered.sort((a,b)=>{
   const an=String(a.name||"").trim(),bn=String(b.name||"").trim();
   if(sortKey==="name_desc")return bn.localeCompare(an,undefined,{sensitivity:"base"});
   if(sortKey==="due_asc")return customerDue(an)-customerDue(bn)||an.localeCompare(bn);
   if(sortKey==="due_desc")return customerDue(bn)-customerDue(an)||an.localeCompare(bn);
   if(sortKey==="sales_asc")return salesFor(a)-salesFor(b)||an.localeCompare(bn);
   if(sortKey==="sales_desc")return salesFor(b)-salesFor(a)||an.localeCompare(bn);
   if(sortKey==="latest_bill"){const ad=latestBillFor(a),bd=latestBillFor(b);return (bd?1:0)-(ad?1:0)||bd.localeCompare(ad)||an.localeCompare(bn);}
   return an.localeCompare(bn,undefined,{sensitivity:"base"});
 });
 const pages=Math.max(1,Math.ceil(filtered.length/customerPageSize)); customerPage=Math.min(Math.max(1,customerPage),pages);
 const slice=filtered.slice((customerPage-1)*customerPageSize,customerPage*customerPageSize);
 box.innerHTML="";
 if(!filtered.length){box.innerHTML='<div class="muted">No customers found.</div>';return;}
 slice.forEach(c=>{
   const name=c.name||"", r=document.createElement("div"); r.className="history-row customer-card";
   r.innerHTML=`<div class="customer-main"><div class="history-title">${esc(name)}</div><div class="customer-detail-grid"><span>📱 ${esc(c.phone||"No mobile")}</span><span>Opening: ${money(c.openingBalance||0)}</span><span>Due: <b>${money(customerDue(name))}</b></span></div>${c.notes?`<div class="muted customer-notes">📝 ${esc(c.notes)}</div>`:"<div class=\"muted\">No notes</div>"}</div><div class="customer-row-actions"><button class="secondary edit-customer">Edit</button><button class="secondary pay-customer">Payment</button><button class="secondary customer-transactions">Transactions</button><button class="secondary delete-customer">Delete</button></div>`;
   r.querySelector(".pay-customer").onclick=()=>openCustomerPayment(c);
   r.querySelector(".edit-customer").onclick=()=>openCustomerEditor(c);
   r.querySelector(".customer-transactions").onclick=()=>openTransactionHistory("customer",c.name);
   r.querySelector(".delete-customer").onclick=()=>deleteCustomerFromList(c);
   box.appendChild(r);
 });
 const pager=document.createElement("div"); pager.className="pagination";
 pager.innerHTML=`<button class="secondary" ${customerPage<=1?"disabled":""}>‹ Previous</button><span>Page ${customerPage} of ${pages} • ${filtered.length} customers</span><button class="secondary" ${customerPage>=pages?"disabled":""}>Next ›</button>`;
 const bs=pager.querySelectorAll("button"); bs[0].onclick=()=>{if(customerPage>1){customerPage--;renderCustomers()}}; bs[1].onclick=()=>{if(customerPage<pages){customerPage++;renderCustomers()}}; box.appendChild(pager);
}

function deleteCustomerFromList(customer){
 const name=String(customer?.name||"").trim();
 if(!name){showNotice("Customer name is missing. Refresh the customer list and try again.","Customer not deleted");return;}
 if(name.toLowerCase()==="walk-in customer"){showNotice("The Walk-in Customer record is a system customer and cannot be deleted.","Customer not deleted");return;}
 let bills=[];
 try{
  if(nativeBridgePresent&&window.Android?.loadCustomerBills){
   bills=JSON.parse(Android.loadCustomerBills(name,"","",moduleShopKey())||"[]");
   if(!Array.isArray(bills))throw new Error("Bill lookup returned an invalid response");
  }else bills=(state.bills||[]).filter(b=>String(b.customer||"").trim().toLowerCase()===name.toLowerCase());
 }catch(e){showNotice("Customer cannot be deleted because SiddhiBill could not verify whether bills exist. Please retry after refreshing Bill History. Details: "+String(e.message||e),"Customer not deleted");return;}
 if(bills.length){showNotice(`Customer "${name}" cannot be deleted because ${bills.length} sales bill(s) are linked to this customer. Keep the customer record to preserve bill history.`,`Customer not deleted`);return;}
 const payments=(state.customerPayments||[]).filter(p=>String(p.customer||"").trim().toLowerCase()===name.toLowerCase());
 if(payments.length){showNotice(`Customer "${name}" cannot be deleted because ${payments.length} payment record(s) are linked to this customer. Delete or resolve those payment records first.`,`Customer not deleted`);return;}
 if(Number(customer.openingBalance||0)!==0){showNotice(`Customer "${name}" cannot be deleted because an opening balance of ${money(customer.openingBalance)} is recorded. Clear or settle the opening balance first.`,`Customer not deleted`);return;}
 const warning=`You are about to permanently delete customer "${name}".\n\nNo sales bills, customer payment records, or opening balance were found for this customer.\n\nThis cannot be undone. Continue?`;
 if(!window.confirm(warning))return;
 const ix=state.customers.findIndex(c=>String(c.name||"").trim().toLowerCase()===name.toLowerCase());
 if(ix<0){showNotice("Customer record was not found in the current shop. Refresh the customer list and try again.","Customer not deleted");return;}
 state.customers.splice(ix,1);
 try{save();renderCustomerDatalist();renderCustomers();showNotice(`Customer "${name}" was deleted successfully.`,"Customer deleted");}
 catch(e){showNotice("Customer could not be deleted because the local customer data could not be saved: "+String(e.message||e),"Customer not deleted");}
}

function openCustomerEditor(c){
 const m=$("customerEditModal"); if(!m)return;
 $("editCustomerName").value=c.name||""; $("editCustomerPhone").value=c.phone||""; $("editCustomerGstin").value=c.gstin||""; $("editCustomerFssai").value=c.fssai||""; $("editCustomerState").value=c.state||""; $("editCustomerAddress").value=c.address||""; $("editCustomerNotes").value=c.notes||""; $("editCustomerOpening").value=String(c.openingBalance||0); m.dataset.key=String(c.name||""); m.classList.remove("hidden");
}
function closeCustomerEditor(){$("customerEditModal")?.classList.add("hidden");}
function saveCustomerEditor(){
 const m=$("customerEditModal");
 if(!m){showNotice("Customer editor is unavailable. Close and reopen the customer details.","Customer not saved");return;}
 const oldName=String(m.dataset.key||"").trim();
 // Match robustly: customer names may have been trimmed or normalized after the editor opened.
 const c=state.customers.find(x=>String(x.name||"").trim()===oldName)
   || state.customers.find(x=>String(x.name||"").trim().toLowerCase()===oldName.toLowerCase());
 if(!c){showNotice("This customer record could not be found, so nothing was saved. Refresh the customer list and reopen the record.","Customer not saved");return;}
 const newName=$("editCustomerName").value.trim(), newPhone=normalizePhone($("editCustomerPhone").value), gstin=$("editCustomerGstin").value.trim().toUpperCase(), fssai=$("editCustomerFssai").value.trim(), customerState=$("editCustomerState").value.trim(), address=$("editCustomerAddress").value.trim(), notes=$("editCustomerNotes").value.trim(), openingRaw=String($("editCustomerOpening").value??"").trim(), opening=openingRaw===""?0:Number(openingRaw);
 if(!newName){alert("Customer name cannot be blank.");return;}
 if(newPhone && !isValidMobile(newPhone)){alert("Enter a valid 10 digit mobile number or leave it blank.");return;}
 if(!Number.isFinite(opening)||opening<0){alert("Opening balance must be a valid amount of zero or more.");return;}
 const conflict=state.customers.find(x=>x!==c&&(String(x.name||"").trim().toLowerCase()===newName.toLowerCase()||(newPhone&&normalizePhone(x.phone)===newPhone)));
 if(conflict){alert(`Another customer already exists with this name or mobile number.\n\n${conflict.name}${conflict.phone?" • "+conflict.phone:""}`);return;}
 const previousName=String(c.name||"").trim();
 c.name=newName;c.phone=newPhone;c.gstin=gstin;c.fssai=fssai;c.state=customerState;c.address=address;c.notes=notes;c.openingBalance=opening;
 if(nativeBridgePresent&&window.Android?.renameCustomerBills){try{const renamed=Android.renameCustomerBills(previousName,newName,moduleShopKey());if(Number(renamed)<0)throw new Error("Native customer bill rename failed");__customerBillSummaryCache=null;}catch(e){console.error("Customer bill rename failed",e);showNotice("Customer details were not fully saved because linked bills could not be updated. Please retry.","Customer not saved");return;}}
 else state.bills.forEach(b=>{if(String(b.customer||"").trim().toLowerCase()===previousName.toLowerCase())b.customer=newName;});
 const renamedPayments=[];state.customerPayments.forEach(p=>{if(String(p.customer||"").trim().toLowerCase()===previousName.toLowerCase()){p.customer=newName;renamedPayments.push(p);}});
 save({skipCustomerPayments:true});if(nativeBridgePresent&&renamedPayments.length&&window.Android?.saveTransactionRecords)Android.saveTransactionRecords("pksCustomerPayments",JSON.stringify(renamedPayments));__customerBillSummaryCache=null;
 // Verify the updated record exists in live state before closing the editor.
 const saved=state.customers.some(x=>String(x.name||"").trim()===newName && normalizePhone(x.phone)===newPhone && Number(x.openingBalance||0)===opening);
 if(!saved){showNotice("The customer changes could not be verified. Keep this window open and try again.","Customer not saved");return;}
 renderCustomerDatalist(); customerQuery=""; renderCustomers(); closeCustomerEditor();
 showNotice("Customer details updated.","Customer saved");
}
function editCustomer(c){openCustomerEditor(c)}

function renderCustomUnits(){
 const box=$("customUnitsList");if(!box)return;const arr=ensureUnitCatalog();
 box.innerHTML="";
 arr.forEach((u,i)=>{
  const row=document.createElement("div");row.className="custom-unit-row";
  row.innerHTML=`<div class="unit-info"><b>${esc(u.name)}</b><div class="muted">Aliases: ${esc((u.aliases||[]).join(", "))}</div></div><div class="unit-actions"><button type="button" class="secondary unit-edit">Edit</button><button type="button" class="secondary unit-delete">Delete</button></div>`;
  row.querySelector(".unit-edit").onclick=()=>{const name=$("customUnitName"),aliases=$("customUnitAliases"),btn=$("addCustomUnitBtn"),cancel=$("cancelCustomUnitBtn");if(name){name.value=u.name;name.focus();}if(aliases)aliases.value=(u.aliases||[]).filter(a=>String(a).toLowerCase()!==String(u.name).toLowerCase()).join(", ");if(btn){btn.textContent="Update Unit";btn.dataset.editIndex=String(i);}cancel?.classList.remove("hidden");};
  row.querySelector(".unit-delete").onclick=()=>{
   const canonical=String(u.name).toLowerCase();
   const usedProduct=state.products.some(p=>normalizeUnitName(p.unit)===canonical);
   const usedBill=state.bills.some(b=>(b.items||[]).some(it=>normalizeUnitName(it.unit)===canonical));
   if(usedProduct||usedBill){showNotice("This unit is already used in Products or Bills. Edit its aliases instead of deleting it.","Unit in use");return;}
   ensureUnitCatalog().splice(i,1);state.settings.customUnits=ensureUnitCatalog().map(x=>({name:x.name,aliases:[...(x.aliases||[])]}));save();renderCustomUnits();refreshUnitControls();renderOcrVocabulary();showNotice("Unit deleted.","Units & Aliases");
  };
  box.appendChild(row);
 });
 if(!arr.length)box.innerHTML='<div class="muted">No units configured.</div>';
}
function resetCustomUnitEditor(){
 $("customUnitName")&&( $("customUnitName").value="");$("customUnitAliases")&&($("customUnitAliases").value="");
 const btn=$("addCustomUnitBtn");if(btn){btn.textContent="+ Add Unit";delete btn.dataset.editIndex;}
 $("cancelCustomUnitBtn")?.classList.add("hidden");
}
function addCustomUnit(){
 const name=$("customUnitName")?.value.trim()||"",raw=$("customUnitAliases")?.value||"",btn=$("addCustomUnitBtn");
 if(!name){showNotice("Enter a unit name.","Units & Aliases");return;}
 const aliases=[...new Set(raw.split(/[,\/;\n]+/).map(x=>x.trim().toLowerCase()).filter(Boolean))];
 const canonical=name.toLowerCase();if(!aliases.includes(canonical))aliases.unshift(canonical);
 const arr=ensureUnitCatalog();const editIndex=Number.isInteger(Number(btn?.dataset.editIndex))&&btn?.dataset.editIndex!==""?Number(btn.dataset.editIndex):-1;
 const duplicate=arr.findIndex((x,i)=>i!==editIndex&&String(x.name||"").toLowerCase()===canonical);
 if(duplicate>=0){showNotice("A unit with this name already exists.","Units & Aliases");return;}
 if(editIndex>=0&&arr[editIndex])arr[editIndex]={name,aliases};else arr.push({name,aliases});
 state.settings.unitCatalog=arr;state.settings.customUnits=arr.map(x=>({name:x.name,aliases:[...(x.aliases||[])]}));save();resetCustomUnitEditor();renderCustomUnits();refreshUnitControls();renderOcrVocabulary();showNotice(editIndex>=0?"Unit updated.":"Unit added.","Units & Aliases");
}
$("addCustomUnitBtn")?.addEventListener("click",addCustomUnit);$("cancelCustomUnitBtn")?.addEventListener("click",resetCustomUnitEditor);
function refreshUnitControls(){
 document.querySelectorAll(".iunit").forEach(s=>{const v=s.value;s.innerHTML=unitOptionsHtml(v);s.value=normalizeUnitName(v);});
 const p=$("modalUnit");if(p){const v=p.value;p.innerHTML=unitOptionsHtml(v);p.value=normalizeUnitName(v);}
}

function refreshPairedPrinterChoices(select, preferredValue){
  if(!select) return;
  const wanted=String(preferredValue||select.value||'auto');
  let names=[];
  try { if(window.Android && typeof Android.getPairedBluetoothPrinters==='function') { const parsed=JSON.parse(Android.getPairedBluetoothPrinters()||'[]'); if(Array.isArray(parsed)) names=parsed.filter(n=>typeof n==='string'&&n.trim()).map(n=>n.trim()); } } catch(e) {}
  const unique=[...new Map(names.map(n=>[n.toLowerCase(),n])).values()];
  select.innerHTML='';
  const auto=document.createElement('option');auto.value='auto';auto.textContent='Auto Detect (any paired printer)';select.appendChild(auto);
  unique.forEach(name=>{const option=document.createElement('option');option.value=name;option.textContent=name;select.appendChild(option);});
  if(wanted!=='auto'&&!unique.some(n=>n.toLowerCase()===wanted.toLowerCase())){const option=document.createElement('option');option.value=wanted;option.textContent=wanted+' (saved; not currently paired)';select.appendChild(option);}
  select.value=Array.from(select.options).some(o=>o.value===wanted)?wanted:'auto';
}
function loadSettings(){
 renderOcrVocabulary();
 if(!$('setShopName'))return;
 const x=state.settings;const mobiles=getShopMobiles();
 if(JSON.stringify(x.shopMobiles||[])!==JSON.stringify(mobiles)){x.shopMobiles=mobiles;x.shopMobile=mobiles[0]||'';save();}
 $('setShopName').value=x.shopName;$('setBillPrefix').value=x.billPrefix;$('setBillStart').value=x.billStart;$('setBillTitle').value=x.billTitle;$('setTaxBillTitle').value=x.taxBillTitle||'TAX INVOICE';$('setAddress').value=x.address;$('setShopMobile').value=mobiles.join(', ');$('setTagline').value=x.tagline||'';$('setFooter').value=x.footer;$('setTermsConditions').value=(String(x.termsConditions||'').trim()==='Goods once sold cannot be taken back.'?'':(x.termsConditions||''));$('setPrintTermsConditions').checked=x.printTermsConditions===true && !!String(x.termsConditions||'').trim();$('setPrintShopName').checked=x.printShopName!==false;$('setPrintShopAddress').checked=x.printShopAddress!==false;$('setPrintShopMobile').checked=x.printShopMobile!==false;$('setPrintShopLogo').checked=x.printShopLogo!==false;$('setShowCustomer').checked=x.showCustomer!==false;$('setPrintCustomerMobile').checked=x.printCustomerMobile!==false;$('setPrintPaymentMode').checked=x.printPaymentMode!==false;$('setPrintItemCode').checked=x.printItemCode===true;$('setSignature').value=x.signature;$('setPaperSize').value=x.paperSize||'80mm';$('setBluetoothPrinter').value=x.bluetoothPrinter||'auto';refreshPairedPrinterChoices($('setBluetoothPrinter'),x.bluetoothPrinter||'auto');$('setCreditFooter').value=x.creditFooter??'Bill created by SiddhiBill • Contact 8087794271 for more details';$('setVendorManagement').checked=x.vendorManagement!==false;if($('setInventoryManagement'))$('setInventoryManagement').checked=x.inventoryManagement===true;
 ensureUnitCatalog();$('setTaxation').checked=!!x.taxationEnabled;$('setGstin').value=x.gstin||'';$('setFssai').value=x.fssai||'';$('setBusinessState').value=x.businessState||'';$('setTaxInvoicePrefix').value=x.taxInvoicePrefix||'INV';$('setTaxInvoiceStart').value=x.taxInvoiceStart||1;$('setReverseCharge').checked=!!x.reverseCharge;
 $('setUpiQrEnabled').checked=!!x.upiQrEnabled;$('setUpiQrSource').value=x.upiQrSource||'upi';$('setUpiId').value=x.upiId||'';$('setUpiPayeeName').value=x.upiPayeeName||x.shopName||'';$('setUpiPrintAmount').checked=x.upiPrintAmount!==false;renderMerchantQrPreview();
 $('setCustomField1Label').value=x.customBillField1Label||'';$('setCustomField1Position').value=x.customBillField1Position||'header';$('setCustomField2Label').value=x.customBillField2Label||'';$('setCustomField2Position').value=x.customBillField2Position||'header';$('setCustomField3Label').value=x.customBillField3Label||'';$('setCustomField3Position').value=x.customBillField3Position||'footer';$('setShowDateFollowUpReport').checked=x.showDateFollowUpReport!==false;
 $('logoPreview').src=logoSource();renderCustomUnits();refreshUnitControls();syncTaxUi();if($('placeOfSupply'))$('placeOfSupply').value=$('placeOfSupply').value||x.businessState||'';$('morePurchasingItem')?.classList.toggle('hidden',x.vendorManagement===false);
}

function openSettingsModal(id){$(id)?.classList.remove('hidden');}
function closeSettingsModal(id){$(id)?.classList.add('hidden');}
$('openCustomFieldsSettingsBtn')?.addEventListener('click',()=>openSettingsModal('customFieldsSettingsModal'));
$('closeCustomFieldsSettingsBtn')?.addEventListener('click',()=>closeSettingsModal('customFieldsSettingsModal'));
$('saveCustomFieldsCloseBtn')?.addEventListener('click',()=>closeSettingsModal('customFieldsSettingsModal'));
$('openUpiSettingsBtn')?.addEventListener('click',()=>{loadSettings();openSettingsModal('upiSettingsModal');});
$('closeUpiSettingsBtn')?.addEventListener('click',()=>closeSettingsModal('upiSettingsModal'));
function renderMerchantQrPreview(){const data=state.settings?.merchantQrData||'';const wrap=$('merchantQrPreviewWrap');if(wrap){wrap.classList.toggle('hidden',!data);if(data&&$('merchantQrPreview'))$('merchantQrPreview').src=data;}}
$('setMerchantQrImage')?.addEventListener('change',()=>{const file=$('setMerchantQrImage').files?.[0];if(!file)return;if(file.size>2*1024*1024){showNotice('Choose a merchant QR image smaller than 2 MB.','UPI QR Settings');$('setMerchantQrImage').value='';return;}const reader=new FileReader();reader.onload=()=>{state.settings.merchantQrData=String(reader.result||'');renderMerchantQrPreview();};reader.readAsDataURL(file);});
$('removeMerchantQrBtn')?.addEventListener('click',()=>{state.settings.merchantQrData='';if($('setMerchantQrImage'))$('setMerchantQrImage').value='';renderMerchantQrPreview();});
$('saveUpiSettingsBtn')?.addEventListener('click',()=>{const source=$('setUpiQrSource').value,upi=$('setUpiId').value.trim();if($('setUpiQrEnabled').checked&&source==='upi'&&!upi){showNotice('Enter the shop UPI ID or disable UPI QR.','UPI QR Settings');return;}if($('setUpiQrEnabled').checked&&source==='merchant'&&!state.settings.merchantQrData){showNotice('Upload the merchant QR image or choose UPI ID.','UPI QR Settings');return;}state.settings=Object.assign({},state.settings,{upiQrEnabled:$('setUpiQrEnabled').checked,upiQrSource:source,upiId:upi,upiPayeeName:$('setUpiPayeeName').value.trim()||state.settings.shopName||'',upiPrintAmount:$('setUpiPrintAmount').checked});save();$('upiSettingsStatus').textContent='UPI QR settings saved.';closeSettingsModal('upiSettingsModal');$('settingsStatus').textContent='UPI QR settings saved.';});

if($('saveSettingsBtn'))$('saveSettingsBtn').onclick=()=>{
 state.settings=Object.assign({},state.settings,{shopName:state.settings.shopName||'',billPrefix:$('setBillPrefix').value.trim()||'BILL',billStart:Number($('setBillStart').value)||1,billTitle:$('setBillTitle').value.trim()||'CASH MEMO / BILL',taxBillTitle:$('setTaxBillTitle').value.trim()||'TAX INVOICE',address:$('setAddress').value.trim(),shopMobiles:normalizeShopMobiles($('setShopMobile').value),shopMobile:normalizeShopMobiles($('setShopMobile').value)[0]||"",tagline:$('setTagline').value.trim(),footer:$('setFooter').value.trim(),termsConditions:$('setTermsConditions').value.trim(),printTermsConditions:$('setPrintTermsConditions').checked,printShopName:$('setPrintShopName').checked,printShopAddress:$('setPrintShopAddress').checked,printShopMobile:$('setPrintShopMobile').checked,printShopLogo:$('setPrintShopLogo').checked,showCustomer:$('setShowCustomer').checked,printCustomerMobile:$('setPrintCustomerMobile').checked,printPaymentMode:$('setPrintPaymentMode').checked,printItemCode:$('setPrintItemCode').checked,signature:$('setSignature').value.trim(),paperSize:$('setPaperSize').value||'80mm',bluetoothPrinter:$('setBluetoothPrinter').value||'auto',logoData:state.settings.logoData||'',creditFooter:$('setCreditFooter').value.trim(),vendorManagement:$('setVendorManagement').checked,inventoryManagement:$('setInventoryManagement')?.checked===true,customUnits:Array.isArray(state.settings.customUnits)?state.settings.customUnits:[],unitCatalog:ensureUnitCatalog(),taxationEnabled:$('setTaxation').checked,gstin:$('setGstin').value.trim().toUpperCase(),fssai:$('setFssai').value.trim(),businessState:$('setBusinessState').value.trim(),taxInvoicePrefix:$('setTaxInvoicePrefix').value.trim()||'INV',taxInvoiceStart:Math.max(1,Number($('setTaxInvoiceStart').value)||1),reverseCharge:$('setReverseCharge').checked,customBillField1Label:$('setCustomField1Label').value.trim(),customBillField1Position:$('setCustomField1Position').value||'header',customBillField2Label:$('setCustomField2Label').value.trim(),customBillField2Position:$('setCustomField2Position').value||'header',customBillField3Label:$('setCustomField3Label').value.trim(),customBillField3Position:$('setCustomField3Position').value||'footer',showDateFollowUpReport:$('setShowDateFollowUpReport').checked,upiQrEnabled:$('setUpiQrEnabled').checked,upiQrSource:$('setUpiQrSource').value||'upi',upiId:$('setUpiId').value.trim(),upiPayeeName:$('setUpiPayeeName').value.trim()||state.settings.shopName||'',upiPrintAmount:$('setUpiPrintAmount').checked});
 save();sbpSyncActiveFirmName();refreshShopHeader();syncTaxUi();refreshUnitControls();applyDateFollowUpReportVisibility();syncNavigation(window.__pageHistory[window.__pageHistory.length-1]||'billing');renderCustomBillInputs(window.__editingCustomBillFields||{});$('setShopName').value=state.settings.shopName;$('settingsStatus').textContent='Settings saved.';syncNavigation(window.__pageHistory[window.__pageHistory.length-1]||'billing');if(!state.settings.vendorManagement&&window.__pageHistory[window.__pageHistory.length-1]==='purchases')showPage('billing');
};
function openShopNameModal(){
 const m=$("shopNameModal");if(!m)return;$("shopNamePassword").value="";$("shopNameNew").value=state.settings.shopName||"Your Shop";m.classList.remove("hidden");setTimeout(()=>$("shopNamePassword")?.focus(),50);
}
function closeShopNameModal(){$("shopNameModal")?.classList.add("hidden");}
$("changeShopNameBtn")?.addEventListener("click",openShopNameModal);
$("shopNameCancel")?.addEventListener("click",closeShopNameModal);
$("shopNameSave")?.addEventListener("click",()=>{
 const pass=$("shopNamePassword").value;const trimmed=$("shopNameNew").value.trim();
 if(!pass){showNotice("Enter the password to change the shop name.","Change Shop Name");return;}
 if(!trimmed){showNotice("Shop name cannot be blank.","Change Shop Name");return;}
 let ok=false;try{ok=!!window.Android?.verifyShopNamePassword?.(pass);}catch(e){ok=false;}
 if(!ok){showNotice("Incorrect password. Shop name was not changed.","Change Shop Name");return;}
 state.settings.shopName=trimmed;save();sbpSyncActiveFirmName();$("setShopName").value=trimmed;refreshShopHeader();if(window.currentBill)renderBill(window.currentBill);$("settingsStatus").textContent="Shop name updated.";closeShopNameModal();
});

function openCustomerAddModal(){
 const m=$("customerAddModal");if(!m)return;m.dataset.billingContinue="";const heading=m.querySelector("h3");if(heading)heading.textContent="Add Customer";const saveBtn=$("addCustomerSave");if(saveBtn)saveBtn.textContent="Save Customer";$("addCustomerName").value="";$("addCustomerPhone").value="";$("addCustomerGstin").value="";$("addCustomerFssai").value="";$("addCustomerState").value="";$("addCustomerAddress").value="";$("addCustomerNotes").value="";$("addCustomerOpening").value="0";m.classList.remove("hidden");setTimeout(()=>$("addCustomerName")?.focus(),50);
}
function closeCustomerAddModal(){const m=$("customerAddModal");if(m){m.classList.add("hidden");m.dataset.billingContinue="";const heading=m.querySelector("h3");if(heading)heading.textContent="Add Customer";const saveBtn=$("addCustomerSave");if(saveBtn)saveBtn.textContent="Save Customer";}}
function continueBillAfterCustomerSaved(customer){
 const modal=$("customerAddModal");if(!modal||modal.dataset.billingContinue!=="1")return;
 const saved=customer||state.customers.find(c=>String(c.name||"").trim().toLowerCase()===String($("addCustomerName")?.value||"").trim().toLowerCase());
 if(!saved)return;
 $("customer").value=String(saved.name||$("addCustomerName")?.value||"").trim();$("customer").dataset.phone=normalizePhone(saved.phone||$("addCustomerPhone")?.value||"");
 closeCustomerAddModal();$("generateBtn")?.click();
}
$("addCustomerBtn")?.addEventListener("click",openCustomerAddModal);
$("addCustomerCancel")?.addEventListener("click",closeCustomerAddModal);
$("addCustomerSave")?.addEventListener("click",()=>{
 const name=$("addCustomerName").value.trim(),phoneRaw=$("addCustomerPhone").value.trim(),phone=normalizePhone(phoneRaw),gstin=$("addCustomerGstin").value.trim().toUpperCase(),fssai=$("addCustomerFssai").value.trim(),customerState=$("addCustomerState").value.trim(),address=$("addCustomerAddress").value.trim(),notes=$("addCustomerNotes").value.trim(),opening=Number($("addCustomerOpening").value||0);
 if(!name){showNotice("Enter customer name.","Add Customer");return;}
 if(phoneRaw&&!isValidMobile(phone)){showNotice("Enter a valid 10 digit mobile number or leave it blank.","Add Customer");return;}
 if(!Number.isFinite(opening)||opening<0){showNotice("Enter a valid opening balance.","Add Customer");return;}
 if(phone){
   handleCustomerConflict(name,phone,(decision,existing)=>{
     try{
       if(decision==="same"||decision==="update"){
         const c=existing||findCustomerByNameOrPhone(name,phone);
         if(!c) throw new Error("Customer record not found");
         c.name=name;c.phone=phone;c.gstin=gstin;c.fssai=fssai;c.state=customerState;c.address=address;c.notes=notes;c.openingBalance=opening;
       }else if(decision==="existing"){
         // Keep the matched customer's original name and profile unchanged.
       }else if(decision==="create"||decision==="none"){
         state.customers.unshift({name,phone,gstin,fssai,state:customerState,address,notes,openingBalance:opening});
         state.customers=state.customers.slice(0,500);
       }else{return;}
       const billingContinue=$("customerAddModal")?.dataset.billingContinue==="1";
       save();renderCustomerDatalist();renderCustomers();
       if(billingContinue){continueBillAfterCustomerSaved(existing||state.customers.find(c=>String(c.name||"").trim().toLowerCase()===name.toLowerCase())||{name,phone,gstin,fssai,state:customerState,address,notes,openingBalance:opening});return;}
       closeCustomerAddModal();showNotice("Customer saved successfully.","Add Customer");
     }catch(e){showNotice("Customer could not be saved. Please try again.","Add Customer");}
   },{gstin,fssai,state:customerState,address,notes,openingBalance:opening});
 }
 else {const same=state.customers.find(c=>String(c.name||"").trim().toLowerCase()===name.toLowerCase());if(same){showNotice("A customer with this name already exists. Select that customer or edit the existing record.","Customer Already Exists");return;}const created={name,phone:"",gstin,fssai,state:customerState,address,notes,openingBalance:opening};state.customers.unshift(created);state.customers=state.customers.slice(0,500);save();renderCustomerDatalist();renderCustomers();if($("customerAddModal")?.dataset.billingContinue==="1"){continueBillAfterCustomerSaved(created);return;}closeCustomerAddModal();}
});

let customerPaymentTarget=null, editingCustomerPaymentId=null;
function updateCustomerPaymentModeFields(){const mode=$("customerPaymentMode")?.value||"Cash",cheque=mode==="Cheque";$("customerPaymentChequeFields")?.classList.toggle("hidden",!cheque);$("customerPaymentTransactionWrap")?.classList.toggle("hidden",cheque||mode==="Cash");}
$("customerPaymentMode")?.addEventListener("change",updateCustomerPaymentModeFields);
function openCustomerPayment(c){customerPaymentTarget=c;editingCustomerPaymentId=null;$("customerPaymentLabel").textContent="Payment received from "+(c.name||"");$("customerPaymentAmount").value="0";$("customerPaymentDate").value=today();$("customerPaymentMode").value="Cash";$("customerPaymentTransactionNo").value="";$("customerPaymentChequeNo").value="";$("customerPaymentChequeDate").value=today();$("customerPaymentNote").value="";$("customerPaymentFollowUpDate").value="";updateCustomerPaymentModeFields();$("customerPaymentModal").classList.remove("hidden");setTimeout(()=>$("customerPaymentAmount")?.focus(),50);}
$("customerPaymentCancel")?.addEventListener("click",()=>{$("customerPaymentModal").classList.add("hidden");customerPaymentTarget=null;editingCustomerPaymentId=null;});
$("customerPaymentSave")?.addEventListener("click",()=>{
 const a=Number($("customerPaymentAmount").value||0),mode=$("customerPaymentMode").value||"Cash";
 if(!customerPaymentTarget||a<=0){showNotice("Enter a payment amount greater than zero.","Customer Payment");return;}
 if(mode==="Cheque"&&!String($("customerPaymentChequeNo").value||"").trim()){showNotice("Enter the cheque number.","Customer Payment");return;}
 const payment={id:editingCustomerPaymentId||Date.now(),customer:customerPaymentTarget.name,shopKey:moduleShopKey(),shopName:moduleCurrentShop(),date:$("customerPaymentDate").value||today(),amount:a,mode,paymentMode:mode,transactionNo:$("customerPaymentTransactionNo").value.trim(),chequeNo:$("customerPaymentChequeNo").value.trim(),chequeDate:mode==="Cheque"?($("customerPaymentChequeDate").value||$("customerPaymentDate").value||today()):"",note:$("customerPaymentNote").value.trim(),followUpDate:$("customerPaymentFollowUpDate").value||""};
 if(editingCustomerPaymentId){const ix=state.customerPayments.findIndex(p=>String(p.id)===String(editingCustomerPaymentId));if(ix>=0)state.customerPayments[ix]={...state.customerPayments[ix],...payment};}else state.customerPayments.unshift(payment);
 if(payment.followUpDate){const ck=String(payment.customer||"").trim().toLowerCase();let customerRecord=state.customers.find(c=>String(c.name||"").trim().toLowerCase()===ck);if(!customerRecord){customerRecord={name:String(payment.customer||"").trim(),phone:"",openingBalance:0};state.customers.unshift(customerRecord);}customerRecord.paymentFollowUpDate=payment.followUpDate;customerRecord.nextPaymentReminderDate=payment.followUpDate;}
 save({skipCustomerPayments:true});
 if(nativeBridgePresent&&window.Android?.saveTransactionRecord&&Android.saveTransactionRecord("pksCustomerPayments",JSON.stringify(payment))===false){showNotice("Payment could not be confirmed in the local database. Keep this screen open and retry.","Payment save warning");return;}
 renderCustomers();renderPaymentFollowUpReport();if(transactionHistoryKind==="customer")renderTransactionHistory();$("customerPaymentModal").classList.add("hidden");customerPaymentTarget=null;editingCustomerPaymentId=null;
});

function handleCustomerPageSearch(e){customerQuery=String(e.target.value||"");customerPage=1;renderCustomers();}
$("customerSortBy")?.addEventListener("change",()=>{customerSortBy=$("customerSortBy").value;customerPage=1;renderCustomers();});$("customerPageSearch")?.addEventListener("input",handleCustomerPageSearch);
$("customerPageSearch")?.addEventListener("keyup",handleCustomerPageSearch);
$("customerPageSearch")?.addEventListener("change",handleCustomerPageSearch);
document.addEventListener("input",e=>{if(e.target?.id==="productPageSearch"){productQuery=String(e.target.value||"");productPage=1;renderProducts();}});
if($("customerEditCancel")) $("customerEditCancel").onclick=closeCustomerEditor;
if($("customerEditSave")) $("customerEditSave").onclick=saveCustomerEditor;
// Owner Dashboard restore hook. The native restore reloads index.html (billing page),
// while the shop list UI is rendered by activation.html. The hook must therefore exist
// on the billing page too and persist the restored list for activation.html to read.
window.restoreOwnerDashboard = function(json) {
  try {
    const data = JSON.parse(json || "{}");
    if (!data || !Array.isArray(data.shops)) return false;
    localStorage.setItem("dukaan_owner_shops", JSON.stringify(data.shops));
    return true;
  } catch (e) {
    console.error("Owner Dashboard restore failed", e);
    return false;
  }
};

// Backup / restore is handled by the Android native layer so the ZIP can include the SQLite DB and invoice attachments.
// Date-based archive: structured transaction ZIP plus a compact printable PDF register.
let pendingArchivePackage=null;
function archiveRows(){
 const type=$("archiveType")?.value||"both",from=$("archiveFrom")?.value||"",to=$("archiveTo")?.value||"";
 const inRange=x=>{const d=String(x?.date||x?.invoiceDate||x?.billDate||"").slice(0,10);return !!d&&(!from||d>=from)&&(!to||d<=to);};
 const bills=type!=="purchase"?(state.bills||[]).filter(inRange):[];
 const purchases=type!=="customer"?(state.purchases||[]).filter(inRange):[];
 const billNos=new Set(bills.map(b=>String(b.billNo||"")));
 const invoiceNos=new Set(purchases.map(p=>String(p.invoiceNo||p.billNo||"")));
 const customerPayments=(state.customerPayments||[]).filter(p=>p.sourceBillNo&&billNos.has(String(p.sourceBillNo)));
 const vendorPayments=(state.vendorPayments||[]).filter(p=>{const ref=String(p.sourceBillNo||p.invoiceNo||p.reference||"");return invoiceNos.has(ref);});
 return {type,from,to,bills,purchases,customerPayments,vendorPayments};
}
function archiveMoney(n){return Number(n||0).toFixed(2)}
function archivePdfHtml(pkg){
 const rows=[...pkg.bills.map(b=>({date:b.date||"",no:b.billNo||"",party:b.customer||"",type:"Customer bill",taxable:Number(b.taxableValue||b.subtotal||0),cgst:Number(b.cgst||0),sgst:Number(b.sgst||0),igst:Number(b.igst||0),total:Number(b.total||0),paid:(String(b.paymentMode||"Cash")==="Credit"?Math.max(0,Number(b.partialPaymentAmount||0)):Number(b.total||0)),balance:(String(b.paymentMode||"Cash")==="Credit"?Math.max(0,Number(b.total||0)-Number(b.partialPaymentAmount||0)):0),status:(String(b.paymentMode||"Cash")==="Credit"&&Number(b.total||0)>Number(b.partialPaymentAmount||0)?"Outstanding":"Paid")})),...pkg.purchases.map(p=>({date:p.date||p.invoiceDate||"",no:p.invoiceNo||p.billNo||"",party:p.vendorName||p.vendor||"",type:"Purchase bill",taxable:Number(p.taxableValue||p.subtotal||0),cgst:Number(p.cgst||0),sgst:Number(p.sgst||0),igst:Number(p.igst||0),total:Number(p.total||p.grandTotal||0),paid:Number(p.paidAmount||p.paid||0),balance:Number(p.balance||p.balancePending||0),status:Number(p.balance||p.balancePending||0)<=0?"Paid":"Outstanding"}))].sort((a,b)=>String(a.date).localeCompare(String(b.date)));
 const total=k=>rows.reduce((a,r)=>a+Number(r[k]||0),0);
 return `<!doctype html><html><head><meta charset="utf-8"><title>SiddhiBill Archive Summary</title><style>body{font:10px Arial,sans-serif;color:#222;margin:18px}h2{margin:0 0 5px}p{margin:4px 0 12px}.meta{font-size:9px;color:#444}table{border-collapse:collapse;width:100%;font-size:8px}th,td{border:1px solid #888;padding:4px 3px;text-align:left}th{background:#eee}.num{text-align:right;white-space:nowrap}.totals{margin-top:12px;font-weight:bold}@page{size:A4 landscape;margin:8mm}@media print{body{margin:0}}</style></head><body><h2>${esc(state.settings.shopName||"SiddhiBill")} — Archive Summary</h2><p class="meta">Period: ${esc(pkg.from||"All dates")} to ${esc(pkg.to||"All dates")} · Generated: ${esc(today())} · Customer bills: ${pkg.bills.length} · Purchase bills: ${pkg.purchases.length}</p><table><thead><tr>${["Date","Bill No.","Customer / Vendor","Type","Taxable","CGST","SGST","IGST","Bill Total","Paid","Balance","Status"].map(x=>`<th>${x}</th>`).join("")}</tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.date)}</td><td>${esc(r.no)}</td><td>${esc(r.party)}</td><td>${esc(r.type)}</td><td class="num">${archiveMoney(r.taxable)}</td><td class="num">${archiveMoney(r.cgst)}</td><td class="num">${archiveMoney(r.sgst)}</td><td class="num">${archiveMoney(r.igst)}</td><td class="num">${archiveMoney(r.total)}</td><td class="num">${archiveMoney(r.paid)}</td><td class="num">${archiveMoney(r.balance)}</td><td>${esc(r.status)}</td></tr>`).join("")}</tbody><tfoot><tr><th colspan="4">Totals</th>${["taxable","cgst","sgst","igst","total","paid","balance"].map(k=>`<th class="num">${archiveMoney(total(k))}</th>`).join("")}<th></th></tr></tfoot></table><p class="totals">No individual item details or original invoice attachments are included in this report.</p></body></html>`;
}
function previewArchive(){const p=archiveRows();const el=$("archivePreview");if(el)el.textContent=`Selected: ${p.bills.length} customer bills, ${p.purchases.length} purchase bills, ${p.customerPayments.length} linked customer payment records and ${p.vendorPayments.length} linked vendor payment records. Date range: ${p.from||"start"} to ${p.to||"today"}.`;return p;}
$("archivePreviewBtn")?.addEventListener("click",previewArchive);
$("archiveImportBtn")?.addEventListener("click",()=>{if(window.Android?.chooseArchiveImport)Android.chooseArchiveImport();else showNotice("Archive import is available in the Android app.","Import Archive");});
window.onArchiveImportData=function(raw){
 let pkg;try{pkg=typeof raw==="string"?JSON.parse(raw):raw;}catch(e){showNotice("The selected ZIP does not contain a valid SiddhiBill archive.","Import Archive");return;}
 if(pkg?.format!=="SiddhiBillArchive"||Number(pkg.version)!==1){showNotice("Unsupported archive format.","Import Archive");return;}
 const r=pkg.records||{},bills=Array.isArray(r.customerBills)?r.customerBills:[],purchases=Array.isArray(r.purchaseBills)?r.purchaseBills:[],cp=Array.isArray(r.customerPayments)?r.customerPayments:[],vp=Array.isArray(r.vendorPayments)?r.vendorPayments:[];
 // Bill prefixes are meaningful identifiers. BILL_2026/001 and INV_2026/001
 // are distinct bills and must not collide during archive import.
 const canonicalArchiveBillNo=value=>String(value||"").trim().replace(/\s+/g,"").toUpperCase();
 // Keep the complete reference and bill type namespace: BILL_2026/001 and INV_2026/001 are different.
 showConfirm(`Import ${bills.length} customer bills and ${purchases.length} purchase bills into ${state.settings.shopName||"the current shop"}? This archive may originate from another shop. Only an exact reference within the same bill type is treated as a duplicate.`,()=>{
  const seenBills=new Set((state.bills||[]).map(b=>canonicalArchiveBillNo(b.billNo)));
  const seenPurchases=new Set((state.purchases||[]).map(b=>canonicalArchiveBillNo(b.invoiceNo||b.billNo)));
  const importedBillKeys=new Set(),importedPurchaseKeys=new Set();
  const newBills=bills.filter(b=>{const k=canonicalArchiveBillNo(b.billNo);if(!k||seenBills.has(k)||importedBillKeys.has(k))return false;importedBillKeys.add(k);return true;});
  const newPurchases=purchases.filter(b=>{const k=canonicalArchiveBillNo(b.invoiceNo||b.billNo);if(!k||seenPurchases.has(k)||importedPurchaseKeys.has(k))return false;importedPurchaseKeys.add(k);return true;});
  state.bills.push(...newBills);state.purchases.push(...newPurchases);
  if(nativeBridgePresent&&window.Android?.saveTransactionRecords){Android.saveTransactionRecords("pksBills",JSON.stringify(newBills));Android.saveTransactionRecords("pksPurchases",JSON.stringify(newPurchases));}
  const billNos=new Set(newBills.map(b=>String(b.billNo||""))),invoiceNos=new Set(newPurchases.map(b=>String(b.invoiceNo||b.billNo||"")));
  const importedCustomerPayments=cp.filter(x=>billNos.has(String(x.sourceBillNo||""))&&!state.customerPayments.some(y=>String(y.id||"")===String(x.id||"")));
  state.customerPayments.push(...importedCustomerPayments);
  if(nativeBridgePresent&&importedCustomerPayments.length&&window.Android?.saveTransactionRecords)Android.saveTransactionRecords("pksCustomerPayments",JSON.stringify(importedCustomerPayments));
  state.vendorPayments.push(...vp.filter(x=>invoiceNos.has(String(x.sourceBillNo||x.invoiceNo||x.reference||""))&&!state.vendorPayments.some(y=>String(y.id||"")===String(x.id||""))));
  save();$("archiveStatus").textContent=`Imported ${newBills.length} customer bills and ${newPurchases.length} purchase bills. Duplicates skipped: ${(bills.length-newBills.length)+(purchases.length-newPurchases.length)}.`;showNotice($("archiveStatus").textContent,"Archive Imported");
 },"Import Archive");
};

$("archiveExportBtn")?.addEventListener("click",()=>{
 const p=previewArchive();if(!p.bills.length&&!p.purchases.length){showNotice("No bills found for the selected type and date range.","Archive Bills");return;}
 const pkg={format:"SiddhiBillArchive",version:1,shopName:state.settings.shopName||"",shopGstin:state.settings.gstin||"",createdAt:new Date().toISOString(),dateRange:{from:p.from,to:p.to},records:{customerBills:p.bills,purchaseBills:p.purchases,customerPayments:p.customerPayments,vendorPayments:p.vendorPayments},note:"Structured transaction data only. Original PDFs and images are not included."};
 pendingArchivePackage={pkg,p};
 if(window.Android?.createArchiveZip){$("archiveStatus").textContent="Preparing the ZIP and separate summary PDF. You will be asked to save exactly these two files.";Android.createArchiveZip(JSON.stringify(pkg));}
 else{$("archiveStatus").textContent="Archive export requires the installed SiddhiBill Android app. No records have been removed.";pendingArchivePackage=null;}
});
window.onArchiveZipSaved=function(ok,message){
 const el=$("archiveStatus");if(!ok){if(el)el.textContent=message||"ZIP was not saved. No records were removed.";pendingArchivePackage=null;return;}
 if(!pendingArchivePackage){if(el)el.textContent="ZIP saved, but the archive session is no longer active. No records were removed.";return;}
 const {p}=pendingArchivePackage;
 showConfirm("Both the archive ZIP and summary PDF have been saved. Remove these archived bills and their linked bill payments from active app storage now?",()=>{
   const billNos=new Set(p.bills.map(b=>String(b.billNo||""))), invoiceNos=new Set(p.purchases.map(x=>String(x.invoiceNo||x.billNo||"")));
   state.bills=(state.bills||[]).filter(b=>!p.bills.includes(b));state.purchases=(state.purchases||[]).filter(b=>!p.purchases.includes(b));
   if(nativeBridgePresent&&window.Android?.deleteTransactionRecords){
     Android.deleteTransactionRecords("pksBills",JSON.stringify(p.bills.flatMap(b=>[moduleRecordShopKey(b)+"|"+String(b.billNo||""),"|"+String(b.billNo||"")])));
     Android.deleteTransactionRecords("pksPurchases",JSON.stringify(p.purchases.map(x=>String(x.id||""))));
   }
   const archivedCustomerPayments=(state.customerPayments||[]).filter(x=>x.sourceBillNo&&billNos.has(String(x.sourceBillNo)));
   state.customerPayments=(state.customerPayments||[]).filter(x=>!(x.sourceBillNo&&billNos.has(String(x.sourceBillNo))));
   if(nativeBridgePresent&&window.Android?.deleteTransactionRecords&&archivedCustomerPayments.length)Android.deleteTransactionRecords("pksCustomerPayments",JSON.stringify(archivedCustomerPayments.map(x=>String(x.id||""))));
   state.vendorPayments=(state.vendorPayments||[]).filter(x=>!invoiceNos.has(String(x.sourceBillNo||x.invoiceNo||x.reference||"")));
   save();pendingArchivePackage=null;
   if(el)el.textContent="Archive exported. Selected bills were removed from active transaction storage. Keep the ZIP safely; it is required to view these bills again.";
   showNotice("Archive completed. Keep both the ZIP and summary PDF. To view archived bills later, import the ZIP into this same shop.","Archive Complete");
 },"Finalize Archive");
};

function configureAutomaticBackup(mode){const field=$("autoBackupHours"),hours=Number(field?.value||12);if(!Number.isInteger(hours)||hours<1||hours>720){showNotice("Enter a whole number of hours from 1 to 720.","Backup Schedule");field?.focus();return;}if(window.Android?.configureAutoBackup)Android.configureAutoBackup(mode,String(hours));else $("autoBackupStatus").textContent="Automatic backup is available in the Android app.";}
$("autoBackupDeviceBtn")?.addEventListener("click",()=>configureAutomaticBackup("device"));
$("autoBackupDriveBtn")?.addEventListener("click",()=>configureAutomaticBackup("drive"));
window.setAutoBackupStatus=function(message){const el=$("autoBackupStatus");if(el)el.textContent=String(message||"");};
try{window.Android?.refreshAutoBackupStatus?.();}catch(e){}

if($("backupNowBtn")) $("backupNowBtn").onclick=()=>{
  const btn=$("backupNowBtn"), status=$("backupStatus");
  if(!window.Android || typeof window.Android.backupData!=="function"){
    status.textContent="Create Backup ZIP requires the installed SiddhiBill Android app. Open this page inside the app and try again.";
    return;
  }
  status.textContent="Preparing your backup… Please keep SiddhiBill open.";
  btn.disabled=true;
  try{
    const ownerBackup={version:1,shops:JSON.parse(localStorage.getItem("dukaan_owner_shops")||"[]"),note:"Owner private key is never included in backup."};
    // Pass the owner data with the backup request to avoid a race between two JS bridge calls.
    Android.backupData(JSON.stringify(ownerBackup));
  }catch(e){
    status.textContent="Could not start backup: "+String(e?.message||e);
    btn.disabled=false;
  }
};
window.setNativeBackupStatus=function(message, finished){
  const status=$("backupStatus"), btn=$("backupNowBtn");
  if(status)status.textContent=String(message||"");
  if(btn && finished)btn.disabled=false;
};
if($("restoreBackupBtn")) $("restoreBackupBtn").onclick=()=>{
  showConfirm("Restore will replace the current local shop data on this phone. Continue?",()=>{if(window.Android?.restoreData){$("backupStatus").textContent="Choose your backup ZIP...";Android.restoreData();}else $("backupStatus").textContent="Restore is available in the Android APK.";},"Restore Backup");
};

// CSV import/export: supports quoted commas and doubled quotes, validates rows, and merges by natural key.
function parseCsv(text){
 const rows=[];let row=[],field='',quoted=false;const t=String(text||'').replace(/^\uFEFF/,'');
 for(let i=0;i<t.length;i++){const c=t[i];if(quoted){if(c==='"'&&t[i+1]==='"'){field+='"';i++;}else if(c==='"')quoted=false;else field+=c;}else if(c==='"')quoted=true;else if(c===','){row.push(field);field='';}else if(c==='\n'){row.push(field);if(row.some(x=>x.trim()))rows.push(row);row=[];field='';}else if(c!=='\r')field+=c;}
 row.push(field);if(row.some(x=>x.trim()))rows.push(row);if(!rows.length)return {headers:[],records:[]};
 const headers=rows.shift().map(x=>String(x||'').trim().toLowerCase().replace(/[ _-]+/g,''));
 return {headers,records:rows.map(r=>Object.fromEntries(headers.map((h,i)=>[h,String(r[i]??'').trim()]))) };
}
function csvEscape(v){const s=String(v??'');return /[",\r\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;}
function exportCsv(filename,headers,rows){const csv=[headers.map(csvEscape).join(','),...rows.map(r=>headers.map(h=>csvEscape(r[h])).join(','))].join('\r\n');if(window.Android?.saveExportFile){Android.saveExportFile(btoa(unescape(encodeURIComponent(csv))),filename);}else{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}}
function readCsvInput(id,handler){const el=$(id);if(!el)return;el.value='';el.onchange=()=>{const f=el.files?.[0];if(!f)return;const reader=new FileReader();reader.onload=()=>{try{handler(String(reader.result||''));}catch(e){showNotice(e.message||'Could not import CSV.','CSV Import');}};reader.onerror=()=>showNotice('Could not read the selected CSV file.','CSV Import');reader.readAsText(f);};}
function importProductsCsv(text){const {headers,records}=parseCsv(text);const has=k=>headers.includes(k);if(!has('name')&&!has('productname'))throw Error('CSV needs a Name or Product Name column.');let added=0,updated=0,skipped=0;for(const r of records){const name=(r.name||r.productname||r.itemname||'').trim();if(!name){skipped++;continue;}const rateText=r.rate||r.sellingprice||r.price||'0',rate=Number(rateText||0);if(!Number.isFinite(rate)||rate<0){skipped++;continue;}const unit=r.unit||r.uom||'piece',hsn=r.hsn||'',barcode=r.barcode||r.ean||r.upc||'',taxRate=Number(r.taxrate||r.gst||0);const idx=state.products.findIndex(p=>String(p.name||'').trim().toLowerCase()===name.toLowerCase());const record={...(idx>=0?state.products[idx]:{}),name,rate,unit,hsn,barcode,taxRate:Number.isFinite(taxRate)?taxRate:0};if(idx>=0){state.products[idx]=record;updated++;}else{state.products.push(record);added++;}}save();renderProducts();renderDatalist();renderOcrVocabulary();showNotice(`Products CSV imported. Added: ${added}, updated: ${updated}, skipped: ${skipped}.`,'CSV Import');}
function importCustomersCsv(text){const {headers,records}=parseCsv(text);if(!headers.some(h=>['name','customername','customer'].includes(h)))throw Error('CSV needs a Name or Customer Name column.');let added=0,updated=0,skipped=0;for(const r of records){const name=(r.name||r.customername||r.customer||'').trim();if(!name){skipped++;continue;}const phone=normalizePhone(r.phone||r.mobile||r.mobilenumber||''),opening=Number(r.openingbalance||r.opening||0);const idx=state.customers.findIndex(c=>String(c.name||'').trim().toLowerCase()===name.toLowerCase()||(phone&&normalizePhone(c.phone)===phone));const record={...(idx>=0?state.customers[idx]:{}),name,phone,gstin:r.gstin||r.gst||'',state:r.state||'',notes:r.notes||r.note||'',openingBalance:Number.isFinite(opening)?opening:0};if(idx>=0){state.customers[idx]=record;updated++;}else{state.customers.push(record);added++;}}save();renderCustomerDatalist();renderCustomers();showNotice(`Customers CSV imported. Added: ${added}, updated: ${updated}, skipped: ${skipped}.`,'CSV Import');}
function importUnitsCsv(text){const {headers,records}=parseCsv(text);if(!headers.some(h=>['name','unit','unitname'].includes(h)))throw Error('CSV needs a Name or Unit column.');const arr=ensureUnitCatalog();let added=0,updated=0,skipped=0;for(const r of records){const name=(r.name||r.unit||r.unitname||'').trim();if(!name){skipped++;continue;}const aliases=[...new Set([name.toLowerCase(),...(r.aliases||r.alias||'').split(/[;|/]+/).map(x=>x.trim().toLowerCase()).filter(Boolean)])];const idx=arr.findIndex(u=>String(u.name||'').trim().toLowerCase()===name.toLowerCase());if(idx>=0){arr[idx]={...arr[idx],name,aliases};updated++;}else{arr.push({name,aliases});added++;}}state.settings.unitCatalog=arr;state.settings.customUnits=arr.map(u=>({name:u.name,aliases:[...(u.aliases||[])]}));save();renderCustomUnits();refreshUnitControls();renderOcrVocabulary();showNotice(`Units CSV imported. Added: ${added}, updated: ${updated}, skipped: ${skipped}.`,'CSV Import');}
$('productCsvImportBtn')?.addEventListener('click',()=>$('productCsvInput')?.click());readCsvInput('productCsvInput',importProductsCsv);
$('customerCsvImportBtn')?.addEventListener('click',()=>$('customerCsvInput')?.click());readCsvInput('customerCsvInput',importCustomersCsv);
$('unitsCsvImportBtn')?.addEventListener('click',()=>$('unitsCsvInput')?.click());readCsvInput('unitsCsvInput',importUnitsCsv);
$('productCsvExport')?.addEventListener('click',()=>exportCsv('SiddhiBill_Products.csv',['name','rate','unit','hsn','taxRate'],state.products));
$('customerCsvExport')?.addEventListener('click',()=>exportCsv('SiddhiBill_Customers.csv',['name','phone','gstin','state','notes','openingBalance'],state.customers));
$('unitsCsvExport')?.addEventListener('click',()=>exportCsv('SiddhiBill_Units.csv',['name','aliases'],ensureUnitCatalog().map(u=>({name:u.name,aliases:(u.aliases||[]).join('; ')}))));

// Same-shop offline sync bundle. Record collections merge without replacing local state.
function syncKey(kind,r){if(kind==='units')return String(r.name||'').trim().toLowerCase();if(kind==='products')return String(r.name||'').trim().toLowerCase();if(kind==='customers')return String(r.name||'').trim().toLowerCase()+'|'+normalizePhone(r.phone||'');if(kind==='vendors')return String(r.name||'').trim().toLowerCase();if(kind==='bills')return [r.billNo||r.id||'',r.date||'',String(r.customer||'').trim().toLowerCase(),Number(r.total||0).toFixed(2)].join('|');if(kind==='purchases')return String(r.id||r.invoiceNo||r.billNo||JSON.stringify(r));if(kind==='vendorPayments')return String(r.id||[r.date,r.vendorId,r.amount,r.note].join('|'));if(kind==='customerPayments')return String(r.id||[r.date,r.customer,r.amount,r.note].join('|'));return String(r.id||[r.date,r.customer||r.vendor,r.amount,r.note].join('|'));}
function mergeCollection(local,incoming,kind){const out=Array.isArray(local)?local.slice():[],map=new Map();out.forEach((r,i)=>map.set(syncKey(kind,r),i));let added=0,updated=0;for(const r of (Array.isArray(incoming)?incoming:[])){const k=syncKey(kind,r);if(!k||k==='|')continue;if(map.has(k)){const i=map.get(k);out[i]={...out[i],...r};updated++;}else{map.set(k,out.length);out.push(r);added++;}}return {out,added,updated};}
function inventoryMovementSyncKey(m){if(m?.id)return String(m.id);return [m?.shopKey||"",m?.productId||m?.productName||"",m?.type||"",m?.sourceType||"",m?.sourceId||"",m?.date||"",Number(m?.qty||0),Number(m?.unitCost||0),m?.reason||""].join("|");}
function mergeInventoryMovements(local,incoming){const out=Array.isArray(local)?local.slice():[],seen=new Set(out.map(inventoryMovementSyncKey));let added=0;for(const m of (Array.isArray(incoming)?incoming:[])){if(!m)continue;const k=inventoryMovementSyncKey(m);if(seen.has(k))continue;seen.add(k);out.push(m);added++;}return {out,added};}
function makeSyncBundle(){
 const shopName=String(state.settings.shopName||'').trim().toLowerCase();
 if(!shopName)throw Error('Set the shop name in Settings before creating a sync file.');
 const units=ensureUnitCatalog().map(u=>{
  const name=String(u.name||'').trim();
  const aliases=[...new Set([...(Array.isArray(u.aliases)?u.aliases:[]).map(a=>String(a||'').trim().toLowerCase()).filter(Boolean),name.toLowerCase()].filter(Boolean))];
  return {name,aliases};
 }).filter(u=>u.name);
 return {format:'SiddhiBillSync',version:3,shopName,createdAt:new Date().toISOString(),data:{products:state.products,bills:state.bills,customers:state.customers,vendors:state.vendors,purchases:state.purchases,vendorPayments:state.vendorPayments,customerPayments:state.customerPayments,teamMembers:state.teamMembers||[],teamAttendance:state.teamAttendance||[],teamPayments:state.teamPayments||[],brokers:state.brokers||[],brokerCommissions:state.brokerCommissions||[],brokerPayments:state.brokerPayments||[],estimates:state.estimates||[],expenses:state.expenses||[],inventoryMovements:state.inventoryMovements||[],unitCatalog:units,customUnits:units,gstCompliance:state.gstCompliance||{},ocrProductAliases:ensureOcrAliases()}};
}
$('createSyncBtn')?.addEventListener('click',()=>{try{const bundle=JSON.stringify(makeSyncBundle());if(window.Android?.shareSyncFile){Android.shareSyncFile(btoa(unescape(encodeURIComponent(bundle))));$('syncStatus').textContent='Choose WhatsApp, Nearby Share, Drive or another file-sharing app.';}else{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([bundle],{type:'application/json'}));a.download='SiddhiBill_Shop_Sync.siddhisync';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);$('syncStatus').textContent='Sync file created.';}}catch(e){$('syncStatus').textContent='Could not create sync file: '+e.message;}});
$('importSyncBtn')?.addEventListener('click',()=>$('syncFileInput')?.click());
function importSyncBundleFromText(text){try{const raw=String(text||'').replace(/^\uFEFF/,'').trim();const b=JSON.parse(raw);if(b.format!=='SiddhiBillSync'||!b.data)throw Error('This is not a SiddhiBill Sync file.');const localShop=String(state.settings.shopName||'').trim().toLowerCase();if(localShop&&b.shopName&&localShop!==b.shopName)throw Error('Shop name does not match. Sync only between devices belonging to the same shop.');if(Array.isArray(b.data.purchaseAttachments)&&window.Android?.restoreSyncAttachments){Android.restoreSyncAttachments(JSON.stringify(b.data.purchaseAttachments));}let totalA=0,totalU=0;for(const k of ['products','bills','customers','vendors','purchases','vendorPayments','customerPayments','teamMembers','teamAttendance','teamPayments','brokers','brokerCommissions','brokerPayments','estimates','expenses']){const m=mergeCollection(state[k],b.data[k],k);state[k]=m.out;totalA+=m.added;totalU+=m.updated;}if(Array.isArray(b.data.inventoryMovements)){const movementMerge=mergeInventoryMovements(state.inventoryMovements,b.data.inventoryMovements);state.inventoryMovements=movementMerge.out;totalA+=movementMerge.added;if(typeof rebuildInventoryBalances==="function")rebuildInventoryBalances();}if(b.data.gstCompliance&&typeof b.data.gstCompliance==='object'){state.gstCompliance={...(state.gstCompliance||{}),...b.data.gstCompliance};} if(nativeBridgePresent&&window.Android?.saveTransactionRecords){Android.saveTransactionRecords("pksBills",JSON.stringify(state.bills));Android.saveTransactionRecords("pksPurchases",JSON.stringify(state.purchases));if(Array.isArray(b.data.customerPayments))Android.saveTransactionRecords("pksCustomerPayments",JSON.stringify(state.customerPayments));if(Array.isArray(b.data.inventoryMovements))Android.saveTransactionRecords("pksInventoryMovements",JSON.stringify(b.data.inventoryMovements));} const incomingUnits=(Array.isArray(b.data.unitCatalog)&&b.data.unitCatalog.length)?b.data.unitCatalog:(Array.isArray(b.data.customUnits)?b.data.customUnits:[]);const unitMap=new Map();[...ensureUnitCatalog(),...incomingUnits].forEach(u=>{const name=String(u?.name||'').trim();if(!name)return;const key=name.toLowerCase(),aliases=[...new Set([...(Array.isArray(u.aliases)?u.aliases:[]).map(a=>String(a||'').trim().toLowerCase()).filter(Boolean),key])];if(unitMap.has(key)){const prior=unitMap.get(key);prior.aliases=[...new Set([...prior.aliases,...aliases])];}else unitMap.set(key,{name,aliases});});const units=[...unitMap.values()];state.settings.unitCatalog=units;state.settings.customUnits=units.map(u=>({name:u.name,aliases:[...(u.aliases||[])]}));if(b.data.ocrProductAliases&&typeof b.data.ocrProductAliases==='object')state.settings.ocrProductAliases={...ensureOcrAliases(),...b.data.ocrProductAliases};save();renderProducts();renderDatalist();renderCustomerDatalist();renderCustomers();renderCustomUnits();refreshUnitControls();renderOcrVocabulary();$('syncStatus').textContent=`Sync complete. Added ${totalA} records; merged ${totalU} matching records. Shop settings, logo, printer setup and local activation were kept on this phone.`;return 'OK';}catch(e){$('syncStatus').textContent='Sync failed: '+e.message;return 'ERROR: '+e.message;}}
window.importSyncBundleFromText=importSyncBundleFromText;
$('syncFileInput')?.addEventListener('change',()=>{const input=$('syncFileInput');const f=input?.files?.[0];if(!f)return;const reader=new FileReader();reader.onload=()=>{importSyncBundleFromText(String(reader.result||''));};reader.readAsText(f);input.value='';});

// Quick List OCR: one button offers camera capture or choosing an image/PDF.
$('quickListUploadBtn')?.addEventListener('click',()=>{
 if(window.Android?.chooseQuickListSource){Android.chooseQuickListSource();return;}
 $('quickListFileInput')?.click();
});
$('quickListFileInput')?.addEventListener('change',()=>{
 const f=$('quickListFileInput').files?.[0]; if(!f)return;
 if(/\.txt$/i.test(f.name)||f.type==='text/plain'){
   const reader=new FileReader();reader.onload=()=>window.receiveQuickListOCR(String(reader.result||''));reader.readAsText(f);$('quickListFileInput').value='';return;
 }
 if(/\.pdf$/i.test(f.name)||f.type==='application/pdf'){
   showNotice('PDF OCR is available in the SiddhiBill Android app.','Quick List OCR'); $('quickListFileInput').value=''; return;
 }
 const reader=new FileReader();
 reader.onload=()=>{const im=new Image();im.onload=()=>{const c=document.createElement('canvas');const scale=Math.min(1,1800/Math.max(im.width,im.height));c.width=Math.round(im.width*scale);c.height=Math.round(im.height*scale);c.getContext('2d').drawImage(im,0,0,c.width,c.height);const data=c.toDataURL('image/jpeg',0.85).split(',')[1];if(window.Android?.recognizeQuickListImage)Android.recognizeQuickListImage(data);else showNotice('On-device OCR is available in the Android app.','Quick List OCR');};im.src=reader.result;};
 reader.readAsDataURL(f); $('quickListFileInput').value='';
});
window.receiveQuickListOCR=function(text){
 const box=$('quickList');const extracted=String(text||'').trim();
 if(!extracted){showNotice('No readable text found. Try a clearer, straight-on photo or PDF.','Quick List OCR');return;}
 const fixNumericWord=v=>{const s=String(v||'');return /\d/.test(s)?s.replace(/[oO]/g,'0').replace(/[lI|]/g,'1'):s;};
 const cleanLine=v=>String(v||'').replace(/^\s*\d+\s*[.)]?\s+(?=[A-Za-z])/,'').replace(/[|]/g,' ').replace(/[—–]/g,'-').replace(/\s+/g,' ').trim();
 const unitMap={job:"Job",jobs:"Job",hour:"Hour",hours:"Hour",hr:"Hour",hrs:"Hour",meter:"Meter",metre:"Meter",m:"Meter",foot:"Foot",feet:"Foot",ft:"Foot",roll:"Roll",rolls:"Roll",set:"Set",sets:"Set",kg:'Kg',k:'Kg',g:'Gram',gm:'Gram',gram:'Gram',grams:'Gram',l:'Litre',ltr:'Litre',litre:'Litre',liter:'Litre',ml:'Ml',pc:'Piece',pcs:'Piece',piece:'Piece',pieces:'Piece',pkt:'Packet',pack:'Pack',packet:'Packet',btl:'Bottle',bottle:'Bottle',bottles:'Bottle',b:'Bottle',pair:'Pair',set:'Set',doz:'Dozen',box:'Box'};
 const normalizeUnit=u=>{const token=String(u||'').toLowerCase().trim();for(const d of getUnitDefinitions())if(d.aliases.includes(token))return d.name;return unitMap[token]||u;};
 // Contextual numeric repair: only apply OCR glyph substitutions to fields whose
 // position in a recognized Item/Qty/Unit/Rate row makes them numeric.
 const numericField=(value,allowLetterOnly=false)=>{
   let s=String(value||'').trim();
   if(!s) return '';
   if(!/[0-9]/.test(s) && !allowLetterOnly) return s;
   return s.replace(/[oO]/g,'0').replace(/[lI|]/g,'1');
 };
 const numericQuantity=value=>{const s=String(value||'').trim();if(/^[zZ]$/.test(s))return '2';return numericField(s,/^[lIi|]$/.test(s));};
 const compactProductText=s=>ocrNorm(s).replace(/\s+/g,'');
 // Normalize common digit/letter confusion only for catalogue comparison; output remains canonical.
 const productMatchKey=s=>compactProductText(s).replace(/0/g,'o');
 const editDistance=(a,b)=>{a=compactProductText(a);b=compactProductText(b);let prev=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){let cur=[i];for(let j=1;j<=b.length;j++)cur[j]=Math.min(cur[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));prev=cur;}return prev[b.length];};
 const matchShopProduct=name=>{
   const source=String(name||'').trim(); if(!source) return source;
   const sharedCorrection=typeof canonicalizeOcrProductName==='function'?canonicalizeOcrProductName(source):source;if(sharedCorrection!==source)return sharedCorrection;
   // Use the same live vocabulary shown in Settings, including owner-confirmed aliases.
   const vocab=getOcrProductVocabulary();
   const products=vocab.map(v=>({name:v.name,aliases:v.aliases||[]}));
   const aliases=ensureOcrAliases();
   let best=null,bestScore=Infinity,bestRatio=Infinity;
   const sourceNorm=productMatchKey(source);
   for(const entry of products){
     const ownerHints=String(state.settings.ocrOwnerKeywords||"").split(/[\n,;|]+/).map(x=>x.trim()).filter(Boolean);
     const candidates=[entry.name,...entry.aliases,...ownerHints.filter(h=>ocrNorm(h)===ocrNorm(entry.name)||ocrNorm(h).startsWith(ocrNorm(entry.name)+" "))];
     for(const candidate of candidates){
       const candidateNorm=productMatchKey(candidate); if(!candidateNorm)continue;
       const d=(()=>{let a=sourceNorm,b=candidateNorm,prev=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){let cur=[i];for(let j=1;j<=b.length;j++)cur[j]=Math.min(cur[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));prev=cur;}return prev[b.length];})(); const max=Math.max(sourceNorm.length,candidateNorm.length);
       // Allow 1 error for short names and up to 2 for longer names. Require a strong
       // normalized similarity so unrelated catalogue entries are not forced matches.
       const threshold=max>=8?2:(max>=5?1:0), ratio=d/Math.max(1,max);
       if(d<=threshold && ratio<=0.22 && (d<bestScore || (d===bestScore&&ratio<bestRatio))){best=entry.name;bestScore=d;bestRatio=ratio;}
     }
   }
   if(best) return best;
   // Shopkeeper-maintained keywords are a second vocabulary source. When a recognized
   // product token is close to one of these hints, emit the owner's canonical spelling.
   const ownerHints=String(state.settings.ocrOwnerKeywords||"").split(/[\n,;|]+/).map(x=>x.trim()).filter(Boolean);
   let hintBest=null,hintDistance=Infinity;
   for(const hint of ownerHints){const hn=productMatchKey(hint);if(!hn)continue;const d=editDistance(source, hint),max=Math.max(sourceNorm.length,hn.length),threshold=max>=8?2:(max>=5?1:0);if(d<=threshold&&d/max<=0.22&&d<hintDistance){hintBest=hint;hintDistance=d;}}
   return hintBest||source;
 };
 const rows=[];
 for(let raw of extracted.split(/\r?\n/)){
   let line=cleanLine(raw);if(!line)continue;
   // Normalize spaced dash separators and currency labels before field parsing.
   // Only remove dashes surrounded by spaces, preserving names such as T-Shirt.
   line=line.replace(/\s+-\s+/g,' ').replace(/\s+-\s*(?=\d)/g,' ').replace(/\b(?:rs\.?|inr)\s*/gi,' ').replace(/₹\s*/g,' ').replace(/\s+/g,' ').trim();
   // Some notes repeat the quantity immediately before the unit (e.g. "Chana 1 1 kg 100").
   // Collapse only identical adjacent numeric tokens before a known unit.
   const dupUnitAlt=[...new Set([...Object.keys(unitMap),...getUnitDefinitions().flatMap(d=>d.aliases||[]),...getUnitDefinitions().map(d=>d.name.toLowerCase())])].filter(Boolean).sort((a,b)=>b.length-a.length).map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join('|');
   if(dupUnitAlt) line=line.replace(new RegExp('\\b(\\d+(?:\\.\\d+)?)\\s+\\1\\s*('+dupUnitAlt+')\\b','i'),'$1 $2');
   line=line.replace(/\bqty\s*:?\s*/gi,' ').replace(/\bquantity\s*:?\s*/gi,' ').replace(/\s+/g,' ').trim();
   line=applyOcrProductAliasesToLine(line);
   if(/^(bhagyalaxmi|quick list|ocr test|item\s*(?:\/|,|\|)\s*qty|please keep each|please read items|no\.?$|unit$|item$|price\s*\(?₹?\)?|qty$|quantity$)/i.test(line))continue;
   // First pass: recognize a unit-anchored row even when handwriting OCR confuses
   // 1/I/l and 0/O in quantity/rate fields (e.g. "Chane lkg lo0"). The unit marks
   // field boundaries; product names are never globally character-substituted.
   const allUnitAliases=[...new Set([...Object.keys(unitMap),...getUnitDefinitions().flatMap(d=>d.aliases||[]),...getUnitDefinitions().map(d=>d.name.toLowerCase())])].filter(Boolean).sort((a,b)=>b.length-a.length);
   const unitAlt=allUnitAliases.map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join('|');
   if(unitAlt){
     // Vocabulary-first recovery: allow common handwritten OCR confusions in the
     // quantity and rate fields, then match the product prefix against live shop vocabulary.
     // This runs before generic parsing so a known multiword product (e.g. Toor Dal)
     // is canonicalized before the row is emitted.
     const vocabFirst=new RegExp('^(.+?)\\s+([0-9lIi|zZ]+)\\s*('+unitAlt+')\\s+([0-9OoIl|]+)(?:\\s+(\\d+(?:\\.\\d+)?%?))?$','i').exec(line);
     if(vocabFirst){
       const qty=numericQuantity(vocabFirst[2]);
       const rate=numericField(vocabFirst[4],true);
       if(/^\d+(?:\.\d+)?$/.test(qty)&&/^\d+(?:\.\d+)?$/.test(rate)){
         const product=matchShopProduct(vocabFirst[1].trim());
         const tax=vocabFirst[5]?' '+vocabFirst[5]:'';
         rows.push(`${product} ${qty} ${normalizeUnit(vocabFirst[3])} ${rate}${tax}`);continue;
       }
     }
     const anchored=new RegExp('^(.+?)\\s+([0-9lIi|zZ]+)\\s*('+unitAlt+')\\s+([0-9OoIl|]+)(?:\\s+(\\d+(?:\\.\\d+)?%?))?$','i').exec(line);
     if(anchored){
       let item=anchored[1].trim().replace(/^[0-9]+[.)]?\\s*/, '');
       let qtyToken=anchored[2], rateToken=anchored[4], taxToken=anchored[5]||'';
       // Only a lone ambiguous glyph in a quantity is inferred as 1 because the
       // quantity field is immediately followed by a recognized unit.
       let qty=numericQuantity(qtyToken);
       let rate=numericField(rateToken, true);
       if(/^0+$/.test(qty)) qty='0';
       if(/^\d+(?:\.\d+)?$/.test(qty) && /^\d+(?:\.\d+)?$/.test(rate)){
         item=matchShopProduct(item);
         rows.push(`${item} ${qty} ${normalizeUnit(anchored[3])} ${rate}${taxToken?' '+taxToken:''}`);continue;
       }
     }
   }
   // Preserve ambiguous OCR glyphs in product names. Numeric tokens are normalized only
   // when they already contain a digit; an all-letter token such as 'loo' is not guessed as 100.
   line=line.replace(/^\s*\d+\s*[.)]?\s+(?=[A-Za-z])/,'').replace(/\bQty\s*:?\s*/gi,' ').replace(/\bRs\.?\s*/gi,'').replace(/\s+/g,' ').trim();
   // Explicit handwritten/typed shorthand: Shampoo 1b 200 or Shampoo lb 200 => one bottle.
   let m=line.match(/^(.+?)\s+([lI]?\s*[1]?)\s*(b|btl|bottle)\s+(\d+(?:\.\d+)?)$/i);
   if(m){let qty=1;rows.push(`${m[1].trim()} ${qty} Bottle ${m[4]}`);continue;}
   // General row: Item, qty, unit, price; tolerate merged number+unit such as 1kg, 2g, 1pkt.
   m=line.match(/^(.+?)\s+(\d+(?:\.\d+)?)\s*(kg|kgs|gm|gram|grams|g|ltr|litre|liter|ml|pkt|packet|pack|btl|bottle|b|pc|pcs|piece|pieces|pair|set|doz|box)\s+(\d+(?:\.\d+)?)$/i);
   if(m){let item=m[1].trim(),qty=Number(fixNumericWord(m[2])),unit=m[3].toLowerCase(),price=fixNumericWord(m[4]);rows.push(`${item} ${qty} ${normalizeUnit(unit)} ${price}`);continue;}
   // Product size before quantity/unit: Elaichi 20g 1pkt 50 -> Elaichi 20g 1 Packet 50.
   m=line.match(/^(.+?)\s+(\d+(?:\.\d+)?)\s*(g|gm|kg|ml)\s+(\d+)\s*(pkt|packet|pack|btl|bottle|b|pc|pcs|piece|pair|set)\s+(\d+(?:\.\d+)?)$/i);
   if(m){rows.push(`${m[1].trim()} ${m[2]}${m[3]} ${fixNumericWord(m[4])} ${normalizeUnit(m[5])} ${fixNumericWord(m[6])}`);continue;}
   // A compact row with separate number and unit tokens; fix l/I as 1 and O as 0 in price.
   m=line.match(/^(.+?)\s+([lI]?\d+(?:\.\d+)?)\s*(kg|kgs|gm|gram|g|pkt|packet|pack|btl|bottle|b|pc|pcs|piece|pair|set|box)\s+([0-9OoIl|.]+)$/i);
   if(m){let qty=Number(fixNumericWord(m[2])),unit=m[3].toLowerCase(),price=fixNumericWord(m[4]);rows.push(`${m[1].trim()} ${qty} ${normalizeUnit(unit)} ${price}`);continue;}
   // Labeled handwritten rows: Item Qty: 2 Piece - Rs. 120
   m=line.match(/^(.+?)\s*(?:[-–]\s*)?qty\s*:?\s*([lI]?[0-9]+)\s*(?:[-–,]\s*)?(kg|kgs|gm|gram|grams|g|pkt|packet|pack|btl|bottle|b|pc|pcs|piece|pair|set|box)?\s*(?:[-–,]\s*)?(?:rs\.?|inr|₹)?\s*([0-9OoIl|]+)$/i);
   if(m){const item=m[1].trim();const q=fixNumericWord(m[2]);const u=normalizeUnit(m[3]||'Piece');const price=fixNumericWord(m[4]);rows.push(`${item} ${q} ${u} ${price}`);continue;}
   // Table rows may include a row number. Prefer the full four-field pattern first.
   m=line.match(/^\d+\s+(.+?)\s+(\d+(?:\.\d+)?)\s+(kg|kgs|g|gm|gram|pkt|packet|pack|btl|bottle|piece|pc|pcs|pair|set|box)\s+(\d+(?:\.\d+)?)$/i);
   if(m){rows.push(`${m[1].trim()} ${m[2]} ${normalizeUnit(m[3])} ${m[4]}`);continue;}
   // Some OCR table rows omit the quantity token (e.g. '4 Imitation Earrings Pair 250').
   m=line.match(/^\d+\s+(.+?)\s+(kg|kgs|g|gm|gram|pkt|packet|pack|btl|bottle|piece|pc|pcs|pair|set|box)\s+(\d+(?:\.\d+)?)$/i);
   if(m){rows.push(`${m[1].trim()} 1 ${normalizeUnit(m[2])} ${m[3]}`);continue;}
   // Non-numbered table rows, in Item Qty Unit Price order.
   m=line.match(/^(.+?)\s+(\d+(?:\.\d+)?)\s+(kg|kgs|g|gm|gram|pkt|packet|pack|btl|bottle|piece|pc|pcs|pair|set|box)\s+(\d+(?:\.\d+)?)$/i);
   if(m){rows.push(`${m[1].trim()} ${m[2]} ${normalizeUnit(m[3])} ${m[4]}`);continue;}
   // Common handwritten shorthand without explicit Qty label: Sugar 1Kg 60, Rice 2kg 70.
   m=line.match(/^(.+?)\s+([lI]?\d+(?:\.\d+)?)\s*(kg|kgs|g|gm|gram|grams|ltr|litre|liter|ml|pkt|packet|pack|btl|bottle|pc|pcs|piece|pieces|pair|set|box)\s+(\d+(?:\.\d+)?)$/i);
   if(m){let item=m[1].trim(),qty=Number(fixNumericWord(m[2])),unit=m[3].toLowerCase(),price=m[4];item=item.replace(/^[0-9]+[.)]?\s*/,'');rows.push(`${item} ${qty} ${normalizeUnit(unit)} ${price}`);continue;}
   // Table row where quantity is genuinely absent: Imitation Earrings Pair 250 => quantity 1.
   m=line.match(/^(.+?)\s+(kg|kgs|g|gm|gram|grams|ltr|litre|liter|ml|pkt|packet|pack|btl|bottle|pc|pcs|piece|pieces|pair|set|box)\s+(\d+(?:\.\d+)?)$/i);
   if(m){rows.push(`${m[1].trim()} 1 ${normalizeUnit(m[2])} ${m[3]}`);continue;}
   // Respect this shop's own configured units, including units not in the generic starter list.
   const configuredUnitPattern=[...new Set(getUnitDefinitions().flatMap(d=>d.aliases).filter(Boolean))].sort((a,b)=>b.length-a.length).map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|");
   if(configuredUnitPattern){
     m=new RegExp("^(.+?)\\s+(\\d+(?:\\.\\d+)?)\\s*("+configuredUnitPattern+")\\s+(\\d+(?:\\.\\d+)?)$","i").exec(line);
     if(m){rows.push(`${m[1].trim()} ${fixNumericWord(m[2])} ${normalizeUnitName(m[3])} ${fixNumericWord(m[4])}`);continue;}
     m=new RegExp("^(.+?)\\s+("+configuredUnitPattern+")\\s+(\\d+(?:\\.\\d+)?)$","i").exec(line);
     if(m){rows.push(`${m[1].trim()} 1 ${normalizeUnitName(m[2])} ${fixNumericWord(m[3])}`);continue;}
   }
   // Keep ambiguous lines intact for user review; never silently invent a price or quantity.
   rows.push(line);
 }
 const result=rows.join('\n');
 box.value=(box.value.trim()?box.value.trim()+'\n':'')+result;box.focus();
 showNotice('OCR text formatted for Quick List where confidently recognized. Review any ambiguous rows before adding. No products were created.','Quick List OCR');
};

// SiddhiBill starter catalogues. Only a genuinely empty/new shop is prompted;
// existing products, bills, customers, and restored data are never overwritten.
const SIDDHI_STARTERS={
 two_wheeler:{label:'Two-wheeler service & spare parts',units:['piece','set','liter','ml','pair','pack','bottle'],categories:{'Engine & Service':['Engine Oil','Oil Filter','Air Filter','Spark Plug','Engine Flush','Coolant','Brake Fluid','Grease','Chain Lubricant','Service Labour'],'Brakes & Drive':['Brake Shoe','Brake Pad','Clutch Plate Set','Clutch Cable','Accelerator Cable','Chain Sprocket Kit','Drive Belt'],'Electrical':['Headlight Bulb','Indicator Bulb','Fuse','Battery','Horn','Wiring Kit'],'Tyres & Body':['Tube','Tyre','Mirror','Lever Set','Brake Cable','Air Valve']},products:['Engine Oil','Oil Filter','Air Filter','Spark Plug','Coolant','Brake Fluid','Grease','Chain Lubricant','Brake Shoe','Brake Pad','Clutch Plate Set','Clutch Cable','Accelerator Cable','Chain Sprocket Kit','Headlight Bulb','Indicator Bulb','Fuse','Battery','Horn','Tube','Tyre','Mirror','General Service Labour','Oil Change Labour','Puncture Repair Labour']},
 kirana:{label:'Grocery / Kirana',units:['kg','gram','piece','packet','pack','box','liter','ml','dozen'],categories:{'Grains & Pulses':['Rice','Wheat Flour','Toor Dal','Moong Dal','Chana Dal','Poha','Suji'],'Daily Essentials':['Sugar','Salt','Tea','Cooking Oil','Ghee','Jaggery'],'Packaged Foods':['Biscuits','Noodles','Namkeen','Chips','Bread'],'Home Care':['Detergent','Dishwash Liquid','Floor Cleaner','Toilet Cleaner']},products:['Rice','Wheat Flour','Toor Dal','Moong Dal','Chana Dal','Poha','Suji','Sugar','Salt','Tea','Coffee','Cooking Oil','Ghee','Jaggery','Biscuits','Noodles','Namkeen','Chips','Bread','Milk','Curd','Detergent','Dishwash Liquid','Floor Cleaner','Toilet Cleaner']},
 general:{label:'General store',units:['piece','packet','pack','box','bottle','liter','ml','dozen'],categories:{'Personal Care':['Bath Soap','Shampoo','Toothpaste','Toothbrush','Hair Oil'],'Household':['Detergent','Dishwash Bar','Floor Cleaner','Garbage Bags','Matchbox'],'Stationery':['Notebook','Pen','Pencil','Eraser']},products:['Bath Soap','Shampoo','Toothpaste','Toothbrush','Hair Oil','Detergent','Dishwash Bar','Floor Cleaner','Garbage Bags','Matchbox','Notebook','Pen','Pencil','Eraser','Batteries','Candles','Water Bottle','Lunch Box','Biscuits','Chips']},
 clothing:{label:'Clothing shop',units:['piece','pair','set','pack','dozen'],categories:{'Clothing':['T-Shirt','Shirt','Trouser','Jeans','Kurta','Dress','Saree','Leggings'],'Accessories':['Belt','Wallet','Cap','Socks','Scarf']},products:['T-Shirt','Shirt','Trouser','Jeans','Kurta','Dress','Saree','Leggings','Dupatta','Jacket','Shorts','Belt','Wallet','Cap','Socks','Scarf','Alteration Labour']},
 electronics:{label:'Electronics shop',units:['piece','set','box','pack'],categories:{'Devices':['Extension Board','Power Strip','LED Bulb','Emergency Light'],'Accessories':['HDMI Cable','USB Cable','Remote Control','Adapter','Charger']},products:['LED Bulb','Extension Board','Power Strip','HDMI Cable','USB Cable','Adapter','Charger','Remote Control','Battery','Power Bank','Earphones','Speaker','Emergency Light','Installation Labour','Repair Labour']},
 hardware:{label:'Hardware shop',units:['piece','box','pack','set','kg','liter','meter','foot'],categories:{'Fasteners':['Nails','Screws','Bolts','Nuts','Washers'],'Tools':['Screwdriver','Hammer','Pliers','Spanner','Drill Bit'],'Supplies':['PVC Tape','Adhesive','Sealant','Sandpaper']},products:['Nails','Screws','Bolts','Nuts','Washers','Screwdriver','Hammer','Pliers','Spanner','Drill Bit','PVC Tape','Adhesive','Sealant','Sandpaper','Paint Brush','Roller','Lock','Hinge','Door Handle','Cutting Labour']},
 mobile:{label:'Mobile accessories',units:['piece','pack','box','set'],categories:{'Power':['USB Cable','Type-C Cable','Charger','Power Bank'],'Protection':['Screen Protector','Mobile Cover'],'Audio':['Wired Earphones','Bluetooth Earbuds','Speaker']},products:['USB Cable','Type-C Cable','Lightning Cable','Charger','Power Bank','Screen Protector','Mobile Cover','Wired Earphones','Bluetooth Earbuds','Speaker','Memory Card','OTG Adapter','Car Charger','Phone Holder','SIM Ejector Pin']},
 salon:{label:'Salon / Beauty parlour',units:['piece','pack','bottle','ml','gram','set'],categories:{'Consumables':['Shampoo','Conditioner','Hair Colour','Hair Gel','Face Pack'],'Services':['Haircut','Hair Wash','Beard Trim','Facial','Hair Colour Service']},products:['Shampoo','Conditioner','Hair Colour','Hair Gel','Face Pack','Wax','Talcum Powder','Disposable Razor','Gloves','Tissue Roll','Haircut Service','Hair Wash Service','Beard Trim Service','Facial Service','Hair Colour Service']},
 other:{label:'Custom / Other',units:['piece','kg','gram','liter','ml','packet','pack','box','meter','foot','set','dozen'],categories:{},products:[]},
 electrical:{label:'Electrical shop',units:['piece','box','pack','meter','roll','set'],categories:{'Lighting':['LED Bulb','Tube Light','Panel Light'],'Wiring':['Electrical Wire','Switch','Socket','Plug Top'],'Accessories':['MCB','Distribution Board','Insulation Tape','Conduit Pipe']},products:['LED Bulb','Tube Light','Panel Light','Electrical Wire','Switch','Socket','Plug Top','MCB','Distribution Board','Insulation Tape','Conduit Pipe','Fan Regulator','Ceiling Rose','Holder','Extension Board','Installation Labour']},
 footwear:{label:'Footwear shop',units:['pair','piece','box','set'],categories:{'Footwear':['Casual Shoes','Formal Shoes','Sports Shoes','Sandals','Slippers'],'Care':['Shoe Polish','Shoe Brush','Laces','Insole']},products:['Casual Shoes','Formal Shoes','Sports Shoes','Sandals','Slippers','School Shoes','Boots','Shoe Polish','Shoe Brush','Laces','Insole']},
 restaurant:{label:'Restaurant / Food shop',units:['piece','kg','gram','liter','ml','plate','portion','pack'],categories:{'Ingredients':['Rice','Wheat Flour','Cooking Oil','Salt','Sugar','Spices'],'Packaging':['Food Container','Paper Cup','Carry Bag'],'Menu Items':['Tea','Coffee','Poha','Sandwich','Thali']},products:['Rice','Wheat Flour','Cooking Oil','Salt','Sugar','Tea','Coffee','Milk','Spices','Food Container','Paper Cup','Carry Bag','Tea (Serving)','Coffee (Serving)','Poha (Plate)','Sandwich','Thali','Delivery Charge']}
};
const SIDDHI_UNIT_ALIASES={piece:['piece','pieces','pc','pcs'],pair:['pair','pairs','pr'],set:['set','sets'],meter:['meter','metre','m'],foot:['foot','feet','ft'],plate:['plate','plates'],portion:['portion','portions']};
function starterUnitFor(name,shopType,units){
 const n=String(name||'').toLowerCase();
 if(/labour|service|repair|haircut|facial|trim|installation|delivery charge|alteration/.test(n))return 'piece';
 if(/oil|coolant|fluid|shampoo|conditioner|liquid|milk|curd|coffee|tea \(serving\)/.test(n))return units.includes('liter')?'liter':(units.includes('ml')?'ml':units[0]);
 if(/rice|flour|dal|poha|suji|sugar|salt|spices|nails|screws|nuts|washers|grease|sandpaper/.test(n))return units.includes('kg')?'kg':(units.includes('gram')?'gram':units[0]);
 if(/wire|tape|pipe|lace|cable|chain lubricant/.test(n))return units.includes('meter')?'meter':(units.includes('roll')?'roll':units[0]);
 if(/shoes|sandals|slippers|socks|earphones|gloves|brake shoe|brake pad|clutch plate/.test(n))return units.includes('pair')?'pair':(units.includes('set')?'set':units[0]);
 if(/biscuits|noodles|namkeen|chips|detergent|packet|screen protector|screws/.test(n))return units.includes('packet')?'packet':(units.includes('pack')?'pack':units[0]);
 return units.includes('piece')?'piece':units[0]||'piece';
}
function setupSiddhiStarterFlow(){
 const splash=$('siddhiSplash');
 if(splash) setTimeout(()=>{splash.style.opacity='0';setTimeout(()=>splash.remove(),220)},1500);
 const modal=$('shopTypeSetup'), select=$('starterShopType'), preview=$('starterPreview'), load=$('starterLoad');
 if(!modal||!select||!preview||!load)return;
 let initialized=getStored('siddhiStarterCatalogInitialized',false)===true;
 const hasBusinessData=state.products.length>0||state.customers.length>0||nativeStateKeySet.has("pksBills")||nativeStateKeySet.has("pksPurchases")||(!nativeBridgePresent&&(!!localStorage.getItem("pksBills")||!!localStorage.getItem("pksPurchases")));
 // Legacy installations with any business data are considered already configured.
 if(!initialized&&hasBusinessData){try{localStorage.setItem(firmStorageKey('siddhiStarterCatalogInitialized'),'true');}catch(e){}; initialized=true;}
 if(initialized)return;
 const update=()=>{const k=select.value,cat=SIDDHI_STARTERS[k];if(!cat){preview.textContent='Select a shop type to preview the starter catalogue.';load.disabled=true;return;}const count=cat.products.length;const cats=Object.keys(cat.categories);preview.innerHTML='<strong>'+esc(cat.label)+'</strong><br>'+count+' essential starter products · '+cat.units.length+' units · '+cats.length+' categories<br><span>'+esc(cats.join(', ')||'No preset categories or products; add your own items later.')+'</span>';load.disabled=false;};
 select.addEventListener('change',update);
 $('starterSkip')?.addEventListener('click',()=>{modal.classList.add('hidden');});
 load.addEventListener('click',()=>{
  const key=select.value,cat=SIDDHI_STARTERS[key];if(!cat||load.disabled)return;
  // Snapshot and roll back if any write/initialization step fails.
  const oldProducts=state.products.slice(),oldSettings=JSON.parse(JSON.stringify(state.settings));
  try{
   const existing=new Set(state.products.map(p=>String(p.name||'').trim().toLowerCase()));
   const added=cat.products.filter(n=>!existing.has(n.toLowerCase())).map(n=>({name:n,rate:0,unit:starterUnitFor(n,key,cat.units),category:Object.keys(cat.categories).find(c=>cat.categories[c].includes(n))||'General',taxRate:0,hsn:'',openingStock:0,stockTracked:!/(labour|service|repair|installation|haircut|facial|wash service|trim service|colour service)/i.test(n),active:true,starterCatalogue:key}));
   state.products=state.products.concat(added);
   const defs=ensureUnitCatalog().map(u=>({name:u.name,aliases:[...(u.aliases||[])]}));
   cat.units.forEach(unit=>{if(!defs.some(u=>u.name.toLowerCase()===unit.toLowerCase()))defs.push({name:unit,aliases:SIDDHI_UNIT_ALIASES[unit]||[unit.toLowerCase()]});});
   state.settings.unitCatalog=defs;state.settings.customUnits=defs.map(u=>({name:u.name,aliases:[...(u.aliases||[])]}));state.settings.shopType=key;state.settings.shopTypeLabel=cat.label;
   save();localStorage.setItem(firmStorageKey('siddhiStarterCatalogInitialized'),'true');
   modal.classList.add('hidden');renderProducts?.();renderDatalist?.();renderCustomUnits?.();refreshUnitControls?.();
   showNotice(added.length+' starter products and '+cat.units.length+' unit types loaded. Prices and opening stock are zero; update them in Product Management.','SiddhiBill setup complete');
  }catch(err){state.products=oldProducts;state.settings=oldSettings;try{save();}catch(_){}showNotice('Setup could not be completed. No partial catalogue was kept. Please try again.','Setup failed');}
 });
 modal.classList.remove('hidden');
}
setupSiddhiStarterFlow();

// Refresh paired Bluetooth printer names when the app opens; unknown printer brands are supported by name.
try{refreshPairedPrinterChoices($("setBluetoothPrinter"),state.settings.bluetoothPrinter||"auto");}catch(e){}


/* SiddhiBill v3.62.1 — Salesperson monthly sales reporting */
function moduleShopKey(){return String(__sbActiveFirm()?.shopKey||__sbActiveFirmId||'default-shop').trim().toLowerCase()}
function moduleRecordShopKey(r){return String(r?.shopKey||moduleShopKey()).trim().toLowerCase()}
function moduleRecordBelongsToCurrentShop(r){
 const current=moduleShopKey();
 // Unstamped legacy rows belong only to the original/default firm.
 // A missing tenant key must never act as a wildcard across firms.
 if(!r?.shopKey)return !!__sbActiveFirm()?.isDefault;
 return String(r.shopKey).trim().toLowerCase()===current;
}
function moduleRows(arr){return (Array.isArray(arr)?arr:[]).filter(r=>moduleRecordBelongsToCurrentShop(r))}
function moduleSalesTrackingEnabled(member){const v=member?.trackSales;return v===true||v===1||String(v??'').trim().toLowerCase()==='true'||String(v??'').trim()==='1'||String(v??'').trim().toLowerCase()==='yes';}
function moduleId(prefix){return prefix+'-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8)}
function moduleMoney(n){return money(Number(n)||0)}
function moduleSafeText(v){return esc(String(v??''))}
function moduleEmpty(text){return `<div class="module-empty">${moduleSafeText(text)}</div>`}
function moduleCurrentShop(){return String(state.settings.shopName||'Your Shop')}
function moduleUpsert(list,record){const i=list.findIndex(x=>String(x.id)===String(record.id));if(i>=0)list[i]={...list[i],...record};else list.unshift(record)}
function moduleActiveTeam(){return moduleRows(state.teamMembers).filter(x=>x.active!==false)}
function renderTeamSelects(){const members=moduleActiveTeam();[['teamAttendanceMember','Choose team member'],['teamPaymentMember','Choose team member']].forEach(([id,placeholder])=>{const el=$(id);if(!el)return;const old=el.value;el.innerHTML=`<option value="">${placeholder}</option>`+members.map(m=>`<option value="${esc(m.id)}">${esc(m.name)}</option>`).join('');if(members.some(m=>m.id===old))el.value=old;});{const el=$('teamBulkMember');if(el){const old=el.value;el.innerHTML='<option value="__all__">All active team members</option>'+members.map(m=>`<option value="${esc(m.id)}">${esc(m.name)}</option>`).join('');el.value=(old==='__all__'||members.some(m=>String(m.id)===String(old)))?old:'__all__';}}
 {const el=$('teamReportMember');if(el){const all=moduleRows(state.teamMembers).filter(moduleRecordBelongsToCurrentShop),old=el.value;el.innerHTML='<option value="__all__">All team members (including inactive)</option>'+all.map(m=>`<option value="${esc(m.id)}">${esc(m.name)}${m.active===false?' · Inactive':''}</option>`).join('');el.value=(old==='__all__'||all.some(m=>String(m.id)===String(old)))?old:'__all__';}}}
function renderBrokerSelect(bill){const el=$('billBrokerSelect');if(!el)return;const active=moduleRows(state.brokers).filter(b=>b.active!==false);const wrap=$('billBrokerWrap');if(wrap)wrap.classList.toggle('hidden',active.length===0);const old=bill?String(bill.brokerId||''):'';el.innerHTML='<option value="">No broker</option>'+active.map(b=>`<option value="${esc(b.id)}">${esc(b.name)}</option>`).join('');el.value=active.some(b=>String(b.id)===old)?old:'';el.disabled=active.length===0;}
function moduleSalesEnabledTeam(){return moduleActiveTeam().filter(moduleSalesTrackingEnabled)}
function renderSalespersonSelect(bill){const wrap=$("billSalespersonWrap"),el=$("billSalespersonSelect");if(!el||!wrap)return;const people=moduleSalesEnabledTeam(),old=String(bill?.salespersonId||el.value||"");wrap.classList.toggle("hidden",!people.length);el.innerHTML='<option value="">No sales person</option>'+people.map(m=>`<option value="${esc(m.id)}">${esc(m.name)}</option>`).join("");el.value=people.some(m=>String(m.id)===old)?old:"";}
function renderTeamSalesReport(){const card=$("teamSalesReportCard"),out=$("teamSalesReport"),range=$("teamSalesReportRange");if(!card||!out)return;const people=moduleRows(state.teamMembers).filter(m=>moduleSalesTrackingEnabled(m)&&moduleRecordBelongsToCurrentShop(m));card.classList.toggle("hidden",!people.length);if(!people.length){out.innerHTML=moduleEmpty("No team members with sales tracking are configured for this shop.");return;}const from=$("teamSalesFrom")?.value||today().slice(0,7)+"-01",to=$("teamSalesTo")?.value||today();if(range)range.textContent=`Sales period: ${displayDate(from)} to ${displayDate(to)}`;if(from>to){out.innerHTML=moduleEmpty("From date must be on or before To date.");return;}let aggregate=null;try{if(nativeBridgePresent&&window.Android?.loadTeamSalesSummary)aggregate=JSON.parse(Android.loadTeamSalesSummary(from,to,String(people[0]?.shopKey||moduleShopKey()))||"[]");}catch(e){console.warn("Native team sales summary unavailable",e);}let rows;if(Array.isArray(aggregate)){const byId=new Map(aggregate.map(x=>[String(x.salespersonId||""),x]));rows=people.map(m=>{const x=byId.get(String(m.id))||{};return {m,total:Number(x.total||0),count:Number(x.billCount||0)};});}else{const bills=moduleRows(state.bills).filter(b=>String(b.date||"")>=from&&String(b.date||"")<=to);rows=people.map(m=>{const assigned=bills.filter(b=>String(b.salespersonId||"")===String(m.id));return {m,total:assigned.reduce((sum,b)=>sum+Number(b.total||0),0),count:assigned.length};});}rows.sort((a,b)=>b.total-a.total||a.m.name.localeCompare(b.m.name));const grand=rows.reduce((a,r)=>a+r.total,0),billCount=rows.reduce((a,r)=>a+r.count,0);out.innerHTML=`<div class="module-kpis"><div class="module-kpi"><span>Total sales</span><strong>${money(grand)}</strong></div><div class="module-kpi"><span>Sales people</span><strong>${rows.length}</strong></div><div class="module-kpi"><span>Bills in period</span><strong>${billCount}</strong></div></div>`+rows.map(r=>`<article class="module-record"><div class="module-record-head"><div><div class="module-record-title">${esc(r.m.name)}</div><div class="module-meta">${r.count} bill${r.count===1?"":"s"} · ${esc(displayDate(from))} – ${esc(displayDate(to))}</div></div><strong>${money(r.total)}</strong></div></article>`).join("");}

function renderBrokerOptions(id,selected=''){const el=$(id);if(!el)return;const old=selected||el.value;el.innerHTML='<option value="">Select broker (optional)</option>'+moduleRows(state.brokers).filter(b=>b.active!==false).map(b=>`<option value="${esc(b.id)}">${esc(b.name)} · ${Number(b.commissionRate||0)}%</option>`).join('');if([...el.options].some(o=>o.value===old))el.value=old;}
function syncBillBrokerCommission(bill,oldBillNo){
 state.brokerCommissions=Array.isArray(state.brokerCommissions)?state.brokerCommissions:[];
 const keys=new Set([String(oldBillNo||''),String(bill.billNo||'')].filter(Boolean));
 state.brokerCommissions=state.brokerCommissions.filter(c=>!(moduleRecordShopKey(c)===moduleShopKey()&&keys.has(String(c.billNo||''))));
 if(bill.brokerId){const broker=(state.brokers||[]).find(x=>String(x.id)===String(bill.brokerId)&&moduleRecordShopKey(x)===moduleShopKey());if(broker){const rate=Number(bill.brokerCommissionRate??broker.commissionRate)||0;const amount=Math.round((Number(bill.total||0)*rate/100+Number.EPSILON)*100)/100;bill.brokerName=broker.name;bill.brokerCommissionRate=rate;bill.brokerCommissionAmount=amount;state.brokerCommissions.unshift({id:'commission-'+moduleShopKey()+'-'+String(bill.billNo),shopKey:moduleShopKey(),shopName:moduleCurrentShop(),brokerId:broker.id,brokerName:broker.name,billNo:bill.billNo,billDate:bill.date||today(),billTotal:Number(bill.total||0),rate,amount,status:'payable',createdAt:new Date().toISOString()});}}
}
function teamPayrollCalculation(member, attendance, monthDays){
 const count=status=>attendance.filter(a=>a.status===status).length;
 const present=count('present'),halfday=count('halfday'),weeklyoff=count('weeklyoff');
 const attendedUnits=present+halfday*.5;
 if(member.payType==='daily') return {baseEarned:attendedUnits*Number(member.dailyRate||0),extraWorkPay:0,earned:attendedUnits*Number(member.dailyRate||0),present,halfday,weeklyoff};
 const weeklyOffDays=Math.max(0,Math.min(3,Number(member.weeklyOffDays??1)||0));
 const scheduledOffs=Math.round(monthDays*weeklyOffDays/7);
 const expectedWorkDays=Math.max(1,monthDays-scheduledOffs);
 const paidUnits=attendedUnits+weeklyoff;
 const baseEarned=Number(member.monthlySalary||0)*Math.min(1,paidUnits/expectedWorkDays);
 const extraDays=Math.max(0,attendedUnits-expectedWorkDays);
 const extraWorkPay=extraDays*(Number(member.monthlySalary||0)/Math.max(1,monthDays));
 return {baseEarned,extraWorkPay,earned:baseEarned+extraWorkPay,present,halfday,weeklyoff,expectedWorkDays,extraDays};
}
function teamExtraEarnings(memberId,from,to){return moduleRows(state.teamPayments).filter(p=>String(p.memberId)===String(memberId)&&p.entryType==='earning'&&String(p.date||'')>=from&&String(p.date||'')<=to).reduce((sum,p)=>sum+Number(p.amount||0),0);}
function teamReportHtml(from,to,memberFilter){
 const members=moduleRows(state.teamMembers).filter(moduleRecordBelongsToCurrentShop).filter(m=>memberFilter==='__all__'||String(m.id)===String(memberFilter));
 const inPeriod=r=>{const d=String(r?.date||'').slice(0,10);return d>=from&&d<=to;};
 const allAtt=moduleRows(state.teamAttendance).filter(inPeriod);
 const allPays=moduleRows(state.teamPayments).filter(inPeriod);
 const allBills=nativeBridgePresent?null:moduleRows(state.bills).filter(inPeriod);
 const escHtml=v=>esc(String(v??''));
 const fmtDate=v=>escHtml(displayDate(v));
 const reportMembers=members.map(m=>{
  const attendance=allAtt.filter(a=>String(a.memberId)===String(m.id)).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
  const payments=allPays.filter(p=>String(p.memberId)===String(m.id)).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
  const salesEnabled=moduleSalesTrackingEnabled(m);
  let bills=[];
  if(salesEnabled){
   if(nativeBridgePresent&&window.Android?.loadTeamSalesBills){try{const result=JSON.parse(Android.loadTeamSalesBills(from,to,String(m.shopKey||moduleShopKey()),String(m.id))||"[]");if(Array.isArray(result))bills=result;}catch(e){console.warn("Team report bills unavailable for "+m.id,e);}}
   else bills=(allBills||[]).filter(b=>String(b.salespersonId||b.salesPersonId||'')===String(m.id));
  }
  const statuses=['present','halfday','absent','weeklyoff','leave'];
  const count=status=>attendance.filter(a=>a.status===status).length;
  const monthKeys=new Set(attendance.map(a=>String(a.date||'').slice(0,7)));let earned=0;for(const monthKey of monthKeys){const monthAtt=attendance.filter(a=>String(a.date||'').startsWith(monthKey));const mdays=new Date(Number(monthKey.slice(0,4)),Number(monthKey.slice(5,7)),0).getDate();earned+=teamPayrollCalculation(m,monthAtt,mdays).earned;}earned+=payments.filter(p=>p.entryType==='earning').reduce((sum,p)=>sum+Number(p.amount||0),0);
  const paid=payments.filter(p=>p.entryType!=='earning').reduce((sum,p)=>sum+Number(p.amount||0),0),sales=bills.reduce((sum,b)=>sum+Number(b.total||0),0);
  return `<section class="member"><h2>${escHtml(m.name)}${m.active===false?' · Inactive':''}${salesEnabled?' · Sales tracking enabled':''}</h2><p><b>Role:</b> ${escHtml(m.role||'Team member')} &nbsp; <b>Pay type:</b> ${m.payType==='daily'?'Daily wage':'Monthly salary'}${m.payType==='monthly'?` · Weekly off days/week: ${Number(m.weeklyOffDays??1)}`:''} &nbsp; <b>Period:</b> ${fmtDate(from)} – ${fmtDate(to)}</p><div class="kpis"><div><b>Present</b><br>${count('present')}</div><div><b>Half-day</b><br>${count('halfday')}</div><div><b>Absent / Leave / Off</b><br>${count('absent')} / ${count('leave')} / ${count('weeklyoff')}</div><div><b>Estimated earned</b><br>${money(earned)}</div><div><b>Payments / advances</b><br>${money(paid)}</div><div><b>Estimated balance</b><br>${money(earned-paid)}</div>${salesEnabled?`<div><b>Total sales</b><br>${money(sales)}</div><div><b>Bills</b><br>${bills.length}</div>`:''}</div><h3>Attendance</h3>${attendance.length?`<table><thead><tr><th>Date</th><th>Status</th></tr></thead><tbody>${attendance.map(a=>`<tr><td>${fmtDate(a.date)}</td><td>${escHtml(a.status)}</td></tr>`).join('')}</tbody></table>`:'<p>No attendance entries in this period.</p>'}<h3>Payments and Extra Earnings</h3>${payments.length?`<table><thead><tr><th>Date</th><th>Type / Note</th><th>Mode</th><th class="num">Amount</th></tr></thead><tbody>${payments.map(p=>`<tr><td>${fmtDate(p.date)}</td><td>${escHtml(p.entryType==='earning'?'Extra earning: ':'Payment / advance: ')}${escHtml(p.note||'')}</td><td>${escHtml(p.mode||'Cash')}</td><td class="num">${money(p.amount)}</td></tr>`).join('')}</tbody></table>`:'<p>No payments or advances in this period.</p>'}${salesEnabled?`<h3>Sales Bills and Items</h3>${bills.length?`<table><thead><tr><th>Date</th><th>Bill No.</th><th>Items</th><th class="num">Total</th></tr></thead><tbody>${bills.map(b=>`<tr><td>${fmtDate(b.date)}</td><td>${escHtml(b.billNo||'')}</td><td>${(b.items||[]).map(i=>`${escHtml(i.name)} (${escHtml(i.qty)} ${escHtml(i.unit||'')})`).join('<br>')}</td><td class="num">${money(b.total)}</td></tr>`).join('')}</tbody></table>`:'<p>No sales bills assigned in this period.</p>'}`:''}</section>`;
 }).join('');
 return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Team Member Report</title><style>@page{size:A4;margin:12mm}body{font:11px Arial,sans-serif;color:#222}h1{font-size:20px;margin:0 0 4px}h2{font-size:15px;border-bottom:1px solid #aaa;padding-bottom:5px}h3{font-size:12px;margin:14px 0 5px}.muted{color:#555}.member{break-inside:avoid;page-break-inside:avoid;margin:0 0 18px;padding:0;display:block;visibility:visible;opacity:1}.member:last-child{margin-bottom:0}.kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}.kpis div{border:1px solid #bbb;padding:7px}table{border-collapse:collapse;width:100%;font-size:9px;margin:6px 0 12px}th,td{border:1px solid #bbb;padding:5px;text-align:left;vertical-align:top}th{background:#eee}.num{text-align:right;white-space:nowrap}</style></head><body><h1>${escHtml(state.settings.shopName||'SiddhiBill')} — Team Report</h1><p><b>Period:</b> ${fmtDate(from)} to ${fmtDate(to)}<br><b>Generated:</b> ${fmtDate(today())}</p>${reportMembers||'<p>No active team members found.</p>'}</body></html>`;
}
function generateTeamReportPdf(){const from=$('teamReportFrom')?.value||today().slice(0,7)+'-01',to=$('teamReportTo')?.value||today(),member=$('teamReportMember')?.value||'__all__';if(from>to){showNotice('From date must be on or before To date.','Team Report');return;}const html=teamReportHtml(from,to,member);if(window.Android?.printHtmlDocument){Android.printHtmlDocument(html,`Team_Member_Report_${from}_${to}_${member==='__all__'?'All_Team':String(moduleRows(state.teamMembers).find(m=>String(m.id)===String(member))?.name||'Member').replace(/[^A-Za-z0-9_-]+/g,'_')}`);if($('teamReportStatus'))$('teamReportStatus').textContent=`Team PDF saved to Downloads/SiddhiBill/Team-Reports (${displayDate(from)} to ${displayDate(to)}). Choose an app to open it.`;}else{const w=window.open('','_blank');if(!w){showNotice('Could not open report. Allow pop-ups and try again.','Team Report');return;}w.document.open();w.document.write(html+'<script>window.onload=()=>window.print()<\/script>');w.document.close();}}
function applyBulkTeamAttendance(){const from=$('teamBulkFrom')?.value||'',to=$('teamBulkTo')?.value||'',filter=$('teamBulkMember')?.value||'__all__',status=$('teamBulkStatus')?.value||'present',overwrite=$('teamBulkOverwrite')?.checked===true;if(!from||!to||from>to){showNotice('Choose a valid From and To date.','Bulk Attendance');return;}const span=(new Date(to+'T12:00:00')-new Date(from+'T12:00:00'))/86400000+1;if(span>366){showNotice('Bulk attendance is limited to 366 days per operation.','Bulk Attendance');return;}const members=moduleActiveTeam().filter(m=>filter==='__all__'||String(m.id)===String(filter));if(!members.length){showNotice('No active team members selected.','Bulk Attendance');return;}let added=0,skipped=0;for(const m of members){for(let n=0;n<span;n++){const d=new Date(from+'T12:00:00');d.setDate(d.getDate()+n);const date=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;const id='attendance-'+moduleShopKey()+'-'+m.id+'-'+date;const existing=moduleRows(state.teamAttendance).find(a=>String(a.id)===id);if(existing&&!overwrite){skipped++;continue;}moduleUpsert(state.teamAttendance,{id,shopKey:moduleShopKey(),shopName:moduleCurrentShop(),memberId:m.id,memberName:m.name,date,status,updatedAt:new Date().toISOString()});added++;}}save();renderTeamModule();const msg=`Saved ${added} attendance entries; skipped ${skipped} existing entries.`;if($('teamBulkAttendanceStatus'))$('teamBulkAttendanceStatus').textContent=msg;showNotice(msg,'Bulk Attendance');}
function renderTeamModule(){
 const label=$('teamShopLabel');if(label)label.textContent=moduleCurrentShop();renderTeamSelects();renderSalespersonSelect();renderTeamSalesReport();
 const list=$('teamMemberList'),members=moduleRows(state.teamMembers);if(list)list.innerHTML=members.length?members.map(m=>{const payments=moduleRows(state.teamPayments).filter(p=>p.memberId===m.id).reduce((a,p)=>a+Number(p.amount||0),0);return `<article class="module-record"><div class="module-record-head"><div><div class="module-record-title">${esc(m.name)} ${m.active===false?'<span class="module-status">Inactive</span>':''}</div><div class="module-meta">${esc(m.role||'Team member')}${m.phone?' · '+esc(m.phone):''} · ${m.payType==='daily'?'Daily wage '+money(m.dailyRate):'Monthly salary '+money(m.monthlySalary)}</div></div><div class="module-actions"><button class="secondary team-edit" data-id="${esc(m.id)}" type="button">Edit</button><button class="secondary team-toggle-active" data-id="${esc(m.id)}" type="button">${m.active===false?'Activate':'Deactivate'}</button></div></div><div class="module-meta">Recorded payments / advances: <b>${money(payments)}</b></div></article>`}).join(''):moduleEmpty('No team members added for this shop yet.');
 const date=$('teamAttendanceDate')?.value||today(),att=moduleRows(state.teamAttendance).filter(a=>a.date===date);const al=$('teamAttendanceSummary');if(al)al.innerHTML=att.length?att.map(a=>{const m=members.find(x=>x.id===a.memberId);return `<div class="module-record"><b>${esc(m?.name||a.memberName||'Team member')}</b><div class="module-meta">${esc(a.status)} · ${esc(displayDate(a.date))}</div><div class="module-actions"><button class="secondary team-delete-attendance" data-id="${esc(a.id)}" type="button">Remove / Correct</button></div></div>`}).join(''):moduleEmpty('No attendance recorded for '+displayDate(date)+'.');
 const month=$('teamPayrollMonth')?.value||today().slice(0,7),[yy,mm]=month.split('-').map(Number),days=new Date(yy,mm,0).getDate(),monthFrom=`${month}-01`,monthTo=`${month}-${String(days).padStart(2,'0')}`;const payroll=$('teamPayrollSummary');if(payroll)payroll.innerHTML=members.length?members.map(m=>{const aa=moduleRows(state.teamAttendance).filter(a=>a.memberId===m.id&&a.date>=monthFrom&&a.date<=monthTo);const count=k=>aa.filter(a=>a.status===k).length;const calc=teamPayrollCalculation(m,aa,days),extra=teamExtraEarnings(m.id,monthFrom,monthTo),earned=calc.earned+extra;const entries=moduleRows(state.teamPayments).filter(p=>p.memberId===m.id&&p.date>=monthFrom&&p.date<=monthTo);const paid=entries.filter(p=>p.entryType!=='earning').reduce((a,p)=>a+Number(p.amount||0),0);return `<div class="module-record"><div class="module-record-head"><div><div class="module-record-title">${esc(m.name)}</div><div class="module-meta">Present ${count('present')} · Half-day ${count('halfday')} · Absent ${count('absent')} · Weekly off ${count('weeklyoff')} · Leave ${count('leave')}${m.payType==='monthly'?` · Scheduled off ${Number(m.weeklyOffDays??1)}/week · Extra days ${calc.extraDays||0}`:''}</div></div><span class="module-status">${m.payType==='daily'?'Daily':'Monthly'}</span></div><div class="module-kpis"><div class="module-kpi"><span>Salary + extra days</span><strong>${money(calc.earned)}</strong></div><div class="module-kpi"><span>Commission / extra work</span><strong>${money(extra)}</strong></div><div class="module-kpi"><span>Paid / advances</span><strong>${money(paid)}</strong></div><div class="module-kpi"><span>Balance payable</span><strong>${money(earned-paid)}</strong></div></div></div>`}).join(''):moduleEmpty('Add a team member to calculate attendance-based salary.');
 const ledger=$('teamPaymentLedger'),payments=moduleRows(state.teamPayments).filter(p=>!month||String(p.date||'').startsWith(month)).sort((a,b)=>String(b.date).localeCompare(String(a.date)));if(ledger)ledger.innerHTML=payments.length?`<h4>Payment history</h4>`+payments.map(p=>`<div class="module-record"><div class="module-record-head"><div><b>${esc(p.memberName||members.find(m=>m.id===p.memberId)?.name||'Team member')}</b><div class="module-meta">${esc(displayDate(p.date))} · ${p.entryType==='earning'?'Extra earning':'Payment made'} · ${esc(p.mode||'Cash')} ${p.note?'· '+esc(p.note):''}</div></div><strong>${p.entryType==='earning'?'+':''}${money(p.amount)}</strong></div></div>`).join(''):moduleEmpty('No staff payments recorded for this month.');
 list?.querySelectorAll('.team-edit').forEach(btn=>btn.onclick=()=>{const m=state.teamMembers.find(x=>x.id===btn.dataset.id&&moduleRecordShopKey(x)===moduleShopKey());if(!m)return;window.editingTeamId=m.id;$('teamName').value=m.name||'';$('teamPhone').value=m.phone||'';$('teamRole').value=m.role||'';$('teamPayType').value=m.payType==='daily'?'daily':'monthly';$('teamRate').value=Number(m.monthlySalary||0);$('teamDailyRate').value=Number(m.dailyRate||0);if($('teamWeeklyOffDays'))$('teamWeeklyOffDays').value=Number(m.weeklyOffDays??1);if($('teamTrackSales'))$('teamTrackSales').checked=moduleSalesTrackingEnabled(m);$('teamSaveBtn').textContent='Save Changes';$('teamName').focus();});
 list?.querySelectorAll('.team-toggle-active').forEach(btn=>btn.onclick=()=>{const m=state.teamMembers.find(x=>x.id===btn.dataset.id&&moduleRecordShopKey(x)===moduleShopKey());if(!m)return;m.active=m.active===false?true:false;save();renderTeamModule();});al?.querySelectorAll('.team-delete-attendance').forEach(btn=>btn.onclick=()=>showConfirm('Remove this attendance record? You can then record the correct status.',()=>{state.teamAttendance=state.teamAttendance.filter(a=>a.id!==btn.dataset.id);save();renderTeamModule();},'Correct attendance'));
}
function clearTeamForm(){['teamName','teamPhone','teamRole'].forEach(id=>{if($(id))$(id).value=''});if($('teamPayType'))$('teamPayType').value='monthly';if($('teamRate'))$('teamRate').value='0';if($('teamDailyRate'))$('teamDailyRate').value='0';if($('teamWeeklyOffDays'))$('teamWeeklyOffDays').value='1';if($('teamTrackSales'))$('teamTrackSales').checked=false;if($('teamSaveBtn'))$('teamSaveBtn').textContent='Add Team Member';window.editingTeamId=null;}
function brokerLedgerDateRange(){const from=$('brokerLedgerFrom')?.value||today().slice(0,7)+'-01',to=$('brokerLedgerTo')?.value||today();return {from,to};}
function openBrokerLedgerPdf(){
 const {from,to}=brokerLedgerDateRange();if(from>to){showNotice('From date must be on or before To date.','Broker Ledger Report');return;}
 const selectedBroker=String($('brokerLedgerFilterBroker')?.value||'');
 const allBrokers=moduleRows(state.brokers).slice().sort((a,b)=>String(a.name||'').localeCompare(String(b.name||'')));
 const brokers=selectedBroker?allBrokers.filter(b=>String(b.id)===selectedBroker):allBrokers;
 const commissions=moduleRows(state.brokerCommissions).filter(c=>(!selectedBroker||String(c.brokerId)===selectedBroker)&&String(c.billDate||'')>=from&&String(c.billDate||'')<=to).slice().sort((a,b)=>String(a.billDate||'').localeCompare(String(b.billDate||'')));
 const payments=moduleRows(state.brokerPayments).filter(p=>(!selectedBroker||String(p.brokerId)===selectedBroker)&&String(p.date||'')>=from&&String(p.date||'')<=to).slice().sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
 const rows=[];commissions.forEach(c=>rows.push({date:String(c.billDate||''),brokerId:String(c.brokerId||''),broker:c.brokerName||'Broker',type:'Commission earned',reference:c.billNo||'—',details:`Bill total ${money(c.billTotal)} · ${Number(c.rate||0)}% including GST`,amount:Number(c.amount||0)}));
 payments.forEach(p=>rows.push({date:String(p.date||''),brokerId:String(p.brokerId||''),broker:p.brokerName||'Broker',type:'Payment made',reference:p.mode||'Payment',details:p.note||'—',amount:Number(p.amount||0)}));
 rows.sort((a,b)=>a.date.localeCompare(b.date)||a.broker.localeCompare(b.broker));
 const fmtDate=d=>esc(d?displayDate(d):'—'),fmt=n=>esc(money(n));
 const brokerSummary=brokers.map(b=>{const earnedRange=commissions.filter(c=>String(c.brokerId)===String(b.id)).reduce((a,c)=>a+Number(c.amount||0),0),paidRange=payments.filter(p=>String(p.brokerId)===String(b.id)).reduce((a,p)=>a+Number(p.amount||0),0),earnedToDate=moduleRows(state.brokerCommissions).filter(c=>String(c.brokerId)===String(b.id)&&String(c.billDate||'')<=to).reduce((a,c)=>a+Number(c.amount||0),0),paidToDate=moduleRows(state.brokerPayments).filter(p=>String(p.brokerId)===String(b.id)&&String(p.date||'')<=to).reduce((a,p)=>a+Number(p.amount||0),0);return {name:b.name,earnedRange,paidRange,net:earnedRange-paidRange,outstanding:earnedToDate-paidToDate};});
 const reportName=selectedBroker?(brokers[0]?.name||'Selected Broker'):'All Brokers';
 const html=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Broker Ledger Report</title><style>@page{size:A4 portrait;margin:12mm}body{font:10px Arial,sans-serif;color:#222}h1{font-size:19px;margin:0 0 5px}h2{font-size:13px;margin:18px 0 7px}.muted{color:#555}table{width:100%;border-collapse:collapse;font-size:9px;margin:8px 0 14px}th,td{border:1px solid #bbb;padding:5px;text-align:left;vertical-align:top}th{background:#edf3f8}.num{text-align:right;white-space:nowrap}.summary{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:12px 0}.box{border:1px solid #bbb;padding:8px}.empty{color:#666;font-style:italic}</style></head><body><h1>${esc(state.settings.shopName||'SiddhiBill')} — Broker Ledger</h1><div class="muted">${esc(reportName)} · Statement</div><p><b>Period:</b> ${fmtDate(from)} to ${fmtDate(to)}<br><b>Generated:</b> ${fmtDate(today())}</p><div class="summary"><div class="box"><b>Commission earned in range</b><br>${fmt(commissions.reduce((a,c)=>a+Number(c.amount||0),0))}</div><div class="box"><b>Payments in range</b><br>${fmt(payments.reduce((a,p)=>a+Number(p.amount||0),0))}</div><div class="box"><b>Outstanding as of ${fmtDate(to)}</b><br>${fmt(brokerSummary.reduce((a,b)=>a+b.outstanding,0))}</div></div><h2>Broker-wise Summary</h2>${brokerSummary.length?`<table><thead><tr><th>Broker</th><th>Commission in range</th><th>Payments in range</th><th>Net movement</th><th>Outstanding as of period end</th></tr></thead><tbody>${brokerSummary.map(b=>`<tr><td>${esc(b.name)}</td><td class="num">${fmt(b.earnedRange)}</td><td class="num">${fmt(b.paidRange)}</td><td class="num">${fmt(b.net)}</td><td class="num">${fmt(b.outstanding)}</td></tr>`).join('')}</tbody></table>`:'<p class="empty">No brokers configured for this selection.</p>'}<h2>Broker Ledger Transactions</h2>${rows.length?`<table><thead><tr><th>Date</th><th>Broker</th><th>Entry</th><th>Reference</th><th>Details</th><th>Amount (₹)</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${fmtDate(r.date)}</td><td>${esc(r.broker)}</td><td>${esc(r.type)}</td><td>${esc(r.reference)}</td><td>${esc(r.details)}</td><td class="num">${fmt(r.amount)}</td></tr>`).join('')}</tbody></table>`:'<p class="empty">No commission or payment transactions for the selected broker/date range.</p>'}<p class="muted">Commission is calculated on the final bill total including GST. Outstanding is cumulative through the selected To date.</p><script>function printReport(){try{if(window.Android&&typeof window.Android.printHtmlDocument==='function'){window.Android.printHtmlDocument(document.documentElement.outerHTML,'Broker_Ledger_Report');return}}catch(e){}window.focus();window.print()}window.onload=()=>setTimeout(printReport,250)</script></body></html>`;
 try{if(window.Android?.printHtmlDocument){window.Android.printHtmlDocument(html,`Broker_Ledger_${selectedBroker?String(brokers[0]?.name||'Broker').replace(/[^A-Za-z0-9_-]+/g,'_'):'All_Brokers'}_${from}_${to}`);const status=$('brokerLedgerPdfStatus');if(status)status.textContent='Broker PDF saved to Downloads/SiddhiBill/Broker-Reports. Choose an app to open it.';return;}}catch(e){console.warn('Native broker report printing unavailable',e)}
 const win=window.open('','_blank');if(win){win.document.open();win.document.write(html);win.document.close();}else showNotice('Could not open the report window. Allow pop-ups and try again.','Broker Ledger Report');
}
function renderBrokerModule(){
 renderBrokerOptions('brokerPaymentBroker');renderBrokerOptions('estimateBroker');renderBrokerSelect();if($('brokerLedgerFilterBroker')){const selected=String($('brokerLedgerFilterBroker').value||'');$('brokerLedgerFilterBroker').innerHTML='<option value="">All brokers</option>'+moduleRows(state.brokers).filter(b=>b.active!==false).map(b=>`<option value="${esc(b.id)}">${esc(b.name)} · ${Number(b.commissionRate||0)}%</option>`).join('');if([...$('brokerLedgerFilterBroker').options].some(o=>o.value===selected))$('brokerLedgerFilterBroker').value=selected;}
 const list=$('brokerList'),brokers=moduleRows(state.brokers);if(list)list.innerHTML=brokers.length?brokers.map(b=>{const earned=moduleRows(state.brokerCommissions).filter(c=>c.brokerId===b.id).reduce((a,c)=>a+Number(c.amount||0),0),paid=moduleRows(state.brokerPayments).filter(p=>p.brokerId===b.id).reduce((a,p)=>a+Number(p.amount||0),0);return `<article class="module-record"><div class="module-record-head"><div><div class="module-record-title">${esc(b.name)} ${b.active===false?'<span class="module-status">Inactive</span>':''}</div><div class="module-meta">${b.phone?esc(b.phone)+' · ':''}${Number(b.commissionRate||0)}% commission · ${esc(b.notes||'')}</div></div><div class="module-actions"><button class="secondary broker-edit" data-id="${esc(b.id)}" type="button">Edit</button><button class="secondary broker-toggle-active" data-id="${esc(b.id)}" type="button">${b.active===false?'Activate':'Deactivate'}</button></div></div><div class="module-kpis"><div class="module-kpi"><span>Commission earned</span><strong>${money(earned)}</strong></div><div class="module-kpi"><span>Payments</span><strong>${money(paid)}</strong></div><div class="module-kpi"><span>Outstanding</span><strong>${money(earned-paid)}</strong></div></div></article>`}).join(''):moduleEmpty('No brokers added for this shop yet.');
 const ledger=$('brokerLedger'),comm=moduleRows(state.brokerCommissions).slice().sort((a,b)=>String(b.billDate).localeCompare(String(a.billDate))),payments=moduleRows(state.brokerPayments).slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)));if(ledger)ledger.innerHTML=(comm.length?'<h4>Commission by bill</h4>'+comm.map(c=>`<div class="module-record"><div class="module-record-head"><div><b>${esc(c.brokerName||'Broker')} · ${esc(c.billNo)}</b><div class="module-meta">${esc(displayDate(c.billDate))} · Bill total ${money(c.billTotal)} · ${Number(c.rate||0)}% including GST</div></div><strong>${money(c.amount)}</strong></div></div>`).join(''):'')+(payments.length?'<h4>Broker payments</h4>'+payments.map(p=>`<div class="module-record"><div class="module-record-head"><div><b>${esc(p.brokerName||'Broker')}</b><div class="module-meta">${esc(displayDate(p.date))} · ${p.entryType==='earning'?'Extra earning':'Payment made'} · ${esc(p.mode||'Cash')} ${p.note?'· '+esc(p.note):''}</div></div><strong>${p.entryType==='earning'?'+':''}${money(p.amount)}</strong></div></div>`).join(''):'')||moduleEmpty('Commission entries will appear here when bills are generated with a broker selected.');
 list?.querySelectorAll('.broker-edit').forEach(btn=>btn.onclick=()=>{const b=state.brokers.find(x=>x.id===btn.dataset.id&&moduleRecordShopKey(x)===moduleShopKey());if(!b)return;window.editingBrokerId=b.id;$('brokerName').value=b.name||'';$('brokerPhone').value=b.phone||'';$('brokerRate').value=Number(b.commissionRate||0);$('brokerNote').value=b.notes||'';$('brokerSaveBtn').textContent='Save Changes';$('brokerName').focus();});
 list?.querySelectorAll('.broker-toggle-active').forEach(btn=>btn.onclick=()=>{const b=state.brokers.find(x=>x.id===btn.dataset.id&&moduleRecordShopKey(x)===moduleShopKey());if(!b)return;b.active=b.active===false?true:false;save();renderBrokerModule();renderBrokerSelect();});
}
function clearBrokerForm(){['brokerName','brokerPhone','brokerNote'].forEach(id=>{if($(id))$(id).value=''});if($('brokerRate'))$('brokerRate').value='0';window.editingBrokerId=null;if($('brokerSaveBtn'))$('brokerSaveBtn').textContent='Add Broker';}
function estimateItemRow(item={}){const wrap=$('estimateItems');if(!wrap)return;const row=document.createElement('div');row.className='estimate-item-row';row.innerHTML=`<label>Item<input class="est-item-name" autocomplete="off" list="productNames" value="${esc(item.name||'')}" placeholder="Search item name"></label><label>Qty<input class="est-item-qty" type="number" min="0.001" step="any" value="${esc(item.qty??1)}"></label><label>Unit<select class="est-item-unit">${unitOptionsHtml(item.unit||'piece')}</select></label><label>Rate (₹)<input class="est-item-rate" type="number" min="0" step="0.01" value="${esc(item.rate??0)}"></label><button type="button" class="est-remove-item" aria-label="Remove item">×</button><label>GST %<select class="est-item-tax"><option value="0">0%</option><option value="5">5%</option><option value="12">12%</option><option value="18">18%</option><option value="28">28%</option></select></label><label>HSN/SAC<input class="est-item-hsn" value="${esc(item.hsn||'')}" placeholder="Optional"></label>`;wrap.appendChild(row);row.querySelector('.est-item-tax').value=String([0,5,12,18,28].includes(Number(item.taxRate))?Number(item.taxRate):0);row.querySelector('.est-item-name').addEventListener('change',()=>{const p=findProduct(row.querySelector('.est-item-name').value);if(p){row.querySelector('.est-item-rate').value=Number(p.rate||0);row.querySelector('.est-item-unit').value=normalizeUnitName(p.unit||'piece');row.querySelector('.est-item-tax').value=String(Number(p.taxRate||0));row.querySelector('.est-item-hsn').value=String(p.hsn||p.hsnCode||'');}});row.querySelector('.est-remove-item').onclick=()=>row.remove();}
function estimateReadForm(){const lines=[...($('estimateItems')?.querySelectorAll('.estimate-item-row')||[])].map(r=>({name:String(r.querySelector('.est-item-name').value||'').trim(),qty:Number(r.querySelector('.est-item-qty').value||0),unit:String(r.querySelector('.est-item-unit').value||'piece').trim(),rate:Number(r.querySelector('.est-item-rate').value||0),taxRate:Number(r.querySelector('.est-item-tax').value||0),hsn:String(r.querySelector('.est-item-hsn')?.value||'').trim()})).filter(x=>x.name&&x.qty>0);const subtotal=lines.reduce((a,x)=>a+x.qty*x.rate,0),dtype=$('estimateDiscountType')?.value||'percent',dv=Math.max(0,Number($('estimateDiscountValue')?.value||0)),discount=dtype==='amount'?Math.min(subtotal,dv):Math.min(subtotal,subtotal*dv/100),taxEnabled=!!state.settings.taxationEnabled;let tax=0;if(taxEnabled)lines.forEach(x=>tax+=(x.qty*x.rate)*(1-discount/(subtotal||1))*x.taxRate/100);return {lines,subtotal,discount,discountType:dtype,discountValue:dv,taxEnabled,taxTotal:tax,total:Math.round((subtotal-discount+(taxEnabled?tax:0))*100)/100};}
function resetEstimateForm(){['estimateCustomer','estimateCustomerPhone','estimateNotes','estimateQuickList'].forEach(id=>{if($(id))$(id).value=''});if($('estimateDate'))$('estimateDate').value=today();if($('estimateValidUntil')){const d=new Date();d.setDate(d.getDate()+15);$('estimateValidUntil').value=d.toISOString().slice(0,10);}if($('estimateBroker'))$('estimateBroker').value='';if($('estimateTaxEnabled')){ $('estimateTaxEnabled').checked=!!state.settings.taxationEnabled; $('estimateTaxEnabled').disabled=true; }if($('estimateDiscountType'))$('estimateDiscountType').value='percent';if($('estimateDiscountValue'))$('estimateDiscountValue').value='0';if($('estimateItems'))$('estimateItems').innerHTML='';estimateItemRow();window.editingEstimateId=null;if($('estimateSaveBtn'))$('estimateSaveBtn').textContent='Save Estimate';if($('estimateFormStatus'))$('estimateFormStatus').textContent='New estimate · totals are recalculated from the entered lines.';}
function renderEstimateModule(){renderBrokerOptions('estimateBroker');const q=String($('estimateSearch')?.value||'').toLowerCase(),filter=$('estimateStatusFilter')?.value||'all',list=$('estimateList');const rows=moduleRows(state.estimates).filter(e=>(filter==='all'||e.status===filter)&&(!q||String(e.estimateNo+' '+e.customer).toLowerCase().includes(q))).sort((a,b)=>String(b.date).localeCompare(String(a.date)));if(list)list.innerHTML=rows.length?rows.map(e=>`<article class="module-record"><div class="module-record-head"><div><div class="module-record-title">${esc(e.estimateNo)} · ${esc(e.customer||'Customer')}</div><div class="module-meta">${esc(displayDate(e.date))} · Valid until ${esc(displayDate(e.validUntil))} · ${e.items?.length||0} items</div></div><span class="module-status ${e.status==='converted'?'converted':e.status==='confirmed'?'confirmed':''}">${esc(e.status||'draft')}</span></div><div class="module-kpis"><div class="module-kpi"><span>Subtotal</span><strong>${money(e.subtotal)}</strong></div><div class="module-kpi"><span>Discount</span><strong>${money(e.discount)}</strong></div><div class="module-kpi"><span>Estimate total</span><strong>${money(e.total)}</strong></div></div>${e.convertedBillNo?`<div class="module-meta">Converted bill: <b>${esc(e.convertedBillNo)}</b></div>`:''}<div class="module-actions"><button class="secondary est-print" data-id="${esc(e.id)}" type="button">Print / PDF</button>${e.status==='draft'?`<button class="secondary est-edit" data-id="${esc(e.id)}" type="button">Edit</button><button class="secondary est-confirm" data-id="${esc(e.id)}" type="button">Confirm</button>`:''}${e.status==='confirmed'?`<button class="primary est-convert" data-id="${esc(e.id)}" type="button">Convert to Bill</button>`:''}${!['converted','rejected'].includes(e.status)?`<button class="secondary est-reject" data-id="${esc(e.id)}" type="button">Reject</button>`:''}</div></article>`).join(''):moduleEmpty('No estimates match the selected filter.');
 list?.querySelectorAll('.est-edit').forEach(b=>b.onclick=()=>loadEstimateToForm(state.estimates.find(x=>x.id===b.dataset.id)));
 list?.querySelectorAll('.est-confirm').forEach(b=>b.onclick=()=>{const e=state.estimates.find(x=>x.id===b.dataset.id&&moduleRecordShopKey(x)===moduleShopKey());if(e){e.status='confirmed';e.confirmedAt=new Date().toISOString();save();renderEstimateModule();}});list?.querySelectorAll('.est-reject').forEach(b=>b.onclick=()=>{const e=state.estimates.find(x=>x.id===b.dataset.id&&moduleRecordShopKey(x)===moduleShopKey());if(e){e.status='rejected';save();renderEstimateModule();}});list?.querySelectorAll('.est-print').forEach(b=>b.onclick=()=>openEstimatePrint(state.estimates.find(x=>x.id===b.dataset.id)));list?.querySelectorAll('.est-convert').forEach(b=>b.onclick=()=>convertEstimateToBill(state.estimates.find(x=>x.id===b.dataset.id)));
}
function loadEstimateToForm(e){if(!e||e.status!=='draft')return;window.editingEstimateId=e.id;$('estimateCustomer').value=e.customer||'';$('estimateCustomerPhone').value=e.customerPhone||'';$('estimateDate').value=e.date||today();$('estimateValidUntil').value=e.validUntil||'';$('estimateBroker').value=e.brokerId||'';$('estimateDiscountType').value=e.discountType||'percent';$('estimateDiscountValue').value=String(e.discountValue||0);$('estimateTaxEnabled').checked=!!state.settings.taxationEnabled;$('estimateNotes').value=e.notes||'';$('estimateItems').innerHTML='';(e.items||[]).forEach(x=>estimateItemRow(x));if(!(e.items||[]).length)estimateItemRow();$('estimateSaveBtn').textContent='Update Estimate';$('estimateFormStatus').textContent='Editing '+e.estimateNo+' · draft only';window.scrollTo(0,0);$('estimateCustomer').focus();}
function estimatePrintHtml(e,paper='A4',printShopName=true){
 const size=String(paper||'A4').toUpperCase(),page=size==='58MM'?'58mm auto':size==='80MM'?'80mm auto':size==='A6'?'105mm 148mm':'A4';
 const lines=(e.items||[]).map((x,i)=>{const qty=Number(x.qty||0),rate=Number(x.rate||0),base=qty*rate,tax= e.taxEnabled?base*Number(x.taxRate||0)/100:0;return {...x,index:i+1,qty,rate,base,tax,amount:base+tax};});
 const compact=size.includes('MM')||size==='A6';
 const rows=lines.map(x=>compact?`<tr><td><b>${esc(x.name)}</b>${x.hsn?`<div class="sub">HSN/SAC: ${esc(x.hsn)}</div>`:''}<div class="sub">${esc(x.qty)} ${esc(x.unit||'')} × ${money(x.rate)}${e.taxEnabled?' · GST '+Number(x.taxRate||0)+'%':''}</div></td><td class="num">${money(x.amount)}</td></tr>`:`<tr><td>${x.index}</td><td><b>${esc(x.name)}</b>${x.hsn?`<div class="sub">HSN/SAC: ${esc(x.hsn)}</div>`:''}</td><td class="num">${esc(x.qty)} ${esc(x.unit||'')}</td><td class="num">${money(x.rate)}</td><td class="num">${e.taxEnabled?Number(x.taxRate||0)+'%':'—'}</td><td class="num">${money(x.amount)}</td></tr>`).join('');
 const itemTableHead=compact?'<tr><th>Item Description / Qty × Rate</th><th class="num">Amount (₹)</th></tr>':'<tr><th>#</th><th>Item / HSN-SAC</th><th class="num">Qty</th><th class="num">Rate (₹)</th><th class="num">GST</th><th class="num">Amount (₹)</th></tr>';
 const taxable=lines.reduce((a,x)=>a+x.base,0),taxTotal=Number(e.taxTotal||lines.reduce((a,x)=>a+x.tax,0)),discount=Number(e.discount||0),grand=Number(e.total||0);
 const shopHeader=printShopName?`<header>${state.settings.printShopLogo!==false&&state.settings.logoData?`<div><img src="${esc(state.settings.logoData)}" alt="Shop logo" style="max-width:90px;max-height:60px;object-fit:contain"></div>`:''}<h1>${esc(state.settings.shopName||'SiddhiBill')}</h1>${state.settings.tagline?`<div>${esc(state.settings.tagline)}</div>`:''}${state.settings.printShopAddress!==false&&state.settings.address?`<div>${esc(state.settings.address)}</div>`:''}${state.settings.printShopMobile!==false&&state.settings.shopMobile?`<div>Mobile: ${esc(state.settings.shopMobile)}</div>`:''}${state.settings.gstin?`<div>GSTIN: ${esc(state.settings.gstin)}</div>`:''}</header>`:'';
 return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(e.estimateNo||'Estimate')}</title><style>@page{size:${page};margin:${size.includes('MM')?'3mm':'10mm'}}*{box-sizing:border-box}body{font:11px Arial,sans-serif;color:#17202b;margin:0;padding:8px;max-width:100%}header{text-align:center;border-bottom:1px solid #555;padding-bottom:7px;margin-bottom:8px}h1{font-size:17px;margin:0 0 4px;color:#111}h2{font-size:15px;text-align:center;margin:8px 0;border:1px solid #555;padding:5px;color:#111}.meta{display:flex;justify-content:space-between;gap:8px;margin:6px 0}.muted,.sub{font-size:9px;color:#555;margin-top:2px}.customer{margin:7px 0;padding:5px;border:1px solid #bbb}table{width:100%;border-collapse:collapse;margin-top:8px;font-size:${size.includes('MM')?'8':'9'}px;table-layout:auto}th,td{border:1px solid #777;padding:4px;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{font-weight:bold;background:#eee}.num{text-align:right;white-space:nowrap}.totals{width:100%;margin-top:8px}.totals td{border:0;padding:3px 4px}.totals .label{text-align:right}.grand{font-size:15px;font-weight:bold;border-top:1px solid #555;margin-top:5px;padding-top:7px;text-align:right}.notes{margin-top:10px;border-top:1px solid #aaa;padding-top:6px}.muted.footer{text-align:center;margin-top:12px}@media print{body{padding:0}}</style></head><body>${shopHeader}<h2>ESTIMATE</h2><div class="meta"><div><b>Estimate No:</b> ${esc(e.estimateNo||'PREVIEW')}<br><b>Date:</b> ${esc(displayDate(e.date))}</div><div><b>Valid Until:</b> ${esc(displayDate(e.validUntil)||'—')}</div></div>${e.customer||e.customerPhone?`<div class="customer"><b>Customer:</b> ${esc(e.customer||'—')}${e.customerPhone?`<br><b>Mobile:</b> ${esc(e.customerPhone)}`:''}</div>`:''}<table><thead>${itemTableHead}</thead><tbody>${rows}</tbody></table><table class="totals"><tbody><tr><td class="label">Subtotal</td><td class="num">${money(taxable)}</td></tr>${discount?`<tr><td class="label">Discount</td><td class="num">−${money(discount)}</td></tr>`:''}${e.taxEnabled?`<tr><td class="label">Estimated GST</td><td class="num">${money(taxTotal)}</td></tr>`:''}</tbody></table><div class="grand">ESTIMATE TOTAL: ${money(grand)}</div>${e.notes?`<div class="notes"><b>Notes / Terms</b><br>${esc(e.notes).replace(/\n/g,'<br>')}</div>`:''}<p class="muted footer">This is an estimate, not a tax invoice.</p></body></html>`;
}
function printEstimate(e,mode='print',paper){if(!e)return;const selectedPaper=String(paper||$('estimatePrintPaperSize')?.value||'A4'),printShop=$('estimatePrintShopName')?.checked!==false,html=estimatePrintHtml(e,selectedPaper,printShop);try{if(mode==='print'&&selectedPaper==='80mm'&&window.Android?.directThermalPrint80){const cfg={...state.settings,paperSize:'80mm',printShopName:printShop,printShopLogo:printShop&&state.settings.printShopLogo!==false,printShopAddress:printShop&&state.settings.printShopAddress!==false,printShopMobile:printShop&&state.settings.printShopMobile!==false,tagline:printShop?(state.settings.tagline||''):'',showCustomer:true,printCustomerMobile:true,printPaymentMode:false};const payload={documentType:'estimate',isEstimate:true,billNo:e.estimateNo||'Estimate',date:e.date||today(),customer:e.customer||'',customerPhone:e.customerPhone||'',items:(e.items||[]).map(x=>({name:x.name,qty:x.qty,unit:x.unit||'piece',rate:Number(x.rate||0),taxRate:Number(x.taxRate||0),hsn:x.hsn||''})),subtotal:Number(e.subtotal||0),discount:Number(e.discount||0),discountType:e.discountType||'percent',discountValue:Number(e.discountValue||0),total:Number(e.total||0),taxationEnabled:!!e.taxEnabled,amountsIncludeTax:false,taxTotal:Number(e.taxTotal||0),notes:e.notes||'',settings:cfg};Android.directThermalPrint80(JSON.stringify(payload));return;}if(window.Android?.printEstimateHtmlDocument){Android.printEstimateHtmlDocument(html,String(e.estimateNo||'Estimate'),selectedPaper);return;}if(window.Android?.printHtmlDocument){Android.printHtmlDocument(html,String(e.estimateNo||'Estimate'));return;}}catch(err){console.warn('Native estimate print unavailable',err)}const win=window.open('','_blank');if(!win){showNotice('Could not open the estimate. Allow pop-ups and try again.','Estimate');return;}win.document.open();win.document.write(html+'<script>window.onload=()=>window.print()<\/script>');win.document.close();}
function openEstimatePrint(e){if(!e)return;window.estimatePrintPreview=null;window.printingEstimateId=e.id;$('estimatePrintCustomer').value=e.customer||'';$('estimatePrintPhone').value=e.customerPhone||'';$('estimatePrintPaperSize').value='A4';if($('estimatePrintShopName'))$('estimatePrintShopName').checked=true;$('estimatePrintModal').classList.remove('hidden');}
function currentEstimateForPrint(){const e=window.estimatePrintPreview||(state.estimates||[]).find(x=>x.id===window.printingEstimateId&&moduleRecordShopKey(x)===moduleShopKey());if(!e)return null;const name=String($('estimatePrintCustomer').value||'').trim(),phone=normalizePhone($('estimatePrintPhone').value||'');if(phone&&!isValidMobile(phone)){showNotice('Enter a valid 10 digit mobile number or leave it blank.','Estimate sharing');return null;}e.customer=name;e.customerPhone=phone;if(e.id!=='__estimate_preview__')save();window.estimatePrintPreview=null;return e;}
function estimateShareMessage(e){const items=(e.items||[]).map((x,i)=>`${i+1}. ${x.name} — ${x.qty} ${x.unit||''} × ${money(x.rate)} = ${money(Number(x.qty||0)*Number(x.rate||0))}${e.taxEnabled&&Number(x.taxRate||0)?` (GST ${Number(x.taxRate)}%)`:''}${x.hsn?' | HSN/SAC '+x.hsn:''}`).join('\n');return `${state.settings.shopName||'SiddhiBill'}\nESTIMATE: ${e.estimateNo}\nDate: ${displayDate(e.date)}${e.validUntil?'\nValid until: '+displayDate(e.validUntil):''}${e.customer?'\nCustomer: '+e.customer:''}${e.customerPhone?'\nMobile: '+e.customerPhone:''}\n\nITEM DETAILS\n${items||'No items'}\n\nSubtotal: ${money(e.subtotal)}${Number(e.discount||0)?'\nDiscount: '+money(e.discount):''}${e.taxEnabled?'\nEstimated GST: '+money(e.taxTotal):''}\nESTIMATE TOTAL: ${money(e.total)}${e.notes?'\nNotes: '+e.notes:''}\n\nThis is an estimate, not a tax invoice.`;}
function setupEstimatePrintActions(){
 $('estimatePrintCancel')?.addEventListener('click',()=>$('estimatePrintModal').classList.add('hidden'));
 $('estimatePrintPaperSize')?.addEventListener('change',()=>{});
 $('estimatePrintMessage')?.addEventListener('click',()=>{const e=currentEstimateForPrint();if(!e)return;const phone=e.customerPhone;if(!isValidMobile(phone)){showNotice('Enter a valid customer mobile number to send a message.','Estimate Message');return;}const msg=estimateShareMessage(e);$('estimatePrintModal').classList.add('hidden');if(window.Android?.sendBillMessage)Android.sendBillMessage(phone,msg);else window.location.href=`sms:${phone}?body=${encodeURIComponent(msg)}`;});
 $('estimatePrintWhatsApp')?.addEventListener('click',()=>{const e=currentEstimateForPrint();if(!e)return;const phone=e.customerPhone;if(!isValidMobile(phone)){showNotice('Enter a valid customer mobile number for WhatsApp.','Estimate WhatsApp');return;}const msg=estimateShareMessage(e),paper=$('estimatePrintPaperSize').value,html=estimatePrintHtml(e,paper,$('estimatePrintShopName')?.checked!==false);$('estimatePrintModal').classList.add('hidden');if(window.Android?.shareEstimatePdfToWhatsApp){Android.shareEstimatePdfToWhatsApp(html,String(e.estimateNo||'Estimate'),phone,msg,paper);}else{showNotice('PDF attachment sharing requires the updated SiddhiBill Android app.','Estimate WhatsApp');}});
 $('estimatePrintPdf')?.addEventListener('click',()=>{const e=currentEstimateForPrint();if(!e)return;const paper=$('estimatePrintPaperSize').value;$('estimatePrintModal').classList.add('hidden');printEstimate(e,'pdf',paper);});
 $('estimatePrintPrint')?.addEventListener('click',()=>{const e=currentEstimateForPrint();if(!e)return;const paper=$('estimatePrintPaperSize').value;$('estimatePrintModal').classList.add('hidden');printEstimate(e,'print',paper);});
 $('estimatePrintOpenBtn')?.addEventListener('click',()=>{let e=(state.estimates||[]).find(x=>x.id===window.editingEstimateId);if(!e){const data=estimateReadForm(),customer=String($('estimateCustomer').value||'').trim(),phone=normalizePhone($('estimateCustomerPhone').value||'');if(phone&&!isValidMobile(phone)){showNotice('Enter a valid 10 digit customer mobile number or leave it blank.','Estimate');return;}if(!data.lines.length){showNotice('Add at least one item before printing.','Estimate');return;}e={id:'__estimate_preview__',estimateNo:'PREVIEW',customer,customerPhone:phone,date:$('estimateDate').value||today(),validUntil:$('estimateValidUntil').value||'',items:data.lines,subtotal:data.subtotal,discount:data.discount,taxEnabled:data.taxEnabled,taxTotal:data.taxTotal,total:data.total,notes:$('estimateNotes').value||''};}else{const data=estimateReadForm();e={...e,customer:String($('estimateCustomer').value||'').trim(),customerPhone:normalizePhone($('estimateCustomerPhone').value||''),date:$('estimateDate').value||today(),validUntil:$('estimateValidUntil').value||'',items:data.lines,subtotal:data.subtotal,discount:data.discount,taxEnabled:data.taxEnabled,taxTotal:data.taxTotal,total:data.total,notes:$('estimateNotes').value||''};}window.estimatePrintPreview=e;$('estimatePrintCustomer').value=e.customer||'';$('estimatePrintPhone').value=e.customerPhone||'';$('estimatePrintPaperSize').value='A4';if($('estimatePrintShopName'))$('estimatePrintShopName').checked=true;$('estimatePrintModal').classList.remove('hidden');});
}

function convertEstimateToBill(e){if(!e||e.status!=='confirmed')return;clearBill();if($('customer')){$('customer').value=e.customer||'Walk-in Customer';$('customer').dataset.phone=e.customerPhone||'';}if($('billDate'))$('billDate').value=today();if($('billTaxToggle'))$('billTaxToggle').checked=!!e.taxEnabled;syncTaxUi();if($('discountType'))$('discountType').value=e.discountType||'percent';if($('discountValue'))$('discountValue').value=String(e.discountValue||0);if($('billBrokerSelect'))$('billBrokerSelect').value=e.brokerId||'';items.innerHTML='';(e.items||[]).forEach(x=>addItem({name:x.name,qty:String(x.qty),unit:x.unit||'piece',rate:Number(x.rate)||0,taxRate:Number(x.taxRate)||0,hsn:x.hsn||'',preventFuzzyAutoFill:true}));if(!e.items?.length)addItem();window.convertingEstimateId=e.id;showPage('billing');if($('billingModeLabel'))$('billingModeLabel').textContent='Converting '+e.estimateNo+' — review and Generate Bill';showNotice('Estimate '+e.estimateNo+' is confirmed. Review the prefilled items, customer, tax and discount, then tap Generate Bill to create the sales bill. The estimate will be marked Converted only after bill generation succeeds.','Convert estimate');}
function estimateNumber(){const prefix=String(state.settings.estimatePrefix||'EST').trim()||'EST',start=Math.max(1,Number(state.settings.estimateStart)||1);state.settings.estimateStart=start+1;return prefix+'-'+String(start).padStart(4,'0');}
function initSiddhiBillModules(){
 if(!$('teamPage'))return;
 // Ensure arrays exist when restoring an older backup created before these modules existed.
 ['teamMembers','teamAttendance','teamPayments','brokers','brokerCommissions','brokerPayments','estimates'].forEach(k=>{if(!Array.isArray(state[k]))state[k]=[];});
 if($('teamAttendanceDate'))$('teamAttendanceDate').value=today();if($('teamBulkFrom'))$('teamBulkFrom').value=today().slice(0,7)+'-01';if($('teamBulkTo'))$('teamBulkTo').value=today();if($('teamReportFrom'))$('teamReportFrom').value=today().slice(0,7)+'-01';if($('teamReportTo'))$('teamReportTo').value=today();if($('teamSalesFrom'))$('teamSalesFrom').value=today().slice(0,7)+'-01';if($('teamSalesTo'))$('teamSalesTo').value=today();if($('teamPaymentDate'))$('teamPaymentDate').value=today();if($('teamPayrollMonth'))$('teamPayrollMonth').value=today().slice(0,7);if($('brokerPaymentDate'))$('brokerPaymentDate').value=today();if($('brokerLedgerFrom'))$('brokerLedgerFrom').value=today().slice(0,7)+'-01';if($('brokerLedgerTo'))$('brokerLedgerTo').value=today();
 $('teamSaveBtn').onclick=()=>{const name=String($('teamName').value||'').trim();if(!name){showNotice('Enter the team member name.','Team Management');return;}const record={id:window.editingTeamId||moduleId('team'),shopKey:moduleShopKey(),shopName:moduleCurrentShop(),name,phone:String($('teamPhone').value||'').trim(),role:String($('teamRole').value||'').trim(),trackSales:!!$('teamTrackSales')?.checked,payType:$('teamPayType').value==='daily'?'daily':'monthly',monthlySalary:Math.max(0,Number($('teamRate').value)||0),dailyRate:Math.max(0,Number($('teamDailyRate').value)||0),weeklyOffDays:Math.max(0,Math.min(3,Number($('teamWeeklyOffDays')?.value??1)||0)),active:true,updatedAt:new Date().toISOString()};if(window.editingTeamId){const old=state.teamMembers.find(x=>x.id===window.editingTeamId);if(old)record.active=old.active!==false;}moduleUpsert(state.teamMembers,record);save();clearTeamForm();renderTeamModule();showNotice('Team member saved.','Team Management');};
 $('teamClearBtn').onclick=clearTeamForm;$('teamMarkAttendanceBtn').onclick=()=>{const member=moduleActiveTeam().find(m=>m.id===$('teamAttendanceMember').value),date=$('teamAttendanceDate').value||today();if(!member){showNotice('Select a team member first.','Attendance');return;}const id='attendance-'+moduleShopKey()+'-'+member.id+'-'+date;moduleUpsert(state.teamAttendance,{id,shopKey:moduleShopKey(),shopName:moduleCurrentShop(),memberId:member.id,memberName:member.name,date,status:$('teamAttendanceStatus').value,updatedAt:new Date().toISOString()});save();renderTeamModule();showNotice('Attendance saved for '+member.name+'.','Attendance');};
 ['teamAttendanceDate','teamPayrollMonth','teamSalesFrom','teamSalesTo'].forEach(id=>$(id)?.addEventListener('change',renderTeamModule));$('teamBulkAttendanceBtn')?.addEventListener('click',applyBulkTeamAttendance);$('teamReportPdfBtn')?.addEventListener('click',generateTeamReportPdf);$('teamAddPaymentBtn').onclick=()=>{const member=moduleActiveTeam().find(m=>m.id===$('teamPaymentMember').value),amount=Number($('teamPaymentAmount').value||0),entryType=$('teamPaymentType')?.value==='earning'?'earning':'payment';if(!member||amount<=0){showNotice('Select a team member and enter an amount greater than zero.','Team Payment');return;}state.teamPayments.unshift({id:moduleId('teampay'),shopKey:moduleShopKey(),shopName:moduleCurrentShop(),memberId:member.id,memberName:member.name,date:$('teamPaymentDate').value||today(),amount,entryType,mode:$('teamPaymentMode').value||'Cash',note:String($('teamPaymentNote').value||'').trim()||(entryType==='earning'?'Commission / extra work':'Salary / advance'),createdAt:new Date().toISOString()});save();$('teamPaymentAmount').value='';$('teamPaymentNote').value='';renderTeamModule();showNotice(entryType==='earning'?'Commission / extra work earning recorded.':'Payment / advance recorded.','Team Payment');};
 $('brokerSaveBtn').onclick=()=>{const name=String($('brokerName').value||'').trim(),rate=Number($('brokerRate').value||0);if(!name){showNotice('Enter the broker name.','Broker Management');return;}if(rate<0||rate>100){showNotice('Commission must be between 0% and 100%.','Broker Management');return;}const record={id:window.editingBrokerId||moduleId('broker'),shopKey:moduleShopKey(),shopName:moduleCurrentShop(),name,phone:String($('brokerPhone').value||'').trim(),commissionRate:rate,notes:String($('brokerNote').value||'').trim(),active:true,updatedAt:new Date().toISOString()};if(window.editingBrokerId){const old=state.brokers.find(x=>x.id===window.editingBrokerId);if(old)record.active=old.active!==false;}moduleUpsert(state.brokers,record);save();clearBrokerForm();renderBrokerModule();renderBrokerSelect();showNotice('Broker saved.','Broker Management');};$('brokerClearBtn').onclick=clearBrokerForm;$('brokerLedgerPdfBtn')?.addEventListener('click',openBrokerLedgerPdf);$('brokerLedgerFilterBroker')?.addEventListener('change',()=>{});
 $('brokerAddPaymentBtn').onclick=()=>{const broker=moduleRows(state.brokers).find(b=>b.id===$('brokerPaymentBroker').value),amount=Number($('brokerPaymentAmount').value||0);if(!broker||amount<=0){showNotice('Select a broker and enter a payment amount greater than zero.','Broker Payment');return;}const earned=moduleRows(state.brokerCommissions).filter(c=>c.brokerId===broker.id).reduce((a,c)=>a+Number(c.amount||0),0),paid=moduleRows(state.brokerPayments).filter(p=>p.brokerId===broker.id).reduce((a,p)=>a+Number(p.amount||0),0);if(amount>earned-paid+0.005&&!confirm('Payment exceeds the currently calculated outstanding commission. Record it anyway?'))return;state.brokerPayments.unshift({id:moduleId('brokerpay'),shopKey:moduleShopKey(),shopName:moduleCurrentShop(),brokerId:broker.id,brokerName:broker.name,date:$('brokerPaymentDate').value||today(),amount,mode:$('brokerPaymentMode').value||'Cash',note:String($('brokerPaymentNote').value||'').trim(),createdAt:new Date().toISOString()});save();$('brokerPaymentAmount').value='';$('brokerPaymentNote').value='';renderBrokerModule();showNotice('Broker payment recorded.','Broker Payment');};
 $('estimateNewBtn').onclick=resetEstimateForm;$('estimateAddItemBtn').onclick=()=>estimateItemRow();$('estimateQuickListAddBtn')?.addEventListener('click',()=>{const text=String($('estimateQuickList').value||'').trim();if(!text){$('estimateQuickList').focus();return;}const parsed=[],errors=[];for(const line of text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean)){if(/^(?:item\s*(?:\/|\|)?\s*qty|quick list)$/i.test(line))continue;const item=parseBillingQuickListEntry(line);if(item?.error)errors.push(item.error);else if(item)parsed.push(item);}if(errors.length){showNotice(errors.join('\n'),'Estimate Quick List');return;}parsed.forEach(item=>{const existing=[...$('estimateItems').querySelectorAll('.estimate-item-row')].find(r=>String(r.querySelector('.est-item-name').value||'').trim().toLowerCase()===String(item.name).trim().toLowerCase());if(existing){existing.querySelector('.est-item-qty').value=String(Number(item.qty||0));existing.querySelector('.est-item-unit').value=normalizeUnitName(item.unit||'piece');existing.querySelector('.est-item-rate').value=Number(item.rate)||0;existing.querySelector('.est-item-tax').value=String(Number(item.taxRate)||0);}else estimateItemRow(item);});$('estimateFormStatus').textContent=parsed.length+' Quick List item(s) added to estimate.';});$('estimateSearch')?.addEventListener('input',renderEstimateModule);$('estimateStatusFilter')?.addEventListener('change',renderEstimateModule);$('estimateSaveBtn').onclick=()=>{const customer=String($('estimateCustomer').value||'').trim(),customerPhone=normalizePhone($('estimateCustomerPhone').value||''),data=estimateReadForm();if(customerPhone&&!isValidMobile(customerPhone)){showNotice('Enter a valid 10 digit customer mobile number or leave it blank.','Estimate');return;}if(!data.lines.length){showNotice('Add at least one estimate item with quantity greater than zero.','Estimate');return;}const existing=(state.estimates||[]).find(e=>e.id===window.editingEstimateId);if(existing&&existing.status==='converted'){showNotice('A converted estimate cannot be edited. Create a new estimate instead.','Estimate');return;}const e={...(existing||{}),id:window.editingEstimateId||moduleId('estimate'),shopKey:moduleShopKey(),shopName:moduleCurrentShop(),estimateNo:existing?.estimateNo||estimateNumber(),customer,customerPhone,date:$('estimateDate').value||today(),validUntil:$('estimateValidUntil').value||'',brokerId:String($('estimateBroker').value||''),taxEnabled:data.taxEnabled,discountType:data.discountType,discountValue:data.discountValue,subtotal:data.subtotal,discount:data.discount,taxTotal:data.taxTotal,total:data.total,items:data.lines,notes:String($('estimateNotes').value||'').trim(),status:existing?.status||'draft',updatedAt:new Date().toISOString()};moduleUpsert(state.estimates,e);save();window.editingEstimateId=e.id;if($('estimateSaveBtn'))$('estimateSaveBtn').textContent='Update Estimate';renderEstimateModule();$('estimateFormStatus').textContent='Saved '+e.estimateNo+' · '+money(e.total)+' · Continue editing this estimate or press New Estimate to start another.';showNotice('Estimate '+e.estimateNo+' saved. Further saves will update this same estimate until you press New Estimate.','Estimate saved');};
 // Initial render for option fields and page entry points.
 renderBrokerSelect();renderSalespersonSelect();renderTeamSelects();renderBrokerOptions('brokerPaymentBroker');renderBrokerOptions('estimateBroker');if($('brokerLedgerFilterBroker'))$('brokerLedgerFilterBroker').innerHTML='<option value="">All brokers</option>'+moduleRows(state.brokers).filter(b=>b.active!==false).map(b=>`<option value="${esc(b.id)}">${esc(b.name)} · ${Number(b.commissionRate||0)}%</option>`).join('');resetEstimateForm();setupEstimatePrintActions();
}

// GST Compliance is an independent, offline-first module. Exports are working files,
// not representations of direct GSTN portal submission.
function gstPeriodKey(){return String($('gstPeriod')?.value||today().slice(0,7));}
function gstPeriodBills(){const period=gstPeriodKey();const rows=reportRowsForPeriod('pksBills',period+'-01',period+'-31');return rows.filter(b=>String(b.date||'').slice(0,7)===period&&billTaxEnabled(b));}
function gstBillTaxableAndTax(b){const tax=calculateBillTax(b);return {...tax,bill:b};}
function gstMoney(v){return Number(v||0).toFixed(2);}
function gstEscapeCsv(v){return csvEscape(v);}
function gstDownloadCsv(filename,headers,rows){const csv=[headers.map(gstEscapeCsv).join(','),...rows.map(r=>headers.map((_,i)=>gstEscapeCsv(r[i])).join(','))].join('\r\n');if(window.Android?.saveExportFile){Android.saveExportFile(btoa(unescape(encodeURIComponent(csv))),filename);}else{const a=document.createElement('a');const url=URL.createObjectURL(new Blob([csv],{type:'application/octet-stream'}));a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);}if($('gstExportStatus'))$('gstExportStatus').textContent='Preparing '+filename+'…';}
function gstAggregate(){const bills=gstPeriodBills(),rates={};let taxable=0,tax=0,cgst=0,sgst=0,igst=0,invoiceCount=0;const invoices=[];bills.forEach(b=>{const t=gstBillTaxableAndTax(b);taxable+=t.taxable;tax+=t.tax;cgst+=t.cgst;sgst+=t.sgst;igst+=t.igst;invoiceCount++;(t.groups||[]).forEach(g=>{const k=String(g.rate);if(!rates[k])rates[k]={rate:g.rate,taxable:0,tax:0,cgst:0,sgst:0,igst:0};rates[k].taxable+=g.taxable;rates[k].tax+=g.tax;const inter=!!t.inter;if(inter)rates[k].igst+=g.tax;else{rates[k].cgst+=g.tax/2;rates[k].sgst+=g.tax/2;}});const isInter=!!t.inter;invoices.push({date:b.date||'',invoiceNo:b.taxInvoiceNo||b.invoiceNo||b.billNo||'',customer:b.customer||'Walk-in Customer',customerGstin:b.customerGstin||'',placeOfSupply:b.placeOfSupply||'',invoiceValue:Number(b.total||0),taxable:t.taxable,cgst:t.cgst,sgst:t.sgst,igst:t.igst,tax:t.tax,reverseCharge:b.reverseCharge?'Y':'N',invoiceType:b.customerGstin?'B2B':'B2C'});});return {bills,invoices,rates:Object.values(rates).sort((a,b)=>a.rate-b.rate),taxable,tax,cgst,sgst,igst,invoiceCount,totalValue:bills.reduce((s,b)=>s+Number(b.total||0),0)};}
function gstAnnualFY(){const period=gstPeriodKey(),year=Number(period.slice(0,4)),month=Number(period.slice(5,7));return month>=4?`${year}-${year+1}`:`${year-1}-${year}`;}
function gstRenderAnnualGuidance(){const turnover=Number($('gstAnnualTurnover')?.value||0),fy=gstAnnualFY(),el=$('gstAnnualGuidance');if(!el)return;const annualExempt=turnover>0&&turnover<=20000000;el.innerHTML=`Financial year <b>${esc(fy)}</b>. `+(turnover<=0?'Enter turnover to calculate a preliminary indication.':annualExempt?'At turnover up to ₹2 crore, GSTR-9 exemption may apply for FY 2024–25 onwards under the applicable notification. Verify eligibility for this FY.':'GSTR-9 applicability must be checked against the turnover threshold and current-year notifications.')+`<br>GSTR-9C generally applies when aggregate turnover exceeds ₹5 crore, subject to applicable rules. This is guidance only, not a legal determination.`;}
function gstLoadSavedPeriod(){const r=(state.gstCompliance||{})[moduleShopKey()+'|'+gstPeriodKey()]||(state.gstCompliance||{})[gstPeriodKey()]||{};[['gstGstr1Status','gstr1Status'],['gstGstr3bStatus','gstr3bStatus'],['gstGstr1Arn','gstr1Arn'],['gstGstr3bArn','gstr3bArn'],['gstItcConfirmed','itcConfirmed'],['gstAdjustments','adjustments']].forEach(([id,k])=>{if($(id))$(id).value=r[k]??(id.includes('Status')?'pending':'');});if($('gstAnnualTurnover')&&r.annualTurnover!=null)$('gstAnnualTurnover').value=r.annualTurnover;}
let gstPeriodAutoSelected=false;
function renderGstCompliance(){if(!$('gstPeriod'))return;if(gstPeriodAutoSelected){const latestDate=(()=>{try{return nativeBridgePresent&&window.Android?.loadLatestTaxBillDate?String(Android.loadLatestTaxBillDate(moduleShopKey())||''):'';}catch(e){return '';}})();const latestTaxBill=latestDate?{date:latestDate}:(()=>{const rows=reportRowsForPeriod('pksBills','0000-01-01','9999-12-31');return rows.filter(b=>billTaxEnabled(b)&&String(b.date||'').length>=7).sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')))[0];})();$('gstPeriod').value=latestTaxBill?String(latestTaxBill.date).slice(0,7):today().slice(0,7);gstPeriodAutoSelected=false;}else if(!$('gstPeriod').value)$('gstPeriod').value=today().slice(0,7);gstLoadSavedPeriod();const a=gstAggregate();if($('gstSummaryKpis'))$('gstSummaryKpis').innerHTML=`<div class="sales-box"><span>Tax invoices</span><strong>${a.invoiceCount}</strong></div><div class="sales-box"><span>Taxable value</span><strong>${money(a.taxable)}</strong></div><div class="sales-box"><span>Total GST</span><strong>${money(a.tax)}</strong></div><div class="sales-box"><span>Invoice value</span><strong>${money(a.totalValue)}</strong></div>`;if($('gstSummaryTable'))$('gstSummaryTable').innerHTML=a.rates.length?`<div class="table-wrap"><table><thead><tr><th>GST Rate</th><th>Taxable Value</th><th>CGST</th><th>SGST</th><th>IGST</th><th>Total GST</th></tr></thead><tbody>${a.rates.map(r=>`<tr><td>${r.rate}%</td><td>${money(r.taxable)}</td><td>${money(r.cgst)}</td><td>${money(r.sgst)}</td><td>${money(r.igst)}</td><td>${money(r.tax)}</td></tr>`).join('')}<tr><th>Total</th><th>${money(a.taxable)}</th><th>${money(a.cgst)}</th><th>${money(a.sgst)}</th><th>${money(a.igst)}</th><th>${money(a.tax)}</th></tr></tbody></table></div>`:'<div class="muted">No tax-enabled bills found for this month. Check that tax was enabled on the saved bills.</div>';if($('gstComplianceStatus'))$('gstComplianceStatus').textContent=`${a.invoiceCount} tax invoice(s) · normal monthly due dates: GSTR-1 on the 11th and GSTR-3B on the 20th of the following month, subject to extensions. CSV exports are preparation files, not direct GSTN upload files.`;gstRenderAnnualGuidance();}
function gstSaveCompliance(){const key=gstPeriodKey();if(!key){showNotice('Select the return month.','GST Compliance');return;}state.gstCompliance=state.gstCompliance||{};state.gstCompliance[moduleShopKey()+'|'+key]={gstr1Status:$('gstGstr1Status').value,gstr3bStatus:$('gstGstr3bStatus').value,gstr1Arn:String($('gstGstr1Arn').value||'').trim(),gstr3bArn:String($('gstGstr3bArn').value||'').trim(),itcConfirmed:Number($('gstItcConfirmed').value||0),adjustments:Number($('gstAdjustments').value||0),annualTurnover:Number($('gstAnnualTurnover').value||0),updatedAt:new Date().toISOString()};save();renderGstCompliance();showNotice('GST compliance status saved for '+key+'.','GST Compliance');}
function gstExportSalesCsv(){const a=gstAggregate();const headers=['GSTIN of Supplier','Return Period','Invoice Number','Invoice Date','Invoice Type','Customer Name','Customer GSTIN','Place of Supply','Reverse Charge','Invoice Value','Taxable Value','Integrated Tax','Central Tax','State/UT Tax','Cess'];const rows=a.invoices.map(i=>[state.settings.gstin||'',gstPeriodKey().replace('-',''),i.invoiceNo,i.date,i.invoiceType,i.customer,i.customerGstin,i.placeOfSupply,i.reverseCharge,gstMoney(i.invoiceValue),gstMoney(i.taxable),gstMoney(i.igst),gstMoney(i.cgst),gstMoney(i.sgst),'0.00']);gstDownloadCsv('SiddhiBill_GSTR1_Sales_Working_'+gstPeriodKey()+'.csv',headers,rows);}
function gstExportHsnCsv(){const a=gstAggregate(),map={};a.bills.forEach(b=>{const t=calculateBillTax(b),sub=Number(b.subtotal||0),discount=Number(b.discount||0);(b.items||[]).forEach(it=>{const qty=Number(it.qty||0),rate=Number(it.rate||0),gross=qty*rate,net=sub>0?gross*(sub-discount)/sub:gross,tr=Number(it.taxRate||0),inclusive=b.amountsIncludeTax!==false,base=tr>0?(inclusive?net/(1+tr/100):net):net,tax=tr>0?(inclusive?net-base:net*tr/100):0,hsn=String(it.hsn||it.hsnCode||'UNSPECIFIED');const k=hsn+'|'+tr;if(!map[k])map[k]={hsn,rate:tr,qty:0,taxable:0,tax:0};map[k].qty+=qty;map[k].taxable+=base;map[k].tax+=tax;});});const rows=Object.values(map).map(r=>[r.hsn,r.rate,gstMoney(r.qty),gstMoney(r.taxable),gstMoney(r.tax),gstMoney(r.tax/2),gstMoney(r.tax/2),gstMoney(0)]);gstDownloadCsv('SiddhiBill_HSN_Summary_'+gstPeriodKey()+'.csv',['HSN/SAC','GST Rate (%)','Quantity','Taxable Value','Total GST','CGST','SGST (assumes intra-state)','Cess'],rows);}
function gstExport3bCsv(){const a=gstAggregate(),saved=(state.gstCompliance||{})[moduleShopKey()+'|'+gstPeriodKey()]||(state.gstCompliance||{})[gstPeriodKey()]||{},itc=Number($('gstItcConfirmed').value||saved.itcConfirmed||0),adj=Number($('gstAdjustments').value||saved.adjustments||0);const rows=[['Financial Year',gstAnnualFY()],['Return Period',gstPeriodKey()],['Outward taxable supplies - taxable value',gstMoney(a.taxable)],['Outward tax - IGST',gstMoney(a.igst)],['Outward tax - CGST',gstMoney(a.cgst)],['Outward tax - SGST/UTGST',gstMoney(a.sgst)],['Total outward GST',gstMoney(a.tax)],['Eligible ITC confirmed from GSTR-2B (manual input)',gstMoney(itc)],['Other adjustments / reversals (signed manual input)',gstMoney(adj)],['Indicative net tax before other liabilities and adjustments',gstMoney(a.tax-itc+adj)],['Reminder','This is a working summary only; verify all GSTR-3B tables, reverse charge, exempt supplies, ITC eligibility and other liabilities before filing.']];gstDownloadCsv('SiddhiBill_GSTR3B_Working_'+gstPeriodKey()+'.csv',['Particulars','Value'],rows);}
function gstPdfHtml(){const a=gstAggregate(),period=gstPeriodKey(),saved=(state.gstCompliance||{})[moduleShopKey()+'|'+period]||(state.gstCompliance||{})[period]||{};return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GST Compliance Summary</title><style>@page{size:A4;margin:14mm}body{font:12px Arial;color:#222}h1{font-size:20px}h2{font-size:15px;margin-top:22px}table{width:100%;border-collapse:collapse;margin:12px 0}td,th{border:1px solid #bbb;padding:6px;text-align:right}td:first-child,th:first-child{text-align:left}th{background:#edf3f8}.muted{color:#555;font-size:10px}.kpis{display:flex;gap:10px;flex-wrap:wrap}.kpis div{border:1px solid #bbb;padding:10px;min-width:120px}</style></head><body><h1>${esc(state.settings.shopName||'SiddhiBill')} — GST Compliance Summary</h1><p><b>GSTIN:</b> ${esc(state.settings.gstin||'Not configured')}<br><b>Return period:</b> ${esc(period)}<br><b>Generated:</b> ${esc(today())}</p><div class="kpis"><div>Tax invoices<br><b>${a.invoiceCount}</b></div><div>Taxable value<br><b>${money(a.taxable)}</b></div><div>Total GST<br><b>${money(a.tax)}</b></div><div>Invoice value<br><b>${money(a.totalValue)}</b></div></div><h2>Rate-wise summary</h2><table><thead><tr><th>GST Rate</th><th>Taxable</th><th>CGST</th><th>SGST</th><th>IGST</th><th>Total GST</th></tr></thead><tbody>${a.rates.map(r=>`<tr><td>${r.rate}%</td><td>${money(r.taxable)}</td><td>${money(r.cgst)}</td><td>${money(r.sgst)}</td><td>${money(r.igst)}</td><td>${money(r.tax)}</td></tr>`).join('')}<tr><th>Total</th><th>${money(a.taxable)}</th><th>${money(a.cgst)}</th><th>${money(a.sgst)}</th><th>${money(a.igst)}</th><th>${money(a.tax)}</th></tr></tbody></table><h2>Filing tracker</h2><p>GSTR-1: ${esc(saved.gstr1Status||'pending')} · Reference: ${esc(saved.gstr1Arn||'—')}<br>GSTR-3B: ${esc(saved.gstr3bStatus||'pending')} · Reference: ${esc(saved.gstr3bArn||'—')}</p><p class="muted">This is a management working report generated from stored tax invoices. Verify GSTIN, invoice type, place of supply, HSN, tax treatment, credit/debit notes, exempt/nil-rated supplies, reverse charge, ITC and current GSTN rules. It is not an official GST return or proof of filing.</p></body></html>`;}
function gstPrintReportHtml(html,name){if(window.Android?.printHtmlDocument){Android.printHtmlDocument(html,name);if($('gstExportStatus'))$('gstExportStatus').textContent=name+' opened in Android Print. Choose Save as PDF.';}else{const w=window.open('','_blank');if(!w){showNotice('Allow pop-ups to generate the PDF.','GST Compliance');return;}w.document.open();w.document.write(html+'<script>window.onload=()=>window.print()<\/script>');w.document.close();}}
function gstGstr1PdfHtml(){const a=gstAggregate(),period=gstPeriodKey();const h=`<!doctype html><html><head><meta charset="utf-8"><title>GSTR-1 Working Report</title><style>@page{size:A4 landscape;margin:10mm}body{font:10px Arial;color:#222}h1{font-size:18px}h2{font-size:13px;margin-top:18px}table{width:100%;border-collapse:collapse;margin:8px 0}td,th{border:1px solid #aaa;padding:4px;text-align:right}td:first-child,th:first-child{text-align:left}th{background:#e8f1f7}.note{font-size:9px;color:#555}</style></head><body><h1>${esc(state.settings.shopName||'SiddhiBill')} — GSTR-1 Sales Working Report</h1><p><b>Supplier GSTIN:</b> ${esc(state.settings.gstin||'Not configured')} &nbsp; <b>Return period:</b> ${esc(period)} &nbsp; <b>Generated:</b> ${esc(today())}</p><p><b>Invoice count:</b> ${a.invoiceCount} &nbsp; <b>Taxable value:</b> ${money(a.taxable)} &nbsp; <b>Total GST:</b> ${money(a.tax)} &nbsp; <b>Invoice value:</b> ${money(a.totalValue)}</p><h2>Sales invoice details</h2><table><thead><tr><th>Invoice No.</th><th>Date</th><th>Type</th><th>Customer</th><th>Customer GSTIN</th><th>Place of Supply</th><th>RCM</th><th>Invoice Value</th><th>Taxable</th><th>IGST</th><th>CGST</th><th>SGST</th></tr></thead><tbody>${a.invoices.map(i=>`<tr><td>${esc(i.invoiceNo)}</td><td>${esc(i.date)}</td><td>${esc(i.invoiceType)}</td><td>${esc(i.customer)}</td><td>${esc(i.customerGstin)}</td><td>${esc(i.placeOfSupply)}</td><td>${esc(i.reverseCharge)}</td><td>${money(i.invoiceValue)}</td><td>${money(i.taxable)}</td><td>${money(i.igst)}</td><td>${money(i.cgst)}</td><td>${money(i.sgst)}</td></tr>`).join('')||'<tr><td colspan="12">No tax invoices found for this period.</td></tr>'}</tbody></table><h2>Rate-wise summary</h2><table><thead><tr><th>GST Rate</th><th>Taxable Value</th><th>IGST</th><th>CGST</th><th>SGST</th><th>Total GST</th></tr></thead><tbody>${a.rates.map(r=>`<tr><td>${r.rate}%</td><td>${money(r.taxable)}</td><td>${money(r.igst)}</td><td>${money(r.cgst)}</td><td>${money(r.sgst)}</td><td>${money(r.tax)}</td></tr>`).join('')}<tr><th>Total</th><th>${money(a.taxable)}</th><th>${money(a.igst)}</th><th>${money(a.cgst)}</th><th>${money(a.sgst)}</th><th>${money(a.tax)}</th></tr></tbody></table><p class="note">Preparation report only; not an official GSTN return. Review B2B/B2C classification, invoice amendments, credit/debit notes, exports, exempt/nil-rated supplies, HSN summary and current GSTN format before filing.</p></body></html>`;return h;}
function gstGstr3bPdfHtml(){const a=gstAggregate(),period=gstPeriodKey(),saved=(state.gstCompliance||{})[moduleShopKey()+'|'+period]||(state.gstCompliance||{})[period]||{},itc=Number($('gstItcConfirmed')?.value||saved.itcConfirmed||0),adj=Number($('gstAdjustments')?.value||saved.adjustments||0),net=a.tax-itc+adj;return `<!doctype html><html><head><meta charset="utf-8"><title>GSTR-3B Working Report</title><style>@page{size:A4;margin:14mm}body{font:11px Arial;color:#222}h1{font-size:19px}h2{font-size:14px;margin-top:20px}table{width:100%;border-collapse:collapse;margin:10px 0}td,th{border:1px solid #aaa;padding:7px}td:last-child,th:last-child{text-align:right}th{background:#e8f1f7}.note{font-size:9px;color:#555}</style></head><body><h1>${esc(state.settings.shopName||'SiddhiBill')} — GSTR-3B Working Report</h1><p><b>GSTIN:</b> ${esc(state.settings.gstin||'Not configured')}<br><b>Return period:</b> ${esc(period)}<br><b>Financial year:</b> ${esc(gstAnnualFY())}<br><b>Generated:</b> ${esc(today())}</p><h2>Table 3.1 — Outward supplies (indicative)</h2><table><thead><tr><th>Particulars</th><th>Taxable Value (₹)</th><th>IGST (₹)</th><th>CGST (₹)</th><th>SGST/UTGST (₹)</th><th>Total Tax (₹)</th></tr></thead><tbody><tr><td>Outward taxable supplies recorded in SiddhiBill</td><td>${money(a.taxable)}</td><td>${money(a.igst)}</td><td>${money(a.cgst)}</td><td>${money(a.sgst)}</td><td>${money(a.tax)}</td></tr><tr><th>Total recorded outward supplies</th><th>${money(a.taxable)}</th><th>${money(a.igst)}</th><th>${money(a.cgst)}</th><th>${money(a.sgst)}</th><th>${money(a.tax)}</th></tr></tbody></table><h2>ITC and adjustments (manual / indicative)</h2><table><tbody><tr><td>Eligible ITC confirmed from GSTR-2B (manual input)</td><td>${money(itc)}</td></tr><tr><td>Other adjustments / reversals (signed manual input)</td><td>${money(adj)}</td></tr><tr><th>Indicative net outward GST after entered ITC/adjustments</th><th>${money(net)}</th></tr></tbody></table><h2>Rate-wise outward tax summary</h2><table><thead><tr><th>GST Rate</th><th>Taxable Value</th><th>IGST</th><th>CGST</th><th>SGST</th><th>Total GST</th></tr></thead><tbody>${a.rates.map(r=>`<tr><td>${r.rate}%</td><td>${money(r.taxable)}</td><td>${money(r.igst)}</td><td>${money(r.cgst)}</td><td>${money(r.sgst)}</td><td>${money(r.tax)}</td></tr>`).join('')}<tr><th>Total</th><th>${money(a.taxable)}</th><th>${money(a.igst)}</th><th>${money(a.cgst)}</th><th>${money(a.sgst)}</th><th>${money(a.tax)}</th></tr></tbody></table><p><b>Filing tracker:</b> Status ${esc(saved.gstr3bStatus||'pending')} · ARN/reference ${esc(saved.gstr3bArn||'—')}</p><p class="note">This is not a complete statutory GSTR-3B computation or GSTN filing file. Reverse charge, exempt/nil-rated/non-GST supplies, imports, all ITC eligibility/reversals, interest, late fee, previous-period corrections and other liabilities must be reconciled separately against records and current GSTN rules.</p></body></html>`;}
function gstPrintGstr1Pdf(){gstPrintReportHtml(gstGstr1PdfHtml(),'GSTR1_Working_'+gstPeriodKey());}
function gstPrintGstr3bPdf(){gstPrintReportHtml(gstGstr3bPdfHtml(),'GSTR3B_Working_'+gstPeriodKey());}
function gstPrintPdf(){const html=gstPdfHtml();if(window.Android?.printHtmlDocument){Android.printHtmlDocument(html,'GST_Compliance_'+gstPeriodKey());$('gstExportStatus').textContent='GST summary opened in Android Print. Choose Save as PDF.';}else{const w=window.open('','_blank');if(!w){showNotice('Allow pop-ups to generate the PDF.','GST Compliance');return;}w.document.open();w.document.write(html+'<script>window.onload=()=>window.print()<\/script>');w.document.close();}}
function initGstCompliance(){if(!$('gstPeriod'))return;$('gstPeriod').value=today().slice(0,7);gstPeriodAutoSelected=true;$('gstPeriod').addEventListener('change',renderGstCompliance);$('gstAnnualTurnover').addEventListener('input',gstRenderAnnualGuidance);$('gstSavePeriodBtn').addEventListener('click',gstSaveCompliance);$('gstRefreshBtn').addEventListener('click',renderGstCompliance);$('gstGstr1CsvBtn').addEventListener('click',gstExportSalesCsv);$('gstHsnCsvBtn').addEventListener('click',gstExportHsnCsv);$('gst3bCsvBtn').addEventListener('click',gstExport3bCsv);$('gstPdfBtn').addEventListener('click',gstPrintPdf);$('gstGstr1PdfBtn')?.addEventListener('click',gstPrintGstr1Pdf);$('gst3bPdfBtn')?.addEventListener('click',gstPrintGstr3bPdf);/* Load transaction history only when the GST Compliance screen is opened. */}
window.onGstExportSaved=function(ok,message){if($('gstExportStatus'))$('gstExportStatus').textContent=ok?'Saved '+message+'. Review the file before GST filing.':'Could not save export: '+message;};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initGstCompliance);else initGstCompliance();


function __sbBuildStartupTraceReport(){
 const d=window.__siddhiStartupTrace||{}, now=__sbTraceClock();
 const rows=["SiddhiBill Startup Trace","Build: 3.64.67","Generated: "+new Date().toISOString(),
 "Elapsed since app.js began: "+Math.round(now-__sbTraceStart)+" ms",
 "Native state transfer: "+(d.nativeTransferMs??"not measured")+" ms",
 "JS initial state setup (cumulative checkpoint): "+(d.jsInitialStateMs??"not measured")+" ms",
 "DOMContentLoaded: "+(d.domReadyMs??"not recorded")+" ms",
 "Window load event: "+(d.loadEventMs??"not recorded")+" ms",
 "First paint: "+(d.firstPaintMs??"not recorded")+" ms",
 "First contentful paint: "+(d.firstContentfulPaintMs??"not recorded")+" ms",
 "Main module initialisation: "+(d.initModulesMs??"not recorded")+" ms",
 "Home-ready marker: "+(d.homeReadyMs==null?"not recorded":d.homeReadyMs+" ms"),
 "Screen marker: "+(d.screen||"startup"),"","Timed startup operations:",...(d.profile||[]).map((x,i)=>(i+1)+". "+x.name+": "+x.durationMs+" ms"+Object.entries(x).filter(([k])=>!['name','durationMs','atMs'].includes(k)).map(([k,v])=>" · "+k+" "+v).join("")),"","Milestones:"];
 (d.marks||[]).forEach(m=>rows.push((m.ms??"?")+" ms - "+m.name));
 rows.push("","Long JavaScript tasks (50 ms+ when browser supports Long Tasks API):");
 if(d.longTasks?.length)d.longTasks.forEach((t,i)=>rows.push((i+1)+". start "+t.startMs+" ms; duration "+t.durationMs+" ms"));
 else rows.push("None captured or Long Tasks API unavailable.");
 rows.push("","Runtime errors:");
 if(d.errors?.length)d.errors.forEach((e,i)=>rows.push((i+1)+". ["+e.type+" at "+e.atMs+" ms] "+e.message));
 else rows.push("None recorded.");
 rows.push("","Note: first-two-frames marker is a visual readiness proxy, not proof all data/screens are fully ready. Long-task data depends on WebView API support.");
 return rows.join("\n");
}
document.addEventListener("DOMContentLoaded",()=>{
 const btn=$("startupTraceBtn"),copy=$("copyStartupTraceBtn"),out=$("startupTraceOutput"),status=$("startupTraceStatus");
 btn?.addEventListener("click",()=>{out.value=__sbBuildStartupTraceReport();out.style.display="block";copy.style.display="inline-block";status.textContent="Trace generated. Copy and share it here.";});
 copy?.addEventListener("click",()=>{try{out.select();document.execCommand("copy");status.textContent="Trace copied. Paste it into this chat.";}catch(e){status.textContent="Select the trace text and copy it manually."; }});
 const storageBtn=$("refreshStorageDiagnosticsBtn"),clearBtn=$("clearTemporaryCacheBtn"),storageOut=$("storageDiagnosticsOutput"),storageStatus=$("storageDiagnosticsStatus");
 window.refreshStorageDiagnostics=function(){
   try{const raw=window.Android?.getStorageDiagnostics?.();const d=JSON.parse(raw||"{}");if(d.error)throw new Error(d.error);
     const mb=n=>(Number(n||0)/1048576).toFixed(2)+" MB";
     storageOut.textContent=["Database: "+mb(d.databaseBytes),"App files: "+mb(d.filesBytes),"App cache: "+mb(d.cacheBytes),"WebView data/cache: "+mb(d.webViewBytes),"Backup archives (preserved): "+mb(d.backupBytes),"Purchase attachments: "+mb(d.attachmentBytes),"Sales bills: "+(d.transactionCounts?.pksBills??"not available"),"Purchase bills: "+(d.transactionCounts?.pksPurchases??"not available"),"Inventory movements: "+(d.transactionCounts?.pksInventoryMovements??"not available"),"Managed total (overlapping categories possible): "+mb(d.totalManagedBytes),"Database: "+d.databasePath,"Backups: "+d.backupPath].join("\n");
     storageStatus.textContent="Analysis complete. Values are measured from app-private storage.";
   }catch(e){storageStatus.textContent="Could not analyze storage: "+(e?.message||e);}
 };
 storageBtn?.addEventListener("click",window.refreshStorageDiagnostics);
 clearBtn?.addEventListener("click",()=>{if(!confirm("Clear temporary WebView/cache files only? Bills, customers, purchases, attachments and backup archives will be preserved."))return;try{window.Android?.clearTemporaryCache?.();storageStatus.textContent="Cache cleanup requested.";}catch(e){storageStatus.textContent="Cleanup failed: "+(e?.message||e);}});
},{once:true});

const __sbInitModulesOriginal=initSiddhiBillModules;
initSiddhiBillModules=function(){
 const t=__sbTraceClock();
 window.__sbTraceMark("module initialisation started");
 try{return __sbInitModulesOriginal.apply(this,arguments);}
 finally{
  window.__siddhiStartupTrace.initModulesMs=Math.round(__sbTraceClock()-t);
  window.__sbTraceMark("module initialisation finished");
 }
};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initSiddhiBillModules);else initSiddhiBillModules();


window.__siddhiMarkHomeReady=function(screenName){
 try{
  const d=window.__siddhiStartupTrace;
  if(d.homeReadyMs==null){d.homeReadyMs=Math.round(__sbTraceClock()-__sbTraceStart);d.screen=String(screenName||"home");window.__sbTraceMark("home ready: "+d.screen);}
 }catch(_){}
};

requestAnimationFrame(()=>requestAnimationFrame(()=>{
 try{
  if(window.__siddhiStartupTrace.homeReadyMs==null){
   window.__siddhiStartupTrace.homeReadyMs=Math.round(__sbTraceClock()-__sbTraceStart);
   window.__siddhiStartupTrace.screen="first-two-frames-proxy";
   window.__sbTraceMark("first two animation frames (home-ready proxy)");
  }
 }catch(_){}
}));

window.__sbTraceMark("app.js top-level execution complete");


// Banking module: all account, transaction and reconciliation records are stored in dedicated SQLite tables.
let bankAccountsCache=[];let bankHistoryPage=1;let bankHistoryRows=[];
function bankShopKey(){return typeof moduleShopKey==='function'?moduleShopKey():'default';}
function bankToday(){return typeof today==='function'?today():new Date().toISOString().slice(0,10);}
function bankId(prefix){return prefix+'-'+Date.now()+'-'+Math.random().toString(36).slice(2,9);}
function bankBridge(){return !!(window.Android&&Android.bankListAccounts&&Android.bankSaveAccount&&Android.bankSaveTransaction);}
function bankReadAccounts(){try{bankAccountsCache=bankBridge()?JSON.parse(Android.bankListAccounts(bankShopKey())||'[]'):[];}catch(e){bankAccountsCache=[];console.error('Bank account load failed',e);}return bankAccountsCache;}
function bankFmt(v){return '₹'+Number(v||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});}
function bankRenderAccountSelects(){const active=bankAccountsCache.filter(a=>Number(a.active)!==0);['bankTxnAccount','bankHistoryAccount','bankReconAccount'].forEach(id=>{const el=$(id);if(!el)return;const prev=el.value;const all=id==='bankHistoryAccount'?'<option value="">All accounts</option>':'';el.innerHTML=all+active.map(a=>`<option value="${esc(a.id)}">${esc(a.account_name)} · ${esc(a.bank_name)}</option>`).join('');if([...el.options].some(o=>o.value===prev))el.value=prev;});}
function renderBanking(){if(!bankBridge()){if($('bankAccountList'))$('bankAccountList').innerHTML='<p class="muted">Banking requires the SiddhiBill Android SQLite bridge.</p>';return;}bankReadAccounts();bankRenderAccountSelects();const cards=bankAccountsCache.filter(a=>Number(a.active)!==0).map(a=>{const sum=JSON.parse(Android.bankAccountSummary(bankShopKey(),a.id,bankToday())||'{}');return `<div class="history-row"><div><b>${esc(a.account_name)}</b><div class="muted">${esc(a.bank_name)} · ${esc(a.account_type||'Account')}</div></div><div><b>${bankFmt(sum.balance)}</b><div class="muted">Opening ${bankFmt(a.opening_balance)}</div></div></div>`;});$('bankAccountList').innerHTML=cards.join('')||'<p class="muted">No bank accounts added yet.</p>';$('bankOverview').innerHTML=`<div class="sales-box"><span>Active accounts</span><strong>${bankAccountsCache.filter(a=>Number(a.active)!==0).length}</strong></div><div class="sales-box"><span>Combined balance</span><strong>${bankFmt(cards.reduce((t,_,i)=>t+Number(JSON.parse(Android.bankAccountSummary(bankShopKey(),bankAccountsCache.filter(a=>Number(a.active)!==0)[i].id,bankToday())||'{}').balance||0),0))}</strong></div>`;bankLoadHistory();bankRenderRecon();}
function bankLoadHistory(){if(!bankBridge())return;const account=$('bankHistoryAccount')?.value||'',from=$('bankHistoryFrom')?.value||'',to=$('bankHistoryTo')?.value||'';try{bankHistoryRows=JSON.parse(Android.bankListTransactions(bankShopKey(),account, (bankHistoryPage-1)*25,25,from,to)||'[]');}catch(e){bankHistoryRows=[];}const el=$('bankTransactionList');if(!el)return;el.innerHTML=bankHistoryRows.length?bankHistoryRows.map(t=>`<div class="history-row"><div><b>${esc(t.description||t.category||t.entry_type)}</b><div class="muted">${esc(t.txn_date)} · ${esc(bankAccountsCache.find(a=>a.id===t.account_id)?.account_name||'Account')} · ${esc(t.category||'')}</div><div class="muted">${esc(t.reference_no||'')} · ${Number(t.matched)===1?'Matched':'Not matched'}</div><button class="secondary" type="button" onclick="Android.bankSetMatched(bankShopKey(),'${esc(t.id)}',${Number(t.matched)!==1});bankLoadHistory()">${Number(t.matched)===1?'Unmark':'Mark matched'}</button></div><div style="text-align:right"><b>${Number(t.credit)>0?'+':'−'}${bankFmt(Number(t.credit)>0?t.credit:t.debit)}</b><div class="muted">${esc(t.entry_type)}</div></div></div>`).join(''):'<p class="muted">No transactions found for this filter.</p>';$('bankPageLabel').textContent='Page '+bankHistoryPage+' · 25 records per page';}
function bankRenderRecon(){const account=$('bankReconAccount')?.value||bankAccountsCache.find(a=>Number(a.active)!==0)?.id||'';const month=$('bankReconMonth')?.value||bankToday().slice(0,7);if(!account||!month){$('bankReconSummary').textContent='Add an account and select a month.';return;}const lastDay=new Date(Number(month.slice(0,4)),Number(month.slice(5,7)),0).getDate();const end=month+'-'+String(lastDay).padStart(2,'0');let sum={};try{sum=JSON.parse(Android.bankAccountSummary(bankShopKey(),account,end)||'{}');}catch(e){}const rec=JSON.parse(Android.bankGetReconciliation(bankShopKey(),account,month)||'{}');if($('bankStatementClosing')&&rec.statement_closing!==undefined)$('bankStatementClosing').value=rec.statement_closing;$('bankReconSummary').innerHTML=`<div class="sales-summary"><div class="sales-box"><span>Calculated closing balance</span><strong>${bankFmt(sum.balance)}</strong></div><div class="sales-box"><span>Statement closing balance</span><strong>${rec.statement_closing===undefined?'Not entered':bankFmt(rec.statement_closing)}</strong></div><div class="sales-box"><span>Difference</span><strong>${rec.statement_closing===undefined?'—':bankFmt(Number(rec.statement_closing)-Number(sum.balance))}</strong></div></div><p class="muted">Credits ${bankFmt(sum.credit)} · Debits ${bankFmt(sum.debit)} · Opening ${bankFmt(sum.opening)}</p>`;}
function bankClearAccountForm(){['bankAccountName','bankBankName','bankAccountNumber','bankIfsc','bankBranch','bankAccountNotes'].forEach(id=>$(id).value='');$('bankOpeningBalance').value='0';$('bankAccountType').value='Current';$('bankOpeningDate').value=bankToday();}
function bankSaveAccountForm(){const name=$('bankAccountName').value.trim(),bank=$('bankBankName').value.trim(),opening=$('bankOpeningBalance').value,date=$('bankOpeningDate').value;if(!name||!bank||opening===''||!date){showNotice('Enter account name, bank name, opening balance and opening date.','Bank Account');return;}const payload={id:bankId('bankacc'),shop_key:bankShopKey(),account_name:name,bank_name:bank,account_number:$('bankAccountNumber').value.trim(),ifsc:$('bankIfsc').value.trim(),branch:$('bankBranch').value.trim(),account_type:$('bankAccountType').value,opening_balance:Number(opening),opening_date:date,notes:$('bankAccountNotes').value.trim(),active:true,created_at:new Date().toISOString(),updated_at:new Date().toISOString()};const result=Android.bankSaveAccount(JSON.stringify(payload));if(String(result).startsWith('ERROR:')){showNotice(String(result),'Bank Account');return;}bankClearAccountForm();renderBanking();showNotice('Bank account added. Opening balance is retained as the account starting balance.','Bank Account');}
function bankSaveTxnForm(){const account=$('bankTxnAccount').value,type=$('bankTxnType').value,amount=Number($('bankTxnAmount').value),date=$('bankTxnDate').value;if(!account||!date||!(amount>0)){showNotice('Select an account and enter a valid date and amount.','Bank Transaction');return;}const direction=type==='adjustment'?$('bankAdjustmentDirection').value:type;const payload={id:bankId('banktxn'),shop_key:bankShopKey(),account_id:account,txn_date:date,entry_type:type,credit:direction==='credit'?amount:0,debit:direction==='debit'?amount:0,category:type==='adjustment'?'Balance adjustment':$('bankTxnCategory').value,description:$('bankTxnDescription').value.trim(),reference_no:$('bankTxnReference').value.trim(),notes:$('bankTxnNotes').value.trim(),created_at:new Date().toISOString()};const result=Android.bankSaveTransaction(JSON.stringify(payload));if(String(result).startsWith('ERROR:')){showNotice(String(result),'Bank Transaction');return;}$('bankTxnAmount').value='';$('bankTxnDescription').value='';$('bankTxnReference').value='';$('bankTxnNotes').value='';bankHistoryPage=1;renderBanking();showNotice('Bank transaction saved in SQLite.','Bank Transaction');}
function bankSaveReconForm(){const account=$('bankReconAccount').value,month=$('bankReconMonth').value,closing=$('bankStatementClosing').value;if(!account||!month||closing===''){showNotice('Select an account and month, then enter the statement closing balance.','Reconciliation');return;}const payload={id:bankId('bankrec'),shop_key:bankShopKey(),account_id:account,period:month,statement_closing:Number(closing),notes:'Manual month-end statement balance',created_at:new Date().toISOString()};const r=Android.bankSaveReconciliation(JSON.stringify(payload));if(String(r).startsWith('ERROR:'))showNotice(String(r),'Reconciliation');else{bankRenderRecon();showNotice('Statement closing balance saved. Compare the difference and review unmatched transactions.','Reconciliation');}}
$('bankSaveAccountBtn')?.addEventListener('click',bankSaveAccountForm);$('bankClearAccountBtn')?.addEventListener('click',bankClearAccountForm);$('bankSaveTxnBtn')?.addEventListener('click',bankSaveTxnForm);$('bankRefreshBtn')?.addEventListener('click',renderBanking);$('bankHistoryAccount')?.addEventListener('change',()=>{bankHistoryPage=1;bankLoadHistory();});['bankHistoryFrom','bankHistoryTo'].forEach(id=>$(id)?.addEventListener('change',()=>{bankHistoryPage=1;bankLoadHistory();}));$('bankPrevBtn')?.addEventListener('click',()=>{bankHistoryPage=Math.max(1,bankHistoryPage-1);bankLoadHistory();});$('bankNextBtn')?.addEventListener('click',()=>{if(bankHistoryRows.length===25)bankHistoryPage++;bankLoadHistory();});$('bankSaveReconBtn')?.addEventListener('click',bankSaveReconForm);['bankReconAccount','bankReconMonth'].forEach(id=>$(id)?.addEventListener('change',bankRenderRecon));$('bankTxnDate')&&($('bankTxnDate').value=bankToday());$('bankOpeningDate')&&($('bankOpeningDate').value=bankToday());$('bankReconMonth')&&($('bankReconMonth').value=bankToday().slice(0,7));



// SiddhiBillPlus multi-firm workspace.
function sbpEscape(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function sbpSyncActiveFirmName(){const f=__sbActiveFirm();if(f&&state.settings?.shopName&&f.name!==state.settings.shopName){f.name=String(state.settings.shopName).trim();persistSbpRegistry();}}
function sbpUpdateFirmChrome(){sbpSyncActiveFirmName();const f=__sbActiveFirm();const label=$('firmSwitcherLabel');if(label)label.textContent=f?.name||state.settings.shopName||'Select firm';const brand=$('shopBrand');if(brand)brand.textContent=state.settings.shopName||f?.name||'Your Business';const home=$('homeShopName');if(home)home.textContent=state.settings.shopName||f?.name||'Your Business';document.title='SiddhiBillPlus · '+(f?.name||'Business');}
function sbpSeedFirm(firm){
 const emptyKeys=['pksProducts','pksCustomers','pksVendors','pksVendorPayments','pksTeamMembers','pksTeamAttendance','pksTeamPayments','pksBrokers','pksBrokerCommissions','pksBrokerPayments','pksEstimates','pksExpenses','pksGstCompliance','pksCustomerPayments','pksBills','pksPurchases','pksInventoryMovements'];
 const seed={};emptyKeys.forEach(k=>seed['sbp_'+firm.id+'__'+k]='[]');
 const cfg={...state.settings,shopName:firm.name,shopType:'',shopTypeLabel:'',address:'',footer:'Thank you for shopping with us!',signature:'',tagline:'',shopMobile:'',shopMobiles:[],logoData:'',gstin:'',businessState:'',fssai:'',billPrefix:'BILL',billStart:1,taxInvoicePrefix:'INV',taxInvoiceStart:1,taxationEnabled:false,inventoryManagement:false,vendorManagement:true,reverseCharge:false,showCustomer:true,printCustomerMobile:true,printPaymentMode:true,printItemCode:false,printShopName:true,printShopAddress:true,printShopMobile:true,printShopLogo:true,customBillField1Label:'',customBillField2Label:'',customBillField3Label:'',upiQrEnabled:false,upiQrSource:'upi',upiPayeeName:'',upiPrintAmount:false,merchantQrData:'',paperSize:'80mm',bluetoothPrinter:'auto',customUnits:[{name:'Roll',aliases:['roll','r','rl']}],unitCatalog:[],ocrProductAliases:{},ocrOwnerKeywords:'',termsConditions:'',printTermsConditions:false,upiId:'',upiName:''};
 seed['sbp_'+firm.id+'__dukaanBillSettings']=JSON.stringify(cfg);
 try{Object.entries(seed).forEach(([k,v])=>{localStorage.setItem(k,v);if(window.Android?.saveAppStateValue)Android.saveAppStateValue(k,v)}); }catch(e){console.error('Could not initialize new firm state',e);throw e;}
}
function sbpRenderFirmList(){
 const host=$('firmManagerList');if(!host)return;
 host.classList.add('firm-list');
 host.innerHTML=__sbFirmRegistry.firms.map(f=>{
  const active=f.id===__sbActiveFirmId,inactive=f.status==='inactive';
  const status=inactive?'Inactive':active?'Currently selected':'Active';
  const statusClass=inactive?'is-inactive':active?'is-selected':'is-active';
  const actions=active
   ? `<span class="firm-selected-label"><span class="firm-status-dot"></span>Selected</span>`
   : inactive
    ? `<button type="button" class="secondary firm-action" data-sbp-activate="${sbpEscape(f.id)}">Reactivate</button>`
    : `<button type="button" class="primary firm-action firm-switch-action" data-sbp-switch="${sbpEscape(f.id)}">Switch to firm</button>`;
  return `<article class="firm-card ${active?'firm-card-current':''} ${inactive?'firm-card-inactive':''}">
    <div class="firm-card-top">
      <div class="firm-avatar" aria-hidden="true">${sbpEscape(String(f.name||'B').trim().charAt(0).toUpperCase())}</div>
      <div class="firm-card-info"><h3>${sbpEscape(f.name)}</h3><div class="firm-card-meta">${f.isDefault?'Original SiddhiBill data':'Independent business data'}</div></div>
      <span class="firm-status ${statusClass}"><span class="firm-status-dot"></span>${status}</span>
    </div>
    <div class="firm-card-actions">${actions}<button type="button" class="secondary firm-action" data-sbp-rename="${sbpEscape(f.id)}">Rename</button>${!f.isDefault&&!inactive?`<button type="button" class="secondary firm-action firm-deactivate-action" data-sbp-deactivate="${sbpEscape(f.id)}">Deactivate</button>`:''}</div>
  </article>`;
 }).join('');
}

function sbpOpenFirmManager(){if(window.__sbFirmMigrationFailed){showNotice("The existing database could not complete the firm-isolation migration. Firm switching and new-firm creation are disabled to protect your data. Close and reopen the updated app, then contact support if this continues.","Firm migration required");return;}sbpUpdateFirmChrome();sbpRenderFirmList();$('firmManagerModal')?.classList.remove('hidden');}
function sbpCloseFirmManager(){$('firmManagerModal')?.classList.add('hidden');}
function sbpSwitchFirm(id){if(window.__sbFirmMigrationFailed){showNotice("Firm switching is blocked until the existing data migration succeeds.","Firm migration required");return;}const f=__sbFirmRegistry.firms.find(x=>x.id===id);if(!f||f.status==='inactive')return;if(id===__sbActiveFirmId){sbpCloseFirmManager();return;}if(typeof save==='function'&&save()===false){showNotice('Current firm data could not be saved. Firm switching has been cancelled.','Firm switch blocked');return;}__sbActiveFirmId=id;persistSbpRegistry();location.reload();}
function sbpAddFirm(){if(window.__sbFirmMigrationFailed){showNotice("Firm creation is blocked until the existing data migration succeeds.","Firm migration required");return;}const name=String($('newFirmName')?.value||'').trim();if(name.length<2){showNotice('Enter a firm name with at least 2 characters.','Add Firm');return;}if(__sbFirmRegistry.firms.some(f=>f.name.trim().toLowerCase()===name.toLowerCase()&&f.status!=='inactive')){showNotice('A firm with this name already exists.','Add Firm');return;}const id='firm_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,9);const firm={id,shopKey:id.toLowerCase(),name,status:'active',createdAt:new Date().toISOString(),isDefault:false};try{sbpSeedFirm(firm);__sbFirmRegistry.firms.push(firm);persistSbpRegistry();$('newFirmName').value='';sbpRenderFirmList();showNotice('Firm created with completely empty, independent business data. Switch to it to begin setup.','Firm created');}catch(e){showNotice('Firm creation failed. No switch was made. '+String(e.message||e),'Firm creation failed');}}
function sbpRenameFirm(id){const f=__sbFirmRegistry.firms.find(x=>x.id===id);if(!f)return;const next=prompt('Enter the new firm name:',f.name);if(next===null)return;const name=String(next).trim();if(name.length<2){showNotice('Firm name must contain at least 2 characters.','Rename Firm');return;}if(__sbFirmRegistry.firms.some(x=>x.id!==id&&x.name.toLowerCase()===name.toLowerCase())){showNotice('Another firm already uses this name.','Rename Firm');return;}f.name=name;if(id===__sbActiveFirmId){state.settings.shopName=name;save();sbpUpdateFirmChrome();}else{const key='sbp_'+id+'__dukaanBillSettings';try{const raw=localStorage.getItem(key);if(raw){const cfg=JSON.parse(raw);cfg.shopName=name;localStorage.setItem(key,JSON.stringify(cfg));if(window.Android?.saveAppStateValue)Android.saveAppStateValue(key,JSON.stringify(cfg));}}catch(e){showNotice('Could not update the firm settings. '+e.message,'Rename Firm');return;}}persistSbpRegistry();sbpRenderFirmList();}
function sbpDeactivateFirm(id){const f=__sbFirmRegistry.firms.find(x=>x.id===id);if(!f||f.isDefault)return;if(id===__sbActiveFirmId){showNotice('Switch to another firm before deactivating this one.','Deactivate Firm');return;}if(!confirm('Deactivate '+f.name+'? Its data will be retained and can be reactivated later.'))return;f.status='inactive';persistSbpRegistry();sbpRenderFirmList();}

function sbpFirmBackupData(){return {products:state.products,customers:state.customers,vendors:state.vendors,vendorPayments:state.vendorPayments,customerPayments:state.customerPayments,bills:state.bills,purchases:state.purchases,inventoryMovements:state.inventoryMovements,teamMembers:state.teamMembers,teamAttendance:state.teamAttendance,teamPayments:state.teamPayments,brokers:state.brokers,brokerCommissions:state.brokerCommissions,brokerPayments:state.brokerPayments,estimates:state.estimates,expenses:state.expenses,gstCompliance:state.gstCompliance,settings:state.settings};}
function sbpExportCurrentFirmBackup(){try{const f=__sbActiveFirm(),bundle={format:'SiddhiBillPlusFirmBackup',schemaVersion:1,exportedAt:new Date().toISOString(),firm:{name:f.name},data:sbpFirmBackupData()};const json=JSON.stringify(bundle);if(window.Android?.saveExportFile){const b64=btoa(unescape(encodeURIComponent(json)));Android.saveExportFile(b64,'SiddhiBillPlus_'+String(f.name).replace(/[^A-Za-z0-9_-]+/g,'_')+'_backup.json');showNotice('Firm backup export has been requested.','Firm Backup');}else{const blob=new Blob([json],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='SiddhiBillPlus_'+String(f.name).replace(/[^A-Za-z0-9_-]+/g,'_')+'_backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}}catch(e){showNotice('Firm backup could not be created: '+String(e.message||e),'Firm Backup');}}
function sbpRestoreBackupAsNewFirm(bundle){if(!bundle||bundle.format!=='SiddhiBillPlusFirmBackup'||!bundle.data||typeof bundle.data!=='object')throw new Error('This is not a supported SiddhiBillPlus firm backup.');const source=bundle.data,base=String(bundle.firm?.name||source.settings?.shopName||'Restored Firm').trim()||'Restored Firm';let name=base;if(__sbFirmRegistry.firms.some(f=>f.name.toLowerCase()===name.toLowerCase()))name=base+' (Restored '+new Date().toLocaleDateString('en-IN')+')';const id='firm_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,9),firm={id,shopKey:id.toLowerCase(),name,status:'active',createdAt:new Date().toISOString(),isDefault:false};sbpSeedFirm(firm);const map={products:'pksProducts',customers:'pksCustomers',vendors:'pksVendors',vendorPayments:'pksVendorPayments',teamMembers:'pksTeamMembers',teamAttendance:'pksTeamAttendance',teamPayments:'pksTeamPayments',brokers:'pksBrokers',brokerCommissions:'pksBrokerCommissions',brokerPayments:'pksBrokerPayments',estimates:'pksEstimates',expenses:'pksExpenses',gstCompliance:'pksGstCompliance'};Object.entries(map).forEach(([src,key])=>{const val=Array.isArray(source[src])?source[src]:src==='gstCompliance'&&source[src]&&typeof source[src]==='object'?source[src]:[];const raw=JSON.stringify(val);localStorage.setItem('sbp_'+id+'__'+key,raw);if(window.Android?.saveAppStateValue)Android.saveAppStateValue('sbp_'+id+'__'+key,raw);});const cfg={...(source.settings||{}),shopName:name};const cfgRaw=JSON.stringify(cfg);localStorage.setItem('sbp_'+id+'__dukaanBillSettings',cfgRaw);if(window.Android?.saveAppStateValue)Android.saveAppStateValue('sbp_'+id+'__dukaanBillSettings',cfgRaw);const remap=(rows)=>Array.isArray(rows)?rows.map(r=>({...r,shopKey:id.toLowerCase(),shopName:name})):[];const transactions={pksBills:remap(source.bills),pksPurchases:remap(source.purchases),pksInventoryMovements:remap(source.inventoryMovements),pksCustomerPayments:remap(source.customerPayments)};if(window.Android?.saveTransactionRecords){Object.entries(transactions).forEach(([collection,rows])=>Android.saveTransactionRecords(collection,JSON.stringify(rows)));}else{Object.entries(transactions).forEach(([collection,rows])=>localStorage.setItem('sbp_'+id+'__'+collection,JSON.stringify(rows)));}__sbFirmRegistry.firms.push(firm);persistSbpRegistry();sbpRenderFirmList();showNotice('Backup restored as a separate firm: '+name+'. Your existing firms were not changed.','Firm Restore');}
function sbpImportFirmBackupFile(file){if(!file)return;const reader=new FileReader();reader.onload=()=>{try{sbpRestoreBackupAsNewFirm(JSON.parse(String(reader.result||'')));}catch(e){showNotice('Restore failed: '+String(e.message||e),'Firm Restore');}};reader.onerror=()=>showNotice('Could not read the selected backup file.','Firm Restore');reader.readAsText(file);}
function sbpReadNativeState(key){try{if(!window.Android?.loadAppStateValueChunk)return null;let raw='',offset=0,part='',n=0;do{part=Android.loadAppStateValueChunk(key,offset,32768);if(typeof part!=='string')return null;raw+=part;n=Array.from(part).length;offset+=n;}while(n===32768);return raw?JSON.parse(raw):null;}catch(_){return null;}}
function sbpLoadCollectionAll(collection){if(!window.Android?.loadTransactionCollectionPage)return [];const out=[];let offset=0;while(true){const page=JSON.parse(Android.loadTransactionCollectionPage(collection,offset,500)||'{}');if(!page.supported||!Array.isArray(page.records))throw new Error('Could not read '+collection+' for consolidated reporting.');out.push(...page.records);if(page.records.length<500)break;offset+=page.records.length;}return out;}
function sbpConsolidatedSummary(){const out=$('firmConsolidatedResult');if(!out)return;out.textContent='Preparing firm-wise summary…';try{let bills=[],purchases=[];if(window.Android?.loadTransactionCollectionPage){bills=sbpLoadCollectionAll('pksBills');purchases=sbpLoadCollectionAll('pksPurchases');}else{__sbFirmRegistry.firms.forEach(f=>{const read=k=>{try{return JSON.parse(localStorage.getItem('sbp_'+f.id+'__'+k)||'[]')}catch(_){return []}};bills.push(...read('pksBills'));purchases.push(...read('pksPurchases'));});}const rows=__sbFirmRegistry.firms.filter(f=>f.status!=='inactive').map(f=>{const key=String(f.shopKey||f.id).toLowerCase(),bs=bills.filter(x=>String(x.shopKey||'').toLowerCase()===key),ps=purchases.filter(x=>String(x.shopKey||'').toLowerCase()===key);return {name:f.name,sales:bs.reduce((a,x)=>a+Number(x.total||0),0),salesCount:bs.length,purchase:ps.reduce((a,x)=>a+Number(x.total||x.grandTotal||0),0),purchaseCount:ps.length};});out.innerHTML='<b>Consolidated view · Active firms</b>'+rows.map(r=>`<div class="history-row"><div><b>${sbpEscape(r.name)}</b><div class="muted">${r.salesCount} sales bills · ${r.purchaseCount} purchase bills</div></div><div style="text-align:right"><b>Sales ${money(r.sales)}</b><div class="muted">Purchases ${money(r.purchase)}</div></div></div>`).join('')+`<p><b>All-firm sales: ${money(rows.reduce((a,r)=>a+r.sales,0))} · Purchases: ${money(rows.reduce((a,r)=>a+r.purchase,0))}</b></p><small>Based on saved bills and purchase records. This summary is not a consolidated statutory or profit-and-loss statement.</small>`;}catch(e){out.textContent='Consolidated summary unavailable: '+String(e.message||e);}}
function sbpBindFirmManager(){
 $('firmSwitcherBtn')?.addEventListener('click',sbpOpenFirmManager);$('firmManagerClose')?.addEventListener('click',sbpCloseFirmManager);$('addFirmBtn')?.addEventListener('click',sbpAddFirm);$('firmExportBtn')?.addEventListener('click',sbpExportCurrentFirmBackup);$('firmImportBtn')?.addEventListener('click',()=>$('firmImportFile')?.click());$('firmImportFile')?.addEventListener('change',e=>{sbpImportFirmBackupFile(e.target.files?.[0]);e.target.value='';});$('firmConsolidatedBtn')?.addEventListener('click',sbpConsolidatedSummary);
 $('firmManagerModal')?.addEventListener('click',e=>{if(e.target===$('firmManagerModal'))sbpCloseFirmManager();});
 $('firmManagerList')?.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.sbpSwitch)sbpSwitchFirm(b.dataset.sbpSwitch);else if(b.dataset.sbpActivate){const f=__sbFirmRegistry.firms.find(x=>x.id===b.dataset.sbpActivate);if(f){f.status='active';persistSbpRegistry();sbpRenderFirmList();}}else if(b.dataset.sbpRename)sbpRenameFirm(b.dataset.sbpRename);else if(b.dataset.sbpDeactivate)sbpDeactivateFirm(b.dataset.sbpDeactivate);});
 sbpUpdateFirmChrome();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',sbpBindFirmManager,{once:true});else sbpBindFirmManager();
