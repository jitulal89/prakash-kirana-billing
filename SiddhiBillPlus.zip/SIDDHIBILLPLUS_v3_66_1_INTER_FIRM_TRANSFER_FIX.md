# SiddhiBillPlus v3.66.1 – Inter-Firm Transfer Selector Fix

## Fixes
- Reads non-active firms' tracked products from the persisted firm-scoped `localStorage` records when they are not present in the in-memory native store.
- Uses the currently active firm's live `state.products` as the source of truth for its product list.
- Populates the transfer product selector only with tracked products that resolve to the same group product ID in both the active source firm and selected destination firm.
- Refreshes mapped transfer products whenever the destination firm changes.
- Shows a clear empty option when no shared mapped products exist or no other active firm is included in the group.
- Keeps firm-specific stock quantities and movement handling separate.

## Validation
- JavaScript syntax check and static transfer-selector assertions passed.
- APK build and Android device regression testing are not available in this environment; verify on device before production rollout.
