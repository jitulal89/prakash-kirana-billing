# SiddhiBillPlus v3.65.0 — Multi-firm source release

- Rebranded the application to SiddhiBillPlus while preserving Android application ID `com.siddhibill.app`, Java namespace `com.dukaanbill.app`, and database `dukaanbill.db`.
- Added a local firm registry, firm switcher, add/rename/activate/deactivate workflows, and firm-specific application-state namespaces.
- Existing unassigned transaction and banking records are migrated to the original firm. Legacy sales bill record IDs are re-keyed as part of this migration.
- Sales, purchases, inventory movements, customer payments and banking use firm-scoped `shop_key` values; products, customers, vendors and other masters/settings are persisted under firm-specific state keys.
- Added per-firm JSON backup export and restore-as-new-firm.
- Added an on-demand consolidated sales/purchase summary by active firm.
- Retained the existing offline-only architecture and app lock/fingerprint behavior.

Validation performed in this workspace:
- JavaScript syntax check passed (`node --check`).
- SiddhiBillPlus multi-firm source assertions passed.
- Existing v3.64.71 inventory source assertions passed.
- SQLite migration SQL was exercised against a temporary SQLite database.

Build limitation: Android Gradle compilation and physical-device testing were not available in this workspace (no local Gradle executable/wrapper or Android SDK). Use the included GitHub Actions workflow to build the APK and complete device-level validation before production rollout.

See `SIDDHIBILLPLUS_V3_65_0_RELEASE_NOTES.md` for scope and safety notes.
