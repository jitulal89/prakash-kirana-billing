# SiddhiBillPlus v3.65.1 — Manage Firms UI

## UI improvements
- Rebuilt firm rows as responsive cards with a dedicated identity, status and action area.
- Removed the overlapping flex-row layout that caused long firm names and action buttons to collide on narrow screens.
- Added clear active/selected/inactive status treatments.
- Added compact, touch-friendly Switch, Reactivate, Rename and Deactivate actions.
- Reworked firm backup, restore and consolidated summary actions into a responsive tool grid.
- Improved modal width, spacing, typography, scrolling and small-screen behaviour.
- Preserved existing firm-management element IDs and event delegation so existing actions remain wired.

## Validation
- JavaScript syntax check: passed with Node.js `--check`.
- ZIP integrity: verified after packaging.
- Android APK build: not run; Gradle is not installed in this environment.
