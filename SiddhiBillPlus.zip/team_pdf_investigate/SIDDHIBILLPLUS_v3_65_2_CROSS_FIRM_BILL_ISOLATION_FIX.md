# SiddhiBillPlus v3.65.2 — Cross-firm bill isolation fix

## Root cause
- Bill persistence did not consistently stamp `shopKey` on the bill JSON.
- SQLite bill primary keys are `shopKey|billNo`; missing shopKey produced the global legacy key `|billNo`.
- Bill view/edit lookup had a fallback to `|billNo`, allowing a firm to fetch an unscoped bill.
- Bill delete also attempted the global `|billNo` key.
- Generic module filtering treated records with missing shopKey as belonging to every firm.

## Fixes
- Stamp active `shopKey` and `shopName` on every newly created or updated bill before state and SQLite persistence.
- Stamp firm identity when saving payment follow-up changes.
- Remove unscoped bill lookup and delete fallbacks.
- Use only the current firm's composite key for bill fetch, update and delete.
- Enforce at the SQLite persistence boundary that every `pksBills` record has a non-empty `shopKey`.
- Treat untagged legacy records as belonging only to the original/default firm, never as a wildcard for all firms.
- Add a final ownership check before opening a bill preview/editor.

## Validation
- Node.js JavaScript syntax check: passed.
- Static assertions for tenant stamping, scoped lookup/delete, strict filtering and native persistence guard: passed.
- ZIP integrity: verified.
- Android APK compilation/device regression: not run in this environment (Android Gradle build unavailable).

## Existing data note
Legacy blank-tenant bills are assigned to the original/default firm by the existing migration routine. Bills created while the previous defective build was active may already have collided if two firms used the same bill number. This source fix prevents future unscoped saves; it cannot reconstruct overwritten historical bill data. Back up the database before installing and review affected firm histories.
