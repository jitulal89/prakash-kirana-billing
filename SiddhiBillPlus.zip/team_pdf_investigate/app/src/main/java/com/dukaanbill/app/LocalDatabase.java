package com.dukaanbill.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONObject;
import org.json.JSONArray;

import java.util.Iterator;

public class LocalDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "dukaanbill.db";
    private static final int DB_VERSION = 1;
    private final java.util.Map<String, String> transactionJsonCache = new java.util.HashMap<>();

    public LocalDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS app_state (state_key TEXT PRIMARY KEY, state_value TEXT NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS meta (meta_key TEXT PRIMARY KEY, meta_value TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS transaction_records (collection TEXT NOT NULL, record_id TEXT NOT NULL, sort_date TEXT, source_type TEXT, source_id TEXT, shop_key TEXT, product_name TEXT, record_json TEXT NOT NULL, PRIMARY KEY(collection, record_id))");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_transaction_records_date ON transaction_records(collection, sort_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_transaction_records_shop_date ON transaction_records(collection, shop_key, sort_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_transaction_records_customer ON transaction_records(collection, shop_key, lower(trim(COALESCE(json_extract(record_json,'$.customer'),''))), sort_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_transaction_records_source ON transaction_records(collection, source_type, source_id)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_transaction_records_product ON transaction_records(collection, shop_key, product_name, sort_date)");
        db.execSQL("CREATE TABLE IF NOT EXISTS bank_accounts (id TEXT PRIMARY KEY, shop_key TEXT NOT NULL, account_name TEXT NOT NULL, bank_name TEXT NOT NULL, account_number TEXT, ifsc TEXT, branch TEXT, account_type TEXT, opening_balance REAL NOT NULL DEFAULT 0, opening_date TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, notes TEXT, created_at TEXT, updated_at TEXT)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_bank_accounts_shop ON bank_accounts(shop_key, active)");
        db.execSQL("CREATE TABLE IF NOT EXISTS bank_transactions (id TEXT PRIMARY KEY, shop_key TEXT NOT NULL, account_id TEXT NOT NULL, txn_date TEXT NOT NULL, entry_type TEXT NOT NULL, credit REAL NOT NULL DEFAULT 0, debit REAL NOT NULL DEFAULT 0, category TEXT, description TEXT, reference_no TEXT, notes TEXT, matched INTEGER NOT NULL DEFAULT 0, created_at TEXT)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_bank_txn_account_date ON bank_transactions(shop_key, account_id, txn_date DESC)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_bank_txn_shop_date ON bank_transactions(shop_key, txn_date DESC)");
        db.execSQL("CREATE TABLE IF NOT EXISTS bank_reconciliations (id TEXT PRIMARY KEY, shop_key TEXT NOT NULL, account_id TEXT NOT NULL, period TEXT NOT NULL, statement_opening REAL NOT NULL DEFAULT 0, statement_closing REAL NOT NULL DEFAULT 0, notes TEXT, created_at TEXT, UNIQUE(shop_key,account_id,period))");
        db.execSQL("CREATE TABLE IF NOT EXISTS bank_reconciliation_items (id TEXT PRIMARY KEY, reconciliation_id TEXT NOT NULL, transaction_id TEXT NOT NULL, match_status TEXT NOT NULL, statement_amount REAL, notes TEXT, UNIQUE(reconciliation_id,transaction_id))");
    }

    @Override public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        // Additive tables are ensured without bumping SQLite user_version. This keeps
        // backup databases readable by older SiddhiBill builds that use the legacy
        // app_state JSON keys and would otherwise reject a database downgrade.
        onCreate(db);
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    // Small backup metadata snapshot. Transaction collections are migrated to the
    // normalized table first and exported inside SQLite by MainActivity, avoiding
    // multiple 100+ MB Java strings during large backups.
    public synchronized String loadStateForBackup() throws Exception {
        SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction();
        try {
            for(String collection:new String[]{"pksBills","pksPurchases","pksInventoryMovements","pksCustomerPayments"}) migrateLegacyCollection(db,collection);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        // Read app_state values in bounded SQLite substr() chunks. Calling Cursor.getString()
        // on an entire large state_value can exceed Android's CursorWindow (the reported
        // "Row too big to fit" failure), even when transaction arrays are normalized.
        JSONObject out=new JSONObject();
        java.util.ArrayList<String> keys=new java.util.ArrayList<>();
        try(Cursor c=db.rawQuery("SELECT state_key FROM app_state WHERE state_key NOT IN ('pksBills','pksPurchases','pksInventoryMovements') ORDER BY state_key",null)) {
            while(c.moveToNext()) keys.add(c.getString(0));
        }
        final int chunkSize=65536;
        for(String key:keys){
            StringBuilder value=new StringBuilder(); int offset=0;
            while(true){
                String part="";
                try(Cursor c=db.rawQuery("SELECT substr(state_value, ?, ?) FROM app_state WHERE state_key=?",new String[]{String.valueOf(offset+1),String.valueOf(chunkSize),key})){
                    if(c.moveToFirst()) part=c.getString(0)==null?"":c.getString(0);
                }
                if(part.isEmpty()) break;
                value.append(part); int points=Character.codePointCount(part,0,part.length()); offset+=points;
                if(points<chunkSize) break;
            }
            out.put(key,value.toString());
        }
        return out.toString();
    }

    public synchronized String loadState() {
        JSONObject out = new JSONObject();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT state_key,state_value FROM app_state", null)) {
            while (c.moveToNext()) {
                out.put(c.getString(0), c.getString(1));
            }
        } catch (Exception ignored) {}
        try {
            for (String collection : new String[]{"pksBills", "pksPurchases", "pksInventoryMovements"}) {
                JSONArray records = readTransactionArray(db, collection);
                if (records.length() > 0 || !out.has(collection)) out.put(collection, records.toString());
            }
        } catch (Exception ignored) {}
        return out.toString();
    }

    public synchronized String loadStateValue(String key) {
        SQLiteDatabase db=getReadableDatabase();
        try(Cursor c=db.rawQuery("SELECT state_value FROM app_state WHERE state_key=?",new String[]{key})) { return c.moveToFirst()?c.getString(0):null; }
        catch(Exception e){return null;}
    }

    // Read large WebView state in bounded pieces instead of returning one multi-megabyte bridge value.
    public synchronized String getTransactionCountsJson() throws Exception {
        JSONObject out=new JSONObject();SQLiteDatabase db=getReadableDatabase();
        for(String collection:new String[]{"pksBills","pksPurchases","pksInventoryMovements"}){
            long count=0;try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM transaction_records WHERE collection=?",new String[]{collection})){if(c.moveToFirst())count=c.getLong(0);}
            if(count==0){try(Cursor c=db.rawQuery("SELECT state_value FROM app_state WHERE state_key=?",new String[]{collection})){if(c.moveToFirst())try{count=new JSONArray(c.getString(0)).length();}catch(Exception ignored){}}}
            out.put(collection,count);
        }
        return out.toString();
    }

    public synchronized String loadStateKeys() throws Exception {
        JSONArray keys = new JSONArray();
        SQLiteDatabase db = getReadableDatabase();
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        try (Cursor c = db.rawQuery("SELECT state_key FROM app_state ORDER BY state_key", null)) {
            while (c.moveToNext()) { String k=c.getString(0); keys.put(k); seen.add(k); }
        }
        try (Cursor c = db.rawQuery("SELECT DISTINCT collection FROM transaction_records", null)) {
            while (c.moveToNext()) { String k=c.getString(0); if(!seen.contains(k)) keys.put(k); }
        }
        return keys.toString();
    }

    public synchronized String loadStateValueChunk(String key, int offset, int maxLength) throws Exception {
        if (key == null || offset < 0 || maxLength < 1 || maxLength > 262144) throw new IllegalArgumentException("Invalid state chunk request");
        // IMPORTANT: slice inside SQLite. Calling getString() on state_value here
        // would materialize the complete multi-megabyte JSON value for every chunk.
        // offset/maxLength are Unicode code-point positions (not UTF-16 code units).
        SQLiteDatabase db = getReadableDatabase();
        if ("pksBills".equals(key) || "pksPurchases".equals(key) || "pksInventoryMovements".equals(key)) {
            // A restored compatibility backup stores transaction arrays in app_state
            // and may not contain transaction_records. Migrate before reading; otherwise
            // diagnostics can count legacy rows while the UI receives an empty array.
            if (!transactionJsonCache.containsKey(key)) {
                SQLiteDatabase writable = getWritableDatabase();
                writable.beginTransaction();
                try { migrateLegacyCollection(writable, key); writable.setTransactionSuccessful(); }
                finally { writable.endTransaction(); }
                db = getReadableDatabase();
            }
            String cached = transactionJsonCache.get(key);
            if (cached == null) { cached = readTransactionJson(db, key); transactionJsonCache.put(key, cached); }
            int total=cached.codePointCount(0,cached.length());
            if (offset >= total) { transactionJsonCache.remove(key); return ""; }
            int start=cached.offsetByCodePoints(0, offset), end=cached.offsetByCodePoints(start, Math.min(maxLength, total-offset));
            String chunk=cached.substring(start,end);
            if (chunk.codePointCount(0,chunk.length()) < maxLength) transactionJsonCache.remove(key);
            return chunk;
        }
        String sql = "SELECT substr(state_value, ?, ?) FROM app_state WHERE state_key=?";
        try (Cursor c = db.rawQuery(sql, new String[]{String.valueOf(offset + 1), String.valueOf(maxLength), key})) {
            if (!c.moveToFirst()) return "";
            String chunk = c.getString(0);
            return chunk == null ? "" : chunk;
        }
    }

    // Persist one state key without serializing or rewriting unrelated large transaction arrays.
    // Read compact vendor balances directly from the JSON transaction store.
    // JSON1 is available on supported Android SQLite builds; callers fall back safely
    // to the existing full-state path if this query is unavailable.
    public synchronized String loadVendorSummaryJson() throws Exception {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction(); try { migrateLegacyCollection(db, "pksPurchases"); db.setTransactionSuccessful(); } finally { db.endTransaction(); }
        JSONObject out = new JSONObject();
        JSONArray rows = new JSONArray();
        try (Cursor c = db.rawQuery(
                "SELECT json_extract(record_json,'$.vendorId'), " +
                "SUM(COALESCE(CAST(json_extract(record_json,'$.total') AS REAL),0)), " +
                "SUM(COALESCE(CAST(json_extract(record_json,'$.paid') AS REAL),0)), COUNT(*) " +
                "FROM transaction_records WHERE collection='pksPurchases' " +
                "GROUP BY json_extract(record_json,'$.vendorId')", null)) {
            while (c.moveToNext()) {
                JSONObject row = new JSONObject();
                row.put("vendorId", c.isNull(0) ? "" : c.getString(0));
                row.put("purchases", c.getDouble(1));
                row.put("purchasePaid", c.getDouble(2));
                row.put("billCount", c.getInt(3));
                rows.put(row);
            }
        }
        JSONArray paymentRows = new JSONArray();
        double paymentTotal = 0;
        try (Cursor c = db.rawQuery(
                "SELECT json_extract(e.value,'$.vendorId'), COALESCE(SUM(CAST(json_extract(e.value,'$.amount') AS REAL)),0) " +
                "FROM app_state s, json_each(s.state_value) e WHERE s.state_key='pksVendorPayments' " +
                "GROUP BY json_extract(e.value,'$.vendorId')", null)) {
            while (c.moveToNext()) { JSONObject row = new JSONObject(); row.put("vendorId", c.isNull(0) ? "" : c.getString(0)); row.put("paid", c.getDouble(1)); paymentTotal += c.getDouble(1); paymentRows.put(row); }
        }
        out.put("supported", true);
        out.put("vendors", rows);
        out.put("paymentsByVendor", paymentRows);
        out.put("vendorPaymentTotal", paymentTotal);
        return out.toString();
    }

    // Return only one purchase-history page. Search includes invoice/vendor metadata
    // and common item identifiers without transferring the full purchase JSON blob.
    public synchronized String loadPurchasePageJson(int offset, int limit, String search) throws Exception {
        if (offset < 0 || limit < 1 || limit > 200) throw new IllegalArgumentException("Invalid purchase page");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction(); try { migrateLegacyCollection(db, "pksPurchases"); db.setTransactionSuccessful(); } finally { db.endTransaction(); }
        String q = search == null ? "" : search.trim().toLowerCase();
        String where = "collection='pksPurchases'";
        java.util.ArrayList<String> args = new java.util.ArrayList<>();
        if (!q.isEmpty()) {
            where += " AND (lower(COALESCE(json_extract(record_json,'$.invoiceNo'),'')) LIKE ? " +
                    "OR lower(COALESCE(json_extract(record_json,'$.vendorName'),'')) LIKE ? " +
                    "OR lower(COALESCE(json_extract(record_json,'$.date'),'')) LIKE ? " +
                    "OR lower(COALESCE(json_extract(record_json,'$.id'),'')) LIKE ? " +
                    "OR EXISTS (SELECT 1 FROM json_each(json_extract(record_json,'$.items')) i WHERE " +
                    "lower(COALESCE(json_extract(i.value,'$.name'),'')) LIKE ? OR " +
                    "lower(COALESCE(json_extract(i.value,'$.hsn'),'')) LIKE ? OR " +
                    "lower(COALESCE(json_extract(i.value,'$.barcode'),'')) LIKE ?))";
            String like = "%" + q + "%";
            for (int i=0;i<7;i++) args.add(like);
        }
        String[] bind = args.toArray(new String[0]);
        int count = 0;
        try (Cursor c = db.rawQuery("SELECT COUNT(*) FROM transaction_records WHERE " + where, bind)) {
            if (c.moveToFirst()) count = c.getInt(0);
        }
        JSONArray records = new JSONArray();
        java.util.ArrayList<String> pageArgs = new java.util.ArrayList<>(args);
        pageArgs.add(String.valueOf(limit)); pageArgs.add(String.valueOf(offset));
        try (Cursor c = db.rawQuery("SELECT record_json FROM transaction_records WHERE " + where +
                " ORDER BY COALESCE(sort_date,'') DESC, rowid DESC LIMIT ? OFFSET ?", pageArgs.toArray(new String[0]))) {
            while (c.moveToNext()) records.put(new JSONObject(c.getString(0)));
        }
        JSONObject out = new JSONObject(); out.put("supported", true); out.put("total", count); out.put("records", records);
        return out.toString();
    }

    // Read one selected transaction without materializing the complete history array.
    // Bounded page reader for legacy features that still require an in-memory collection.
    // Normal screen rendering should use purpose-built summary/page queries instead.
    public synchronized String loadTransactionCollectionPageJson(String collection,int offset,int limit) throws Exception {
        if(!isTransactionCollection(collection)) throw new IllegalArgumentException("Unsupported transaction collection");
        if(offset<0)offset=0;if(limit<1)limit=100;if(limit>10000)limit=10000;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try { migrateLegacyCollection(db,collection); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); }
        JSONArray rows=new JSONArray();
        try(Cursor c=db.rawQuery("SELECT record_json FROM transaction_records WHERE collection=? ORDER BY COALESCE(sort_date,''),rowid LIMIT ? OFFSET ?",new String[]{collection,String.valueOf(limit),String.valueOf(offset)})) {
            while(c.moveToNext()) rows.put(new JSONObject(c.getString(0)));
        }
        JSONObject out=new JSONObject();out.put("supported",true);out.put("records",rows);out.put("count",rows.length());
        return out.toString();
    }

    // Compact team sales aggregate; avoids parsing the entire sales history in Team Management.
    public synchronized String loadTeamSalesSummaryJson(String from,String to,String shopKey) throws Exception {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try { migrateLegacyCollection(db,"pksBills"); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); }
        JSONArray rows=new JSONArray();
        String salespersonExpr="COALESCE(NULLIF(json_extract(record_json,'$.salespersonId'),''),NULLIF(json_extract(record_json,'$.salesPersonId'),''),NULLIF(json_extract(record_json,'$.salesperson_id'),''),'')";
        String dateExpr="COALESCE(NULLIF(sort_date,''),json_extract(record_json,'$.date'),'')";
        String shopExpr="LOWER(TRIM(COALESCE(NULLIF(shop_key,''),json_extract(record_json,'$.shopKey'),'')))";
        String sql="SELECT "+salespersonExpr+",COUNT(*),COALESCE(SUM(COALESCE(json_extract(record_json,'$.total'),0)),0) FROM transaction_records WHERE collection='pksBills' AND "+dateExpr+">=? AND "+dateExpr+"<=? AND ("+shopExpr+"=LOWER(TRIM(?)) OR "+shopExpr+"='') AND "+salespersonExpr+"<>'' GROUP BY "+salespersonExpr;
        try(Cursor c=db.rawQuery(sql,new String[]{from==null?"":from,to==null?"9999-12-31":to+"\uffff",shopKey==null?"":shopKey})) {
            while(c.moveToNext()){JSONObject o=new JSONObject();o.put("salespersonId",c.getString(0));o.put("billCount",c.getInt(1));o.put("total",c.getDouble(2));rows.put(o);}
        }
        return rows.toString();
    }

    // Detailed bills are fetched only when the Team Report PDF is explicitly requested.
    public synchronized String loadTeamSalesBillsJson(String from,String to,String shopKey,String memberId) throws Exception {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try { migrateLegacyCollection(db,"pksBills"); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); }
        JSONArray rows=new JSONArray();
        String salespersonExpr="COALESCE(NULLIF(json_extract(record_json,'$.salespersonId'),''),NULLIF(json_extract(record_json,'$.salesPersonId'),''),NULLIF(json_extract(record_json,'$.salesperson_id'),''),'')";
        String dateExpr="COALESCE(NULLIF(sort_date,''),json_extract(record_json,'$.date'),'')";
        String shopExpr="LOWER(TRIM(COALESCE(NULLIF(shop_key,''),json_extract(record_json,'$.shopKey'),'')))";
        String sql="SELECT record_json FROM transaction_records WHERE collection='pksBills' AND "+dateExpr+">=? AND "+dateExpr+"<=? AND ("+shopExpr+"=LOWER(TRIM(?)) OR "+shopExpr+"='') AND "+salespersonExpr+"=? ORDER BY "+dateExpr+",rowid";
        try(Cursor c=db.rawQuery(sql,new String[]{from==null?"":from,to==null?"9999-12-31":to+"\uffff",shopKey==null?"":shopKey,memberId==null?"":memberId})) {
            while(c.moveToNext()) rows.put(new JSONObject(c.getString(0)));
        }
        return rows.toString();
    }

    // Cash sales and cash purchases for the Payment Transactions report, scoped in SQLite.
    public synchronized String loadCashPaymentReportRowsJson(String from,String to,String shopKey) throws Exception {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try { migrateLegacyCollection(db,"pksBills"); migrateLegacyCollection(db,"pksPurchases"); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); }
        JSONArray rows=new JSONArray();
        String billSql="SELECT record_json FROM transaction_records WHERE collection='pksBills' AND COALESCE(sort_date,'')>=? AND COALESCE(sort_date,'')<=? AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='') AND lower(trim(COALESCE(json_extract(record_json,'$.paymentMode'),'Cash')))='cash'";
        try(Cursor c=db.rawQuery(billSql,new String[]{from==null?"":from,to==null?"9999-12-31":to+"\uffff",shopKey==null?"":shopKey})) {
            while(c.moveToNext()){JSONObject b=new JSONObject(c.getString(0));double amount=b.optDouble("total",0);if(amount<=0)continue;JSONObject o=new JSONObject();o.put("date",b.optString("date",""));o.put("party",b.optString("customer","Walk-in Customer"));o.put("type","Cash sale");o.put("credit",amount);o.put("debit",0);o.put("reference",b.optString("billNo",""));o.put("paymentId","cash-sale-"+b.optString("billNo",""));rows.put(o);}
        }
        String purchaseSql="SELECT record_json FROM transaction_records WHERE collection='pksPurchases' AND COALESCE(COALESCE(json_extract(record_json,'$.paymentDate'),json_extract(record_json,'$.date'),''),'')>=? AND COALESCE(COALESCE(json_extract(record_json,'$.paymentDate'),json_extract(record_json,'$.date'),''),'')<=? AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='') AND lower(trim(COALESCE(json_extract(record_json,'$.paymentMode'),'Credit')))='cash'";
        try(Cursor c=db.rawQuery(purchaseSql,new String[]{from==null?"":from,to==null?"9999-12-31":to+"\uffff",shopKey==null?"":shopKey})) {
            while(c.moveToNext()){JSONObject p=new JSONObject(c.getString(0));double amount=p.has("paid")?p.optDouble("paid",0):p.optDouble("total",p.optDouble("grandTotal",0));if(amount<=0)continue;String invoice=p.optString("invoiceNo",p.optString("billNo",p.optString("id","")));JSONObject o=new JSONObject();o.put("date",p.optString("paymentDate",p.optString("date","")));o.put("party",p.optString("vendorName","Vendor"));o.put("type","Cash purchase");o.put("credit",0);o.put("debit",amount);o.put("reference",invoice);o.put("paymentId","cash-purchase-"+invoice);rows.put(o);}
        }
        return rows.toString();
    }

    public synchronized String loadTransactionRecordJson(String collection,String recordId) throws Exception {
        if(!isTransactionCollection(collection)) throw new IllegalArgumentException("Unsupported transaction collection");
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,collection);db.setTransactionSuccessful();}finally{db.endTransaction();}
        try(Cursor c=db.rawQuery("SELECT record_json FROM transaction_records WHERE collection=? AND record_id=? LIMIT 1",new String[]{collection,recordId==null?"":recordId})) {return c.moveToFirst()?c.getString(0):"";}
    }

    public synchronized String loadServiceDueBillsJson(String from,String to,String shopKey) throws Exception {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,"pksBills");db.setTransactionSuccessful();}finally{db.endTransaction();}
        JSONArray rows=new JSONArray();
        String sql="SELECT record_json FROM transaction_records WHERE collection='pksBills' AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='') AND COALESCE(json_extract(record_json,'$.customFields.field3'),'')>=? AND COALESCE(json_extract(record_json,'$.customFields.field3'),'')<=? ORDER BY COALESCE(json_extract(record_json,'$.customFields.field3'),''),rowid";
        try(Cursor c=db.rawQuery(sql,new String[]{shopKey,from,to})){while(c.moveToNext())rows.put(new JSONObject(c.getString(0)));}
        return rows.toString();
    }

    // Compact customer credit summary for the Reports landing screen.
    public synchronized String loadCustomerCreditSummaryJson(String shopKey) throws Exception {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,"pksBills");migrateLegacyCollection(db,"pksCustomerPayments");db.setTransactionSuccessful();}finally{db.endTransaction();}
        JSONArray rows=new JSONArray();
        String sql="SELECT COALESCE(json_extract(record_json,'$.customer'),''), SUM(CASE WHEN COALESCE(json_extract(record_json,'$.paymentMode'),'Cash')='Credit' THEN MAX(0,COALESCE(json_extract(record_json,'$.total'),0)-MAX(COALESCE(json_extract(record_json,'$.partialPaymentAmount'),0),(SELECT COALESCE(SUM(COALESCE(json_extract(lp.record_json,'$.amount'),0)),0) FROM transaction_records lp WHERE lp.collection='pksCustomerPayments' AND COALESCE(json_extract(lp.record_json,'$.sourceBillNo'),'')=COALESCE(json_extract(transaction_records.record_json,'$.billNo'),'') AND (COALESCE(lp.shop_key,'')=? OR COALESCE(lp.shop_key,'')='')))) ELSE 0 END), MAX(COALESCE(json_extract(record_json,'$.paymentFollowUpDate'),'')), MAX(COALESCE(json_extract(record_json,'$.customerPhone'),'')), MAX(COALESCE(json_extract(record_json,'$.billNo'),'')), SUM(COALESCE(json_extract(record_json,'$.total'),0)), COUNT(*), MAX(COALESCE(sort_date,'')), (SELECT COALESCE(SUM(COALESCE(json_extract(cp.record_json,'$.amount'),0)),0) FROM transaction_records cp WHERE cp.collection='pksCustomerPayments' AND lower(trim(COALESCE(json_extract(cp.record_json,'$.customer'),'')))=lower(trim(COALESCE(json_extract(transaction_records.record_json,'$.customer'),''))) AND (COALESCE(cp.shop_key,'')=? OR COALESCE(cp.shop_key,'')='') AND COALESCE(json_extract(cp.record_json,'$.sourceBillNo'),'')='') FROM transaction_records WHERE collection='pksBills' AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='') GROUP BY lower(COALESCE(json_extract(record_json,'$.customer'),''))";
        try(Cursor c=db.rawQuery(sql,new String[]{shopKey,shopKey,shopKey})){while(c.moveToNext()){JSONObject o=new JSONObject();o.put("customer",c.getString(0));o.put("creditSales",c.getDouble(1));o.put("followUpDate",c.getString(2));o.put("customerPhone",c.getString(3));o.put("billNo",c.getString(4));o.put("totalSales",c.getDouble(5));o.put("billCount",c.getInt(6));o.put("latestBillDate",c.getString(7));o.put("standalonePayments",c.getDouble(8));rows.put(o);}}
        return rows.toString();
    }


    // Return the next invoice sequence without materializing the complete bill history in WebView.
    public synchronized int nextInvoiceSequence(String prefix,String year,String shopKey,int start) throws Exception {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,"pksBills");db.setTransactionSuccessful();}finally{db.endTransaction();}
        String billPrefix=prefix==null?"PKS":prefix;
        // Support both the current PREFIX-YEAR/NNN format and legacy PREFIX-NNNNN
        // bills. The old array-based implementation scanned all bills, so retain its
        // monotonic sequence behaviour and never restart at 001 after a migration.
        String sql="SELECT MAX(CASE WHEN instr(COALESCE(json_extract(record_json,'$.billNo'),''),'/')>0 THEN CAST(substr(json_extract(record_json,'$.billNo'),instr(json_extract(record_json,'$.billNo'),'/')+1) AS INTEGER) ELSE CAST(substr(json_extract(record_json,'$.billNo'),instr(upper(json_extract(record_json,'$.billNo')),upper(?)||'-')+length(?)+1) AS INTEGER) END) FROM transaction_records WHERE collection='pksBills' AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='') AND instr(upper(COALESCE(json_extract(record_json,'$.billNo'),'')),upper(?)||'-')>0";
        try(Cursor c=db.rawQuery(sql,new String[]{billPrefix,billPrefix,shopKey==null?"":shopKey,billPrefix})){return Math.max(start,c.moveToFirst()?c.getInt(0)+1:start);}
    }

    // Customer balance aggregate; only two scalar totals cross the bridge.
    public synchronized String loadCustomerDueJson(String customer,String shopKey) throws Exception {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,"pksBills");migrateLegacyCollection(db,"pksCustomerPayments");db.setTransactionSuccessful();}finally{db.endTransaction();}
        double credit=0,paid=0;
        String billSql="SELECT COALESCE(SUM(CASE WHEN COALESCE(json_extract(record_json,'$.paymentMode'),'Cash')='Credit' THEN MAX(0,COALESCE(json_extract(record_json,'$.total'),0)-MAX(COALESCE(json_extract(record_json,'$.partialPaymentAmount'),0),(SELECT COALESCE(SUM(COALESCE(json_extract(lp.record_json,'$.amount'),0)),0) FROM transaction_records lp WHERE lp.collection='pksCustomerPayments' AND COALESCE(json_extract(lp.record_json,'$.sourceBillNo'),'')=COALESCE(json_extract(transaction_records.record_json,'$.billNo'),'') AND (COALESCE(lp.shop_key,'')=? OR COALESCE(lp.shop_key,'')='')))) ELSE 0 END),0) FROM transaction_records WHERE collection='pksBills' AND lower(trim(COALESCE(json_extract(record_json,'$.customer'),'')))=lower(trim(?)) AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='')";
        try(Cursor c=db.rawQuery(billSql,new String[]{shopKey==null?"":shopKey,customer==null?"":customer,shopKey==null?"":shopKey})){if(c.moveToFirst())credit=c.getDouble(0);}
        String paySql="SELECT COALESCE(SUM(COALESCE(json_extract(record_json,'$.amount'),0)),0) FROM transaction_records WHERE collection='pksCustomerPayments' AND lower(trim(COALESCE(json_extract(record_json,'$.customer'),'')))=lower(trim(?)) AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='') AND COALESCE(json_extract(record_json,'$.sourceBillNo'),'')=''";
        try(Cursor c=db.rawQuery(paySql,new String[]{customer==null?"":customer,shopKey==null?"":shopKey})){if(c.moveToFirst())paid=c.getDouble(0);}
        JSONObject out=new JSONObject();out.put("supported",true);out.put("creditSales",credit);out.put("standalonePayments",paid);return out.toString();
    }

    // Customer-scoped bill history. Only matching rows cross the WebView bridge.
    public synchronized String loadCustomerBillsJson(String customer,String from,String to,String shopKey) throws Exception {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,"pksBills");db.setTransactionSuccessful();}finally{db.endTransaction();}
        String sql="SELECT record_json FROM transaction_records WHERE collection='pksBills' AND lower(trim(COALESCE(json_extract(record_json,'$.customer'),'')))=lower(trim(?)) AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='')";
        java.util.ArrayList<String> args=new java.util.ArrayList<>();args.add(customer==null?"":customer);args.add(shopKey==null?"":shopKey);
        if(from!=null&&!from.isEmpty()){sql+=" AND COALESCE(sort_date,'')>=?";args.add(from);}
        if(to!=null&&!to.isEmpty()){sql+=" AND COALESCE(sort_date,'')<=?";args.add(to+"\uffff");}
        sql+=" ORDER BY COALESCE(sort_date,''),rowid";
        JSONArray rows=new JSONArray();try(Cursor c=db.rawQuery(sql,args.toArray(new String[0]))){while(c.moveToNext())rows.put(new JSONObject(c.getString(0)));}
        return rows.toString();
    }

    // Bounded customer bill lookup used by the optional last-five-transactions invoice section.
    public synchronized String loadCustomerRecentBillsJson(String customer,String shopKey,int limit) throws Exception {
        if(limit<1)limit=5;if(limit>20)limit=20;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,"pksBills");db.setTransactionSuccessful();}finally{db.endTransaction();}
        JSONArray rows=new JSONArray();
        String sql="SELECT record_json FROM transaction_records WHERE collection='pksBills' AND lower(trim(COALESCE(json_extract(record_json,'$.customer'),'')))=lower(trim(?)) AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='') ORDER BY COALESCE(sort_date,'') DESC,rowid DESC LIMIT ?";
        try(Cursor c=db.rawQuery(sql,new String[]{customer==null?"":customer,shopKey==null?"":shopKey,String.valueOf(limit)})){while(c.moveToNext())rows.put(new JSONObject(c.getString(0)));}
        return rows.toString();
    }

    // Rename a customer on their bill records without loading the full bill history into WebView.
    public synchronized int renameCustomerBills(String oldName,String newName,String shopKey) throws Exception {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,"pksBills");
            // Use a bound SQL update so the JSON value is changed in-place; the record id remains stable.
            db.execSQL("UPDATE transaction_records SET record_json=json_set(record_json,'$.customer',?) WHERE collection='pksBills' AND lower(trim(COALESCE(json_extract(record_json,'$.customer'),'')))=lower(trim(?)) AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='')",new Object[]{newName==null?"":newName,oldName==null?"":oldName,shopKey==null?"":shopKey});
            try(Cursor c=db.rawQuery("SELECT changes()",null)){int count=c.moveToFirst()?c.getInt(0):0;db.setTransactionSuccessful();return count;}
        }finally{db.endTransaction();transactionJsonCache.remove("pksBills");}
    }

    // Bounded inventory history for the Inventory screen (latest first, normally 100 rows).
    public synchronized String loadRecentInventoryMovementsJson(String shopKey,int limit) throws Exception {
        if(limit<1)limit=100;if(limit>10000)limit=10000;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,"pksInventoryMovements");db.setTransactionSuccessful();}finally{db.endTransaction();}
        JSONArray rows=new JSONArray();
        try(Cursor c=db.rawQuery("SELECT record_json FROM transaction_records WHERE collection='pksInventoryMovements' AND shop_key=? AND COALESCE(json_extract(record_json,'$.reversed'),0)=0 ORDER BY COALESCE(sort_date,'') DESC,rowid DESC LIMIT ?",new String[]{shopKey,String.valueOf(limit)})){while(c.moveToNext())rows.put(new JSONObject(c.getString(0)));}
        return rows.toString();
    }

    // Date-scoped movement rows for the Inventory Movement Ledger report only.
    public synchronized String loadInventoryReportMovementsJson(String from,String to,String shopKey) throws Exception { return loadInventoryReportMovementsJson(from,to,shopKey,""); }
    public synchronized String loadInventoryReportMovementsJson(String from,String to,String shopKey,String productName) throws Exception {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,"pksInventoryMovements");db.setTransactionSuccessful();}finally{db.endTransaction();}
        JSONArray rows=new JSONArray();String shopClause="*".equals(shopKey)?"":" AND shop_key=?";
        String productClause=(productName==null||productName.trim().isEmpty())?"":" AND lower(COALESCE(json_extract(record_json,'$.productName'),''))=lower(?)";
        String sql="SELECT record_json FROM transaction_records WHERE collection='pksInventoryMovements' AND COALESCE(sort_date,'')>=? AND COALESCE(sort_date,'')<=? AND COALESCE(json_extract(record_json,'$.reversed'),0)=0"+shopClause+productClause+" ORDER BY COALESCE(sort_date,''),rowid";
        String[] args;if("*".equals(shopKey)){args=productClause.isEmpty()?new String[]{from,to+"\uffff"}:new String[]{from,to+"\uffff",productName};}else{args=productClause.isEmpty()?new String[]{from,to+"\uffff",shopKey}:new String[]{from,to+"\uffff",shopKey,productName};}
        try(Cursor c=db.rawQuery(sql,args)){while(c.moveToNext())rows.put(new JSONObject(c.getString(0)));}
        return rows.toString();
    }

    // Date- and shop-scoped report reads. Reports must not deserialize the complete
    // sales or inventory history on the WebView thread (large shops can have 100k+ movements).
    public synchronized String loadReportRecordsJson(String collection,String from,String to,String shopKey) throws Exception {
        if(!"pksBills".equals(collection) && !"pksInventoryMovements".equals(collection)) throw new IllegalArgumentException("Unsupported report collection");
        SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction(); try { migrateLegacyCollection(db,collection); db.setTransactionSuccessful(); } finally { db.endTransaction(); }
        String where="collection=? AND COALESCE(sort_date,'')>=? AND COALESCE(sort_date,'')<=? AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='')";
        JSONArray rows=new JSONArray();
        try(Cursor c=db.rawQuery("SELECT record_json FROM transaction_records WHERE "+where+" ORDER BY COALESCE(sort_date,'') DESC,rowid DESC",new String[]{collection,from, to+"\uffff",shopKey})) {
            while(c.moveToNext()) rows.put(new JSONObject(c.getString(0)));
        }
        JSONObject out=new JSONObject(); out.put("supported",true); out.put("records",rows); return out.toString();
    }

    public synchronized String loadLatestTaxBillDate(String shopKey) throws Exception {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { migrateLegacyCollection(db,"pksBills"); db.setTransactionSuccessful(); } finally { db.endTransaction(); }
        try(Cursor c=db.rawQuery("SELECT sort_date FROM transaction_records WHERE collection='pksBills' AND (COALESCE(shop_key,'')=? OR COALESCE(shop_key,'')='') AND COALESCE(json_extract(record_json,'$.taxationEnabled'),0)!=0 ORDER BY COALESCE(sort_date,'') DESC LIMIT 1",new String[]{shopKey})) {
            return c.moveToFirst()?c.getString(0):"";
        }
    }

    // Page sales history directly from SQLite. This keeps the WebView from loading
    // and sorting every historical bill merely to display the first 50 rows.
    public synchronized String loadSalesPageJson(int offset,int limit,String search) throws Exception { return loadSalesPageJson(offset,limit,search,"",""); }
    public synchronized String loadSalesPageJson(int offset,int limit,String search,String from,String to) throws Exception {
        if(offset<0)offset=0;if(limit<1)limit=50;if(limit>100)limit=100;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{migrateLegacyCollection(db,"pksBills");db.setTransactionSuccessful();}finally{db.endTransaction();}
        String q=search==null?"":search.trim().toLowerCase(java.util.Locale.ROOT);StringBuilder where=new StringBuilder("collection='pksBills'");java.util.ArrayList<String> bind=new java.util.ArrayList<>();
        if(!q.isEmpty()){where.append(" AND instr(lower(record_json),?)>0");bind.add(q);}if(from!=null&&!from.isEmpty()){where.append(" AND COALESCE(sort_date,'')>=?");bind.add(from);}if(to!=null&&!to.isEmpty()){where.append(" AND COALESCE(sort_date,'')<=?");bind.add(to+"\uffff");}
        String[] args=bind.toArray(new String[0]);long total=0;try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM transaction_records WHERE "+where,args)){if(c.moveToFirst())total=c.getLong(0);}
        JSONArray records=new JSONArray();String sql="SELECT record_json FROM transaction_records WHERE "+where+" ORDER BY COALESCE(sort_date,'') DESC,rowid DESC LIMIT ? OFFSET ?";String[] pageArgs=java.util.Arrays.copyOf(args,args.length+2);pageArgs[args.length]=String.valueOf(limit);pageArgs[args.length+1]=String.valueOf(offset);try(Cursor c=db.rawQuery(sql,pageArgs)){while(c.moveToNext())records.put(new JSONObject(c.getString(0)));}
        JSONObject out=new JSONObject();out.put("supported",true);out.put("total",total);out.put("records",records);return out.toString();
    }

    // Fetch only one vendor's purchases and payments for the selected date window.
    // This avoids materializing all 10,000+ purchase invoices and item arrays on the
    // WebView thread when a one-month Vendor Ledger PDF is requested.
    public synchronized String loadVendorLedgerDataJson(String vendorId, String vendorName, String from, String to, String shopKey) throws Exception {
        SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction();
        try { migrateLegacyCollection(db, "pksPurchases"); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); }
        JSONArray purchases=new JSONArray();
        String name=vendorName==null?"":vendorName.trim().replaceAll("\\s+"," ");
        String sql="SELECT record_json FROM transaction_records WHERE collection='pksPurchases' " +
            "AND (CAST(COALESCE(json_extract(record_json,'$.vendorId'),json_extract(record_json,'$.supplierId'),json_extract(record_json,'$.partyId'),'') AS TEXT)=? " +
            "OR LOWER(TRIM(COALESCE(json_extract(record_json,'$.vendorName'),json_extract(record_json,'$.supplierSnapshot.name'),json_extract(record_json,'$.vendor.name'),'')))=LOWER(?)) " +
            "AND substr(COALESCE(NULLIF(sort_date,''),json_extract(record_json,'$.invoiceDate'),''),1,10)>=? " +
            "AND substr(COALESCE(NULLIF(sort_date,''),json_extract(record_json,'$.invoiceDate'),''),1,10)<=? " +
            "AND (COALESCE(shop_key,'')='' OR LOWER(TRIM(shop_key))=LOWER(?)) " +
            "ORDER BY COALESCE(sort_date,'') ASC, record_id ASC";
        try(Cursor c=db.rawQuery(sql,new String[]{vendorId==null?"":vendorId,name,from==null?"":from,to==null?"":to,shopKey==null?"":shopKey.trim()})) {
            while(c.moveToNext()) purchases.put(new JSONObject(c.getString(0)));
        }
        JSONArray payments=new JSONArray();
        try(Cursor c=db.rawQuery("SELECT e.value FROM app_state s, json_each(s.state_value) e WHERE s.state_key='pksVendorPayments' AND (CAST(COALESCE(json_extract(e.value,'$.vendorId'),json_extract(e.value,'$.supplierId'),'') AS TEXT)=? OR LOWER(TRIM(COALESCE(json_extract(e.value,'$.vendorName'),'')))=LOWER(?)) AND substr(COALESCE(json_extract(e.value,'$.date'),''),1,10)>=? AND substr(COALESCE(json_extract(e.value,'$.date'),''),1,10)<=? AND (COALESCE(json_extract(e.value,'$.shopKey'),'')='' OR LOWER(TRIM(json_extract(e.value,'$.shopKey')))=LOWER(?)) ORDER BY COALESCE(json_extract(e.value,'$.date'),''), e.key",
                new String[]{vendorId==null?"":vendorId,name,from==null?"":from,to==null?"":to,shopKey==null?"":shopKey.trim()})) {
            while(c.moveToNext()) payments.put(new JSONObject(c.getString(0)));
        }
        JSONObject out=new JSONObject();out.put("supported",true);out.put("purchases",purchases);out.put("payments",payments);
        return out.toString();
    }

    // Vendor transaction history is deliberately compact: the ledger needs only
    // invoice/date/amount fields, not every purchase item's OCR and tax JSON blob.
    // Match older records that stored supplierId/partyId or only a supplier name.
    public synchronized String loadVendorPurchasesJson(String vendorId, String vendorName, String shopKey) throws Exception {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction(); try { migrateLegacyCollection(db, "pksPurchases"); db.setTransactionSuccessful(); } finally { db.endTransaction(); }
        JSONArray rows = new JSONArray();
        String sql = "SELECT json_extract(record_json,'$.id'), " +
                "COALESCE(json_extract(record_json,'$.vendorId'),json_extract(record_json,'$.supplierId'),json_extract(record_json,'$.partyId'),?), " +
                "COALESCE(json_extract(record_json,'$.vendorName'),json_extract(record_json,'$.supplierSnapshot.name'),json_extract(record_json,'$.vendor.name'),?), " +
                "COALESCE(json_extract(record_json,'$.invoiceNo'),json_extract(record_json,'$.billNo'),''), " +
                "COALESCE(NULLIF(sort_date,''),json_extract(record_json,'$.date'),json_extract(record_json,'$.invoiceDate'),''), " +
                "COALESCE(CAST(json_extract(record_json,'$.total') AS REAL),CAST(json_extract(record_json,'$.grandTotal') AS REAL),0), " +
                "COALESCE(CAST(json_extract(record_json,'$.paid') AS REAL),0), " +
                "COALESCE(json_extract(record_json,'$.paymentMode'),'Credit') " +
                "FROM transaction_records WHERE collection='pksPurchases' AND " +
                "(CAST(COALESCE(json_extract(record_json,'$.vendorId'),json_extract(record_json,'$.supplierId'),json_extract(record_json,'$.partyId'),'') AS TEXT)=? " +
                "OR LOWER(TRIM(COALESCE(json_extract(record_json,'$.vendorName'),json_extract(record_json,'$.supplierSnapshot.name'),json_extract(record_json,'$.vendor.name'),'')))=LOWER(TRIM(?))) " +
                "AND (COALESCE(shop_key,'')='' OR LOWER(TRIM(shop_key))=LOWER(TRIM(?))) " +
                "ORDER BY COALESCE(sort_date,'') DESC, rowid DESC";
        String id = vendorId == null ? "" : vendorId;
        String name = vendorName == null ? "" : vendorName;
        try (Cursor c = db.rawQuery(sql, new String[]{id, name, id, name, shopKey == null ? "" : shopKey})) {
            while (c.moveToNext()) {
                JSONObject row = new JSONObject();
                row.put("id", c.isNull(0) ? "" : c.getString(0));
                row.put("vendorId", c.isNull(1) ? id : c.getString(1));
                row.put("vendorName", c.isNull(2) ? name : c.getString(2));
                row.put("invoiceNo", c.getString(3)); row.put("date", c.getString(4));
                row.put("total", c.getDouble(5)); row.put("paid", c.getDouble(6));
                row.put("paymentMode", c.getString(7)); rows.put(row);
            }
        }
        return rows.toString();
    }

    private boolean isTransactionCollection(String collection) { return "pksBills".equals(collection) || "pksPurchases".equals(collection) || "pksInventoryMovements".equals(collection) || "pksCustomerPayments".equals(collection); }

    private String transactionId(String collection, JSONObject record) throws Exception {
        if ("pksBills".equals(collection)) {
            String no=record.optString("billNo", "");
            String shop=record.optString("shopKey", "");
            return shop + "|" + no;
        }
        String id=record.optString("id", "");
        if (id.isEmpty()) throw new IllegalArgumentException("Transaction record is missing id");
        return id;
    }

    private String readTransactionJson(SQLiteDatabase db,String collection) throws Exception {
        StringBuilder out=new StringBuilder("["); boolean first=true; int count=0;
        try(Cursor c=db.rawQuery("SELECT record_json FROM transaction_records WHERE collection=? ORDER BY COALESCE(sort_date,'') DESC, rowid DESC",new String[]{collection})) {
            while(c.moveToNext()) { if(!first)out.append(','); out.append(c.getString(0)); first=false; count++; }
        }
        if(count>0) return out.append(']').toString();
        try(Cursor c=db.rawQuery("SELECT state_value FROM app_state WHERE state_key=?",new String[]{collection})) { if(c.moveToFirst()) return c.getString(0); }
        return "[]";
    }

    private JSONArray readTransactionArray(SQLiteDatabase db, String collection) throws Exception {
        JSONArray out=new JSONArray();
        try (Cursor c=db.rawQuery("SELECT record_json FROM transaction_records WHERE collection=? ORDER BY COALESCE(sort_date,'') DESC, rowid DESC", new String[]{collection})) {
            while(c.moveToNext()) out.put(new JSONObject(c.getString(0)));
        }
        if(out.length()==0) {
            try(Cursor c=db.rawQuery("SELECT state_value FROM app_state WHERE state_key=?", new String[]{collection})) {
                if(c.moveToFirst()) { JSONArray legacy=new JSONArray(c.getString(0)); for(int i=0;i<legacy.length();i++) out.put(legacy.optJSONObject(i)); }
            }
        }
        return out;
    }

    private void migrateLegacyCollection(SQLiteDatabase db, String collection) throws Exception {
        String marker="transaction_migrated_"+collection;
        boolean marked=false;
        try(Cursor c=db.rawQuery("SELECT meta_value FROM meta WHERE meta_key=?",new String[]{marker})) {
            marked=c.moveToFirst() && "1".equals(c.getString(0));
        }
        // Restoring a legacy-compatible backup can reintroduce app_state JSON arrays
        // while retaining a migration marker from a newer database. In that case the
        // marker must not hide restored history: import/merge the legacy array again.
        boolean legacyPresent=false;
        try(Cursor c=db.rawQuery("SELECT 1 FROM app_state WHERE state_key=? LIMIT 1",new String[]{collection})) { legacyPresent=c.moveToFirst(); }
        if(marked && !legacyPresent) return;
        if(marked && legacyPresent) {
            // A current-format backup may intentionally contain both the normalized
            // transaction table and legacy compatibility arrays. The migration marker
            // proves the normalized rows were committed before backup creation; discard
            // only the redundant compatibility key instead of importing 100+ MB again.
            boolean normalizedRows=false;
            try(Cursor c=db.rawQuery("SELECT 1 FROM transaction_records WHERE collection=? LIMIT 1",new String[]{collection})) {
                normalizedRows=c.moveToFirst();
            }
            if(normalizedRows) {
                db.delete("app_state","state_key=?",new String[]{collection});
                return;
            }
        }
        // Let SQLite's JSON1 expand the legacy array in one set-based operation.
        // This avoids parsing and inserting thousands of records individually on
        // the WebView bridge thread during the first post-upgrade bill save.
        String idExpr = "pksBills".equals(collection)
                ? "COALESCE(json_extract(e.value,'$.shopKey'),'') || '|' || COALESCE(NULLIF(json_extract(e.value,'$.billNo'),''),e.key)"
                : "COALESCE(NULLIF(json_extract(e.value,'$.id'),''),e.key)";
        db.execSQL("INSERT OR REPLACE INTO transaction_records(collection,record_id,sort_date,source_type,source_id,shop_key,product_name,record_json) " +
                "SELECT ?, " + idExpr + ", COALESCE(json_extract(e.value,'$.date'),''), json_extract(e.value,'$.sourceType'), json_extract(e.value,'$.sourceId'), json_extract(e.value,'$.shopKey'), json_extract(e.value,'$.productName'), e.value " +
                "FROM app_state s, json_each(s.state_value) e WHERE s.state_key=?",
                new Object[]{collection, collection});
        db.delete("app_state", "state_key=?", new String[]{collection});
        ContentValues markerValue=new ContentValues(); markerValue.put("meta_key",marker); markerValue.put("meta_value","1");
        db.insertWithOnConflict("meta",null,markerValue,SQLiteDatabase.CONFLICT_REPLACE);
    }

    /**
     * Normalize legacy transaction arrays before opening the WebView screens.
     * Each collection commits independently so an interrupted migration can safely
     * resume on the next launch without losing already migrated collections.
     */
    /**
     * Assign pre-multi-firm rows with no tenant key to the original/default firm.
     * This is intentionally a one-way migration: blank tenant keys must never be
     * treated as belonging to whichever firm happens to be active later.
     */
    public synchronized int assignUnassignedRecordsToFirm(String firmKey) throws Exception {
        if (firmKey == null || firmKey.trim().isEmpty()) throw new IllegalArgumentException("Firm key is required");
        SQLiteDatabase db=getWritableDatabase(); int changed=0; db.beginTransaction();
        try {
            String key=firmKey.trim().toLowerCase(java.util.Locale.ROOT);
            ContentValues cv=new ContentValues(); cv.put("shop_key",key);
            // Bill record IDs include the tenant key. Re-key legacy blank-tenant
            // bills before updating their JSON so future edits replace, not duplicate, them.
            db.execSQL("DELETE FROM transaction_records WHERE collection='pksBills' AND record_id IN (SELECT ? || '|' || COALESCE(NULLIF(json_extract(record_json,'$.billNo'),''),record_id) FROM transaction_records WHERE collection='pksBills' AND COALESCE(shop_key,'')='')",new Object[]{key});
            db.execSQL("UPDATE transaction_records SET record_id=? || '|' || COALESCE(NULLIF(json_extract(record_json,'$.billNo'),''),record_id), shop_key=?, record_json=json_set(record_json,'$.shopKey',?) WHERE collection='pksBills' AND COALESCE(shop_key,'')=''",new Object[]{key,key,key});
            for(String collection:new String[]{"pksPurchases","pksInventoryMovements","pksCustomerPayments"}) {
                db.execSQL("UPDATE transaction_records SET shop_key=?, record_json=json_set(record_json,'$.shopKey',?) WHERE collection=? AND COALESCE(shop_key,'')=''",new Object[]{key,key,collection});
            }
            changed+=db.update("bank_accounts",cv,"COALESCE(shop_key,'')=''",null);
            changed+=db.update("bank_transactions",cv,"COALESCE(shop_key,'')=''",null);
            changed+=db.update("bank_reconciliations",cv,"COALESCE(shop_key,'')=''",null);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        return changed;
    }

    public synchronized void migrateLegacyCollections() throws Exception {
        SQLiteDatabase db=getWritableDatabase();
        for(String collection:new String[]{"pksBills","pksPurchases","pksInventoryMovements","pksCustomerPayments"}) {
            db.beginTransaction();
            try { migrateLegacyCollection(db,collection); db.setTransactionSuccessful(); }
            finally { db.endTransaction(); }
        }
    }

    private void upsertTransactionInDb(SQLiteDatabase db,String collection,JSONObject record) throws Exception {
        String id=transactionId(collection,record);
        ContentValues cv=new ContentValues(); cv.put("collection",collection); cv.put("record_id",id);
        cv.put("sort_date",record.optString("date", "")); cv.put("source_type",record.optString("sourceType", "")); cv.put("source_id",record.optString("sourceId", "")); cv.put("shop_key",record.optString("shopKey", "")); cv.put("product_name",record.optString("productName", "")); cv.put("record_json",record.toString());
        db.insertWithOnConflict("transaction_records",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }

    public synchronized void saveTransactionRecord(String collection,String json) throws Exception {
        if(!isTransactionCollection(collection)) throw new IllegalArgumentException("Unsupported transaction collection");
        JSONObject record=new JSONObject(json);
        // Enforce tenant identity at the persistence boundary. A bill without shopKey
        // would otherwise receive the legacy "|billNo" primary key and collide globally.
        if ("pksBills".equals(collection) && record.optString("shopKey", "").trim().isEmpty()) {
            throw new IllegalArgumentException("Bill is missing its active firm identity (shopKey). Refusing an unscoped save.");
        }
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { migrateLegacyCollection(db,collection); upsertTransactionInDb(db,collection,record); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); transactionJsonCache.remove(collection); }
    }

    public synchronized boolean deleteTransactionRecord(String collection,String recordId) throws Exception {
        if(!isTransactionCollection(collection)) throw new IllegalArgumentException("Unsupported transaction collection");
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction(); int deleted=0;
        try { migrateLegacyCollection(db,collection); deleted=db.delete("transaction_records","collection=? AND record_id=?",new String[]{collection,recordId}); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); transactionJsonCache.remove(collection); }
        return deleted>0;
    }

    public synchronized String replaceInventorySource(String sourceType,String sourceId,String shopKey,String newRowsJson) throws Exception {
        JSONArray rows=new JSONArray(newRowsJson==null?"[]":newRowsJson); SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try {
            migrateLegacyCollection(db,"pksInventoryMovements");
            java.util.LinkedHashSet<String> affected=new java.util.LinkedHashSet<>();
            try(Cursor c=db.rawQuery("SELECT DISTINCT product_name FROM transaction_records WHERE collection='pksInventoryMovements' AND source_type=? AND source_id=? AND shop_key=? AND COALESCE(json_extract(record_json,'$.reversed'),0)=0",new String[]{sourceType,sourceId,shopKey})) {
                while(c.moveToNext()) if(c.getString(0)!=null&&!c.getString(0).isEmpty()) affected.add(c.getString(0));
            }
            for(int i=0;i<rows.length();i++){JSONObject r=rows.optJSONObject(i);if(r!=null&&!r.optString("productName","").isEmpty())affected.add(r.optString("productName"));}
            String now=String.valueOf(System.currentTimeMillis());
            db.execSQL("UPDATE transaction_records SET record_json=json_set(record_json,'$.reversed',json('true'),'$.reversedAt',?) " +
                    "WHERE collection='pksInventoryMovements' AND source_type=? AND source_id=? AND shop_key=? AND COALESCE(json_extract(record_json,'$.reversed'),0)=0",
                    new Object[]{now,sourceType,sourceId,shopKey});
            // New rows are inserted after the reversal so the current source remains active.
            for(int i=0;i<rows.length();i++){JSONObject r=rows.optJSONObject(i);if(r!=null)upsertTransactionInDb(db,"pksInventoryMovements",r);}
            JSONArray summaries=new JSONArray();
            for(String product:affected){double qty=0,value=0;
                try(Cursor c=db.rawQuery("SELECT record_json FROM transaction_records WHERE collection='pksInventoryMovements' AND shop_key=? AND product_name=? AND COALESCE(json_extract(record_json,'$.reversed'),0)=0 ORDER BY COALESCE(sort_date,''), COALESCE(json_extract(record_json,'$.createdAt'),''), rowid",new String[]{shopKey,product})) {
                    while(c.moveToNext()){JSONObject m=new JSONObject(c.getString(0));double q=m.optDouble("qty",0),cost=Math.max(0,m.optDouble("unitCost",0));if(q>0){qty+=q;value+=q*cost;}else if(q<0){double avg=qty>0?value/qty:cost;qty+=q;value=Math.max(0,value+q*avg);}}
                }
                JSONObject summary=new JSONObject();summary.put("productName",product);summary.put("stockQty",Math.round(qty*1000000d)/1000000d);summary.put("averageCost",qty>0?Math.round(value/qty*1000000d)/1000000d:0);summaries.put(summary);
            }
            db.setTransactionSuccessful(); return summaries.toString();
        } finally { db.endTransaction(); transactionJsonCache.remove("pksInventoryMovements"); }
    }

    public synchronized void saveTransactionRecords(String collection,String jsonArray) throws Exception {
        if(!isTransactionCollection(collection)) throw new IllegalArgumentException("Unsupported transaction collection");
        JSONArray records=new JSONArray(jsonArray==null?"[]":jsonArray); SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { migrateLegacyCollection(db,collection); for(int i=0;i<records.length();i++){JSONObject r=records.optJSONObject(i);if(r!=null)upsertTransactionInDb(db,collection,r);} db.setTransactionSuccessful(); }
        finally { db.endTransaction(); transactionJsonCache.remove(collection); }
    }

    public synchronized void deleteTransactionRecords(String collection,String idsJson) throws Exception {
        if(!isTransactionCollection(collection)) throw new IllegalArgumentException("Unsupported transaction collection");
        JSONArray ids=new JSONArray(idsJson==null?"[]":idsJson); SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { migrateLegacyCollection(db,collection); for(int i=0;i<ids.length();i++) db.delete("transaction_records","collection=? AND record_id=?",new String[]{collection,ids.optString(i)}); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); transactionJsonCache.remove(collection); }
    }

    public synchronized void saveStateValue(String key, String value) throws Exception {
        if (key == null || key.trim().isEmpty()) throw new IllegalArgumentException("Invalid state key");
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("state_key", key);
        cv.put("state_value", value == null ? "" : value);
        db.insertWithOnConflict("app_state", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public synchronized void saveState(String json) throws Exception {
        JSONObject obj = new JSONObject(json == null ? "{}" : json);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                if ("pksBills".equals(key) || "pksPurchases".equals(key) || "pksInventoryMovements".equals(key)) {
                    JSONArray a = new JSONArray(obj.optString(key, "[]"));
                    db.delete("transaction_records", "collection=?", new String[]{key});
                    for (int i=0;i<a.length();i++) { JSONObject r=a.optJSONObject(i); if(r!=null) upsertTransactionInDb(db,key,r); }
                    db.delete("app_state", "state_key=?", new String[]{key});
                    ContentValues migrated=new ContentValues(); migrated.put("meta_key","transaction_migrated_"+key); migrated.put("meta_value","1"); db.insertWithOnConflict("meta",null,migrated,SQLiteDatabase.CONFLICT_REPLACE);
                    transactionJsonCache.remove(key);
                    continue;
                }
                ContentValues cv = new ContentValues();
                cv.put("state_key", key);
                cv.put("state_value", obj.optString(key, ""));
                db.insertWithOnConflict("app_state", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    private static JSONObject bankRow(Cursor c) throws Exception { JSONObject o=new JSONObject(); for(int i=0;i<c.getColumnCount();i++){String k=c.getColumnName(i); if(c.isNull(i))o.put(k,JSONObject.NULL); else if(c.getType(i)==Cursor.FIELD_TYPE_INTEGER)o.put(k,c.getLong(i)); else if(c.getType(i)==Cursor.FIELD_TYPE_FLOAT)o.put(k,c.getDouble(i)); else o.put(k,c.getString(i));} return o; }
    public synchronized String bankListAccounts(String shopKey) throws Exception { JSONArray a=new JSONArray(); try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM bank_accounts WHERE shop_key=? ORDER BY active DESC,account_name COLLATE NOCASE",new String[]{shopKey})){while(c.moveToNext())a.put(bankRow(c));} return a.toString(); }
    public synchronized String bankSaveAccount(String json) throws Exception { JSONObject o=new JSONObject(json); ContentValues v=new ContentValues(); String[] keys={"id","shop_key","account_name","bank_name","account_number","ifsc","branch","account_type","opening_date","notes","created_at","updated_at"}; for(String k:keys)if(o.has(k)&&!o.isNull(k))v.put(k,o.optString(k)); v.put("opening_balance",o.optDouble("opening_balance",0));v.put("active",o.optBoolean("active",true)?1:0); getWritableDatabase().insertWithOnConflict("bank_accounts",null,v,SQLiteDatabase.CONFLICT_REPLACE);return o.optString("id"); }
    public synchronized String bankSaveTransaction(String json) throws Exception { JSONObject o=new JSONObject(json);String id=o.optString("id");double amount=o.optDouble("amount",0);String type=o.optString("entry_type"); if(id.isEmpty()||amount<=0||(!"credit".equals(type)&&!"debit".equals(type)&&!"adjustment".equals(type)))throw new IllegalArgumentException("Invalid bank transaction"); ContentValues v=new ContentValues();v.put("id",id);v.put("shop_key",o.optString("shop_key"));v.put("account_id",o.optString("account_id"));v.put("txn_date",o.optString("txn_date"));v.put("entry_type",type);v.put("credit",o.optDouble("credit", "credit".equals(type)?amount:0));v.put("debit",o.optDouble("debit", "debit".equals(type)?amount:0));v.put("category",o.optString("category"));v.put("description",o.optString("description"));v.put("reference_no",o.optString("reference_no"));v.put("notes",o.optString("notes"));v.put("matched",o.optBoolean("matched",false)?1:0);v.put("created_at",o.optString("created_at"));getWritableDatabase().insertWithOnConflict("bank_transactions",null,v,SQLiteDatabase.CONFLICT_ABORT);return id; }
    public synchronized String bankListTransactions(String shopKey,String accountId,int offset,int limit,String from,String to) throws Exception { JSONArray a=new JSONArray();StringBuilder q=new StringBuilder("SELECT * FROM bank_transactions WHERE shop_key=?");java.util.ArrayList<String> args=new java.util.ArrayList<>();args.add(shopKey);if(accountId!=null&&!accountId.isEmpty()){q.append(" AND account_id=?");args.add(accountId);}if(from!=null&&!from.isEmpty()){q.append(" AND txn_date>=?");args.add(from);}if(to!=null&&!to.isEmpty()){q.append(" AND txn_date<=?");args.add(to);}q.append(" ORDER BY txn_date DESC, rowid DESC LIMIT ? OFFSET ?");args.add(String.valueOf(Math.max(1,Math.min(100,limit))));args.add(String.valueOf(Math.max(0,offset)));try(Cursor c=getReadableDatabase().rawQuery(q.toString(),args.toArray(new String[0]))){while(c.moveToNext())a.put(bankRow(c));}return a.toString(); }
    public synchronized String bankAccountSummary(String shopKey,String accountId,String toDate) throws Exception { JSONObject o=new JSONObject();SQLiteDatabase db=getReadableDatabase();double opening=0,credit=0,debit=0;String openingDate="0000-01-01";try(Cursor c=db.rawQuery("SELECT opening_balance,opening_date FROM bank_accounts WHERE shop_key=? AND id=?",new String[]{shopKey,accountId})){if(c.moveToFirst()){opening=c.getDouble(0);openingDate=c.getString(1);}}String cutoff=toDate==null||toDate.isEmpty()?"9999-12-31":toDate;if(cutoff.compareTo(openingDate)<0)opening=0;try(Cursor c=db.rawQuery("SELECT COALESCE(SUM(credit),0),COALESCE(SUM(debit),0) FROM bank_transactions WHERE shop_key=? AND account_id=? AND txn_date>=? AND txn_date<=?",new String[]{shopKey,accountId,openingDate,cutoff})){if(c.moveToFirst()){credit=c.getDouble(0);debit=c.getDouble(1);}}o.put("opening",opening);o.put("credit",credit);o.put("debit",debit);o.put("balance",opening+credit-debit);return o.toString(); }
    public synchronized String bankSaveReconciliation(String json) throws Exception {JSONObject o=new JSONObject(json);ContentValues v=new ContentValues();v.put("id",o.optString("id"));v.put("shop_key",o.optString("shop_key"));v.put("account_id",o.optString("account_id"));v.put("period",o.optString("period"));v.put("statement_opening",o.optDouble("statement_opening",0));v.put("statement_closing",o.optDouble("statement_closing",0));v.put("notes",o.optString("notes"));v.put("created_at",o.optString("created_at"));getWritableDatabase().insertWithOnConflict("bank_reconciliations",null,v,SQLiteDatabase.CONFLICT_REPLACE);return o.optString("id");}
    public synchronized String bankGetReconciliation(String shopKey,String accountId,String period) throws Exception {try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM bank_reconciliations WHERE shop_key=? AND account_id=? AND period=?",new String[]{shopKey,accountId,period})){return c.moveToFirst()?bankRow(c).toString():"{}";}}
    public synchronized boolean bankSetMatched(String shopKey,String txnId,boolean matched) {ContentValues v=new ContentValues();v.put("matched",matched?1:0);return getWritableDatabase().update("bank_transactions",v,"shop_key=? AND id=?",new String[]{shopKey,txnId})>0;}

}
