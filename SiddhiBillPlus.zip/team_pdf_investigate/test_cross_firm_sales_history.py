from pathlib import Path
import re
base=Path('app/src/main')
js=(base/'assets/www/app.js').read_text()
db=(base/'java/com/dukaanbill/app/LocalDatabase.java').read_text()
bridge=(base/'java/com/dukaanbill/app/MainActivity.java').read_text()
assert 'loadSalesHistoryPage?.(offset,limit,query||"",from||"",to||"",moduleShopKey())' in js
assert 'pageRows=pageRows.filter(b=>moduleRecordBelongsToCurrentShop(b));' in js
assert 'LOWER(TRIM(COALESCE(shop_key,\'\')))=LOWER(TRIM(?))' in db
assert 'loadSalesPageJson(offset,limit,search,from,to,shopKey)' in bridge
assert 'String shopKey){ try { return localDb.loadSalesPageJson(offset,limit,search,from,to,shopKey);' in bridge
assert 'r.querySelector(".view-bill").onclick=()=>{if(!moduleRecordBelongsToCurrentShop(b))' in js
print('PASS: native sales-history query is firm-scoped; result rows and view/edit/delete actions enforce active-firm ownership')
