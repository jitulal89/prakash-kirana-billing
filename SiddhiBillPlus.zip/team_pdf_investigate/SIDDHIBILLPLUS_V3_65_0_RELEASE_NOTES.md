# SiddhiBillPlus v3.65.0 — Multi-firm foundation

## Included
- Product/app identity updated to SiddhiBillPlus; Android application ID and Java namespace are unchanged.
- Local firm registry with a single active owner workspace, firm switcher, add firm, rename, activate/deactivate.
- Existing SiddhiBill data is adopted as the default/original firm; legacy unassigned SQLite transaction and banking rows are assigned to that firm before multi-firm controls are enabled.
- Firm-specific SQLite `app_state` keys for products, customers, vendors, team, brokers, expenses, estimates, GST configuration and firm settings.
- Firm-specific `shop_key` for sales, purchases, inventory movements, customer payments and banking records.
- Native transaction isolation by active firm when transaction collections are loaded.
- Export of the selected firm as a SiddhiBillPlus JSON backup and restore as a separate new firm.
- On-demand consolidated sales and purchase totals by active firm. This is a management summary, not a consolidated statutory report.
- Existing app lock/fingerprint flow remains the single local owner authentication; no cloud login or internet dependency is introduced.

## Data safety behavior
- Firm deactivation retains all data; destructive firm deletion is intentionally not offered.
- New firms start with empty master data, settings, billing history, inventory and banking.
- Existing database rows with empty tenant keys are assigned to the original firm. Legacy sales bill record IDs are re-keyed so editing a migrated bill updates the original row instead of creating a duplicate.
- If the native legacy-key migration returns an error, firm switching and creation are blocked to avoid exposing unassigned legacy rows to another firm.

## Scope notes
- The consolidated summary currently covers sales and purchase totals/counts only. Consolidated receivables/payables, cash/bank, inventory valuation, GST and profit-and-loss reports are not represented as complete consolidated financial statements.
- Restore is intentionally implemented as **Restore as New Firm**, avoiding destructive overwrite of an existing firm's records.
- Deactivation is provided instead of permanent firm deletion to protect historical records.
- This ZIP contains Android source and GitHub Actions build configuration; an APK was not built in this environment because a local Gradle executable/wrapper is not present. Run the repository's GitHub Actions workflow to build the APK.

## Version
- `versionCode`: 254
- `versionName`: 3.65.0
- Android application ID: `com.siddhibill.app` (preserved)
- Java namespace: `com.dukaanbill.app` (preserved)
- Database: `dukaanbill.db` (preserved)
