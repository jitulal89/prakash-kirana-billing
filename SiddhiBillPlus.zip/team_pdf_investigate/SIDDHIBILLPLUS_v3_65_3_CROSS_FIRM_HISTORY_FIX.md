# SiddhiBillPlus v3.65.3 — Cross-firm bill history isolation

## Confirmed root cause
The sales history screen uses the optimized native SQLite paging API (`loadSalesHistoryPage`). In v3.65.2, this API queried all rows in `pksBills` and did not accept or filter by the active firm's `shopKey`. Therefore the sales history screen displayed bills from every firm even though the general lazy state loader had a firm filter.

## Fix
- Added a firm-key parameter to the Android JavaScript bridge for sales-history paging.
- Added a firm-key overload to `LocalDatabase.loadSalesPageJson`.
- Applied exact normalized `shop_key` filtering in both the count query and page query, so pagination totals and rows are firm-specific.
- Updated the WebView to pass the active firm's `moduleShopKey()` to the native sales-history API.
- Added a second ownership filter before rendering any bill row.
- Added ownership checks to View, Edit and Delete actions.
- Preserved old Java overloads for compatibility with any other call sites; the updated app uses the new required firm-key overload.

## Validation
- JavaScript syntax and focused static regression assertions are included.
- ZIP integrity verified.
- Android APK compilation and real-device testing remain required; this environment does not have the Android Gradle build toolchain.

## Data safety
This is a read/display isolation fix for the native paginated Bill History path. It does not alter existing bill rows or attempt to split records that were previously saved under an incorrect firm key. Review historical records with a backup before making corrective data changes.
