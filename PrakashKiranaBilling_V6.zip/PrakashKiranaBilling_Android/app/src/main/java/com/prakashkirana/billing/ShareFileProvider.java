package com.prakashkirana.billing;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.File;

public class ShareFileProvider extends ContentProvider {
    @Override public boolean onCreate(){ return true; }
    private File resolve(Uri uri){
        File base=new File(getContext().getCacheDir(),"share");
        String name=uri.getLastPathSegment();
        if(name==null) return null;
        return new File(base,name);
    }
    @Override public String getType(Uri uri){
        String n=uri.getLastPathSegment();
        if(n!=null && n.toLowerCase().endsWith(".pdf")) return "application/pdf";
        return "image/png";
    }
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws java.io.FileNotFoundException{
        File f=resolve(uri); if(f==null||!f.exists()) throw new java.io.FileNotFoundException();
        return ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,String sortOrder){
        File f=resolve(uri); MatrixCursor c=new MatrixCursor(new String[]{"_display_name","_size"});
        if(f!=null&&f.exists()) c.addRow(new Object[]{f.getName(),f.length()}); return c;
    }
    @Override public int delete(Uri uri,String selection,String[] selectionArgs){ File f=resolve(uri); return f!=null&&f.delete()?1:0; }
    @Override public int update(Uri uri,ContentValues values,String selection,String[] selectionArgs){ return 0; }
    @Override public Uri insert(Uri uri,ContentValues values){ return null; }
}
